SELECT schemaname, relname, last_vacuum, last_autovacuum, vacuum_count, autovacuum_count
FROM pg_stat_user_tables;

SELECT n_tup_ins, n_tup_del FROM pg_stat_all_tables WHERE relname = 'mtx_sample';
SELECT pg_table_size('mtx_sample');
SELECT pg_indexes_size('mtx_sample');
SELECT pg_total_relation_size('mtx_sample');
SELECT pg_database_size('matrix');
