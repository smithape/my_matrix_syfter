/* Simple interface to libnetsnmp for twisted. Inspired by synchronous module
 * from snimpy (https://trac.luffy.cx/snimpy/)
 *
 * (c) Copyright 2008 Vincent Bernat <bernat@luffy.cx>
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
// https://vincent.bernat.ch/en/blog/2012-snmp-event-loop
#include <Python.h>
#include <stdbool.h>
#include <net-snmp/net-snmp-config.h>
#include <net-snmp/net-snmp-includes.h>
#include <net-snmp/library/large_fd_set.h>

/* Exceptions */
struct ErrorException {
	int error;
	char *name;
	PyObject *exception;
};
static PyObject *SnmpException;
static PyObject *SnmpNoSuchObject;
static PyObject *SnmpNoSuchInstance;
static PyObject *SnmpEndOfMibView;
static struct ErrorException SnmpErrorToException[] = {
	{ SNMP_ERR_TOOBIG, "SNMPTooBig" },
	{ SNMP_ERR_NOSUCHNAME, "SNMPNoSuchName" },
	{ SNMP_ERR_BADVALUE, "SNMPBadValue" },
	{ SNMP_ERR_READONLY,  "SNMPReadonly" },
	{ SNMP_ERR_GENERR, "SNMPGenerr" },
	{ SNMP_ERR_NOACCESS, "SNMPNoAccess" },
	{ SNMP_ERR_WRONGTYPE, "SNMPWrongType" },
	{ SNMP_ERR_WRONGLENGTH, "SNMPWrongLength" },
	{ SNMP_ERR_WRONGENCODING, "SNMPWrongEncoding" },
	{ SNMP_ERR_WRONGVALUE, "SNMPWrongValue" },
	{ SNMP_ERR_NOCREATION, "SNMPNoCreation" },
	{ SNMP_ERR_INCONSISTENTVALUE, "SNMPInconsistentValue" },
	{ SNMP_ERR_RESOURCEUNAVAILABLE, "SNMPResourceUnavailable" },
	{ SNMP_ERR_COMMITFAILED, "SNMPCommitFailed" },
	{ SNMP_ERR_UNDOFAILED, "SNMPUndoFailed" },
	{ SNMP_ERR_AUTHORIZATIONERROR, "SNMPAuthorizationError" },
	{ SNMP_ERR_NOTWRITABLE, "SNMPNotWritable" },
	{ SNMP_ERR_INCONSISTENTNAME, "SNMPInconsistentName" },
	{ -1, NULL },
};

static PyObject *DeferModule;
static PyObject *FailureModule;
static PyObject *reactor;
static PyObject *SnmpFds;
static PyObject *timeoutId;
static PyObject *timeoutFunction;

/* Types */
typedef struct {
	PyObject_HEAD
	struct snmp_session *ss;
	PyObject *defers;
} SnmpObject;

typedef struct {
	PyObject_HEAD
	int fd;
} SnmpReaderObject;
static PyTypeObject SnmpReaderType;

static int
Snmp_updatereactor(void)
{
	int maxfd = 0, block = 0, fd, result, i;
	PyObject *keys, *key, *tmp;
	SnmpReaderObject *reader;
	netsnmp_large_fd_set fdset;
	struct timeval timeout;
	double to;

        // levy: init fdset
        netsnmp_large_fd_set_init(&fdset, FD_SETSIZE);
        NETSNMP_LARGE_FD_ZERO(&fdset);
	block = 1;
	snmp_select_info2(&maxfd, &fdset, &timeout, &block);
	for (fd = 0; fd < maxfd; fd++) {
		if (NETSNMP_LARGE_FD_ISSET(fd, &fdset)) {
			result = PyDict_Contains(SnmpFds, PyLong_FromLong(fd));
			if (result == -1)
				return -1;
			if (!result) {
				/* Add this fd to the reactor */
				if ((reader = (SnmpReaderObject *)
					PyObject_CallObject((PyObject *)&SnmpReaderType,
					    NULL)) == NULL)
					return -1;
				reader->fd = fd;
				if ((key =
					PyLong_FromLong(fd)) == NULL) {
					Py_DECREF(reader);
					return -1;
				}
				if (PyDict_SetItem(SnmpFds, key, (PyObject*)reader) != 0) {
					Py_DECREF(reader);
					Py_DECREF(key);
					return -1;
				}
				Py_DECREF(key);
				if ((tmp = PyObject_CallMethod(reactor,
					    "addReader", "O", (PyObject*)reader)) ==
				    NULL) {
					Py_DECREF(reader);
					return -1;
				}
				Py_DECREF(tmp);
				Py_DECREF(reader);
			}
		}
	}
	if ((keys = PyDict_Keys(SnmpFds)) == NULL)
		return -1;
	for (i = 0; i < PyList_Size(keys); i++) {
		if ((key = PyList_GetItem(keys, i)) == NULL) {
			Py_DECREF(keys);
			return -1;
		}
		fd = PyLong_AsLong(key);
		if (PyErr_Occurred()) {
			Py_DECREF(keys);
			return -1;
		}
		if ((fd >= maxfd) || (!NETSNMP_LARGE_FD_ISSET(fd, &fdset))) {
			/* Delete this fd from the reactor */
			if ((reader = (SnmpReaderObject*)PyDict_GetItem(SnmpFds,
				    key)) == NULL) {
				Py_DECREF(keys);
				return -1;
			}
			if ((tmp = PyObject_CallMethod(reactor,
				    "removeReader", "O", (PyObject*)reader)) == NULL) {
				Py_DECREF(keys);
				return -1;
			}
			Py_DECREF(tmp);
			if (PyDict_DelItem(SnmpFds, key) == -1) {
				Py_DECREF(keys);
				return -1;
			}
		}
	}
	Py_DECREF(keys);
	/* Setup timeout */
	if (timeoutId) {
		if ((tmp = PyObject_CallMethod(timeoutId, "cancel", NULL)) == NULL) {
			/* Don't really know what to do. It seems better to
			 * raise an exception at this point. */
			Py_CLEAR(timeoutId);
			return -1;
		}
		Py_DECREF(tmp);
		Py_CLEAR(timeoutId);
	}
	if (!block) {
            to = (double)timeout.tv_sec +
                (double)timeout.tv_usec/(double)1000000;
            if ((timeoutId = PyObject_CallMethod(reactor, "callLater", "dO",
                                                 to, timeoutFunction)) == NULL) {
                return -1;
            }
	}
	return 0;
}

static void
Snmp_dealloc(SnmpObject* self)
{
	if (self->ss)
		snmp_close(self->ss);
	Snmp_updatereactor();
	Py_XDECREF(self->defers);
	Py_TYPE(self)->tp_free((PyObject*)self);
}

static PyObject *
Snmp_new(PyTypeObject *type, PyObject *args, PyObject *kwds)
{
	SnmpObject *self;

	self = (SnmpObject *)type->tp_alloc(type, 0);
	if (self != NULL) {
		self->ss = NULL;
		self->defers = NULL;
	}
	return (PyObject *)self;
}

static void
Snmp_raise_error(struct snmp_session *session)
{
	int liberr, snmperr;
	char *err;
	snmp_error(session, &liberr, &snmperr, &err);
	PyErr_Format(SnmpException, "%s", err);
	free(err);
}

static int
Snmp_init(SnmpObject *self, PyObject *args, PyObject *kwds)
{
	struct snmp_session session;
        int version = 2;
        PyObject *py_peer=NULL;
        char *peer;
        int  retries;
        int  timeout;
        /* v1-2 */
        PyObject *py_community=NULL;
        char *community;
        /* v3 */
        PyObject *py_sec_name=NULL;
        char *sec_name;
        int sec_level = 1;
        PyObject *py_auth_proto=NULL;
        char *auth_proto;
        PyObject *py_auth_pass=NULL;
        char *auth_pass;
        PyObject *py_priv_proto=NULL;
        char *priv_proto;
        PyObject *py_priv_pass=NULL;
        char *priv_pass;


        static char *kwlist[] = {"ip", "version", "retries", "timeout",
                                 // v1-2
                                 "community",
                                 // v3
                                 "sec_name", "sec_level", "auth_proto", "auth_pass",
                                 "priv_proto", "priv_pass",
                                 NULL};

        if (!PyArg_ParseTupleAndKeywords(args, kwds, "O|iiiOOiOOOO", kwlist,
                                         &py_peer, &version, &retries, &timeout,
                                         &py_community, &py_sec_name, &sec_level,
                                         &py_auth_proto, &py_auth_pass,
                                         &py_priv_proto, &py_priv_pass))
            return -1;

	snmp_sess_init(&session);

        // convert peer string
        if ((peer = PyBytes_AsString(py_peer)) == NULL)
            return -1;

	switch (version) {
	case 1:
		session.version = SNMP_VERSION_1;
		break;
	case 2:
		session.version = SNMP_VERSION_2c;
		break;
	case 3:
		session.version = SNMP_VERSION_3;
		break;
	default:
		PyErr_Format(PyExc_ValueError, "invalid SNMP version: %d",
		    version);
		return -1;
	}

        // set session vars
        session.peername = peer;
        session.retries = retries; /* 5 */
        session.timeout = timeout; /* 1000000L */
        session.authenticator = NULL;

        if (version == 3) {
            // convert strings
            if ((sec_name = PyBytes_AsString(py_sec_name)) == NULL)
		return -1;
            if ((auth_proto = PyBytes_AsString(py_auth_proto)) == NULL)
		return -1;
            if ((auth_pass = PyBytes_AsString(py_auth_pass)) == NULL)
		return -1;
            if ((priv_proto = PyBytes_AsString(py_priv_proto)) == NULL)
		return -1;
            if ((priv_pass = PyBytes_AsString(py_priv_pass)) == NULL)
		return -1;

            session.securityLevel = sec_level;
            session.securityModel = USM_SEC_MODEL_NUMBER;

            // sec_name
            session.securityNameLen = strlen(sec_name);
            session.securityName = sec_name;

            // auth
            if (!strcmp(auth_proto, "MD5")) {
                session.securityAuthProto =
                    snmp_duplicate_objid(usmHMACMD5AuthProtocol,
                                         USM_AUTH_PROTO_MD5_LEN);
                session.securityAuthProtoLen = USM_AUTH_PROTO_MD5_LEN;
            } else if (!strcmp(auth_proto, "SHA")) {
                session.securityAuthProto =
                    snmp_duplicate_objid(usmHMACSHA1AuthProtocol,
                                         USM_AUTH_PROTO_SHA_LEN);
                session.securityAuthProtoLen = USM_AUTH_PROTO_SHA_LEN;
            } else {
                const oid* a = get_default_authtype(&session.securityAuthProtoLen);
                session.securityAuthProto
                    = snmp_duplicate_objid(a, session.securityAuthProtoLen);
            }
            if (session.securityLevel >= SNMP_SEC_LEVEL_AUTHNOPRIV) {
                if (strlen(auth_pass) > 0) {
                    session.securityAuthKeyLen = USM_AUTH_KU_LEN;
                    if (generate_Ku(session.securityAuthProto,
                                    session.securityAuthProtoLen,
                                    (u_char *)auth_pass, strlen(auth_pass),
                                    session.securityAuthKey,
                                    &session.securityAuthKeyLen) != SNMPERR_SUCCESS) {
                        // exception
                        PyErr_Format(PyExc_ValueError, "invalid SNMP auth config: %s/%s",
                            auth_proto, auth_pass);
                    }
                }
            }

            // priv
            if (!strcmp(priv_proto, "DES")) {
                session.securityPrivProto =
                    snmp_duplicate_objid(usmDESPrivProtocol,
                                         USM_PRIV_PROTO_DES_LEN);
                session.securityPrivProtoLen = USM_PRIV_PROTO_DES_LEN;
            } else if (!strncmp(priv_proto, "AES", 3)) {
                session.securityPrivProto =
                    snmp_duplicate_objid(usmAESPrivProtocol,
                                         USM_PRIV_PROTO_AES_LEN);
                session.securityPrivProtoLen = USM_PRIV_PROTO_AES_LEN;
            } else {
                const oid *p = get_default_privtype(&session.securityPrivProtoLen);
                session.securityPrivProto
                    = snmp_duplicate_objid(p, session.securityPrivProtoLen);
            }

            if (session.securityLevel >= SNMP_SEC_LEVEL_AUTHPRIV) {
                session.securityPrivKeyLen = USM_PRIV_KU_LEN;
                if (generate_Ku(session.securityAuthProto,
                                session.securityAuthProtoLen,
                                (u_char *)priv_pass, strlen(priv_pass),
                                session.securityPrivKey,
                                &session.securityPrivKeyLen) != SNMPERR_SUCCESS) {
                    // exception
                    PyErr_Format(PyExc_ValueError, "invalid SNMP priv config: %s/%s",
                                 priv_proto, priv_pass);
                }
            }
        } else {
            /*
             * v1-2
             */
            // convert community string
            if ((community = PyBytes_AsString(py_community)) == NULL)
		return -1;
            session.community_len = strlen(community);
            session.community = (u_char *)community;
        }

        // open the session
	if ((self->ss = snmp_open(&session)) == NULL) {
		Snmp_raise_error(&session);
		free(session.community);
		free(session.peername);
		return -1;
	}
	if ((self->defers = PyDict_New()) == NULL)
		return -1;
	if (Snmp_updatereactor() == -1)
		return -1;

	return 0;
}

static PyObject*
Snmp_repr(SnmpObject *self)
{
    return PyUnicode_FromFormat("%s(host=%s, community=%s, version=%d)",
                                Py_TYPE(self)->tp_name,
                                self->ss->peername,
                                self->ss->community,
                                (self->ss->version == SNMP_VERSION_1)?1:2);
}

static PyObject*
Snmp_oid2string(PyObject *resultvalue)
{
    PyObject *dot, *tmp, *tmp2, *list;
    int i;
    // create a tuple of the right size for the oid
    if ((list = PyTuple_New(PyTuple_Size(resultvalue))) == NULL)
        return NULL;
    // fill the tuple with the oid numbers
    for (i = 0; i < PyTuple_Size(resultvalue); i++) {
        if ((tmp = PyTuple_GetItem(resultvalue, i)) == NULL) {
            Py_DECREF(list);
            return NULL;
        }
        // convert the int to a string
        if ((tmp2 = PyObject_Str(tmp)) == NULL) {
            Py_DECREF(list);
            return NULL;
        }
        // set the tuple item
        PyTuple_SetItem(list, i, tmp2);
        if (PyErr_Occurred()) {
            Py_DECREF(tmp2);
            Py_DECREF(list);
            return NULL;
        }
    }
    Py_DECREF(resultvalue);
    resultvalue = list;

    // get a unicode version of '.'
    if ((dot = PyUnicode_FromString(".")) == NULL)
        return NULL;
    // join the tuple using the '.'
    if ((tmp = PyObject_CallMethod(dot,
                                   "join", "(O)", resultvalue)) == NULL) {
        Py_DECREF(dot);
        return NULL;
    }
    Py_DECREF(resultvalue);
    Py_DECREF(dot);
    resultvalue = tmp;
    // put the result in a tuple
    if ((tmp = PyTuple_Pack(1, resultvalue)) == NULL)
        return NULL;
    Py_DECREF(resultvalue);
    resultvalue = tmp;
    // get a unicode version of ".%s"
    if ((tmp2 = PyUnicode_FromString(".%s")) == NULL)
        return NULL;
    // add a period to the beggining of the oid
    if ((tmp = PyUnicode_Format(tmp2,
                                resultvalue)) == NULL) {
        Py_DECREF(tmp2);
        return NULL;
    }
    Py_DECREF(tmp2);
    Py_DECREF(resultvalue);
    return tmp;
}

static void
Snmp_invokeerrback(PyObject *defer)
{
	PyObject *type, *value, *traceback, *failure, *tmp;

	PyErr_Fetch(&type, &value, &traceback);
        if (!traceback)
                failure = PyObject_CallMethod(FailureModule,
		    "Failure", "OO", value, type);
	else
                failure = PyObject_CallMethod(FailureModule,
		    "Failure", "OOO", value, type, traceback);
	if (failure != NULL) {
		if ((tmp = PyObject_GetAttrString(defer, "errback")) != NULL) {
			Py_DECREF(PyObject_CallMethod(reactor, "callLater",
				"iOO", 0, tmp, failure));
			Py_DECREF(tmp);
		}
		Py_DECREF(failure);
	}
	Py_XDECREF(type);
	Py_XDECREF(value);
	Py_XDECREF(traceback);
}

static int
Snmp_handle(int operation, netsnmp_session *session, int reqid,
    netsnmp_pdu *response, void *magic)
{
	PyObject *key, *defer, *results = NULL, *resultvalue = NULL,
	    *resultoid = NULL, *tmp;
	PyObject *resulttype = PyUnicode_FromString("");
	struct ErrorException *e;
	struct variable_list *vars;
	int i, nb;
	long long counter64;
	SnmpObject *self;

	if ((key = PyLong_FromLong(reqid)) == NULL)
		/* Unknown session, don't know what to do... */
		return 1;
	self = (SnmpObject *)magic;
	if ((defer = PyDict_GetItem(self->defers, key)) == NULL)
		return 1;
	Py_INCREF(defer);
	PyDict_DelItem(self->defers, key);
	Py_DECREF(key);
	/* We have our deferred object. We will be able to trigger callbacks and
	 * errbacks */
	if (operation == NETSNMP_CALLBACK_OP_RECEIVED_MESSAGE) {
		if (response->errstat != SNMP_ERR_NOERROR) {
			for (e = SnmpErrorToException; e->name; e++) {
				if (e->error == response->errstat) {
					PyErr_SetString(e->exception, snmp_errstring(e->error));
					goto fireexception;
				}
			}
			PyErr_Format(SnmpException, "unknown error %ld", response->errstat);
			goto fireexception;
		}
	} else {
		PyErr_SetString(SnmpException, "Timeout");
		goto fireexception;
	}
	if ((results = PyDict_New()) == NULL)
		goto fireexception;
	nb = 0;
	for (vars = response->variables; vars; vars = vars->next_variable) nb++;
	for (vars = response->variables; vars;
	     vars = vars->next_variable) {
	/* Let's handle the value */
		switch (vars->type) {
		case SNMP_NOSUCHOBJECT:
			if (nb == 1) {
				PyErr_SetString(SnmpNoSuchObject, "No such object was found");
				goto fireexception;
			}
			Py_INCREF(Py_None);
			resultvalue = Py_None;
			break;
		case SNMP_NOSUCHINSTANCE:
			if (nb == 1) {
				PyErr_SetString(SnmpNoSuchInstance, "No such instance exists");
				goto fireexception;
			}
			Py_INCREF(Py_None);
			resultvalue = Py_None;
			break;
		case SNMP_ENDOFMIBVIEW:
			if (PyDict_Size(results) == 0) {
				PyErr_SetString(SnmpEndOfMibView,
				    "End of MIB was reached");
				goto fireexception;
			} else {
                            resultvalue = PyLong_FromLong(true);
                            resultoid = PyUnicode_FromString("ENDOFMIBVIEW");
                            /* Put into dictionary */
                            PyDict_SetItem(results, resultoid, resultvalue);
                            Py_CLEAR(resultoid);
                            Py_CLEAR(resultvalue);
                            continue;
                        }
		case ASN_INTEGER:
			resultvalue = PyLong_FromLong(*vars->val.integer);
                        resulttype = PyUnicode_FromString("Integer");
			break;
		case ASN_UINTEGER:
			resultvalue = PyLong_FromUnsignedLong(
				(unsigned long)*vars->val.integer);
                        resulttype = PyUnicode_FromString("Integer");
			break;
		case ASN_TIMETICKS:
			resultvalue = PyLong_FromUnsignedLong(
				(unsigned long)*vars->val.integer);
                        resulttype = PyUnicode_FromString("TimeTicks");
			break;
		case ASN_GAUGE:
			resultvalue = PyLong_FromUnsignedLong(
				(unsigned long)*vars->val.integer);
                        resulttype = PyUnicode_FromString("Gauge");
			break;
		case ASN_COUNTER:
			resultvalue = PyLong_FromUnsignedLong(
				(unsigned long)*vars->val.integer);
                        resulttype = PyUnicode_FromString("Counter");
			break;
		case ASN_OCTET_STR:
			resultvalue = PyBytes_FromStringAndSize(
				(char*)vars->val.string, vars->val_len);
                        resulttype = PyUnicode_FromString("String");
			break;
		case ASN_BIT_STR:
			resultvalue = PyBytes_FromStringAndSize(
				(char*)vars->val.bitstring, vars->val_len);
                        resulttype = PyUnicode_FromString("String");
			break;
		case ASN_OBJECT_ID:
			if ((resultvalue = PyTuple_New(
					vars->val_len/sizeof(oid))) == NULL)
				goto fireexception;
			for (i = 0; i < vars->val_len/sizeof(oid); i++) {
				if ((tmp = PyLong_FromLong(
						vars->val.objid[i])) == NULL)
					goto fireexception;
				PyTuple_SetItem(resultvalue, i, tmp);
			}
			if ((resultvalue = Snmp_oid2string(resultvalue)) == NULL)
				goto fireexception;
			break;
		case ASN_IPADDRESS:
			if (vars->val_len < 4) {
				PyErr_Format(SnmpException, "IP address is too short (%zd < 4)",
				    vars->val_len);
				goto fireexception;
			}
			resultvalue = PyBytes_FromFormat("%d.%d.%d.%d",
			    vars->val.string[0],
			    vars->val.string[1],
			    vars->val.string[2],
			    vars->val.string[3]);
                        resulttype = PyUnicode_FromString("IP Address");
			break;
		case ASN_COUNTER64:
#ifdef NETSNMP_WITH_OPAQUE_SPECIAL_TYPES
		case ASN_OPAQUE_U64:
		case ASN_OPAQUE_I64:
		case ASN_OPAQUE_COUNTER64:
#endif                          /* NETSNMP_WITH_OPAQUE_SPECIAL_TYPES */
			counter64 = ((unsigned long long)(vars->val.counter64->high) << 32) +
			    (unsigned long long)(vars->val.counter64->low);
			resultvalue = PyLong_FromUnsignedLongLong(counter64);
			break;
#ifdef NETSNMP_WITH_OPAQUE_SPECIAL_TYPES
		case ASN_OPAQUE_FLOAT:
			resultvalue = PyFloat_FromDouble(*vars->val.floatVal);
			break;
		case ASN_OPAQUE_DOUBLE:
			resultvalue = PyFloat_FromDouble(*vars->val.doubleVal);
			break;
#endif                          /* NETSNMP_WITH_OPAQUE_SPECIAL_TYPES */
		default:
			PyErr_Format(SnmpException, "unknown type returned (%d)",
			    vars->type);
			goto fireexception;
		}
		if (resultvalue == NULL) goto fireexception;

		/* And now, the OID */
                if ((resultoid = PyTuple_New(vars->name_length)) == NULL)
                    goto fireexception;
                for (i = 0; i < vars->name_length; i++) {
                    if ((tmp = PyLong_FromLong(vars->name[i])) == NULL)
                        goto fireexception;
                    PyTuple_SetItem(resultoid, i, tmp);
                }
                if ((resultoid = Snmp_oid2string(resultoid)) == NULL)
                    goto fireexception;

                /* package the result and type into a tuple */
                resultvalue = PyTuple_Pack(2, resultvalue, resulttype);

		/* Put into dictionary */
		PyDict_SetItem(results, resultoid, resultvalue);
		Py_CLEAR(resultoid);
		Py_CLEAR(resultvalue);
	}
	if ((tmp = PyObject_GetAttrString(defer, "callback")) == NULL)
		goto fireexception;
	Py_DECREF(PyObject_CallMethod(reactor, "callLater", "iOO", 0, tmp, results));
	Py_DECREF(tmp);
	Py_DECREF(results);
	Py_DECREF(defer);
	Py_DECREF(self);
	return 1;

fireexception:
	Snmp_invokeerrback(defer);
	Py_XDECREF(results);
	Py_XDECREF(resultvalue);
	Py_XDECREF(resultoid);
	Py_DECREF(defer);
	Py_DECREF(self);
	return 1;
}

static PyObject*
Snmp_op(SnmpObject *self, PyObject *args, int op)
{
	PyObject *roid, *oids, *item, *deferred = NULL, *req = NULL,
		*rwvalue, *wvalues = NULL, *setobject;
	char *aoid, *next;
	oid poid[MAX_OID_LEN];
	struct snmp_pdu *pdu=NULL;
	int maxrepetitions = 10, norepeaters = 0;
	int i, oidlen, reqid, type;
	size_t arglen;
	u_char *buffer;
	long long_ret;
	ssize_t bufsize;

	if (op == SNMP_MSG_GETBULK) {
		if (!PyArg_ParseTuple(args, "O|ii",
			&roid, &maxrepetitions, &norepeaters))
			return NULL;
	} else if (op == SNMP_MSG_SET) {
		if (!PyArg_ParseTuple(args, "OO", &roid, &rwvalue))
			return NULL;
	} else {
		if (!PyArg_ParseTuple(args, "O", &roid))
			return NULL;
	}

	/* Turn the first argument into a tuple */
	if (!PyTuple_Check(roid) && !PyList_Check(roid) && !PyBytes_Check(roid)) {
		PyErr_SetString(PyExc_TypeError,
		    "argument should be a string, a list or a tuple");
		return NULL;
	}
	if (PyBytes_Check(roid)) {
		if ((oids = PyTuple_Pack(1, roid)) == NULL)
			return NULL;
	} else if (PyList_Check(roid)) {
		if ((oids = PyList_AsTuple(roid)) == NULL)
			return NULL;
	} else {
		oids = roid;
		Py_INCREF(oids);
	}

	/* For SET, the second argument is the list of values to set */
	if (op == SNMP_MSG_SET) {
		if (!PyTuple_Check(rwvalue) && !PyList_Check(rwvalue) && \
		    !PyBytes_Check(rwvalue) && !PyLong_Check(rwvalue)) {
			PyErr_SetString(PyExc_TypeError,
					"second argument should be long, bytearray, "
					"list or tuple");
			Py_DECREF(oids);
			return NULL;
		}
		if (PyBytes_Check(rwvalue) || PyLong_Check(rwvalue)) {
			if ((wvalues = PyTuple_Pack(1, rwvalue)) == NULL) {
				Py_DECREF(oids);
				return NULL;
			}
		} else if (PyList_Check(rwvalue)) {
			if ((wvalues = PyList_AsTuple(rwvalue)) == NULL) {
				Py_DECREF(oids);
				return NULL;
			}
		} else {
			wvalues = rwvalue;
			Py_INCREF(wvalues);
		}
		if (PyTuple_Size(oids) != PyTuple_Size(wvalues)) {
			PyErr_SetString(PyExc_ValueError,
					"first and second arguments must be of "
					"the same size");
			Py_DECREF(wvalues);
			Py_DECREF(oids);
			return NULL;
		}
	}

	Py_INCREF(self);
	arglen = PyTuple_Size(oids);
	pdu = snmp_pdu_create(op);
	if (op == SNMP_MSG_GETBULK) {
		pdu->max_repetitions = maxrepetitions;
		pdu->non_repeaters = norepeaters;
	}
	for (i = 0; i < arglen; i++) {
		if ((item = PyTuple_GetItem(oids, i)) == NULL)
			goto operror;
		if (!PyBytes_Check(item)) {
			PyErr_Format(PyExc_TypeError,
			    "element %d should be a bytearray", i);
			goto operror;
		}
		aoid = PyBytes_AsString(item);
		oidlen = 0;
		while (aoid && (*aoid != '\0')) {
			if (aoid[0] == '.')
				aoid++;
			if (oidlen >= MAX_OID_LEN) {
				PyErr_Format(PyExc_ValueError,
				    "element %d is too large for OID", i);
				goto operror;
			}
			poid[oidlen++] = strtoull(aoid, &next, 10);
			if (aoid == next) {
				PyErr_Format(PyExc_TypeError,
				    "element %d is not a valid OID: %s", i, aoid);
				goto operror;
			}
			aoid = next;
		}
		if (op == SNMP_MSG_SET) {
			if ((setobject = PyTuple_GetItem(wvalues, i)) == NULL)
				goto operror;
			if (!PyLong_Check(setobject) && \
			    !PyBytes_Check(setobject)) {
				PyErr_Format(PyExc_TypeError,
				    "element %d shoud be int or str", i);
				goto operror;
			}
			/* Copy in buffer */
			if (PyLong_Check(setobject)) {
				type = ASN_INTEGER;
				if ((long_ret = PyLong_AsLong(setobject)) == -1)
					goto operror;
				buffer = (u_char*)&long_ret;
				bufsize = sizeof(long_ret);
			} else {
				type = ASN_OCTET_STR;
				if ((buffer = (u_char*)
					PyBytes_AsString(setobject)) == NULL)
					goto operror;
				bufsize = PyBytes_Size(setobject) + 1;
			}
			snmp_pdu_add_variable(pdu, poid, oidlen,
			    type, buffer, bufsize);
		} else {
			snmp_add_null_var(pdu, poid, oidlen);
		}
	}
	self->ss->callback = Snmp_handle;
	self->ss->callback_magic = self;
	if ((deferred = PyObject_CallMethod(DeferModule,
		    "Deferred", NULL)) == NULL)
		goto operror;
	if (!snmp_send(self->ss, pdu)) {
		Snmp_raise_error(self->ss);
		/* Instead of raising, we will fire errback */
		Snmp_invokeerrback(deferred);
		Py_DECREF(self);
		Py_DECREF(oids);
		if (op == SNMP_MSG_SET) {
			Py_DECREF(wvalues);
		}
		snmp_free_pdu(pdu);
		return deferred;
	}
	reqid = pdu->reqid;
	pdu = NULL;		/* Avoid to free it when future errors occurs */

	/* We create a Deferred object and put it in a dictionary using
	 * pdu->reqid to be able to call its callbacks later. */
	if ((req = PyLong_FromLong(reqid)) == NULL)
		goto operror;
	if (PyDict_SetItem(self->defers, req, deferred) != 0) {
		Py_DECREF(req);
		goto operror;
	}
	Py_DECREF(req);
	if (Snmp_updatereactor() == -1)
		goto operror;
	if (op == SNMP_MSG_SET) {
		Py_DECREF(wvalues);
	}
	Py_DECREF(oids);
	return deferred;

operror:
	Py_XDECREF(deferred);
	Py_DECREF(self);
	if (op == SNMP_MSG_SET) {
		Py_DECREF(wvalues);
	}
	Py_DECREF(oids);
	snmp_free_pdu(pdu);
	return NULL;
}

static PyObject*
Snmp_get(PyObject *self, PyObject *args)
{
	return Snmp_op((SnmpObject*)self, args, SNMP_MSG_GET);
}

static PyObject*
Snmp_getnext(PyObject *self, PyObject *args)
{
	return Snmp_op((SnmpObject*)self, args, SNMP_MSG_GETNEXT);
}

static PyObject*
Snmp_getbulk(PyObject *self, PyObject *args)
{
	return Snmp_op((SnmpObject*)self, args, SNMP_MSG_GETBULK);
}

static PyObject*
Snmp_set(PyObject *self, PyObject *args)
{
	return Snmp_op((SnmpObject*)self, args, SNMP_MSG_SET);
}

static PyObject*
Snmp_getip(SnmpObject *self, void *closure)
{
	return PyBytes_FromString(self->ss->peername);
}

static PyObject*
Snmp_getcommunity(SnmpObject *self, void *closure)
{
	return PyBytes_FromStringAndSize((char*)self->ss->community,
	    self->ss->community_len);
}

static int
Snmp_setcommunity(SnmpObject *self, PyObject *value, void *closure)
{
	char *newcommunity;
	ssize_t size;

	if (value == NULL) {
		PyErr_SetString(PyExc_TypeError, "cannot delete community");
		return -1;
	}
	if (!PyBytes_Check(value)) {
		PyErr_SetString(PyExc_TypeError, 
                    "community should be a string");
		return -1;
	}

	if (PyBytes_AsStringAndSize(value, &newcommunity, &size) == -1)
		return -1;

	free(self->ss->community);
	self->ss->community = (u_char*)strdup(newcommunity);
	self->ss->community_len = size;
	return 0;
}

static PyObject*
Snmp_getversion(SnmpObject *self, void *closure)
{
	switch (self->ss->version) {
	case SNMP_VERSION_1:
		return PyLong_FromLong(1);
	case SNMP_VERSION_2c:
		return PyLong_FromLong(2);
	}
	PyErr_Format(SnmpException, "Unkown SNMP version: %ld",
	    self->ss->version);
	return NULL;
}

static int
Snmp_setversion(SnmpObject *self, PyObject *value, void *closure)
{
	int version;

	if (value == NULL) {
		PyErr_SetString(PyExc_TypeError, "cannot delete version");
		return -1;
	}
	if (!PyLong_Check(value)) {
		PyErr_SetString(PyExc_TypeError,
                    "version should be 1 or 2");
		return -1;
	}

	version = PyLong_AsLong(value);
	if (PyErr_Occurred())
		return -1;
	switch (version) {
	case 1:
		self->ss->version = SNMP_VERSION_1;
		break;
	case 2:
		self->ss->version = SNMP_VERSION_2c;
		break;
	default:
		PyErr_Format(PyExc_ValueError, "version should be 1 or 2, not %d",
		    version);
		return -1;
	}
	return 0;
}

static PyObject*
SnmpReader_repr(SnmpReaderObject *self)
{
	return PyBytes_FromFormat("<SnmpReader fd:%d>", self->fd);
}

static PyObject*
SnmpReader_doRead(SnmpReaderObject *self)
{
	netsnmp_large_fd_set fdset;
        // levy: init fdset
        netsnmp_large_fd_set_init(&fdset, FD_SETSIZE);
	NETSNMP_LARGE_FD_ZERO(&fdset);
	NETSNMP_LARGE_FD_SET(self->fd, &fdset);
	snmp_read2(&fdset);
	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject*
SnmpReader_fileno(SnmpReaderObject *self)
{
	return PyLong_FromLong(self->fd);
}

static PyObject*
SnmpReader_connectionLost(PyObject *self, PyObject *args)
{
	PyObject *fd;
	if ((fd = PyLong_FromLong(((SnmpReaderObject*)self)->fd)) == NULL)
		return NULL;
	if (PyDict_DelItem(SnmpFds, fd) == -1) {
		Py_DECREF(fd);
		return NULL;
	}
	Py_DECREF(fd);
	Py_INCREF(Py_None);
	return Py_None;
}

static PyObject*
SnmpReader_logPrefix(SnmpReaderObject *self)
{
	return PyBytes_FromString("SnmpReader");
}

static PyObject*
SnmpModule_timeout(PyObject *self)
{
	Py_CLEAR(timeoutId);
	snmp_timeout();
	if (Snmp_updatereactor() == -1)
		return NULL;
	Py_INCREF(Py_None);
	return Py_None;
}

static PyMethodDef SnmpModule_methods[] = {
	{"timeout", (PyCFunction)SnmpModule_timeout,
	 METH_NOARGS, "Handle SNMP timeout"},
	{NULL}
};

static PyMethodDef Snmp_methods[] = {
	{"get", Snmp_get,
	 METH_VARARGS, "Retrieve an OID value using GET"},
	{"getnext", Snmp_getnext,
	 METH_VARARGS, "Retrieve an OID value using GETNEXT"},
	{"getbulk", Snmp_getbulk,
	 METH_VARARGS, "Retrieve an OID value using GETBULK"},
	{"set", Snmp_set,
	 METH_VARARGS, "Set an OID value using SET"},
	{NULL}  /* Sentinel */
};

static PyGetSetDef Snmp_getseters[] = {
    {"ip", (getter)Snmp_getip, NULL, "ip", NULL},
    {"community",
     (getter)Snmp_getcommunity, (setter)Snmp_setcommunity,
     "community", NULL},
    {"version",
     (getter)Snmp_getversion, (setter)Snmp_setversion,
     "version", NULL},
    {NULL}  /* Sentinel */
};


static PyMethodDef SnmpReader_methods[] = {
	{"doRead", (PyCFunction)SnmpReader_doRead,
	 METH_NOARGS, "some data available for reading"},
	{"fileno", (PyCFunction)SnmpReader_fileno,
	 METH_NOARGS, "get file descriptor"},
	{"connectionLost", SnmpReader_connectionLost,
	 METH_VARARGS, "call when connection is lost"},
	{"logPrefix", (PyCFunction)SnmpReader_logPrefix,
	 METH_NOARGS, "log prefix"},
	{NULL}  /* Sentinel */
};

static PyTypeObject SnmpType = {
        PyVarObject_HEAD_INIT(NULL, 0)
	"snmp.Session",	           /*tp_name*/
	sizeof(SnmpObject),	   /*tp_basicsize*/
	0,                         /*tp_itemsize*/
	(destructor)Snmp_dealloc,  /*tp_dealloc*/
	0,                         /*tp_print*/
	0,                         /*tp_getattr*/
	0,                         /*tp_setattr*/
	0,                         /*tp_compare*/
	(reprfunc)Snmp_repr,	   /*tp_repr*/
	0,                         /*tp_as_number*/
	0,                         /*tp_as_sequence*/
	0,                         /*tp_as_mapping*/
	0,                         /*tp_hash */
	0,                         /*tp_call*/
	0,			   /*tp_str*/
	0,                         /*tp_getattro*/
	0,                         /*tp_setattro*/
	0,                         /*tp_as_buffer*/
	Py_TPFLAGS_DEFAULT |
	Py_TPFLAGS_BASETYPE,	   /*tp_flags*/
	"SNMP session",            /*tp_doc*/
	0,			   /* tp_traverse */
	0,			   /* tp_clear */
	0,			   /* tp_richcompare */
	0,			   /* tp_weaklistoffset */
	0,			   /* tp_iter */
	0,			   /* tp_iternext */
	Snmp_methods,		   /* tp_methods */
	0,			   /* tp_members */
	Snmp_getseters,		   /* tp_getset */
	0,                         /* tp_base */
	0,                         /* tp_dict */
	0,                         /* tp_descr_get */
	0,                         /* tp_descr_set */
	0,                         /* tp_dictoffset */
	(initproc)Snmp_init,	   /* tp_init */
	0,                         /* tp_alloc */
	Snmp_new,		   /* tp_new */
};

static PyTypeObject SnmpReaderType = {
        PyVarObject_HEAD_INIT(NULL, 0)
	"snmp.SnmpReader",	   /*tp_name*/
	sizeof(SnmpReaderObject),  /*tp_basicsize*/
	0,                         /*tp_itemsize*/
	0,			   /*tp_dealloc*/
	0,                         /*tp_print*/
	0,                         /*tp_getattr*/
	0,                         /*tp_setattr*/
	0,                         /*tp_compare*/
	(reprfunc)SnmpReader_repr, /*tp_repr*/
	0,                         /*tp_as_number*/
	0,                         /*tp_as_sequence*/
	0,                         /*tp_as_mapping*/
	0,                         /*tp_hash */
	0,                         /*tp_call*/
	0,			   /*tp_str*/
	0,                         /*tp_getattro*/
	0,                         /*tp_setattro*/
	0,                         /*tp_as_buffer*/
	Py_TPFLAGS_DEFAULT |
	Py_TPFLAGS_BASETYPE,	   /*tp_flags*/
	"SNMP reader object",	   /*tp_doc*/
	0,			   /* tp_traverse */
	0,			   /* tp_clear */
	0,			   /* tp_richcompare */
	0,			   /* tp_weaklistoffset */
	0,			   /* tp_iter */
	0,			   /* tp_iternext */
	SnmpReader_methods,	   /* tp_methods */
};

PyDoc_STRVAR(module_doc,
    "simple interface for twisted to libnetsnmp");

static struct PyModuleDef moduledef = {
    PyModuleDef_HEAD_INIT,
    "snmp",              /* m_name */
    module_doc,          /* m_doc */
    -1,                  /* m_size */
    SnmpModule_methods,  /* m_methods */
    NULL,                /* m_reload */
    NULL,                /* m_traverse */
    NULL,                /* m_clear */
    NULL,                /* m_free */
};

PyMODINIT_FUNC PyInit_snmp(void)
{
    PyObject *m, *exc;
    char *name;
    struct ErrorException *e;
    netsnmp_log_handler *logh;

    if (PyType_Ready(&SnmpType) < 0) return NULL;
    SnmpReaderType.tp_new = PyType_GenericNew;
    if (PyType_Ready(&SnmpReaderType) < 0) return NULL;

    m = PyModule_Create(&moduledef);
    if (m == NULL)
        return NULL;

    /* Exception registration */
#define ADDEXCEPTION(var, name, parent)                         \
    if (var == NULL) {						\
        var = PyErr_NewException("snmp." name, parent, NULL);	\
        if (var == NULL)                                        \
            return NULL;					\
    }								\
    Py_INCREF(var);                                             \
    PyModule_AddObject(m, name, var)
    ADDEXCEPTION(SnmpException, "SNMPException", NULL);
    ADDEXCEPTION(SnmpNoSuchObject, "SNMPNoSuchObject", SnmpException);
    ADDEXCEPTION(SnmpNoSuchInstance, "SNMPNoSuchInstance", SnmpException);
    ADDEXCEPTION(SnmpEndOfMibView, "SNMPEndOfMibView", SnmpException);
    for (e = SnmpErrorToException; e->name; e++) {
        if (!e->exception) {
            if (asprintf(&name, "snmp.%s", e->name) == -1) {
                PyErr_NoMemory();
                return NULL;
            }
            exc = PyErr_NewException(name, SnmpException, NULL);
            free(name);
            if (exc == NULL) return NULL;
            e->exception = exc;
        }
        Py_INCREF(e->exception);
        PyModule_AddObject(m, e->name, e->exception);
    }

    Py_INCREF(&SnmpType);
    PyModule_AddObject(m, "Session", (PyObject *)&SnmpType);

    if (DeferModule == NULL)
        if ((DeferModule =
             PyImport_ImportModule("twisted.internet.defer")) == NULL)
            return NULL;
    if (FailureModule == NULL)
        if ((FailureModule =
             PyImport_ImportModule("twisted.python.failure")) == NULL)
            return NULL;
    if (reactor == NULL)
        if ((reactor =
             PyImport_ImportModule("twisted.internet.reactor")) == NULL)
            return NULL;
    if (SnmpFds == NULL)
        if ((SnmpFds = PyDict_New()) == NULL)
            return NULL;
    if (timeoutFunction == NULL)
        //if ((timeoutFunction = Py_FindMethod(SnmpModule_methods, m, "timeout")) == NULL)
        if ((timeoutFunction = PyObject_GenericGetAttr(m, PyUnicode_FromString("timeout"))) == NULL)
            return NULL;

    /* Try to load as less MIB as possible */
    unsetenv("MIBS");
    setenv("MIBDIRS", "/dev/null", 1);
    /* Disable any logging */
    snmp_disable_log();
    logh = netsnmp_register_loghandler(NETSNMP_LOGHANDLER_NONE, LOG_DEBUG);

    /* Init SNMP */
    init_snmp("snmp");

    return m;
}
