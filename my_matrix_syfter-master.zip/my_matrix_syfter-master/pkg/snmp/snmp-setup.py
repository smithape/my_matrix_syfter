from distutils.core import setup, Extension

setup(name="snmp",
      version="1.0",
      ext_modules=[
          Extension(
              "snmp",
              libraries = ['netsnmp'],
              sources =["snmp.c"]
          )
      ]
  )
