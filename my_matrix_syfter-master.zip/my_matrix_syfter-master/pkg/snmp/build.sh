python snmp-setup.py build
cp build/lib.linux-*/snmp.*.so snmp.so
rm -rf build/
