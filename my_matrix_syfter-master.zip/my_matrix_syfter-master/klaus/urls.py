# -*- coding: utf-8 -*-
from django.urls import path, re_path

from . import views

app_name = 'klaus'

# TODO: These regexps are probably not going to cover all the cases
repo = r'(?P<repo>[\w\.\-_]+)'
rev = r'(?P<rev>[\w\.\-_]+)'
path = r'(?P<path>.+)'


urlpatterns = [
    re_path('^$',
         views.repo_list, name=views.RepoListView.view_name),

    re_path(r'^' + repo + '/$',
            views.history, name=views.HistoryView.view_name),

    re_path(r'^' + repo + '/tree/' + rev + '/$',
            views.history, name=views.HistoryView.view_name),
    re_path(r'^' + repo + '/tree/' + rev + '/' + path + '/$',
            views.history, name=views.HistoryView.view_name),

    re_path(r'^' + repo + '/blob/' + rev + '/$',
            views.blob, name=views.BlobView.view_name),
    re_path(r'^' + repo + '/blob/' + rev + '/' + path + '/$',
            views.blob, name=views.BlobView.view_name),

    re_path(r'^' + repo + '/raw/' + rev + '/$',
            views.raw, name=views.RawView.view_name),
    re_path(r'^' + repo + '/raw/' + rev + '/' + path + '/$',
            views.raw, name=views.RawView.view_name),

    re_path(r'^' + repo + '/commit/' + rev + '/$',
            views.commit, name=views.CommitView.view_name),
    re_path(r'^' + repo + '/commit/' + rev + '/' + path + '/$',
            views.commit, name=views.CommitView.view_name)
]
