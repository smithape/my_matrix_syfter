from django.apps import AppConfig


class KlausConfig(AppConfig):
    name = 'klaus'
