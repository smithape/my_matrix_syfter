import os
import sys
import time
from datetime import datetime
import traceback
from subprocess import getstatusoutput
from threading import Thread
from django.contrib.sessions.models import Session

import psutil
from common.PeriodicThread import PeriodicThread
from common import \
    utility, \
    config as cfg, \
    logger as log, \
    License as lic, \
    DB

class MonitorDaemon():
    def __init__(self):
        self.stdin_path = '/dev/null'
        self.stdout_path = '/dev/tty'
        self.stderr_path = '/dev/tty'
        self.pidfile_path =  cfg.get_pidfile('monitor')
        self.pidfile_timeout = 1
        self.interrupt = False


    def run(self):
        self.monitor = Monitor()
        try:
            self.monitor.start();
            while not self.interrupt:
                msg = self.monitor.sub.get_message(timeout=1)
                if msg:
                    self.process_message(msg)
        except Exception as e:
            print(traceback.format_exc())
        finally:
            try:
                self.monitor.stop()
            except:
                log.debug("exception in monitor shutdown")
                log.debug(traceback.format_exc())
            finally:
                # hacky way to make sure we die
                getstatusoutput('pkill -9 -f "python\s.*%s\s*start"'
                                % sys.argv[0])

    def terminate(self, signal_number, stack_frame):
        self.interrupt = True

    def process_message (self, msg):
        if msg['type'] == 'message':
            if msg['channel'] == b'syfter.control':
                command = msg['data'].decode()
                (code, result) = getstatusoutput('%s %s' % (cfg.tool_name, command))

class Monitor(object):

    def __init__ (self):
        # init the db manager
        DB.init()

        # init the redis consumer
        self.sub = None

        # Initialize the timestamp dictionary. This dictionary is used for
        # periodic monitor/maintenance functions and stores the last runtime
        # for the various functions. An initial value of 0 means the function
        # hasn't been run yet
        now = int(time.time())
        self.tstamp_d = {
            # start 5 minutes after the hour
            'start': utility.epoch_to_hour(now - 300) + 300,
            'maintenance': 0,
            }


    def start (self):
        """ start the service """
        # subscribe to data
        self.sub = DB.redis.pubsub(ignore_subscribe_messages=True)
        self.sub.subscribe('%s.control' % cfg.tool_name)

        # Start the monitor thread
        self.monitor_t = PeriodicThread(name="monitor",
                                        interval=3600,
                                        action=self.monitor,
                                        daemon=True)
        # start 5 minutes after the hour
        start_time = self.tstamp_d['start'] + 3600
        self.monitor_t.start(start_time)

    def stop (self):
        """ stop the service """

        # stop the monitor thread
        if self.monitor_t:
            self.monitor_t.stop()

    def monitor (self):
        now = int(time.time())
        day = utility.epoch_to_day(now)
        local_hour = datetime.now().hour

        # memory check
        check_memory()

        # nightly DB maintenance
        prev_day = utility.epoch_to_day(self.tstamp_d['maintenance'])
        if (local_hour == cfg.maintenance_hour and day != prev_day):
            self.tstamp_d['maintenance'] = now

            #
            # config tracking
            Thread(target=track_config).start()

            #
            # Database Maintenance
            Thread(target=DB.db.maintenance).start()

            #
            # License Checkin
            if cfg.license_required:

                # contact the license server
                chk = lic.check_key()
                valid = lic.is_licensed()

                if chk is None and valid:
                    # we can't connect, but we're in the hold time
                    utility.send_email("Cannot Access License Server", message="The license will expire after the hold time.")
                elif not chk:
                    if chk is False:
                        # the license is invalid
                        utility.send_email("License Invalid", message="The polling engine will shut down.")
                    else:
                        # server is unreachable
                        utility.send_email("License Server Unreachable",
                                           message="The hold time has expired, and The polling engine will shut down.")

                    # end all web sessions
                    Session.objects.all().delete()
                    # shut down the poller
                    (code, result) = getstatusoutput('syfter poller stop' % cfg.tool_name)
                else:
                    # send license warning?
                    ret = lic.get_license_info()
                    if ret['exp_date']:
                        exp_timestamp = utility.date_str_to_secs(ret['exp_date'])
                        diff_secs = exp_timestamp - time.time()
                        diff_days = round(diff_secs / 86400, 1)
                        if diff_days < 7:
                            utility.send_email("License will expire in %s days" % diff_days)

def track_config ():
    now = int(time.time())
    # pull configs
    for device_name,device in cfg.devices().items():
        if device.get("track_config") == True and hasattr(device, "track_cfg"):
            device.track_cfg()

    git_cmd = "git --git-dir={0}/.git --work-tree={0}/".format(cfg.config_tracker_dir)

    # get the full diff
    command = "%s --no-pager diff" % git_cmd
    (code, diff) = getstatusoutput(command)
    if diff:
        diff = '<PRE style="font-size:medium">' + diff + '</PRE>'
        utility.send_email("Config change", message=diff)

    # get the changed files
    command = "%s diff --name-only" % git_cmd
    (code, response) = getstatusoutput(command)
    filename_l = response.split()
    for filename in filename_l:
        command = "%s --no-pager diff %s%s" % (git_cmd, cfg.config_tracker_dir, filename)
        (code, diff) = getstatusoutput(command)
        device_name = filename.split('.')[0]
        query = {
            'name' : "diff_insert",
            'options' : {
                "diff_data": (now, device_name, diff)
            }
        }
        utility.db_query(query)

    # commit changes
    command = "%s add --all" % git_cmd
    (code, result) = getstatusoutput(command)
    command = "%s commit -m %s" % (git_cmd, time.strftime("%Y-%m-%d"))
    (code, result) = getstatusoutput(command)

def check_memory ():
    mem = psutil.virtual_memory()
    if mem.percent > cfg.mem_usage_threshold:
        # prepare the alert subject
        subject = "Memory utilization high! (%s%%)" % mem.percent
        # prepare the alert message body
        GB = 1073741824
        text = ("Usage:\t%s%%\n" % mem.percent
                +"Total:\t%s GB\n" % round(mem.total / GB, 1)
                +"Used:\t%s GB\n" % round((mem.total - mem.available) / GB, 1)
                +'Free:\t%s GB\n' % round(mem.available / GB, 1))
        text = '<PRE style="font-size:medium">' + text + '</PRE>'
        # send the email
        utility.send_email(subject, message=text)
