#!/bin/bash

# add the symlink
DIR=$( cd "$( dirname $BASH_SOURCE )" && pwd )
ln -sf $DIR/syfter.sh /usr/local/bin/syfter

docker-compose build --build-arg http_proxy=$http_proxy --build-arg https_proxy=$https_proxy syfter
docker-compose run syfter bash -c './install/init_db.sh && ./install/create_users.py'
docker-compose down
