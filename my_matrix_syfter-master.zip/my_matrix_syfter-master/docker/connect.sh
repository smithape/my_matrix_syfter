#!/bin/bash
docker exec -it docker_syfter_1 /bin/bash 2> /dev/null
if [ $? -ne 0 ]; then
    docker-compose run syfter /bin/bash
fi

