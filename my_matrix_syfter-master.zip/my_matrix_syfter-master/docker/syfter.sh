#!/bin/bash
docker exec docker_syfter_1 syfter "$@"

