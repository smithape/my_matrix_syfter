#!/bin/bash
docker-compose up -d
docker exec docker_syfter_1 bash -c 'chmod 755 run && chown 0:0 run'
