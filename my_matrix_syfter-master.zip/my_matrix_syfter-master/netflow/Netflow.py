import os
import sys
import time
import json, csv
import binascii
from datetime import datetime
import traceback
from threading import Thread
import subprocess
from django.contrib.sessions.models import Session
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler


from common.PeriodicThread import PeriodicThread
from common import \
    utility, \
    config as cfg, \
    logger as log, \
    License as lic, \
    DB

class NetflowDaemon():
    def __init__(self):
        self.stdin_path = '/dev/null'
        self.stdout_path = '/dev/tty'
        self.stderr_path = '/dev/tty'
        self.pidfile_path =  cfg.get_pidfile('netflow')
        self.pidfile_timeout = 1
        self.interrupt = False

        # make the dir
        if not os.path.exists(cfg.netflow_dir):
            os.makedirs(cfg.netflow_dir)


    def run(self):
        watcher = NFWatcher()
        observer = Observer()
        observer.schedule(watcher, cfg.netflow_dir)
        try:
            observer.start()
            self.generate_nfacctd_config()
            self.start_nfacctd()
            while not self.interrupt:
                time.sleep(1)
        except Exception as e:
            print(traceback.format_exc())
        finally:
            try:
                observer.stop()
                self.stop_nfacctd()
            except:
                log.debug("exception in netflow shutdown")
                log.debug(traceback.format_exc())

    def terminate(self, signal_number, stack_frame):
        self.interrupt = True

    def start_nfacctd (self):
        command = 'nfacctd -f /tmp/nfacctd.conf'
        subprocess.call(command.split())

    def stop_nfacctd (self):
        command = 'pkill nfacctd'
        subprocess.call(command.split())

    def generate_nfacctd_config (self):
        output_format = "json"
        buffer_size = 8192

        map_l = ["app_map"]
        field_d = {
            "app_name": "app_id",
            "dns_dn": "",
            "http_url": "http_host, http_url",
            "http_host": "",
            "http_uagent": "",
            "http_ref": "",
            "ssl_cn": "",
            "src_host": "src_host, app_id"
        }

        text = (
            "daemonize: true\n"
            "logfile: /storage/netflow.log\n"
            "nfacctd_port: %s\n" % cfg.netflow_port +
            "nfacctd_time_new: true\n"
            "nfacctd_account_options: true\n"
            "aggregate_primitives: %s/primitives.lst\n" % cfg.netflow_config_dir +
            "pre_tag_map: %s/pretag.map\n" % cfg.netflow_config_dir +
            "\n"
            "plugins: %s\n" % ', '.join([("print[%s]" % x) for x in field_d.keys() + map_l])
        )

        for field, prim in field_d.items():
            prim = prim or field
            text += (
                "\n"
                "aggregate[{0}]: peer_src_ip, flows, {1}\n"
                "pre_tag_filter[{0}]: 100\n"
                "print_refresh_time[{0}]: {2}\n"
                "print_history[{0}]: {2}\n"
                "print_history_roundoff[{0}]: m\n"
                "print_output[{0}]: {3}\n"
                "print_output_file[{0}]: {4}/{0}.data\n"
                "plugin_buffer_size[{0}]: {5}\n"
                .format(field, prim, cfg.netflow_period, output_format, cfg.netflow_dir, buffer_size))


        text += (
            "\n"
            "aggregate[app_map]: app_id, app_name\n"
            "pre_tag_filter[app_map]: 200\n"
            "print_refresh_time[app_map]: 30\n"
            "print_output[app_map]: {0}\n"
            "print_output_file[app_map]: {1}/app.map\n"
            .format(output_format, cfg.netflow_dir))


        with open("/tmp/nfacctd.conf", 'w') as f:
            f.write(text)

class NFWatcher(FileSystemEventHandler):
    def __init__ (self):
        self.app_map = {}
        self.tstamp_d = {}

    def on_any_event(self, e):
        now = int(time.time())

        if (not e.is_directory
            and e.event_type in ['modified', 'created']
            and (e.src_path not in self.tstamp_d or
                 now - self.tstamp_d[e.src_path] > (cfg.netflow_period // 2))):

            # remember the event time
            self.tstamp_d[e.src_path] = now

            data = []
            filename = os.path.basename(e.src_path)

            with open (e.src_path, "r") as f:
                for row in f:
                    data.append(json.loads(row))

            if not data:
                return

            if filename == "app.map":
                self.app_map_handler(data)
            else:
                field = filename.split('.')[0]
                self.data_handler(field, data)

    def get_app_map (self):
        data = []
        with open (app_map_file, "r") as f:
            for row in f:
                data.append(json.loads(row))

        self.app_map_handler(data)

    def app_map_handler (self, data):
        for row in data:
            self.app_map[row['app_id']] = row['app_name']

    def data_handler (self, field, data):
        for row in data:
            self.decode(field, row)

        data = [x for x in data if x[field]]

        now = int(time.time())
        # timestamp with the beginning of the period
        timestamp = int(round(now/cfg.netflow_period) * cfg.netflow_period - cfg.netflow_period)

        if data:
            query = {
                'name' : 'nf_insert',
                'options': {
                    'field' : field,
                    'timestamp': timestamp,
                    'data' : data
                }
            }

            utility.db_query(query)

    def decode(self, field, row):
        # rename the peer field
        row['device'] = row.pop('peer_ip_src')

        # convert hex to strings
        for opt,value in row.items():
            if opt in ['dns_dn', 'http_url', 'http_host', 'http_uagent', 'http_ref', 'ssl_cn']:
                value = value.replace('-', '')[12:]
                try:
                    value = binascii.unhexlify(value).decode('latin1').strip("\u0000")
                except Exception as e:
                    log.debug("exception in unhexlify: %s\n%s" % (e, value))

                row[opt] = value

        # build the app_id
        if field == 'app_name':
            row['app_name'] = self.app_map[str(row['app_id'])]
            del row['app_id']

        elif field == "http_url":
            row['http_url'] = row['http_host'] + row['http_url']
            del row['http_host']

        elif field == 'src_host':
            row['src_host'] = row.pop('ip_src')
            row['app_name'] = self.app_map[str(row['app_id'])]
            del row['app_id']
