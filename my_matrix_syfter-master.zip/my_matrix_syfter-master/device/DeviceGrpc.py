import time
import socket
import grpc
import json
from common import config as cfg
from common import logger as log

# import metadata_call_credentials, composite_call_credentials, insecure_channel, secure_channel


# class BasicCallCredentials(grpc.AuthMetadataPlugin):
#     """ Basic Authentication Credentials wrapper """
#     def __init__(self, username, password):
#         self._username = username
#         self._password = password
#     def __call__(self, context, callback):
#         basic_auth = "Basic %s" % base64.b64encode("%s:%s" % (self._username, self._password))
#         metadata = (('authorization', basic_auth),)
#         callback(metadata, None)
#         #end class
# USERNAME = 'admin'
# PASSWORD = 'Csco@123'

# call_creds = metadata_call_credentials(BasicCallCredentials(USERNAME, PASSWORD))
# chan_cress = grpc.composite_call_credentials(call_creds)

# with grpc.secure_channel('10.111.155.174:9090', chan_creds) as channel:
#     storeStub = rpc_pb2_grpc.StoreStub(channel)
#     print (' store info ', storeStub.Info)    

class DeviceGrpc (object):
    def __init__(self, device, protocol = "https"):
        self.device = device
        self.port = self.device.get("grpc_port", default=50051)
        self.channel = None

        self.username = self.device.get("grpc_username") or self.device.get("username")
        self.password = self.device.get("grpc_password") or self.device.get("password")
        self.login_required = False

    def login (self):
        return True

    def init_channel (self):
        if not self.channel:
            channel_str = '%s:%s' % (self.device.get_address(), self.port)
            self.channel = grpc.insecure_channel(channel_str)

    def is_up (self):
        address = self.device.get_address()
        if address:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(1)

            # check http
            try:
                if sock.connect_ex((address, 80)) == 0:
                    return True
            except socket.gaierror: pass

            # check https
            try:
                if sock.connect_ex((address, 443)) == 0:
                    return True
            except socket.gaierror: pass

        return False

