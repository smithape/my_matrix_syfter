from common import config as cfg
from common import logger as log
from .Device import Device
from .DeviceRest import DeviceRest, RestException

class CiscoDNAC (Device):
    def init_rest (self):
        self.rest = CiscoDNACRest(self)

class CiscoDNACRest(DeviceRest):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.login_required = True

    def login (self):
        self.token = self.post('/dna/system/api/v1/auth/token')['Token']
        self.headers['X-Auth-Token'] = self.token
        self.login_required = False
        return True

    def query (self, *args, **kwargs):
        """
        We need to handle login timeouts and re-login if it's timed out
        """
        try:
            response = super().query(*args, **kwargs)
        except RestException as e:
            if e.code == 401 and 'token expired' in e.text: # login token invalid
                self.login()
                response = super().query(*args, **kwargs)
            else: raise

        try:
            return response['response']
        except:
            return response
