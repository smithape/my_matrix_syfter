"""
File: CiscoDHCP.py
Class: CiscoDHCP
Parent: Device

This module supports Cisco devices.
"""

import sys, os, time
import re

from common import utility
from common import logger as log
from .Device import Device

# supported action flags
supported_actions = [
    "confintdesc",
    "copyto",
    ]

class CiscoDHCP(Device):
    def __init__(self, device_name, device_type = None):
        super().__init__(device_name, device_type)
        self.supported_actions += supported_actions

    def connect_misc (self, session, required=True):
        """
        placeholder to perform platform-specific operations after a connection
        is made
        """
        super().connect_misc(session, required=True)

        self.nrcmd_login(session, required=required)

    def nrcmd_login (self, session, required=False):
        username = self.get("nrcmd_username", required=True)
        password = self.get("nrcmd_password", required=True)

        s = session
        s.send("/opt/nwreg2/local/usrbin/nrcmd -N %s -P '%s'\r" % (username, password))
        s.expect(self.prompt_re)
