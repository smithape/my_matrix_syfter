import time
import socket
import requests
import re
import json
import urllib3
urllib3.disable_warnings()
from common import config as cfg
from common import logger as log

class DeviceRest (object):
    def __init__(self, device):
        self.device = device
        self.headers = {
            'Content-Type': self.device.get("rest_header_content_type") or 'application/json',
            'Accept':       self.device.get("rest_header_accept") or 'application/json'
        }
        self.cookies = {}
        self.address = self.device.get_address()
        self.protocol = self.device.get("rest_protocol") or 'https'
        self.port = self.device.get("rest_port")
        self.username = self.device.get("rest_username") or self.device.get("username")
        self.password = self.device.get("rest_password") or self.device.get("password")
        self.login_required = False

    def login (self):
        return True

    def is_up (self):
        address = self.device.get_address()
        if address:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(1)

            # check http
            try:
                if sock.connect_ex((address, 80)) == 0:
                    return True
            except socket.gaierror: pass

            # check https
            try:
                if sock.connect_ex((address, 443)) == 0:
                    return True
            except socket.gaierror: pass

        return False

    def build_url (self, url):
        x = "%s://%s" % (self.protocol, self.address)
        if self.port:
            x += ':%s' % self.port
        x += url

        return x

    def post (self, *args, **kwargs):
        return self.query("post", *args, **kwargs)

    def get (self, *args, **kwargs):
        return self.query("get", *args, **kwargs)

    def query (self, method, url, body=None, auth=None, timeout=None):
        response = None

        if auth is None:
            auth = (self.username, self.password)
        url = self.build_url(url)
        timeout = timeout or cfg.rest_timeout

        if method == "get":
            r = requests.get(url,
                             auth = auth,
                             verify = False,
                             timeout = timeout,
                             headers = self.headers,
                             cookies = self.cookies)

        elif method == "post":
            r = requests.post(url,
                              json = body,
                              auth = auth,
                              verify = False,
                              timeout = timeout,
                              headers = self.headers,
                              cookies = self.cookies)

        if r and r.status_code == 200:
            if r.headers.get('Content-Type') == "text/xml":
                response = xmltodict.parse(r.content, attr_prefix='', dict_constructor=dict)
            else:
                response = r.json()
        else:
            raise RestException(r.status_code, r.text)

        return response

    def nugget_get (self, nugget_cfg={}, cache={}):

        # do we need to login?
        if self.login_required:
            self.login()

        # find the url
        url = nugget_cfg.get('url_built')

        # check the cache
        data = cache.get(url)

        if not data:
            # find the timeout
            timeout = nugget_cfg.get('timeout', cfg.rest_timeout)

            # try to get the response
            method = nugget_cfg.get("http_method", 'GET')
            if method == "POST":
                body = nugget_cfg.get("body", {})
                if body: body = json.loads(body)
                data = self.post(url, body=body, timeout=timeout)
            else:
                data = self.get(url, timeout=timeout)

            # cache the response
            cache[url] = data

        return data

    def poll (self, nugget_d):

        response_l = []
        cache = {}

        for nugget_name, entry in nugget_d.items():
            try:
                response = self.nugget_get(entry.cfg, cache=cache)
            except Exception as e:
                log.exception("REST Exception: %s" % e, "device",
                              device=self.device, nugget_name=nugget_name)
                continue

            if response is not None:
                response_l.append([nugget_name, int(time.time()), response])

        if not response_l:
            log.error("HTTP: No Response [%s]" % list(nugget_d.keys()), "device", device=self.device)

        return response_l

class RestException(Exception):
    """ Very simple class definition to define our own exception type"""

    def __init__(self, code, text):
        # remove html document <head>
        if '<body>' in text:
            text = re.search('<body>(.*)(</body>)?', text, re.DOTALL | re.IGNORECASE).group(1)

        self.text = text
        self.code = code

    def __str__(self):
        return "%s\n%s" % (self.code, self.text)

