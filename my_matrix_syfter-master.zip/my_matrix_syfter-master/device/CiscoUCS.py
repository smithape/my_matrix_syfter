import time
import xml.etree.ElementTree as ET
import xmltodict

import requests

from common import utility
from common import config as cfg
from common import logger as log
from .Device import Device
from .DeviceRest import DeviceRest

class CiscoUCS (Device):
    def __init__(self, device_name, device_type = None):
        super().__init__(device_name, device_type)

        #self.rest_cookie = None
        self.rest_nuova = None

    def init_rest (self):
        self.rest = RestNuova(self)

class RestNuova (DeviceRest):
    def __init__(self, device, protocol = "https"):
        self.device = device
        self.protocol = protocol
        self.headers={'Content-Type': 'application/xml'}
        self.cookie = None

    def init (self):
        log.debug("Logging in to nuova...")
        body = '<aaaLogin inName="%s" inPassword="%s"/>' % (self.device.get("rest_username"),
                                                            self.device.get("rest_password"))
        data = self.get_response(body)
        self.cookie = data['aaaLogin']['outCookie']

    def get_response (self, body, timeout=10):
        data = None

        # hardcoded url for nuova
        url = '%s://%s/nuova' % (self.protocol, self.device.get_address())

        try:
            r = requests.post(url, data=body,
                              auth=(self.device.get("rest_username"), self.device.get("rest_password")),
                              verify=False, timeout=timeout or cfg.rest_timeout,
                              headers=self.headers)
            if r and r.status_code == 200:
                data = xmltodict.parse(r.content, attr_prefix='', dict_constructor=dict)

        except ValueError as e:
            log.debug(e)
        except requests.exceptions.ConnectionError as e:
            log.debug(e)
        except requests.exceptions.Timeout as e:
            log.debug(e)

        return data

    def nugget_get (self, nugget_cfg={}, cache={}):

        # extract the message body
        body = nugget_cfg.get('body')

        # check the cache
        data = cache.get(body)

        if not data:
            if not self.cookie:
                self.init()

            # add the cookie to the body
            body_xml = ET.fromstring(body)
            body_xml.set('cookie', self.cookie)
            body = ET.tostring(body_xml)

            # find the timeout
            timeout = nugget_cfg.get('timeout', cfg.rest_timeout)

            # try to get the response
            data = self.get_response(body, timeout)

            # make sure our login hasn't expired
            if data.get('errorCode') == "552":
                log.debug("Login Expired...relogin")
                self.init()
                data = self.get_response(body, timeout)

            # cache the response
            cache[body] = data

        return data
