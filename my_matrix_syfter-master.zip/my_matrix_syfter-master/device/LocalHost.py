# default modules
from subprocess import getstatusoutput
import time
import re
import psutil

# project modules
from common import utility
from common import config as cfg
from common import logger as log
from .Linux import Linux
from .DeviceCli import DeviceCli

class LocalHost(Linux):
    def __init__(self, device_name, device_type = None):
        super().__init__(device_name, device_type)

        self.ip_address = "127.0.0.1"
        self.hostname = "localhost"
        self.ifname = cfg.localhost_ifname

        # list of urls to check RTT
        self.url_d = self.get_url_d()

    def init_cli (self):
        self.cli = LocalHostCli(self)

    def gather_nugget_vars (self):
        for var in self.get_nugget_variables():
            if var == "pageDownloadTime_url":
                self.nugget_var_d[var] = self.url_d

    def get_url_d (self):
        urls = self.get("pageDownloadTime_urls")
        urls = [x.strip() for x in urls.split(',')]
        url_d = {}
        for url in urls:
            try:
                alias, url = [x.strip() for x in url.split("=")]
                url = url.lower()
            except ValueError:
                url = url.lower()
                alias = url

            url_d[alias] = url

        return url_d

    def get_cpuUtilization (self):
        return psutil.cpu_percent() or None

    def get_ramUtilization (self):
        return psutil.virtual_memory().percent

    def trim_polling_config (self):
        pass

    def poll_collect (self, nugget_d):
        response_l = []

        #
        # function query
        if 'function' in nugget_d:
            response_l += self.poll_function(nugget_d['function'])

        #
        # cli query
        if 'cli' in nugget_d:
            response_l += self.cli.poll(nugget_d['cli'])

        return response_l

    def cli_session_required (self):
        return False

    def snmp_required (self):
        return False


class LocalHostCli(DeviceCli):
    def __init__(self, device):
        super().__init__(device)

    def is_alive (self):
        """ spoof the function """
        return True

    def session_read_to_end (self, session = None, timeout=0):
        """ spoof the function """
        return b''

    def get_response (self, command, timeout=10):
        """ instead of using a session """
        (code, text) = getstatusoutput(command)
        return text
