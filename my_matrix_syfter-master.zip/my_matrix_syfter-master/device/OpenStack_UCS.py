from .CiscoUCS import CiscoUCS, RestNuova

class OpenStack_UCS (CiscoUCS):
    def init_rest (self):
        self.rest = Openstack_RestNuova(self)

class Openstack_RestNuova (RestNuova):
    def init_jump_session (self):
        # check for jump server
        jump_server = self.device.get("jump_server")
        if jump_server:
            # initialize the jump server object
            jmp = cfg.init_device_object(jump_server, self.device.get("jump_server_type"))
            # set it's parameters
            if not utility.is_valid_ip_address(jmp.name):
                jmp.hostname = jump_server
            jmp.username = self.device.get("jump_server_username")
            jmp.password = self.device.get("jump_server_password")
            jmp.cli_post_connect_commands = self.device.get("jump_server_cli_post_connect_commands")
            # connect to jump server
            jmp.cli.session = jmp.cli.connect()
            jmp.cli.set_prompt()
            return jmp.cli

    def init (self):
        log.debug("initializing cli session...")
        self.cli = self.init_jump_session()
        log.debug("Logging in to nuova...")
        username = self.device.get("rest_username") or self.device.get("username")
        password = self.device.get("rest_password") or self.device.get("password")
        body = '<aaaLogin inName="%s" inPassword="%s"/>' % (username, password)

        data = self.get_response(body)
        self.cookie = data['aaaLogin']['outCookie']

    def get_response (self, body, timeout=10):
        data = None

        # hardcoded url for nuova
        url = '%s://%s/nuova' % (self.protocol, self.device.get_address())

        try:
            command = 'curl -d "%s" %s --insecure' % (body.replace("\"", "'"), url)
            text = self.cli.get_response(command)
            if text:
                data = xmltodict.parse(text, attr_prefix='', dict_constructor=dict)
        except ValueError as e:
            log.debug(e)

        return data

    def nugget_get (self, nugget_cfg={}, cache={}):

        # extract the message body
        body = nugget_cfg.get('body')

        # check the cache
        data = cache.get(body)

        if not data:
            if not self.cookie:
                self.init()

            # add the cookie to the body
            body_xml = ET.fromstring(body)
            body_xml.set('cookie', self.cookie)
            body = ET.tostring(body_xml).decode()

            # find the timeout
            timeout = nugget_cfg.get('timeout', cfg.rest_timeout)

            # try to get the response
            data = self.get_response(body, timeout)

            # make sure our login hasn't expired
            if data.get('errorCode') == "552":
                log.debug("Login Expired...relogin")
                self.init()
                data = self.get_response(body, timeout)

            # cache the response
            cache[body] = data

        return data

