"""
File: VirtualDevice.py
Class: VirtualDevice
Parent: Device

This module contains the class for the root/summary pseudo-device.
"""
import time
import numpy as np

from .Device import Device
from nugget import Nugget
from common import \
    config as cfg, \
    logger

class VirtualDevice(Device):
    def __init__(self, name, group, aggregation = True, dtype = "CiscoAP"):
        super().__init__(name)

        self.group = group
        self.aggregation = aggregation
        self.dtype = dtype or "CiscoAP"
        self.suffix = name.rsplit('_', 1)[-1]
        self.type = self.dtype+"_Agg"
        self.group = group
        self.db_index = group.db_index
        self.nugget_cfg = Nugget.getNuggetConfig("CiscoAP")
        self.event_detector = None
        self.device_l = []
        self.nugget_cfg = Nugget.getNuggetByFlag(self.suffix)

    def init_polling_config (self):
        self.device_l = self.group.device_list(dtype=self.dtype)

        for device in self.device_l:
            for nugget_name, nugget_entry in device.nugget_d.items():
                nugget_root = nugget_name.split(':')[0]
                if nugget_root in self.nugget_cfg and nugget_name not in self.nugget_d:
                    self.nugget_d[nugget_name] = cfg.init_nugget(self, nugget_name, nugget_entry.interval,
                                                                 counter=nugget_entry.interval,
                                                                 nugget_cfg=nugget_entry.cfg)

        # set the polling interval
        self.polling_interval = self.get_polling_interval()

    def poll (self, time_delta):
        timestamp = int(time.time())

        #
        # loop through the nugget_d and find Nuggets to poll
        to_poll = {}
        for nugget_name, nugget_entry in self.nugget_d.items():
            if not nugget_entry.enabled:
                continue

            # find the entries that are due to poll
            if nugget_entry.counter <= 0:
                nugget_entry.counter = nugget_entry.interval;
                to_poll[nugget_name] = nugget_entry

            # decrement the counter
            nugget_entry.counter -= time_delta

        for nugget_name, nugget_entry in to_poll.items():
            value = self.aggregate_nugget(nugget_name)

            if value is None:
                continue

            # store the latest sample
            nugget_entry.store_sample(timestamp, value)

    def aggregate_nugget (self, metric_name):
        vals = []

        for ap in self.device_l:
            if metric_name in ap.nugget_d:
                value = ap.nugget_d[metric_name].prev_value
                if value is not None:
                    vals.append(value)

        if vals:
            method = self.suffix.lower()
            if method == "avg":
                return np.mean(vals)
            elif method == "sum":
                return np.sum(vals)

        # didn't work out :-/
        return None
