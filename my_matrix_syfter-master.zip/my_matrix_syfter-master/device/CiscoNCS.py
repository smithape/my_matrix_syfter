import sys
import re

from pkg import pexpect
from common import config as cfg
from common import logger as log
from common import utility

from .DeviceCli import DeviceCli
from .Device import Device

class CiscoNCS (Device):
    def init_cli (self):
        self.cli = CiscoNCSCli(self)

class CiscoNCSCli(DeviceCli):
    def __init__(self, device):
        super().__init__(device)
        self.post_connect_commands = [
            'INH-MSG-ALL:::wwp01',
            'INH-MSG-DBCHG:::wwp02',
            'INH-MSG-SECU:::wwp03',
            'INH-PMREPT-ALL:::wwp04'
        ]

    success_re = re.compile(b'User [^\s]+ logged in', flags=re.I)
    failure_re = re.compile(b'User [^\s]+ logged in', flags=re.I)
    def connect_login (self, session, required=False, timeout=10):
        """
        The automation function for logging into devices.

        session: the current session
        required: True if the action requires successful login (automation)
        """
        # run the standard login (in case of login prompts)
        if not super().connect_login(session, required=required, timeout=timeout):
            return False

        #session.logfile = sys.stdout
        command_tag = utility.random_string()
        username = self.device.get("username", required=required)
        password = self.device.get("password", required=required)

        # if login is required, set a higher timeout
        if required:
            timeout = cfg.pexpect_login_timeout;

        # send the login command
        session.send("ACT-USER::%s:%s::%s;" % (username, command_tag, password))
        ret = session.expect_list([self.prompt_re, pexpect.TIMEOUT], timeout=timeout)
        if ret == 0:
            if re.search(self.success_re, session.before):
                return True
            else:
                return False
        else:
            if required:
                utility.error("Connection timeout!")
            else:
                return False

    def connect_misc (self, session, required=True):
        """
        placeholder to perform platform-specific operations after a connection
        is made
        """
        command_l = self.get_all_post_connect_commands()
        for command in command_l:
            session.send("%s;" % command)
            session.expect_list([self.prompt_re])

    response_re = re.compile(r'"(.*)"\r\n')
    def get_response (self, command, timeout=10):
        #log.debug("get_response: %s/%s" % (command, timeout))

        try:
            command_tag = "S" + utility.random_string(length=5)
            command = command.replace('<CTAG>', command_tag)

            self.session.send("%s;" % command)
            ret = self.session.expect_exact(["%s COMPLD" % command_tag,
                                             "%s DENY" % command_tag,
                                             "%s PRTL" % command_tag],
                                            timeout=timeout)
            if ret == 1:
                log.debug("DENY")
                if self.connect_login(self.session, required = True):
                    log.debug("LOGIN_DONE")
                    # try again
                    self.session.send("%s;" % command)
                    ret = self.session.expect_exact(["%s COMPLD" % command_tag,
                                                     "%s DENY" % command_tag],
                                                    timeout=timeout)
                    if ret == 1:
                        return None
                else:
                    return None

            try:
                response = self.session.before.decode()
                # find the end of the response
                self.session.expect_exact(b";\r\n" + self.prompt, timeout=timeout)
                response += self.session.before.decode()
                # remove unwanted lines
                response = '\n'.join(re.findall(self.response_re, response))
                return response
            except IndexError:
                return ""
        except pexpect.TIMEOUT:
            # cancel the command
            self.session.sendcontrol('c')
            self.session.expect_exact('\r\n' + self.prompt, timeout=timeout)
            return pexpect.TIMEOUT
        except pexpect.EOF:
            log.exception("CLI Exception: session closed",
                          "device", device=self.device)
        except OSError:
            log.exception("CLI Exception: OSError (probably a buffer overflow)",
                          "device", device=self.device)
        except Exception as e:
            log.exception("CLI Exception: unexpected issue",
                          "device", device=self.device)
            raise

        raise

