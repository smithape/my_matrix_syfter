"""
File: Item.py
Class: Item

This module is the top of the Item class tree.

It contains functions that are common to all Items and device classes.
"""

import yaml

from common import utility
from common import config as cfg

def get_descendant_l (cls):
    return set(cls.__subclasses__()).union(
        [s for c in cls.__subclasses__() for s in get_descendant_l(c)])

def get_descendant_d (cls, tree, path, path_d):
    name_l = [(x, x.__name__) for x in cls.__subclasses__()]
    for cls, name in name_l:
        new_path = path_d[name] = path + [name]
        tree[name] = get_descendant_d(cls, {}, new_path, path_d)

    return tree

class Item(object):
    def __init__(self, device_name, device_type = None):
        self.supported_actions = [
            "show",
            "connect",
            ]

        self.name = self.name_key = device_name
        self.type = device_type or type(self).__name__
        self.db_entry = None

        # tree-related values
        self.children = []
        #LEVY SAVE self.parent = None
        self.parents = []

        # filter-related values
        self.match = False
        self.filtered = False

        # The 'force' variable will prevent prompting for
        # automation tasks
        self.force = False
        self.ancestor_l = cfg.device_type_path_d.get(self.type, [])
        self.descendant_class_l = get_descendant_l(self.__class__)
        self.descendant_l = [x.__name__ for x in self.descendant_class_l]
        self.descendant_path_d = {}
        self.descendant_d = get_descendant_d(self.__class__, {}, [], self.descendant_path_d)

    def get_ownership (self, look_up=True, look_down=True):
        """
        Return ownership information for this device

        This is a fairly complicated recursive function (sorry).

        (1) it checks to see if the device is directly owned
        (2) it searches up the ancestor chain in the device tree to see if
            the device is owned through an ancestor
        (3) it searches the device descendants to determine whether the device
            is 'partially owned' (one or more descendants are owned).

        This function is recursive in two directions:
          (1) up the tree
          (2) down the tree
        The look_up and look_down flags help keep the recursion in check.

        Args:
          look_up: should we look up the tree (at ancestors)?
          look_down: should we look down the tree (at descendants)?
        """

        owner = self.get("owner")
        reserved_until = self.get("reserved_until")
        device_name = self.name
        partially_owned = False
        device_tree = cfg.device_tree;

        if look_down:
            for device in device_tree[self.name].children:
                (tmp0,
                 tmp1,
                 tmp2,
                 tmp3) = device.get_ownership()#(look_up=False)
                if tmp0 or tmp3:
                    partially_owned = True
                    break

        if not owner and look_up:
            for parent in self.parents:
                (owner,
                 reserved_until,
                 device_name,
                 tmp3) = parent.get_ownership(look_down=False)
                if owner:
                    break

        return (owner, reserved_until, device_name, partially_owned)

    def get_ownership_old (self, look_up=True, look_down=True):
        """
        Return ownership information for this device

        This is a fairly complicated recursive function (sorry).

        (1) it checks to see if the device is directly owned
        (2) it searches up the ancestor chain in the device tree to see if
            the device is owned through an ancestor
        (3) it searches the device descendants to determine whether the device
            is 'partially owned' (one or more descendants are owned).

        This function is recursive in two directions:
          (1) up the tree
          (2) down the tree
        The look_up and look_down flags help keep the recursion in check.

        Args:
          look_up: should we look up the tree (at ancestors)?
          look_down: should we look down the tree (at descendants)?
        """

        owner = self.get("owner")
        reserved_until = self.get("reserved_until")
        device_name = self.name
        partially_owned = False
        device_tree = cfg.device_tree;

        if look_down:
            for device in device_tree[self.name].children:
                (tmp0,
                 tmp1,
                 tmp2,
                 tmp3) = device.get_ownership(look_up=False)
                if tmp0 or tmp3:
                    partially_owned = True
                    break

        if not owner and look_up:
            parent_name = self.get("parent")
            if parent_name and (parent_name in device_tree):
                parent = device_tree[parent_name]
                (owner,
                 reserved_until,
                 device_name,
                 tmp3) = parent.get_ownership(look_down=False)

        return (owner, reserved_until, device_name, partially_owned)

    def is_filtered (self, filters):
        """
        This function is used when displaying the summary list of devices.

        It determines whether or not the device will be filtered out of the
        output.

        Args:
          filters: This is a list of filter strings to be checked against
        """

        if not filters:
            return False

        (owner,
         reserved_until,
         ownership_origin,
         partially_owned) = self.get_ownership()

        filtered = False
        for filter in filters:
            filter = filter.split('=')
            if len(filter) < 2:
                value=filter[0].lower()
                found_match = False
                # first check in the device name
                if value in self.name or value in owner:
                    found_match = True
                # next check each one of the attributes
                else :
                    for option in cfg.parser.options(self.name):
                        option_value = self.get(option).lower()
                        if value in option_value:
                            found_match = True
                            break
                if not found_match:
                    filtered = True
            else:
                option = filter[0].lower()
                value = filter[1].lower()
                # special handling for "name"
                if option == 'name':
                    option_value = self.name
                elif option == 'owner':
                    option_value = owner;
                    if not option_value and partially_owned:
                        option_value = "~~"
                else:
                    option_value = self.get(option).lower()
                if (value not in option_value) or (option_value and not value):
                    filtered = True
        return filtered

    def reload_cfg (self):
        # initialize the latest site config
        cfg_text = cfg.get_config_text("site")
        site_cfg = yaml.full_load(cfg_text) or {}

        cfg.config["site"][self.name] = site_cfg.get(self.name, {})

    def get (self, option, size=1, required=False, default=""):
        """
        Retrieve device configuration options.

        Parts are separated by the colon ':'.

        Args:
          option: the option to retrieve
          size: the expected number of parts to this option
          required: if this option is not configured correctly,
                    we should not proceed when this is True.
          default: the default value (for size=1)
        """
        value = None

        # (for simple values) first see if the attribute is stored in the object
        value = getattr(self, option, None)
        if value is not None:
            if size > 1:
                value = value.split('/', size-1)
        # otherwise, check in the config parser
        else:
            value = cfg.get(self.name_key, option, size, default)

        if size == 1 and default:
            value = value or default

        if required:
            self.validate_config_option(option, value)

        return value

    def validate_config_option(self, option, value):
        """
        this will validate various configuration options

        Args:
          option: the name of the option
          value: the value(s) (sometimes in list form) to verify
        """

        if option == "ip_address":
            ip_address = value
            if not ip_address or not utility.is_valid_ip_address(ip_address):
                example = "ip_address = 10.0.0.4"
                utility.cfg_error (self.name, option,
                                   example=example)
        elif option == "console":
            [ts_hostname, ts_port] = value
            valid = True
            if not ts_hostname:
                valid = False
            if not ts_port or not utility.str_is_int(ts_port):
                valid = False

            if not valid:
                syntax = ("console = <terminal_server_hostname>:"
                          + "<terminal_server_port>")
                example = "console = jw-ts-e05:2009"
                utility.cfg_error (self.name, option,
                                   syntax = syntax,
                                   example = example)
        else:
            if not value:
                utility.cfg_error (self.name, option)

    def set_cfg (self, option, value):
        """set a config option in the config file"""

        cfg.set_cfg(self.name_key, option, value)

    def remove_config_option(self, option):
        """remove a config option from the config file"""

        cfg.remove_config_option(self.name_key, option)
