from .Linux import Linux
class Kubernetes (Linux): pass
