"""
File: CiscoAP.py
Class: CiscoAP
Parent: Device

This module supports devices that run Cisco AP.
"""

import sys, os, time
from fractions import gcd
import re

from nugget import Nugget
from common import config as cfg
from common import logger as log
from .CiscoIOS import CiscoIOS

class CiscoAP(CiscoIOS):
    def __init__(self, device_name, device_type, wlc=None, dot3_addr=None):
        super().__init__(device_name, device_type = device_type)

        self.type = "CiscoAP"
        self.wlc = wlc # associated Wireless Lan Controller
        self.snmp_proxy = wlc # all snmp queries go to the wlc
        self.dot3_addr = dot3_addr # the dot3 address of this AP
        # upstream switch info
        self.switch = None
        self.switch_ifname = None # interface on the upstream switch
        self.switch_ifindex = None # interface on the upstream switch
        self.ap_group = None
        # radio interfaces
        self.interfaces = []
        # update interval for some of the SNMP counters
        self.stats_timer = 0
        # supported channels
        self.channels = []
        self.update_other = None
        self.snmp_supported = False

    def get_device_d (self, full=False):
        d = super(CiscoAP, self).get_device_d(full=full)
        try:
            d['ap_group'] = self.ap_group
            d['switch'] = self.switch.name
            d['switch_if'] = self.switch_ifname
        except: pass

        return d

    def needs_update (self):
        return (super(CiscoAP, self).needs_update() or
                'switch_if' in self.code_d or
                'switch' in self.code_d or
                self.update_other is not None)

    def update (self):
        if self.update_other:
            self.update_from_other(self.update_other)
            self.update_other = None

        super(CiscoAP, self).update()

    def equals_other (self, other):
        """ wlc, ip, switch interface are all equal? """

        if (self.wlc is not other.wlc or
            self.ip_address != other.ip_address or
            (other.switch and self.switch is not other.switch) or
            (other.switch_ifindex and self.switch_ifindex != other.switch_ifindex) or
            (other.ap_group and self.ap_group != other.ap_group)):
            return False

        return True

    def update_from_other (self, other):
        try:
            if other.wlc and self.wlc is not other.wlc:
                log.info("WLC changed from %s to %s" % (self.wlc.name, other.wlc.name), "device", device=self)
                self.wlc = other.wlc
            if other.switch and self.switch is not other.switch:
                log.info("switch changed from %s to %s" % (self.switch.name, other.switch.name), "device", device=self)
                self.switch = other.switch
            if other.switch_ifindex and self.switch_ifindex != other.switch_ifindex:
                log.info("switch_ifindex changed from %s to %s" % (self.switch_ifindex, other.switch_ifindex), "device", device=self)
                self.switch_ifindex = other.switch_ifindex

            if self.dot3_addr != other.dot3_addr:
                self.dot3_addr = other.dot3_addr

                # build oids
                for x in self.nugget_d.values():
                    if x.type == "snmp@wlc":
                        # build the simple oids
                        x.build()

                log.info("WLC entry changed", "device", device=self)

            if self.ip_address != other.ip_address:
                log.info("ip address changed from %s to %s" % (self.ip_address, other.ip_address), "device", device=self)
                # set the new IP
                self.ip_address = other.ip_address
                self.cli.close_session()

            self.ap_group = other.ap_group

        except Exception as e:
            log.debug("Error in device update from other (%s): %s" % (self.name, e))

    def is_up_check (self):
        # check the wlc association
        capwap_up = False
        snmp_query = self.oid_map['cLLwappUpTime'] + "." + self.dot3_addr
        snmp_response = self.snmp_get([snmp_query])
        if snmp_response:
            val = snmp_response[0]
            if int(val)//(100*60) > 5:
                capwap_up = True

        return capwap_up or self.ssh_is_up()

    def switch_info_required (self):
        return self.wlc.switch_info_required()

    switch_id_re = re.compile(r'(?:Device ID:\s+)([^\n]+)')
    switch_ip_re = re.compile(r'(?:IP address:\s+)([\d\.]+)')
    switch_if_re = re.compile(r'(?:Port ID \(outgoing port\):\s+)([\w/]+)')
    def find_upstream_switch (self, timeout=10):
        switch_name = switch_ip = switch_if = None
        # try to create a term session
        close_session = False
        if not self.cli.set_session(quiet=True):
            return None

        s = self.cli.session

        #
        # get the IP
        s.send("show cdp neighbor detail | inc IP|Port|ID\r")
        s.expect_exact(self.prompt, timeout=timeout)
        try:
            switch_name = re.search(self.switch_id_re, s.before).group(1)
            switch_ip = re.search(self.switch_ip_re, s.before).group(1)
            #
            # get the interface
            switch_if = re.search(self.switch_if_re, s.before).group(1).lower()
            # we use abbreviated names
            switch_if = re.sub(r'fastethernet', 'fa', switch_if)
            switch_if = re.sub(r'gigabitethernet', 'gi', switch_if)
        except AttributeError:
            return None

        return (switch_name, switch_ip, switch_if)

    def switch_snmp_get (self, oid_l, timeout=None, retries=None):
        return self.switch.snmp_get(oid_l, timeout=timeout, retries=retries)

    def snmp_get (self, oid_l, timeout=None, retries=None):
        "SNMP for APs lives in the WLC"
        return self.wlc.snmp_get(oid_l, timeout=timeout, retries=retries)

    def snmp_get2 (self, oid_l, timeout=None, retries=None):
        "SNMP for APs lives in the WLC"
        return self.wlc.snmp_get2(oid_l, timeout=timeout, retries=retries)

    def gather_nugget_vars (self):
        for var in self.get_nugget_variables():
            if var == "ssid":
                self.nugget_var_d['ssid'] = self.wlc.ssid_d
            if var == "ap_id":
                self.nugget_var_d['ap_id'] = self.dot3_addr

    def trim_polling_config (self):
        # call the parent function
        super(CiscoAP, self).trim_polling_config()

        # disable snmp@switch entries if we don't have an upstream switchport
        if self.polling_cfg_includes_type('snmp@switch'):
            if not self.switch_ifindex:
                # disable nuggets
                if not self.switch:
                    self.add_code('switch')
                else:
                    self.add_code('switch_if', quiet=True)

                for x in self.nugget_d.values():
                    if x.type == "snmp@switch":
                        x.enabled = False
            else:
                # enable nuggets
                self.remove_code('switch')
                self.remove_code('switch_if', quiet=True)

                for nugget_name,x in self.nugget_d.items():
                    if x.type == "snmp@switch":
                        x.build()
                        x.enabled = True

        # disable Nuggets for radio interfaces that don't exist
        if 1 not in self.interfaces and type(self).__name__ != "CiscoAPv2":
            log.info("No 2.4GHz radio", "device", device=self)
            for nugget_name,x in self.nugget_d.items():
                if "2.4GHz" in nugget_name:
                    x.enabled = False

        if 2 not in self.interfaces:
            log.info("No 5GHz radio", "device", device=self)
            for nugget_name,x in self.nugget_d.items():
                if "5GHz" in nugget_name:
                    x.enabled = False

    def poll_collect (self, nugget_d):
        now = int(time.time())
        response_l = []

        #
        # Send Keepalive?
        if [x for x in nugget_d.keys() if x in ['cli', 'snmp@wlc']]:
            touched = True
        else:
            touched = False
            if 'keepalive' in nugget_d:
                if not self.is_up(check=True):
                    return

        #
        # Send CLI Keepalive?
        if not 'cli' in nugget_d and 'cli_keepalive' in nugget_d:
            self.cli.session_keepalive()

        #
        # snmp@wlc query
        snmp_wlc = ('snmp@wlc' in nugget_d and self.wlc.is_up())
        if snmp_wlc:
            self.poll_snmp_queue(self.wlc, nugget_d['snmp@wlc'])

        #
        # snmp@switch query
        snmp_switch = ('snmp@switch' in nugget_d and
                       self.switch.is_up() and
                       self.switch.snmp_is_up())
        if snmp_switch:
            self.poll_snmp_queue(self.switch, nugget_d['snmp@switch'])

        #
        # cli query
        if 'cli' in nugget_d:
            response_l += self.cli.poll(nugget_d['cli'])

        #
        # function query
        if 'function' in nugget_d:
            response_l += self.poll_function(self, nugget_d['function'])

        #
        # snmp@wlc read
        if snmp_wlc:
            response_l += self.poll_snmp_read(self.wlc, nugget_d['snmp@wlc'], now, bulk=cfg.poll_bulk)

        # Null response? Check whether the device is down
        # (snmp@switch below doesn't count)
        if touched and not response_l and not self.is_up(check=True):
            return

        #
        # snmp@switch read
        if snmp_switch:
            response_l += self.poll_snmp_read(self.switch, nugget_d['snmp@switch'], now, bulk=cfg.poll_bulk)

        return response_l

    def init_polling_config (self):
        """ DESCRIBE """

        # call the parent function
        super(CiscoAP, self).init_polling_config()

        try:
            #condition to check whether an AP supports dual band
            #An AP that returns values >= 34 for both channels, supports dual band
            if all(channel >= 34 for channel in self.channels):
                #update the Nugget dictionary and clientCount children for dual band APs
                if 'clientCount_2.4GHz' in self.nugget_d:
                    self.nugget_d['clientCount'].child_l.remove(self.nugget_d['clientCount_2.4GHz'])
                    self.nugget_d.pop('clientCount_2.4GHz')
                if 'clientCount_5GHz' in self.nugget_d:
                    #clientCount has only 1 child element in this case, removing the other child elements
                    self.nugget_d['clientCount'].child_l.remove(self.nugget_d['clientCount_5GHz_band_1'])
                    self.nugget_d['clientCount'].child_l.remove(self.nugget_d['clientCount_5GHz_band_2'])
                    #since both bands belong to 5GHz, clientCount_5GHz becomes the parent element
                    self.nugget_d['clientCount_5GHz'].child_l = [self.nugget_d['clientCount_5GHz_band_1'],self.nugget_d['clientCount_5GHz_band_2']]
                    self.nugget_d['clientCount_5GHz'].type = 'aggregation'
            else:
                #update the Nugget dictionary and clientCount children for APs that don't support dual band
                if 'clientCount_5GHz_band_1' in self.nugget_d:
                    self.nugget_d['clientCount'].child_l.remove(self.nugget_d['clientCount_5GHz_band_1'])
                    self.nugget_d.pop('clientCount_5GHz_band_1')
                if 'clientCount_5GHz_band_2' in self.nugget_d:
                    self.nugget_d['clientCount'].child_l.remove(self.nugget_d['clientCount_5GHz_band_2'])
                    self.nugget_d.pop('clientCount_5GHz_band_2')

        except Exception as e:
            log.debug("Exception in CiscoAP init polling config")

class CiscoAPv1(CiscoAP): pass
class CiscoAPv2(CiscoAP): pass
