import json
from common import config as cfg
from common import logger as log
from .Device import Device
from .DeviceRest import DeviceRest, RestException

class CiscoAPIC (Device):
    def init_rest (self):
        self.rest = CiscoAPICRest(self)

class CiscoAPICRest(DeviceRest):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.login_required = True

    def login (self):
        body = {
            'aaaUser': {
                'attributes': {
                    'name': self.username,
                    'pwd': self.password
                }
            }
        }
        response = self.post('/api/aaaLogin.json', body=body)
        # extract the cookie
        response = response['imdata'][0]['aaaLogin']['attributes']
        self.cookies['APIC-Cookie'] = response['token']
        self.login_required = False
        return True

    def query (self, *args, **kwargs):
        """
        We need to handle login timeouts and re-login if it's timed out
        """
        try:
            return super().query(*args, **kwargs)
        except RestException as e:
            if e.code == 403: # login token invalid
                self.login()
                return super().query(*args, **kwargs)
            else: raise
