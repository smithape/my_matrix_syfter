from pkg import pexpect

from common import parse
from common import logger as log

from .OpenStack import OpenStack

class OpenStack_v18 (OpenStack):
    def parse_inventory (self, d):
        # add nodes
        response = self.undercloud.cli.get_response('nova list', timeout=30)
        if response is pexpect.TIMEOUT:
            return None

        response = parse.table(response)
        for x in response:
            if 'osd-compute' in x['Name']:
                fn = OpenStack_v18_OSDCompute
            elif 'compute' in x['Name']:
                fn = OpenStack_v18_Compute
            elif 'controller' in x['Name']:
                fn = OpenStack_v18_Controller
            else:
                fn = OpenStack_v18_Node

            name = self.name +':' + x['Name']
            node = fn(name)
            node.ip_address = x['Networks'].split('=')[1]
            node.username = 'heat-admin'
            node.post_connect_commands.insert(0, 'sudo su -')
            node.jump_server = self.get_address()
            node.jump_server_type = self.type
            node.jump_server_username = self.get("username")
            node.jump_server_password = self.get("password")
            node.jump_server_cli_post_connect_commands = self.get("cli_post_connect_commands")
            node.init_io()
            d[name] = node

class OpenStack_v18_Undercloud (OpenStack_v18): pass
class OpenStack_v18_Overcloud (OpenStack_v18): pass
class OpenStack_v18_Node (OpenStack_v18): pass
class OpenStack_v18_Controller (OpenStack_v18_Node): pass
class OpenStack_v18_Compute (OpenStack_v18_Node): pass
class OpenStack_v18_OSDCompute (OpenStack_v18_Node): pass
