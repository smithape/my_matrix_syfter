import re
import yaml
import json

from common import parse
from common import logger as log

from .OpenStack import OpenStack
from .OpenStack_UCS import OpenStack_UCS

class OpenStack_v19 (OpenStack): pass
class OpenStack_v19_Undercloud (OpenStack_v19): pass
class OpenStack_v19_Overcloud (OpenStack_v19): pass
class OpenStack_v19_Node (OpenStack_v19): pass
class OpenStack_v19_Controller (OpenStack_v19_Node): pass
class OpenStack_v19_Compute (OpenStack_v19_Node): pass
class OpenStack_v19_OSDCompute (OpenStack_v19_Node): pass
