import time
import json
import netsnmp

from common import config as cfg
from common import logger as log
from common import SNMPEngine

def parseVal (sample, type=None):
    if type:
        if type in ['INTEGER', 'COUNTER', 'GAUGE', 'TICKS']:
            sample = int(sample)
        else:
            try:
                sample = sample.decode()
            except:
                sample = sample.decode('unicode_escape')
    else:
        try: # try INT
            sample = int(sample)
        except (ValueError, TypeError):
            try: # try FLOAT
                sample = float(sample)
            except (ValueError, TypeError):
                if sample:
                    sample = sample.decode()
                else:
                    sample = None

    return sample

class DeviceSnmp (object):
    def __init__(self, device):
        self.device = device
        self.proxy = None
        self.timeout_detected = 0
        self.init_config()

    def init_config (self):
        try:
            d = {}
            d['address'] = self.device.get_address(required=True)
            d['version'] = self.device.get("snmp_version", default=2)
            d['snmp_bulkwalk_reps'] = self.device.get("snmp_bulkwalk_reps", default=cfg.snmp_bulkwalk_reps)

            if d['version'] == 3:
                d['username'] = self.device.get("snmp_username", required=True)
                d['seclevel'] = seclevel = self.device.get("snmp_seclevel", default="authPriv")

                if seclevel in ["authPriv", "auth"]:
                    [authproto, authpass] = self.device.get("snmp_auth", size=2, required=True)
                    d['authproto'] = authproto
                    d['authpass'] = authpass
                if seclevel in ["authPriv", "priv"]:
                    [privproto, privpass] = self.device.get("snmp_priv", size=2, required=True)
                    d['privproto'] = privproto
                    d['privpass'] = privpass
            else:
                d['community'] = self.device.get("snmp_community", required=True)

            # store as attributes
            for opt in d:
                setattr(self, opt, d[opt])

            # remember the parameters
            self.config_d = d
        except:
            self.config_d = None

    def is_configured (self):
        return (self.config_d is not None)

    def is_up (self, check=False, quiet=False):
        if not self.is_configured():
            return False

        if check:
            if self.get(['.1.3.6.1.2.1.1.1.0'], timeout=1, retries=0):
                if not quiet:
                    self.device.remove_code('snmp_down')
                return True
            else:
                if not quiet:
                    self.device.add_code('snmp_down')
                return False
        else:
            return not ('snmp_down' in self.device.code_d)

    def new_session (self, timeout=None, retries=None):
        " intiialize an snmp session "

        # get the required snmp options
        if timeout is None: timeout = cfg.snmp_timeout
        timeout = timeout * 1000000
        if retries is None: retries = cfg.snmp_retries

        if self.version == 3:
            session = netsnmp.Session(DestHost=self.address,
                                      Version=self.config_d.get('version'),
                                      SecName=self.config_d.get('username'),
                                      SecLevel=SNMPEngine.secLevelMap[self.config_d.get('seclevel')],
                                      AuthProto=self.config_d.get('authproto'),
                                      AuthPass=self.config_d.get('authpass'),
                                      PrivProto=self.config_d.get('privproto'),
                                      PrivPass=self.config_d.get('privpass'),
                                      Timeout=timeout,
                                      Retries=retries,
                                      UseNumeric=True)
        else:
            session = netsnmp.Session(DestHost=self.address,
                                      Version=self.version,
                                      Community=self.community,
                                      Timeout=timeout,
                                      Retries=retries,
                                      UseNumeric=True)

        return session

    def get (self, oid_l, timeout=None, retries=None):
        # convert single oid to list format
        if isinstance(oid_l, str):
            oid_l = [oid_l]

        # set the snmp session
        session = self.new_session(timeout=timeout, retries=retries)

        # put our oid_l into varbind format
        varbind_list = []
        for oid in oid_l:
            oid = SNMPEngine.format_oid(oid)
            varbind_list.append(netsnmp.Varbind(oid))

        # create a varlist object
        var_list = netsnmp.VarList(*varbind_list)

        session.get(var_list)

        # timeout
        if session.ErrorInd == -24:
            #device.snmp_timeout_detected = time.time()
            return None

        # prepare the response list.
        res_l = []
        empty = True
        for x in var_list:
            if x.val:
                empty = False
            res_l.append(parseVal(x.val, x.type))

        # if everything is None
        if empty:
            return []

        return res_l

    def walk (self, oid, timeout=None, retries=None):
        """
        execute an snmp walk request to device starting with the input OID
        """

        if self.device.get("snmp_use_bulkwalk", default=True):
            return self.bulkwalk(oid, timeout=timeout, retries=retries)

        # set the snmp session
        session = self.new_session(timeout=timeout, retries=retries)

        # put our oid into varbind format
        varbind_list = []
        varbind_list.append(netsnmp.Varbind(oid))

        # create a varlist object
        var_list = netsnmp.VarList(*varbind_list)

        # perform walk
        session.walk(var_list)

        # timeout
        if session.ErrorInd == -24:
            device.snmp_timeout_detected = time.time()
            return None

        # prepare the response list.
        for x in var_list:
            # find the full numeric oid
            if x.iid:
                x.oid = x.tag + "." + x.iid
            else:
                x.oid = x.tag

            # the __setattr__ function will always cast to 'str'
            # otherwise, this would be: x.val = ...
            x.__dict__["val"] = parseVal(x.val, x.type)

            # if not x.oid:
            #     log.error("snmp walk returned null tag!", "system")

        if var_list:
            return {x.oid:x.val for x in var_list}

    def bulkwalk (self, oid, timeout=None, retries=None, max_repeat=1024):

        # set the snmp session
        session = self.new_session(timeout=timeout, retries=retries)

        oid_pfx = oid+'.'
        var_list_full = []
        oid_l = []
        prev_start_oid = None
        start_oid = oid
        while start_oid and start_oid != prev_start_oid and (start_oid == oid or start_oid.startswith(oid_pfx)):
            prev_start_oid = start_oid
            varbind = netsnmp.Varbind(start_oid)
            var_list = netsnmp.VarList(varbind)

            # send the request
            session.getbulk(0, max_repeat, var_list)

            # timeout
            if session.ErrorInd == -24:
                self.timeout_detected = time.time()
                return None

            # prepare the response list.
            for x in var_list:
                if x.tag:
                    if x.tag.startswith(oid_pfx) and x.type != "ENDOFMIBVIEW":
                        # find the full numeric oid
                        if x.iid:
                            x.oid = x.tag + "." + x.iid
                        else:
                            x.oid = x.tag

                        start_oid = x.oid

                        # the __setattr__ function will always cast to 'str'
                        # otherwise, this would be: x.val = ...
                        x.__dict__["val"] = parseVal(x.val, x.type)

                        # add to output list
                        if x.oid in oid_l:
                            log.debug("dups")
                        oid_l.append(x.oid)
                        var_list_full.append(x)
                    else:
                        start_oid = None
                        break
                else:
                    break

        if start_oid != oid:
            return {x.oid:x.val for x in var_list_full}
        else:
            return {}

    def poll_queue (self, nugget_d, proxy=None):
        """ perform an snmp query """

        get_d = {}
        walk_d = {}

        if proxy:
            q_name = "%s/%s" % (proxy.name, self.device.name)
            device = proxy
        else:
            q_name = self.device.name
            device = self.device

        # compile the list of OIDs to query
        for nugget_name, nugget_entry in nugget_d.items():
            nugget_cfg = nugget_entry.cfg
            if nugget_cfg.get('oid_built'):
                if nugget_cfg.get("query_type") in ['walk', 'bulkwalk']:
                    walk_d[nugget_name] = {
                        'query_type': nugget_cfg.get('query_type'),
                        'oid': nugget_cfg['oid_built'],
                        'timeout': nugget_cfg.get('timeout', cfg.snmp_timeout),
                        'retries': nugget_cfg.get('retries', cfg.snmp_retries),
                        'max_repititions': nugget_cfg.get('max_repititions', cfg.snmp_bulkwalk_reps),
                    }
                else:
                    get_d[nugget_name] = {
                        'oid': nugget_cfg['oid_built'],
                        'timeout': nugget_cfg.get('timeout', cfg.snmp_timeout),
                        'retries': nugget_cfg.get('retries', cfg.snmp_retries),
                    }


        #
        # queue the SNMP GET query
        if get_d:
            opt = {
                'oid_l': [x['oid'].encode() for x in get_d.values()],
                'timeout': max([x['timeout'] for x in get_d.values()]),
                'retries': max([x['retries'] for x in get_d.values()]),
            }
            try:
                cfg.snmpEngine.add(q_name, device, opt)
            except Exception as e:
                log.exception("snmpEngine.add failed: %s" % e, "device", device=self.device)

        #
        # for snmp walks (consolidate)
        if walk_d:
            walk_oid_d = {}
            for nugget_name, opt in walk_d.items():
                oid = opt['oid']
                if oid not in walk_oid_d:
                    walk_oid_d[oid] = opt
                else:
                    walk_oid_d[oid] = {
                        'query_type': min(opt['query_type'], walk_oid_d[oid]['query_type']),
                        'oid': oid,
                        'timeout': max(opt['timeout'], walk_oid_d[oid]['timeout']),
                        'retries': max(opt['retries'], walk_oid_d[oid]['retries']),
                        'max_repititions': max(opt['max_repititions'], walk_oid_d[oid]['max_repititions']),
                    }

            for oid, opt in walk_oid_d.items():
                q = "%s/%s" % (q_name, opt['oid'])
                cfg.snmpEngine.add(q, device, opt, fn_name=opt['query_type'])


    def poll_read (self, nugget_d, poll_time, proxy=None):
        get_d = {}
        walk_d = {}

        if proxy:
            q_name = "%s/%s" % (proxy.name, self.device.name)
            device = proxy
        else:
            q_name = self.device.name
            device = self.device

        # compile the list of OIDs to query
        for nugget_name, nugget_entry in nugget_d.items():
            nugget_cfg = nugget_entry.cfg
            if nugget_entry.cfg.get('oid_built'):
                if nugget_cfg.get("query_type") in ['walk', 'bulkwalk']:
                    walk_d[nugget_name] = nugget_cfg['oid_built']
                else:
                    get_d[nugget_name] = nugget_cfg['oid_built']

        response_l = []
        error_l = []

        #
        # collect the GET responses
        if get_d:
            try:
                timestamp, response_d = cfg.snmpEngine.read(q_name)
            except SNMPEngine.SNMPEngineTimeout:
                log.error("SNMP Engine Timeout @ %s" % q_name,
                          "system", device=self.device, nugget_name=nugget_name)
                return []

            #
            # process get responses
            if 'Error' in response_d:
                if response_d.get("Error") == "Timeout":
                    device.snmp.timeout_detected = time.time()
                else:
                    log.error("SNMP Error: %s" % response_d['Error'],
                              "device", device=self.device)
            else:
                for nugget_name, oid in get_d.items():
                    try:
                        response = response_d.get(oid)['value']
                        if response is None:
                            error_l.append(nugget_name)
                        else:
                            response_l.append([nugget_name, timestamp, response])
                    except KeyError: continue

        #
        # collect walk responses
        if walk_d:
            walk_response = {}
            for oid in set(walk_d.values()):
                q = "%s/%s" % (q_name, oid)
                try:
                    walk_response[oid] = cfg.snmpEngine.read(q)
                except SNMPEngine.SNMPEngineTimeout:
                    log.error("SNMP Engine Timeout @ %s" % q_name,
                              "system", device=self.device)
                    return []
            #
            # process walk responses
            for nugget_name, oid in walk_d.items():
                timestamp, response_d = walk_response[oid]
                if 'Error' in response_d:
                    if response_d.get("Error") == "Timeout":
                        device.snmp.timeout_detected = time.time()
                    else:
                        error_l.append(nugget_name)
                else:
                    nugget_cfg = nugget_d[nugget_name].cfg
                    response = SNMPEngine.process(response_d, oid,
                                                  nugget_cfg.get("oid_style"),
                                                  nugget_cfg.get("index_decoder_built"),
                                                  nugget_cfg.get("type_filter"))
                    response_l.append([nugget_name, timestamp, response])

            # should we mark snmp up/down?
            if device is self.device or device is self.proxy:
                if response_l:
                    self.device.remove_code('snmp_down')
                elif error_l: # there were errors (and no success)
                    self.device.add_code('snmp_down')

        return response_l

