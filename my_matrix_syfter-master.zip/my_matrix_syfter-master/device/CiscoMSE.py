import json
import datetime, time
from django.utils import timezone

from nugget import Nugget
from common import utility
from common import config as cfg
from common import logger as log

from .Device import Device

class CiscoMSE(Device):
    def __init__(self, device_name):
        super().__init__(device_name)

        self.vc_login_period = None

        self.type = "CiscoMSE"

        self.snmp_supported = False

        self.modules = []
        modules_str = self.get('modules')
        if modules_str:
            self.modules = [x.strip() for x in modules_str.split(',')]

        if 'contextaware' in self.modules:
            self.nugget_cfg.update(Nugget.getNuggetConfig("CiscoMSE_contextaware"))
        elif 'presence' in self.modules:
            self.nugget_cfg.update(Nugget.getNuggetConfig("CiscoMSE_presence"))

    def is_up_check (self):
        return (self.rest_is_up() or self.is_pingable())

    def get_visitors (self):
        url = '/api/connect/reports/v1/summary/-1'
        return self.rest_get(url)

    # def get_clientProbingCount (self):
    #     #url = '/api/contextaware/v1/location/clients/count.json'
    #     url = '/api/location/v2/clients/count'
    #     return self.rest_get(url)['count']

    def get_clientLocationDetails (self):
        #
        # collect the client list
        url = '/api/location/v2/clients'
        return self.rest_get(url) or []

    def get_clientPresenceDetails (self):
        #
        # collect the client list
        url = '/api/presence/v1/clients'
        return self.rest_get(url) or []

    def get_clientVCLoginRate (self):
        end = int(time.time())
        start = end - self.vc_login_period

        return self.get_clientVCDetails(start, end, count_only=True) / (self.vc_login_period / 60)

    def get_clientVCDetails (self, start, end, count_only=False):
        url_prefix = '/api/connect/v1/clients'
        client_l = []
        index = 0

        #
        # collect the client list
        while True:
            count = 0
            url = '%s?index=%s&start=%s&end=%s' % (url_prefix, index, start*1000, end*1000)
            response = self.rest_get(url)
            if response:
                ret_client_l = response['records']

                # convert the timestamp strings?
                if not count_only:
                    tz_offset = response['timeZoneOffset'] // 1000
                    for client in ret_client_l:
                        last_login = client['lastLoginTime']
                        # print(last_login)
                        last_login_dt = utility.parse_time(last_login)
                        if tz_offset != -time.altzone:
                            last_login_dt = last_login_dt + datetime.timedelta(seconds=(-time.altzone - tz_offset))
                        client['last_login_time'] = utility.datetime_to_epoch(last_login_dt, local=True)
                        #print(client['last_login_time'])

                client_l += ret_client_l
                if len(ret_client_l) == response['queryRecordCount']:
                    index = response['nextIndex']
                else:
                    break
            else:
                break

        if count_only:
            return len(client_l)
        else:
            return client_l

    def get_clientPresenceProbingCount (self):
        """
        Collect the number of clients from presence
        """
        url = '/api/presence/v1/clients'
        client_count = 0

        # number of clients with associated False and either of passerBy or visitor set to True
        response = self.rest_get(url)
        if response:
            for client in response:
                if 'siteEntries' in client:
                    for key, val in client['siteEntries'].iteritems():
                        if (val['passerBy'] or val['visitor']) and not val['associated']:
                            client_count += 1

        return client_count

    def init_polling_config (self):
        """ DESCRIBE """

        # call the parent function
        super(CiscoMSE, self).init_polling_config()

        # store the login rate period
        if 'clientVCLoginRate' in self.nugget_d:
            self.vc_login_period = self.nugget_d['clientVCLoginRate'].interval

        if not self.modules:
            self.modules = ['cmx', 'location']

        self.nugget_d = {x:y for x,y in self.nugget_d.items()
                         if y.cfg['module'] in self.modules}

class CiscoCMX (CiscoMSE):
    def __init__(self, device_name):
        super(CiscoCMX, self).__init__(device_name)

        self.modules.append('cmx')

class CiscoCMXCloud (CiscoMSE):
    def __init__(self, device_name):
        super(CiscoCMXCloud, self).__init__(device_name)

        self.modules.append('cmx')

    def get_clientVCDetails (self, start, end, count_only=False):
        url_prefix = '/api/connect/v1/clients'
        client_l = []
        index = 0

        #
        # collect the client list
        while True:
            count = 0
            url = '%s?index=%s&start=%s&end=%s' % (url_prefix, index, start*1000, end*1000)
            response = self.rest_get(url)
            if response:
                ret_client_l = response['records']

                # convert the timestamp strings?
                if not count_only:
                    for client in ret_client_l:
                        if self.get("client_location") and self.get('client_location') != client['location/Site']:
                            continue
                        last_login = client['lastLoginTime']
                        last_login_dt = utility.parse_time(last_login)
                        client['last_login_time'] = utility.datetime_to_epoch(last_login_dt)

                client_l += ret_client_l
                if len(ret_client_l) == response['queryRecordCount']:
                    index = response['nextIndex']
                else:
                    break
            else:
                break

        if count_only:
            return len(client_l)
        else:
            return client_l
