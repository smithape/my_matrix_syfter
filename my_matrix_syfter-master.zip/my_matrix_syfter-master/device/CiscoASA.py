"""
File: CiscoASA.py
Class: CiscoASA
Parent: CiscoDevice

This module supports devices that run Cisco ASA.
"""

import sys, time, operator, os, collections
import re

from pkg import pexpect

from nugget import Nugget
from common import utility
from common import logger as log
from common import config as cfg
from .CiscoDevice import CiscoDevice, CiscoDeviceCli

class CiscoASA(CiscoDevice):
    def __init__(self, device_name, device_type = None):
        super().__init__(device_name, device_type)
        self.supported_actions += [
            "reboot",
            "loadconfig",
            "copyfrom",
            ]

        self.inside_ifindex = None
        self.inside_if = {}
        self.outside_ifindex = None
        self.outside_if = {}

        self.add_do_prefix_in_config_mode = False

    def init_cli (self):
        self.cli = CiscoAsaCli(self)

    def config_is_unsaved (self, session):
        """determine whether the device has unsaved configuration"""

        self.term_enable(session, required=True)

        session.sendline("reload")
        ret = session.expect(["modified", "confirm"])
        if ret == 0:
            session.send('n')
        session.send('n')
        session.expect("#")

        if ret == 0:
            return True
        else:
            return False

    def reboot (self, session):
        """perform a soft reset or 'reload' on the device"""

        self.term_enable(session, required=True)
        session.sendline("reload")

        while True:
            ret = session.expect(["modified",
                                  "confirm"
                                  ])
            if ret == 0:
                if (not self.force
                    and not utility.prompt("The device has unsaved config!"
                                            + " Continue?")):
                    # back out
                    session.send('n')
                    session.send('n')
                    session.expect('#')
                    return
                else:
                    session.send('n')
            else:
                session.send('y')
                session.expect(["#", pexpect.EOF])
                return

    def get_int_desc_entries (self, session, ldm_signature_re):
        """
        Get the list of currently configured descriptions
        (those with the ldm_signature_re prepended).
        """

        # first, get the list of all interfaces
        if_list = []
        session.sendline("show interface ip brief")
        regex = "\n([^\s]+[0-9]+)\s+[^\n]+" # find interfaces in output
        while True:
            ret = session.expect([regex, "#"])
            if ret == 1:
                break
            if_list += [session.match.group(1)]

        # next, we look at the running config of each interface
        # and determine whether it has an ldm description
        entries = collections.OrderedDict()
        for interface in if_list:
            session.sendline("show run int %s | inc desc" % interface)
            # This regex searches the output of the above command
            # for descriptions including the ldm_signature prefix
            regex = "description %s([^\n]+)\n" % ldm_signature_re
            ret = session.expect([regex, "#"])
            if ret == 0:
                description = session.match.group(1)
                entries[interface] = description
                session.expect("#")

        return entries

    def load_config (self, session, filename):
        """
        This will load a config file into the device's running-config
        """

        self.term_conf_t(session, required=True)

        session.sendline("clear configure all")
        session.expect("#")

        f = open(filename)
        for line in f:
            session.sendline(line)
            session.expect("#")
        session.sendline("end")
        session.expect("#")

    def copy_from (self, session, src_filepath, dst_filepath):
        """
        Copy a file from the device to the local file system.
        """

        filename = os.path.basename(dst_filepath)
        dirname = os.path.dirname(dst_filepath)

        server_ip = utility.get_local_ip()
        # spawn the ftp server that will recieve the file from the device
        # and write it to the specified directory
        server_port = utility.start_ftp_server_thread(dirname)

        src = src_filepath
        dst = ("ftp://%s:%s/%s" % (server_ip, server_port, filename))

        self.copy(session, src, dst)

    def query_nugget_vars(self):
        self.get_ifindexes()

    def get_ifindexes (self):
        # get names of inside/outside interfaces
        inside_ifname = self.get("inside_ifname", default="inside").lower()
        outside_ifname = self.get("outside_ifname", default="outside").lower()

        # remove whitespace and split at comma
        inside_ifname = re.sub(r'\s', '', inside_ifname).split(',')
        outside_ifname = re.sub(r'\s', '', outside_ifname).split(',')

        # run the query
        snmp_query = self.oid_map['ifName']
        snmp_response = self.snmp_walk(snmp_query)
        if not snmp_response:
            self.snmp_is_up(check=True)
            return

        for oid, val in snmp_response.items():
            # only consider valid responses
            if not val: continue
            ifname = val.lower()
            ifindex = int(oid.rsplit('.', 1)[-1])
            for name in inside_ifname:
                if ifname == name:
                    short_name = name.replace("inside", "").strip("_")
                    self.inside_ifindex = ifindex
                    self.inside_if[short_name] = ifindex
            for name in outside_ifname:
                if ifname == name:
                    short_name = name.replace("outside", "").strip("_")
                    self.outside_ifindex = ifindex
                    self.outside_if[short_name] = ifindex

        if not self.inside_ifindex:
            log.error("Can't find inside interface: \"%s\"" % inside_ifname, "config", device=self)
        if not self.outside_ifindex:
            log.error("Can't find outside interface: \"%s\"" % outside_ifname, "config", device=self)

    def init_polling_config (self):
        """ DESCRIBE """

        # call the parent function
        super(CiscoASA, self).init_polling_config()

        for nugget_name, nugget_entry in self.nugget_d.items():
            # handle multi-interface ASA inside/outside
            if (nugget_name.startswith("ethThroughputInside") or nugget_name.startswith("ethThroughputOutside")):
                if nugget_name.startswith("ethThroughputInside"):
                    if_d = self.inside_if
                elif nugget_name.startswith("ethThroughputOutside"):
                    if_d = self.outside_if
                if len(if_d) > 1:
                    nugget_entry.poll = False
                    for ifname, ifindex in if_d.items():
                        nugget_name_child = "%s:%s" % (nugget_name, ifname)
                        nugget_entry.indexes.append(nugget_name_child)
                        new_nugget_entry = cfg.init_nugget(self, nugget_name_child, nugget_entry.interval,
                                                           nugget_cfg = nugget_entry.cfg,
                                                           store = nugget_entry.store)
                        new_nugget_entry.init_thresholds(nugget_entry.threshold_cfg)
                        if 'oid_built' in nugget_entry.cfg and nugget_entry.cfg['oid_built']:
                            new_nugget_entry.cfg['oid_built'] = re.sub(r'{(in|out)side_ifindex}', str(ifindex), nugget_entry.cfg['oid'])
                        self.nugget_d[nugget_name_child] = new_nugget_entry
                    continue

    def track_cfg (self):
        # get the config
        s = self.cli.connect()
        s.sendline('term pager 0')
        #s.send('term len 0\r')
        s.expect(self.prompt_re)
        s.sendline("show run")
        s.expect(self.prompt_re)
        cfg_str = s.before
        s.close()

        # remove the show command (1st line)
        cfg_str = cfg_str.split('\r', 1)[1]
        # remove carriage returns
        cfg_str = re.sub(r'\r', '', cfg_str)
        # remove empty lines
        cfg_str = re.sub(r'^\n', '', cfg_str, flags=re.MULTILINE)
        # remove the checksum
        cfg_str = re.sub(r'^Cryptochecksum:.*\n', '', cfg_str, flags=re.MULTILINE)
        # edit out comments
        #cfg_str = re.sub(r'^[:|!].*\n', '', cfg_str, flags=re.MULTILINE)

        # write the file
        filepath = "%s/%s.cfg" % (cfg.config_tracker_dir, self.name)
        with open (filepath, 'w') as f:
            f.write(cfg_str)

    def gather_nugget_vars (self):
        for var in self.get_nugget_variables():
            if var == "ssid":
                self.nugget_var_d[var] = self.get_ssid_names()

    def get_ssid_names (self):
        ssid_names = self.get("ssid_list")
        ssid_names = [x.strip() for x in ssid_names.split(',')]
        ssid_d = {}
        for url in ssid_names:
            try:
                alias, url = [x.strip() for x in url.split("=")]
                url = re.sub(r'\s', '', url)
            except ValueError:
                url = re.sub(r'\s', '', url)
                alias = url

            ssid_d[alias] = url

        return ssid_d

    def get_nat_pool_per_ssid (self,text=None):

        grep_regex = re.compile(r'allocated\s+(\d+)')
        active_translations = None

        if text:
            matches = list(map(int,re.findall(grep_regex,text)))
            active_translations = sum(matches)

        return active_translations

class CiscoAsaCli(CiscoDeviceCli):
    def __init__(self, device):
        super().__init__(device)

    def clean_prompt (self, session):
        """For console, make sure there's no stale text on the line."""

        session.send('q')
        session.sendcontrol('u')

