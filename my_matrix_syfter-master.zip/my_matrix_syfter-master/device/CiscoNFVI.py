import time

from common import utility
from common import config as cfg
from common import logger as log

from .Device import Device

class CiscoNFVI (Device):
    def __init__(self, device_name):
        super().__init__(device_name)

        self.type = "CiscoNFVI"
        self.core_d = {}
        self.disk_d = {}
        self.rest_headers = {'content-type': 'application/vnd.yang.data+json',
                             'accept': 'application/vnd.yang.data+json'}

    def scan (self):
        d = {}
        response = self.rest_get('/api/operational/system-monitoring/vnf/disk/stats/disk-operations/1min?deep')

        if response:
            response = response['system_monitoring:disk-operations']['vnf']
            for i, val in enumerate(response):
                name = self.name + ':' + response[i]['name']
                d[name] = CiscoNFVI_VNF(name, i, parent=self)

        return d

    def get_core_d (self):

        core_d = {}
        response = self.rest_get('/api/operational/system-monitoring/host/cpu/table/cpu-usage/5min?deep')

        if response:
            response = response['system_monitoring:cpu-usage']['cpu']
            for i, val in enumerate(response):
                core_d[i] = i

        return core_d

    def get_disk_d (self):

        d = {}
        response = self.rest_get('/api/operational/system-monitoring/host/disk/stats/disk-space/1min?deep')

        if response:
            response = response['system_monitoring:disk-space']['mount-point']
            for i, val in enumerate(response):
                name = response[i]['name']
                d[name] = i

        return d

    def get_port_d (self):

        d = {}
        response = self.rest_get('/api/operational/system-monitoring/host/port/stats/port-usage/1min?deep')

        if response:
            response = response['system_monitoring:port-usage']['port']
            for i, val in enumerate(response):
                name = response[i]['name']
                d[name] = i

        return d

    def query_nugget_vars (self):
        self.core_d = self.get_core_d()
        self.disk_d = self.get_disk_d()
        self.port_d = self.get_port_d()

    def gather_nugget_vars (self):
        for var in self.get_nugget_variables():
            if var == "cpu_count":
                self.nugget_var_d[var] = len(self.core_d)
                log.info("Found %d cpus" % len (self.core_d), "config", device=self)
            elif var == "cpu_index":
                self.nugget_var_d[var] = self.core_d
            elif var == "disk":
                self.nugget_var_d[var] = self.disk_d
            elif var == "port":
                self.nugget_var_d[var] = self.port_d

class CiscoNFVI_VNF (CiscoNFVI):
    def __init__(self, device_name, vnf_index, parent=None):
        super(CiscoNFVI_VNF, self).__init__(device_name)

        self.type = "CiscoNFVI_VNF"
        self.vnf_index = vnf_index

        if parent:
            self.ip_address = parent.ip_address
            self.hostname = parent.hostname
            self.rest_headers = parent.rest_headers
            self.http_username = parent.get("http_username")
            self.http_password = parent.get("http_password")
            self.https_username = parent.get("https_username")
            self.https_password = parent.get("https_password")


    def get_core_d (self):

        d = {}
        response = self.rest_get('/api/operational/system-monitoring/vnf/vcpu/stats/vcpu-usage/1min?deep')

        if response:
            response = response['system_monitoring:vcpu-usage']['vnf'][self.vnf_index]['vcpu']
            for i, val in enumerate(response):
                d[i] = i

        return d

    def get_disk_d (self):

        d = {}
        response = self.rest_get('/api/operational/system-monitoring/vnf/disk/stats/disk-operations/1min?deep')

        if response:
            response = response['system_monitoring:disk-operations']['vnf'][self.vnf_index]['disk']
            for i, val in enumerate(response):
                name = response[i]['disk-name']
                d[name] = i

        return d

    def get_port_d (self):

        d = {}
        response = self.rest_get('/api/operational/system-monitoring/vnf/port/stats/port-usage/1min?deep')

        if response:
            response = response['system_monitoring:port-usage']['vnf'][self.vnf_index]['port']
            for i, val in enumerate(response):
                name = response[i]['port-name']
                d[name] = i

        return d

