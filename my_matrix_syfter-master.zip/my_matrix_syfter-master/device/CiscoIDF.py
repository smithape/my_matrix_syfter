import re

from .CiscoIOS import CiscoIOS

class CiscoIDF (CiscoIOS):
    def __init__(self, device_name):
        super().__init__(device_name)

        self.neighbor_scanned = False

    def neighbor_scan (self,timeout=10):
        # connect to CiscoIDF via ssh
        # collect all the cdp neighbors
        try:
            s = self.connect(access_method="ssh")
            s.send("show cdp neighbor detail | inc Device ID\r")
            s.expect(self.prompt_re, timeout)
            cfg_str = s.before
            cdp_neighbors_list = re.findall("Device ID:\s*(\S+)",cfg_str)
            s.close()
            self.neighbor_scanned = True
            return cdp_neighbors_list

        except Exception as e:
            self.neighbor_scanned = False
