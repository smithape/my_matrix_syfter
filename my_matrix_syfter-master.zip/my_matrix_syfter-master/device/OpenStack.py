import re
import yaml
import json
from .Linux import Linux_RHEL
from .OpenStack_UCS import OpenStack_UCS
from common import logger as log

class OpenStack (Linux_RHEL):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.undercloud = None
        self.overcloud = None
        self.node_username = None
        self.node_password = None
        self.ipmi_username = None
        self.ipmi_password = None

    def find_child_class (self, dtype):
        for x in self.descendant_class_l:
            if dtype in x.__name__.lower():
                return x

    def scan (self):
        d = {}
        self.cli.set_session()
        if not self.cli.is_alive():
            return {}

        # verify overcloud/undercloud scripts
        for x in ['undercloud', 'overcloud']:
            rc = self.get("%s_rc" % x).strip()
            if rc and rc == self.cli.get_response("ls %s" % rc).strip():
                name = self.name + ':' + x
                fn = self.find_child_class(x)
                node = fn(name)
                node.ip_address = self.ip_address
                node.hostname = self.hostname
                node.username = self.get("username")
                node.password = self.get("password")
                node.post_connect_commands = self.get("cli_post_connect_commands", default=[]).copy()
                node.post_connect_commands.append('source %s' % rc)
                node.init_io()
                d[name] = node
                setattr(self, x, node)
            else:
                log.error("%s script missing! (%s)" % (x.capitalize(), rc), "device", device=self)
                if x == "undercloud":
                    return {}

        # connect to undercloud so we can parse the nova list
        self.undercloud.cli.set_session()
        if not self.undercloud.cli.is_alive():
            return {}

        self.parse_inventory(d)

        # add cimc
        response = self.undercloud.cli.get_response('cat /opt/cisco/usp/ultram-manager/servinv.cfg')
        for ip, name in re.findall('([\d.]+)\|(.+)\r', response):
            name = ':'.join([self.name, name, "ucs"])
            node = OpenStack_UCS(name)
            node.ip_address = ip
            node.username = 'admin'
            node.password = self.get("password")
            node.snmp_community = "public"
            node.jump_server = self.get_address()
            node.jump_server_type = self.type
            node.jump_server_username = self.get("username")
            node.jump_server_password = self.get("password")
            node.init_io()
            d[name] = node

        return d

    node_type_map = {
        'ctrl': 'controller',
        'compute': 'compute',
        'osd': 'osdcompute'
    }

    def search_for_children (self, d, node_type = None, children = None):
        for key, val in d.items():
            if key == "hosts" and node_type:
                for node_name, node_d in val.items():
                    children[node_name] = {
                        'type': self.find_child_class(self.node_type_map[node_type]),
                        'ip_address': node_d['ansible_ssh_host'],
                        'username': self.node_username,
                        'password': self.node_password
                    }
                    children[node_name + '-ipmi'] = {
                        'type' : OpenStack_UCS,
                        'ip_address': node_d['ansible_ipmi_ip'],
                        'username': self.ipmi_username,
                        'password': self.ipmi_password
                    }
            else:
                if key in self.node_type_map.keys():
                    node_type = key
                elif key == "ansible_user":
                    self.node_username = val
                elif key == "ipmi_user":
                    self.ipmi_username = val
                elif key == "ipmi_passwd":
                    self.ipmi_password = val

                if isinstance(val, dict):
                    # recurse
                    self.search_for_children(val, node_type = node_type, children = children)
                
        
    def parse_inventory (self, d):
        inventory_file = self.get("inventory_file").strip()
        response = self.undercloud.cli.get_response('cat %s' % inventory_file)

        if isinstance(response, str):
            inv = yaml.full_load(response)['all'] or {}

            # discover child nodes
            children = {}
            self.search_for_children(inv, children=children)

            for node_name, node_d in children.items():
                node_name = self.name + ':' + node_name
                fn = node_d['type']
                node = fn(node_name)
                node.ip_address = node_d['ip_address']
                node.jump_server = self.get_address()
                node.jump_server_type = self.type
                node.jump_server_username = self.get("username")
                node.jump_server_password = self.get("password")
                node.jump_server_cli_post_connect_commands = self.get("cli_post_connect_commands")
                node.username = node_d['username']
                node.password = node_d['password']
                node.init_io()
                d[node_name] = node

