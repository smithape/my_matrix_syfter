import sys
import re
import time
import socket

from pkg import pexpect
from common import config as cfg
from common import logger as log
from common import utility
from common.exception import NuggetNotSupported

class DeviceCli (object):
    prompt_re = re.compile(b'([\n\r]+)([^\r\n]*[#>%\$])')

    def __init__(self, device):
        self.device = device
        self.session = None
        self.command_cache = {}

        # a generic prompt regex
        self.prompt = None

        # for filtering CLI output
        self.filter_command = "grep"

        # commands to run after connecting
        self.post_connect_commands = []

    def get_all_post_connect_commands (self):
        command_l = []

        # add the user-defined commands
        commands = self.device.get("cli_post_connect_commands")
        if commands:
            if isinstance(commands, str):
                commands = commands.split(';')

            command_l.extend(commands)

        # add the device-level commands
        command_l.extend(self.device.get("post_connect_commands"))

        # add the device cli commands
        command_l.extend(self.post_connect_commands)

        return command_l

    def is_alive (self):
        return self.session and self.session.isalive()

    def is_up (self):
        connect_method = self.device.get("connect_method", default=cfg.connect_method)
        if connect_method == "ssh":
            return self.ssh_is_up()
        elif connect_method == "telnet":
            return self.telnet_is_up()

    def ssh_is_up (self):
        address = self.device.get("jump_server") or self.device.get_address()
        if not address:
            return False

        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(1)

        # check ssh
        port = int(self.device.get("ssh_port", default=22))
        try:
            if sock.connect_ex((address, port)) == 0:
                return True
        except socket.gaierror: pass
        finally:
            sock.close()
        return False

    def telnet_is_up (self):
        address = self.device.get("jump_server") or self.device.get_address()
        if not address:
            return False

        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(1)

        # check telnet
        port = int(self.device.get("telnet_port", default=23))
        try:
            if sock.connect_ex((address, port)) == 0:
                return True
        except socket.gaierror: pass
        finally:
            sock.close()
        return False

    username_re = re.compile(b'(?:user|name|user\s*name|login):\s*(?!.+)', flags=re.I)
    password_re = re.compile(b'password:[^\n\r]*', flags=re.I)
    def connect_login (self, session, required=False, timeout=None):
        """
        The automation function for logging into devices.

        session: the current session
        required: True if the action requires successful login (automation)
        """
        timeout = timeout or cfg.cli_connect_timeout
        #session.logfile = sys.stdout

        # if login is required, set a higher timeout
        if required:
            timeout = cfg.pexpect_login_timeout;

        login_attempts = 0
        login_successful = False

        while True:
            if login_attempts > 1:
                break

            ret = session.expect_list([self.username_re, # 0
                                       self.password_re, # 1
                                       self.prompt_re,   # 2
                                       pexpect.TIMEOUT], # 3
                                      timeout = timeout)
            if ret < 3:
                after = session.after
                match = session.match.group(0)

                if after.endswith(match): # make sure we're at the end
                    if ret == 0:
                        username = self.device.get("username", required=required)
                        if not username:
                            break
                        session.send("%s\r" % username)
                    elif ret == 1:
                        password = self.device.get("password", required=required)
                        if not password:
                            break
                        session.send("%s\r" % password)
                        login_attempts += 1
                    elif ret == 2:
                        login_successful = True
                        break
            else: # timeout
                if required:
                    utility.error("Connection timeout!")
                else:
                    break

        if required and not login_successful:
            session.close()
            utility.error("Device login failed!")
        else:
            return login_successful

    def connect_misc (self, session, required=True):
        """
        placeholder to perform platform-specific operations after a connection
        is made
        """
        command_l = self.get_all_post_connect_commands()
        for command in command_l:
            session.send("%s\r" % command)
            session.expect_list([self.prompt_re])

    def init_webterm (self):
        try:
            self.session_read_to_end()
            self.session.sendcontrol('u')
        except Exception as e:
            # try to init the session
            if not self.set_session():
                return False

        return True

    def clean_prompt (self, session):
        """For console, make sure there's no stale text on the line."""

        session.send('q')
        session.sendcontrol('u')
        session.sendcontrol('c')

    def connect_console (self):
        """Connect to the console port of a device via it's termserver"""

        [ts_hostname, ts_port] = self.device.get("console", size=2, required=True)
        termserver = cfg.device_tree[ts_hostname]
        ts_ip_address = termserver.get("ip_address", required=True)

        line = str(int(ts_port))
        session = pexpect.spawn("telnet %s %s" % (ts_ip_address, line),
                                use_epoll=cfg.pexpect_use_epoll)
        #session.logfile = sys.stdout

        # determine whether the connection failed
        ret = session.expect([r"\^]'\.", r"refused"])

        if ret == 1:
            return None

        # These lines are to ensure that we start with a clean prompt and
        # don't accidentally execute leftover commands etc.
        self.clean_prompt(session)

        # This will disable tty echo, and also clear the input buffer
        session.setecho(False)

        # This will consume all of the existing text on the console stream
        self.session_read_to_end(session)

        # Console will only show output if we send \r
        session.send("\r")

        return session


    def connect_telnet (self, session=None):
        """Connect to the device via telnet"""

        address = self.device.get_address(required=True)
        port = self.device.get("telnet_port")

        # generate the telnet command
        command = "telnet %s" % address
        if port:
            command += " %s" % port

        if session:
            session.send("%s\r" % command)
        else:
            session = pexpect.spawn(command,
                                    use_epoll=cfg.pexpect_use_epoll,
                                    env = {"TERM": "dumb"})

        return session

    def connect_ssh (self, session=None):
        """Connect to the device via ssh"""

        address = self.device.get_address(required=True)
        port = self.device.get("ssh_port")
        options = self.device.get("ssh_options") or ""
        username = self.device.get("username", required=True)

        # generate the ssh command
        command = 'ssh %s %s %s@%s' % (cfg.ssh_options, options, username, address)
        if port:
            command += " -p %s" % port

        if session:
            session.send("%s\r" % command)
        else:
            session = pexpect.spawn(command,
                                    use_epoll=cfg.pexpect_use_epoll,
                                    env = {"TERM": "dumb"})

        return session

    def connect (self, access_method="", interact=False):
        """
        This is the top-level function for connecting to devices.

        It will call other connect methods such as connect_console.

        Args:
          access_method: if this is defined, it will dictate the connection
                         method to use.
          interact: true if this connection is meant for human interaction
                    false if it's for automation.
        """

        if not access_method:
            access_method = self.device.get("automated_connect_method")
        if not access_method:
            access_method = self.device.get("connect_method",
                                     default=cfg.connect_method)
        if not access_method:
            utility.error("connect_method undefined!")

        # build the connect function name
        connect_fn = "connect_%s" % access_method

        # check for jump server
        jump_server = self.device.get("jump_server")
        if jump_server:
            # initialize the jump server object
            jmp = cfg.init_device_object(jump_server, self.device.get("jump_server_type"))
            # set it's parameters
            if not utility.is_valid_ip_address(jmp.name):
                jmp.hostname = jump_server
            jmp.username = self.device.get("jump_server_username")
            jmp.password = self.device.get("jump_server_password")
            jmp.cli_post_connect_commands = self.device.get("jump_server_cli_post_connect_commands")

            # connect/login to jump server
            try:
                jmp.cli.session = jmp.cli.connect()
                jmp.cli.set_prompt()
            except Exception as e:
                utility.error("Jump Server Error!%s" % e)

            # jump to end device
            session = getattr(self, connect_fn)(jmp.cli.session)
        else:
            # for automated console connections, we need to clear the line
            if access_method == "console" and not interact:
                self.clear_my_line()

            # connect to host
            session = getattr(self, connect_fn)()
            if not session: return None

        # login
        login_successful = self.connect_login(session, required=(not interact))

        if login_successful:
            self.connect_misc(session, required=(not interact))

        if session and interact:
            print("Escape character is '^]'")
            try:
                # print out the last line of the stream for the user to
                # see (usually a prompt)
                #string = session.before + session.after
                #start = string.rfind("\r") + 1
                #string = string[start:]
                # remove newlines and carriage returns
                #string = re.sub(r'\n', '', string)
                #string = re.sub(r'\r', '', string)
                # write out the line
                #sys.stdout.write("\n"+string)
                session.send("\r")

                session.interact()
                session.close()
                print("") # make sure the prompt is on a new line
            except OSError:
                pass
        return session

    def expect_prompt (self, timeout):
        self.session.expect_exact(self.prompt,
                                  searchwindowsize = self.prompt_searchwindowsize,
                                  timeout=timeout)

    def set_prompt (self):
        self.session.send('\r')
        timeout = cfg.cli_timeout
        while True:
            ret = self.session.expect_list([self.prompt_re,
                                            pexpect.TIMEOUT],
                                           timeout=timeout)
            if ret == 0:
                self.prompt = self.session.match.group(2)
                self.prompt_searchwindowsize = max(len(self.prompt) + 1, 32)
                # set the timeout lower for next ieteration
                timeout = 0.1
            elif ret == 1:
                break

    def set_session (self, quiet=False):
        """connect to device and set the session variable"""
        err_msg = ''

        if self.is_up():
            try:
                if not self.is_alive():
                    self.session = self.connect()
                    self.set_prompt()

                # success, remove code
                self.device.remove_code('term_fail', quiet=quiet)
                return True
            except pexpect.EOF as e:
                err_msg = "Connection refused"
                # try to extract useful info from the error
                error_re = r"before[^:]*:\s*'([^']+)"
                match = re.search(error_re, str(e))
                if match:
                    err_msg += ": %s" % match.group(1)
            except pexpect.TIMEOUT:
                err_msg = "Timeout exceeded"
                self.device.add_code('term_down', quiet=quiet, txt=err_msg)
                return
            except Exception as e:
                err_msg = e
        else:
            err_msg = "Not Reachable"

        # failure, add code
        self.device.add_code('term_fail', quiet=quiet, txt=err_msg)
        return False

    def close_session (self):
        # stop the terminal session
        try:
            self.session.close()
        except AttributeError: pass

    def monitor_session (self):
        # check the session
        if not self.is_alive():
            log.info("Starting new cli session", "device", device=self.device)
            if not self.set_session():
                # if we can't get a session, remove the CLI Nugget entries
                self.device.update_polling_config()
                return False

        return True

    def session_keepalive (self, timeout=10):
        try:
            # check the session
            if not self.monitor_session():
                return

            self.session.send('\r')
            self.session.expect_exact(self.prompt, timeout=timeout)
        except OSError:
            log.exception("CLI Exception: OSError (probably a buffer overflow)",
                          "device", device=self.device)
            self.close_session()
        except (pexpect.EOF, pexpect.TIMEOUT):
            log.exception("CLI Exception: session closed",
                          "device", device=self.device)
            self.close_session()

    def session_read_to_end (self, session = None, timeout=0):
        """
        Advance to the current end of the input stream.

        timeout: How long to wait for new text before assuming we're at the end.
        """

        session = session or self.session

        ret = b''
        while True:
            try:
                ret += session.read_nonblocking(timeout=0)
            except pexpect.TIMEOUT:
                break

        return ret

    def cli_prescrape (self, nugget_d):
        """
        The first phase of CLI scraping: send commands and store
        the text response

        @param nugget_d: dictionary of cli Nuggets to scrape
        @param timeout: the cli response timeout
        """

        #
        # create composite commands, combining similar commands where possible
        cache_key = ','.join(list(nugget_d.keys()))
        try:
            full_command_d = self.command_cache[cache_key]
        except KeyError:
            # find all Nuggets sharing the same root command and compile
            # all of their filters
            command_d = {}
            for nugget_name, entry in nugget_d.items():
                command = entry.cfg['command_built']
                if command not in command_d:
                    command_d[command] = {
                        'filters': set(),
                        'timeout': 0,
                        }

                # update the timeout (maximum of any LPIs)
                command_d[command]['timeout'] = max(command_d[command]['timeout'],
                                                    entry.cfg.get("timeout", cfg.cli_timeout))

                # add to the list of filters required
                if 'filter' in entry.cfg:
                    command_d[command]['filters'].update(entry.cfg['filter'])

            # build the full commands (adding all filters)
            full_command_d = {}
            for command, x in command_d.items():
                if x['filters']:
                    full_command_d[command] = ("%s | %s %s" % (command, self.filter_command, '|'.join(filters)),
                                               x['fimeout'])
                else:
                    full_command_d[command] = (command, x['timeout'])

            # add to cache for next time
            self.command_cache[cache_key] = full_command_d

        #
        # execute the commands, store the response
        text_d = {}
        s = self.session
        for command, (full_command, timeout) in full_command_d.items():
            try:
                text_d[command] = self.get_response(command, timeout=timeout)
            except:
                self.close_session()
                break

        return text_d

    def get_response (self, command, timeout=10):
        #log.debug("get_response: %s/%s" % (command, timeout))

        try:
            self.session.send("%s\r" % command)
            # collect the response
            response = b''
            while True:
                self.expect_prompt(timeout)
                response += self.session.before
                if self.session.before[-1] in [10, 13]:
                    break
            try:
                return response.decode().strip().split('\n', 1)[-1]
            except IndexError:
                return ""
        except pexpect.TIMEOUT:
            # cancel the command
            self.session.sendcontrol('c')
            self.expect_prompt(timeout)
            return pexpect.TIMEOUT
        except pexpect.EOF:
            log.exception("CLI Exception: session closed",
                          "device", device=self.device)
        except OSError:
            log.exception("CLI Exception: OSError (probably a buffer overflow)",
                          "device", device=self.device)
        except Exception as e:
            log.exception("CLI Exception: unexpected issue",
                          "device", device=self.device)
            raise

        raise

    def cli_scrape (self, nugget_entry, text=None, timeout=10):
        ret_val = None
        nugget_cfg = nugget_entry.cfg

        if not text:
            s = self.session

            # issue the command
            if nugget_cfg.get('filter'):
                command = "%s | %s %s" % (nugget_cfg['command_built'], self.filter_command, '|'.join(nugget_cfg['filter']))
            else:
                command = nugget_cfg['command_built']

            text = self.get_response(command, timeout=timeout)

            if text is pexpect.TIMEOUT:
                return None

        # initialize the text list
        data = text

        # line filter
        try:
            data = nugget_entry.filter_by_line(data)
        except Exception as e:
            log.exception("CLI Error in line filtering: %s" % e,
                          "device", device=self.device, nugget_name=nugget_entry.name)
            return None

        # extract/parse the value(s)
        parse = nugget_cfg.get('parse_built')
        if parse:
            try:
                data = parse(data, nugget_cfg)
            except Exception as e:
                log.exception("CLI Error in parse phase: %s" % e,
                              "device", device=self.device, nugget_name=nugget_entry.name)
                return None

        # try to convert string to number
        if not isinstance(data, (int, float)):
            try: # try INT
                data = int(data)
            except:
                try: # try FLOAT
                    data = float(data)
                except: pass

        return data

    def poll (self, nugget_d):
        """
        CLI poll the Nuggets given in nugget_d
        """

        response_l = []

        # check the session
        if not self.monitor_session():
            return []

        # clean the buffer
        try:
            junk = self.session_read_to_end()
        except pexpect.EOF:
            log.exception("CLI Exception: session closed",
                          "device", device=self.device)
            self.close_session()


        # scrape phase 1 (collection)
        text_d = self.cli_prescrape(nugget_d)

        # scrape phase 2 (parsing)
        for nugget_name, entry in nugget_d.items():
            try:
                text = text_d[entry.cfg['command_built']]

                if text is pexpect.TIMEOUT:
                    response = None
                    log.exception("CLI Timeout",
                                  "device", device=self.device, nugget_name=nugget_name)
                elif 'get_fn' in entry.cfg:
                    fn_name = entry.cfg['get_fn']
                    fn = getattr(self.device, fn_name)
                    response = fn(text)
                else:
                    response = self.cli_scrape(entry, text=text)

                response_l.append([nugget_name, int(time.time()), response])
            except NuggetNotSupported:
                log.info("Nugget not supported", "device",
                         device=self.device, nugget_name=nugget_name)
                self.device.nugget_d[nugget_name].enabled = False
            except Exception as e:
                log.exception("CLI Exception: %s" % e,
                              "device", device=self.device, nugget_name=nugget_name)

        if response_l:
            self.device.remove_code("term_down")
        else:
            self.device.add_code("term_down")

        return response_l

