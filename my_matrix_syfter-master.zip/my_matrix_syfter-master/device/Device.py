"""
File: Device.py
Class: Device
Parent: Item

This module represents the most generic type of device.

It contains functions that are common to all other device classes.
"""
import math
import os, sys
import time
import re
import socket
import subprocess
from pkg import pexpect
from fractions import gcd
from threading import Thread
from collections import OrderedDict
from functools import reduce
from django.utils import timezone
from datetime import datetime
import yaml
import json
import inspect

from nugget import Nugget
from common import PeriodicThread
from common import config as cfg
from common import DB
from common import logger as log
from common import utility
from common.exception import ConfigError, NuggetNotSupported

from .Item import Item
from .DeviceCli import DeviceCli
from .DeviceRest import DeviceRest
from .DeviceGrpc import DeviceGrpc
from .DeviceSnmp import DeviceSnmp

codes = {
    'invalid' : {
        'type' : "config",
        'sev' : 50,
        'msg' : "Device Invalid",
        'msg_rm' : "Device Valid",
        'overrides' : ['down', 'snmp_timeout', 'snmp_down',
                       'term_down', 'term_fail',
                       'switch', 'switch_if'],
        },
    'down' : {
        'type' : "device",
        'sev' : 50,
        'msg' : "Device Unreachable",
        'msg_rm' : "Device Reachable",
        'overrides' : ['snmp_timeout', 'snmp_down',
                       'term_down', 'term_fail',
                       'switch', 'switch_if'],
        },
    'snmp_timeout' : {
        'type' : 'device',
        'sev' : 30,
        'msg' : "SNMP timing out",
        'msg_rm' : "SNMP OK",
        'overrides' : [],
        },
    'snmp_down' : {
        'type': 'config',
        'sev' : 40,
        'msg' : "SNMP not responding",
        'msg_rm' : "SNMP OK",
        'overrides' : ['snmp_timeout'],
        },
    'switch' : {
        'type': 'config',
        'sev' : 40,
        'msg' : "Can't find upstream switch",
        'msg_rm' : "Upstream switch found",
        'overrides' : ['switch_if'],
        },
    'switch_if' : {
        'type': 'config',
        'sev' : 40,
        'msg' : "Can't find upstream switch interface",
        'msg_rm' : "Upstream switch interface found",
        'overrides' : []
        },
    'term_fail' : {
        'type' : "config",
        'sev' : 40,
        'msg' : "Terminal session failed",
        'msg_rm' : "Terminal session connected",
        'overrides' : ['term_down'],
        },
    'term_down' : {
        'type' : "device",
        'sev' : 40,
        'msg' : "Terminal not responding",
        'msg_rm' : "Terminal OK",
        'overrides' : [],
        },
    }

class Device(Item):
    def __init__(self, device_name, device_type = None):
        super().__init__(device_name, device_type)
        self.supported_actions += [
            "connect",
            ]

        self.model = None
        self.ip_address = self.get("ip_address")
        self.hostname = self.get("hostname")
        self.mac_address = None
        self.ts = None
        self.last_touch = None
        self.nugget_d = {} # the polling config
        self.poll_thread = None
        self.error_codes = codes.copy()
        self.code_d = {}
        self.db_entry = None
        self.nugget_var_d = {}
        self.nugget_function_d = {}

        self.nugget_cfg = {}
        self.oid_map = {}
        # read nugget configs
        for x in self.ancestor_l:
            self.oid_map.update(Nugget.getOIDMap(x))
            self.nugget_cfg.update(Nugget.getNuggetConfig(x))

        # offset for polling_thread timing
        self.poll_thread_offset = 0

        # device groups
        self.group_d = {}
        self.manual_group_l = []
        groups = self.get("group") or self.get("groups")
        if groups:
            # remove whitespace
            groups = re.sub(r'\s', '', groups)
            # split into list
            self.manual_group_l = groups.split(',')

        # if no index is configured, a default will be used
        self.db_index = ''

        # by default, we assume it's a discovered device
        self.configured = False
        self.cfg = {}

        self.nugget_vars_update = False
        self.last_nugget_vars_update = int(time.time())

        # commands to run after connecting
        self.post_connect_commands = []

        # jump server
        self.jump_server = None
        jump_server = self.get("jump_server")
        if jump_server:
            self.jump_server = cfg.init_device_object(jump_server,
                                                      self.get("jump_server_type"))

        # IO modules
        self.init_io()

    def __repr__(self):
        address = self.get_address()
        s = self.name
        if address:
            s += "/%s" % address

        return s

    def init_io (self):
        self.init_cli()
        self.init_snmp()
        self.init_rest()
        self.init_grpc()

    def init_cli (self):
        self.cli = DeviceCli(self)

    def init_rest (self):
        self.rest = DeviceRest(self)

    def init_grpc (self):
        self.grpc = DeviceGrpc(self)

    def init_snmp (self):
        self.snmp = DeviceSnmp(self)

    def init_config (self):
        try:
            self.cfg = cfg.config['site'][self.name]
            default_block = cfg.config['site']['defaults']
            default_cfg = {}
            # add the root options
            default_cfg.update({x:y for x,y in default_block.items() if not isinstance(y, dict)})
            for cls in self.ancestor_l:
                if cls in default_block:
                    default_cfg.update(default_block[cls])

            for opt, val in default_cfg.items():
                if opt not in self.cfg:
                    self.cfg[opt] = val

        except KeyError: pass

    def set_groups (self):
        self.group_d = {}
        for group_name, group in cfg.group_d.items():
            if group.parent is None and group.contains_device(self):
                self.group_d[group.name] = group
                if group.db_index:
                    self.db_index = group.db_index
                # subgroups
                for child in group.children:
                    if child.contains_device(self):
                        self.group_d[child.name] = child

    def get_device_d (self, full=False):
        d = {
            'name' : self.name,
            'type' : self.type,
            'model' : self.model,
            'ip_address' : self.ip_address,
            "hostname": self.hostname,
            'mac_address' : self.mac_address,
            'has_login_creds' : self.get('username'), # and self.get('password'),
            'snmp_supported' : self.snmp and self.snmp.is_configured(),
            'rest_supported' : bool(self.rest),
            'groups' : [x.name for x in self.group_d.values() if x.name != "AP"],
            'db_index': self.db_index,
            'track_config': self.get("track_config")
            }

        try:
            d['id'] = self.db_entry.id
        except AttributeError: pass
            #log.debug("Device has no db_entry: %s" % self.name)

        if full:
            d.update({
                'connect_method': self.get('connect_method'),
                'post_connect_commands': self.get('post_connect_commands'),
                'username': self.get('username'),
                'password': self.get('password'),
                'rest_username': self.get('rest_username'),
                'rest_password': self.get('rest_password'),
                'jump_server': self.get('jump_server'),
                'jump_server_type': self.get('jump_server_type'),
                'jump_server_username': self.get('jump_server_username'),
                'jump_server_password': self.get('jump_server_password'),
                'jump_server_cli_post_connect_commands': self.get('jump_server_cli_post_connect_commands'),
                'class': type(self).__name__
                })

            if d['snmp_supported']:
                d.update({'snmp_params': self.snmp.config_d})

        return d

    def get_device_status (self):

        d = {}
        for nugget_name, entry in self.nugget_d.items():
            try:
                entry_cfg = self.nugget_cfg[nugget_name]
            except: continue
            if 'status_idx' in entry_cfg:
                if 'members' in entry_cfg:
                    d[nugget_name] = {}
                    child_d = OrderedDict()
                    for child in entry.cfg['members']:
                        child_name = "%s_%s" % (nugget_name, child)
                        try:
                            child_entry = self.nugget_d[child_name]
                            child_d[child] = child_entry.get_status()
                        except: pass
                    d[nugget_name]['children'] = child_d
                else:
                    d[nugget_name] = entry.get_status()

                d[nugget_name]['idx'] = entry_cfg['status_idx']

        d = OrderedDict(sorted(d.items(), key=lambda x: x[1]['idx']))
        return d

    def has_connections_defined (self):
        """
        Returns whether or not the config file contains connection
        information about this device.
        """

        # first check if we have any connections defined locally
        [local_if,  remote_hostname, remote_if] = self.get("connection0", size=3)
        if local_if and remote_hostname and remote_if:
            return True

        # next, check if other configs references this device
        for key, device in cfg.device_tree.items():
            # connections
            i = 0
            while (True):
                [local_if,  remote_hostname, remote_if] = device.get("connection%s" % i, size=3)
                if local_if and remote_hostname and remote_if:
                    if remote_hostname == self.name:
                        return True
                    else:
                        i += 1
                else:
                    break

        return False

    def get_interface_dict (self):
        """
        Use connection information from the config file to compile a dictionary
        of local interfaces and the devices on the other end.
        """

        if_dict = {}

        # first get connections defined in the device's config
        i = 0
        while (True):
            [local_if,  remote_hostname, remote_if] = self.get("connection%s" % i, size=3)
            if local_if and remote_hostname:
                if_dict[local_if] = (remote_hostname, remote_if)
                i += 1
            else:
                break

        # next get connections configured on other devices
        for key, device in cfg.device_tree.items():
            # connections
            i = 0
            while (True):
                [local_if,  remote_hostname, remote_if] = device.get("connection%s" % i, size=3)
                if remote_hostname and remote_if:
                    if remote_hostname == self.name:
                        if_dict[remote_if] = (device.name, local_if)
                    i += 1
                else:
                    break

        return if_dict

    def snmp_get_hostname (self):
        hostname = None

        snmp_query = self.oid_map['sysName']
        snmp_response = self.snmp_get([snmp_query], timeout=5, retries=1)

        if snmp_response:
            hostname, = snmp_response
            # change the name in the device dict
            if hostname not in cfg.device_d:
                try:
                    # update the global dict
                    del cfg.device_d[self.name]
                    cfg.device_d[hostname] = self
                    # set the new name
                    self.name = hostname
                    self.hostname = hostname
                except KeyError: pass
            else:
                log.info("Hostname (%s) already exists! Using IP address for name" % hostname,
                         "config", device=device)
        else:
            self.snmp_is_up(check=True)

        return hostname

    def show_interfaces (self):
        """
        Display connection information for this device.
        """

        output = ""

        if_dict = self.get_interface_dict()
        sorted_if_list = utility.natural_sort(list(if_dict.keys()))

        # find the longest string length for the local interface
        # (this is used for column indentation/alignment)
        indent = 9 # start with 9 because of the "Interface" header below
        for local_if in sorted_if_list:
            indent = max(indent, len(local_if))

        indent += 4
        output += "%s %s\n" % ("Interface".ljust(indent), "Remote:Interface")
        output += "%s %s\n" % ("=========".ljust(indent), "================")
        for local_if in sorted_if_list:
            (remote_hostname, remote_if) = if_dict[local_if]
            output += "%s %s"% (local_if.ljust(indent), remote_hostname)
            if remote_if:
                output += ":%s" % remote_if
            output += "\n"

        return output

    def is_locked (self):
        """does the device have the 'locked' option configured as True?"""

        locked = self.get("locked")
        if locked and locked.lower() == "true":
            return True
        else:
            return False

    def is_up (self, check=False):
        if check:
            if self.is_up_check():
                self.remove_code('down')
                return True
            else:
                self.add_code('down')
                return False
        else:
            return not ('down' in self.code_d)

    def is_up_check (self):
        return (self.snmp_is_required() and self.snmp.is_up(check=True)) or self.is_pingable()

    def get_state (self):
        if not self.is_up():
            return "Down"
        else:
            return "OK"

    def is_pingable (self):
        address = self.jump_server or self.get_address()
        if not address:
            return False

        # ping once with a timeout of 1 second
        command = 'ping -c 1 -w 1 %s' % address
        with open(os.devnull, 'w') as devnull:
            code = subprocess.call(command.split(),
                                   stdout=devnull,
                                   stderr=devnull)

        return (code == 0)

    def clear_my_line (self):
        """
        This will use the termserver information to login and clear the line
        for this device.
        """

        [ts_hostname, ts_port] = self.get("console", size=2, required=True)
        termserver = cfg.device_tree[ts_hostname]

        termserver.clear_line(ts_port)

    def get_polling_cfg (self):
        # from the polling config (type)
        polling_cfg = cfg.get_polling_cfg(self.type) or {}
        # from the polling config (device)
        device_polling_cfg = cfg.get_polling_cfg(self.name) or {}
        polling_cfg.update(device_polling_cfg)
        # from the device config block
        device_polling_cfg = self.get('polling_config') or {}
        polling_cfg.update(device_polling_cfg)

        return polling_cfg

    def snmp_is_required (self):
        return self.polling_cfg_includes_type('snmp') and self.snmp.is_configured()

    def cli_session_required (self):
        return (self.polling_cfg_includes_type('cli') or self.polling_cfg_includes_type('file')) and self.cli_polling_enabled()

    def cli_polling_enabled (self):
        for f in cfg.cli_poll_filter:
            if f in self.name.lower():
                return True

        return False

    def polling_cfg_includes_type (self, poll_type):
        """
        Determine whether or not this device needs a terminal session
        """

        for x in self.nugget_d.values():
            if x.type == poll_type:
                return True

        return False

    def get_polling_interval (self):

        # get the list of enabled Nuggets
        enabled_nugget_l = [x for x in self.nugget_d.values() if x.enabled and x.periodic]

        # if there are entries, find the polling interval
        if enabled_nugget_l:
            # the poll interval is the greatest common denominator of all intervals
            interval = reduce(gcd, (x.schedule for x in enabled_nugget_l))
        else:
            interval = None

        return interval

    def add_or_remove_keepalive (self):
        # We add a keepalive if the device isn't being touched enough
        # The following statement gets the Nugget configs that will actually
        # touch the device (and hence act as a keepalive)
        nugget_d_touches = {x:y for x,y in self.nugget_d.items() if
                         y.poll and y.enabled and y.periodic
                         and y.type != "snmp@switch"}

        if nugget_d_touches:
            tmp_polling_interval = reduce(gcd, (x.schedule for x in nugget_d_touches.values()))

        if not nugget_d_touches or tmp_polling_interval > cfg.keepalive_period:
            if 'keepalive' not in self.nugget_d:
                self.nugget_d["keepalive"] = cfg.init_nugget(self, 'keepalive', cfg.keepalive_period,
                                                             nugget_cfg = {'type': 'keepalive'},
                                                             store = False)
        else:
            # no need for a keepalive...remove it
            self.nugget_d.pop("keepalive", None)


    def add_or_remove_cli_keepalive (self):
        # We add a keepalive if the device isn't being touched enough
        # The following statement gets the Nugget configs that will actually
        # touch the device (and hence act as a keepalive)
        nugget_d_touches = {x:y for x,y in self.nugget_d.items() if
                         y.poll and y.enabled and y.periodic and y.collect_type == "cli"}

        if not nugget_d_touches: return

        tmp_polling_interval = reduce(gcd, (x.schedule for x in nugget_d_touches.values()))

        if tmp_polling_interval > cfg.cli_keepalive_period:
            if 'cli_keepalive' not in self.nugget_d:
                self.nugget_d["cli_keepalive"] = cfg.init_nugget(self, 'cli_keepalive',
                                                                 cfg.cli_keepalive_period,
                                                                 nugget_cfg = {'type': 'cli_keepalive'},
                                                                 store = False)
        else:
            # no need for a keepalive...remove it
            self.nugget_d.pop("cli_keepalive", None)


    weekday_re = re.compile('((?:mon|tue?s?|wed(?:nes)?|thu?r?s?|fri|sat(?:ur)?|sun)(?:day)?)', flags=re.IGNORECASE)
    time_re = re.compile('(\d+(?::\d{2})?(?:am|pm))', flags=re.IGNORECASE)
    def parse_schedule (self, config_body):
        # extract the schedule configuration
        if isinstance(config_body, dict):
            schedule_str = config_body['schedule']
        else:
            schedule_str = config_body

        # parse the schedule configuration
        try:
            # if it's a periodic notation
            schedule = int(schedule_str)
        except ValueError:
            # it's scheduled, first check for days
            schedule = []
            weekday_l = re.findall(self.weekday_re, schedule_str) or ['']
            time_l = re.findall(self.time_re, schedule_str)
            for d in weekday_l:
                for t in time_l:
                    # could consider doing tz aware (appendingcfg.timezone)
                    schedule.append("%s %s" % (d, t))

        return schedule

    def init_polling_config (self, polling_cfg = None):
        """
        Look at the config and generate a dictionary of nuggets and
        associated information. This dictionary is a device variable
        and is used for the polling.
        """
        self.nugget_d = {}

        # First, read the global config
        if not polling_cfg:
            polling_cfg = self.get_polling_cfg()

        # initialize polling entries
        for nugget_name, block in polling_cfg.items():
            try:
                nugget = self.nugget_cfg[nugget_name]
                #
                # check Nugget support
                # ignore if this Nugget isn't supported
                if ('support' in nugget and self.model):
                    eq = nugget['support'].replace(r'{model}', self.model)
                    if not eval(eq):
                        log.info("Nugget not supported", "device",
                                 device=self, nugget_name=nugget_name)
                        continue
            except KeyError:
                # only take valid Nuggets
                continue

            # get the schedule from the config block
            schedule = self.parse_schedule(block)

            # get the initial entry
            entry = cfg.init_nugget(self, nugget_name, schedule, nugget_cfg=nugget)

            thresholds = None
            if isinstance(block, dict) and 'thresholds' in block:
                thresholds = block['thresholds']
                # find the thresholds config string and initialize
                if isinstance(thresholds, list):
                    entry.init_thresholds(thresholds)
                elif isinstance(thresholds, dict) and 'total' in block['thresholds']:
                    entry.init_thresholds(thresholds['total'])

            self.nugget_d[nugget_name] = entry

        # add group members
        group_nugget_d = {x:y for x,y in self.nugget_d.items() if y.type == "group"}
        for nugget_name, entry in group_nugget_d.items():
            ## add child entries
            for child_name in self.get_formula_dependencies(nugget_name):
                if child_name not in self.nugget_d:
                    child_entry = cfg.init_nugget(self, child_name, schedule,
                                                  store=(child_name in entry.members))
                    if (thresholds and
                        isinstance(thresholds, dict) and
                        child_name in thresholds):
                        child_entry.init_thresholds(thresholds[child_name])
                    self.nugget_d[child_name] = child_entry
                    #entry.child_l.append(child_entry)

        # set group child/parent relationships
        group_nugget_d = {x:y for x,y in self.nugget_d.items() if y.type == "group"}
        for nugget_name, entry in group_nugget_d.items():
            entry.child_l = [self.nugget_d[x] for x in entry.members]
            for x in entry.child_l:
                x.parent_l.append(entry)

        # add formula variables
        formula_nugget_d = {x:y for x,y in self.nugget_d.items() if y.type == "formula"}
        for nugget_name, entry in formula_nugget_d.items():
            for nugget_var in self.get_formula_dependencies(entry.name_root):
                if entry.index:
                    nugget_var += ':' + entry.index

                try:
                    var_entry = self.nugget_d[nugget_var]
                except KeyError:
                    var_entry = cfg.init_nugget(self, nugget_var, entry.schedule, store=False)
                    self.nugget_d[nugget_var] = var_entry

                # set child/parent relationships
                var_entry.parent_l.append(entry)
                entry.child_l.append(var_entry)

        # expand the nugget_d from dict/list variables
        self.gather_nugget_vars()

        # expand the nugget_d from dict/list variables
        self.expand_nugget_vars()

        # group_nugget_d = {x:y for x,y in self.nugget_d.items() if y.type == "group"}
        # for nugget_name, entry in group_nugget_d.items():
        #     log.debug("%s: %s" % (nugget_name, [x.name for x in entry.child_l]))

        # de-reference simple variables
        for nugget_name, entry in self.nugget_d.items():
            entry.build()

        # update adjust polling intervals
        for nugget_name, entry in self.nugget_d.items():
            entry.schedule_adjust()

        # rename nuggets by alias
        for nugget_name, entry in list(self.nugget_d.items()):
            if ':' not in nugget_name and 'alias' in entry.cfg:
                alias = entry.cfg['alias']
                if alias not in self.nugget_d:
                    # rename/move the Nugget
                    entry.name = alias
                    self.nugget_d[alias] = entry
                del self.nugget_d[nugget_name]


    def get_formula_dependencies (self, nugget_name, already_done = None, ancestors = None):
        """
        A recursive function that helps find all the nuggets required for
        a formula nugget (including all descendants)
        """

        if already_done is None:
            already_done = set()
            ancestors = []

        already_done.add(nugget_name)

        # find the config for this nugget
        nugget_cfg = self.nugget_cfg[nugget_name]

        # check if dependencies are hard coded, start with those
        dependencies =  nugget_cfg.get("dependencies")
        if dependencies:
            # remove the brackets
            dependencies = [x.strip("{}") for x in dependencies]
            nugget_var_l = set(dependencies)
        elif nugget_cfg['type'] == "group":
            nugget_var_l = set([x.replace('*', nugget_name) for x in nugget_cfg.get('members', [])])
        else:
            # automatically discover/parse which nuggets are required for this formula
            formula = nugget_cfg['formula']
            # remove commented lines
            formula = re.sub(r'(?m)^ *#.*\n?', '', formula)
            # get the list of required variables
            nugget_var_l = set([x.split(':')[0] for x in re.findall(cfg.nugget_var_re, formula)])

        # make sure we aren't exploring a nugget we have explored before
        intersection = nugget_var_l.intersection(ancestors)
        if intersection:
            loop = ancestors + [nugget_name] + [list(intersection)[0]]
            log.exception("Reference loop in Nugget Config (%s)" % "->".join(loop),
                          "device", device=self)
        else:
            # loop through all the formula children and recurse
            formula_children = (x for x in nugget_var_l if x not in already_done and
                                self.nugget_cfg[x].get("type") in ["formula", "group"])

            ancestors.append(nugget_name)
            for var in formula_children:
                nugget_var_l = nugget_var_l | self.get_formula_dependencies(var, already_done, ancestors)
            ancestors.remove(nugget_name)

        return nugget_var_l

    def get_nugget_var (self, var):
        if var in self.nugget_var_d:
            return self.nugget_var_d[var]
        else:
            return self.get(var, default=None)

    def expand_nugget_vars (self):
        #
        # create new Nuggets from the iterator variables
        for nugget_name, entry in list(self.nugget_d.items()):
            new_indexes = []
            # extract the text with variables
            try:
                formula = entry.cfg[entry.formula_key]
            except KeyError:
                continue

            for var in re.findall(cfg.nugget_var_re, formula):
                value = self.get_nugget_var(var)

                if value is None:
                    # for now we just delete Nuggets with null variables
                    # del self.nugget_d[nugget_name]
                    continue

                # for now, convert lists to dict where key == value
                if isinstance(value, list):
                    value = {x:x for x in value}

                if isinstance(value, dict):
                    if "alias" in entry.cfg:
                        prefix = entry.cfg['alias']
                    else:
                        prefix = nugget_name

                    #
                    # disable polling this Nugget
                    entry.poll = False

                    # since this nugget is expanding, we need to remove it from parents
                    for parent in entry.parent_l:
                        parent.child_l.remove(entry)
                        # log.debug("remove %s from %s/%s" % (entry.name, parent.name, 
                        #                                     [x.name for x in parent.child_l]))

                    # fill in the vars
                    for id, name in value.items():

                        child_name = "%s:%s" % (prefix, name)
                        new_indexes.append(child_name)

                        # find the new config
                        nugget_cfg = entry.cfg.copy()
                        nugget_cfg[entry.formula_key] = re.sub(r'{%s}' % var, str(id), formula)
                        self.nugget_cfg[child_name] = nugget_cfg
                        if child_name in self.nugget_d:
                            old_entry = self.nugget_d[child_name]
                            # use the new config and rebuild the oid/whatever
                            old_entry.cfg[entry.formula_key] = nugget_cfg[entry.formula_key]
                        else:
                            # create a new nugget entry
                            new_entry = cfg.init_nugget(self, child_name, entry.schedule,
                                                        counter = entry.counter,
                                                        nugget_cfg = nugget_cfg,
                                                        store = entry.store_setting)
                            self.nugget_d[child_name] = new_entry

                            # init thresholds from parent
                            # new_entry.init_thresholds(entry.threshold_cfg)

                            # if there's an aggregation parent, we need to insert a dynamic one
                            for parent in entry.parent_l:
                                # add this new entry to the parent
                                parent.child_l.append(new_entry)
                                if len(parent.cfg.get("members", [])) > 1:
                                    if "alias" in parent.cfg:
                                        parent_prefix = parent.cfg['alias']
                                    else:
                                        parent_prefix = parent.name

                                    new_parent_name = "%s:%s" % (parent_prefix, name)

                                    if new_parent_name not in self.nugget_d:
                                        new_parent = cfg.init_nugget(self, new_parent_name, parent.schedule,
                                                                     counter = parent.counter,
                                                                     nugget_cfg = parent.cfg,
                                                                     store = parent.store_setting)
                                        self.nugget_d[new_parent_name] = new_parent
                                        new_entry.parent = new_parent
                                        # init thresholds from parent
                                        # new_entry.init_thresholds(parent.threshold_cfg)

                                    # add to the parent's children
                                    self.nugget_d[new_parent_name].child_l.append(new_entry)

                elif isinstance(value, list):
                    # Levy: no lists yet! Cross this bridge later
                    pass

            # #
            # # log new indexes
            # for child_name in new_indexes:
            #     if child_name not in entry.indexes:
            #         log.debug("adding index: %s/%s" % (self.name, child_name))

            #if entry.cfg.get('aggregate'):
            if new_indexes:
                #
                # remove old indexes
                for child_name in entry.indexes:
                    if child_name not in new_indexes:
                        old_entry = self.nugget_d[child_name]
                        for parent in old_entry.parent_l:
                            if parent.name in self.nugget_d:
                                # log.debug("removing index: %s/%s" % (self.name, old_entry.parent.name))
                                del self.nugget_d[parent.name]
                        # log.debug("removing index: %s/%s" % (self.name, child_name))
                        del self.nugget_d[child_name]

                # assign new indexes
                entry.indexes = new_indexes

    def gather_nugget_vars (self):
        self.nugget_var_d = {}
        var_l = set(self.get_nugget_variables())
        todo_var_l = list(var_l)

        # We'll keep looping through until we've recursed through all vars
        while True:
            start_length = len(todo_var_l)
            # initialize the nugget_var entries and sort by type
            nugget_d = {}
            nugget_d_by_type = {}

            for var in todo_var_l:
                try:
                    nugget_cfg = self.nugget_cfg[var]
                except KeyError:
                    continue

                nugget_entry = cfg.init_nugget(self, var, 0, nugget_cfg = nugget_cfg)

                # try to build the entry
                missing_vars = nugget_entry.build()
                if missing_vars:
                    var_l.update(missing_vars)
                    continue

                # insert the entry into the var dictionaries
                nugget_d[var] = nugget_entry
                try:
                    nugget_d_by_type[nugget_entry.type][var] = nugget_entry
                except KeyError:
                    nugget_d_by_type[nugget_entry.type] = {var: nugget_entry}

            if not nugget_d:
                return

            # collect the data
            response_l = self.poll_collect(nugget_d_by_type)
            if response_l:
                # process the data
                response_l = self.poll_process(nugget_d, response_l)

                # insert into the nugget_var_d
                for nugget_name, timestamp, value in response_l:
                    self.nugget_var_d[nugget_name] = value

            # add constants
            if 'constant' in nugget_d_by_type:
                for nugget_name, entry in nugget_d_by_type['constant'].items():
                    self.nugget_var_d[nugget_name] = entry.cfg['value']

            # add functions
            if 'function' in nugget_d_by_type:
                for nugget_name, entry in nugget_d_by_type['function'].items():
                    self.nugget_function_d[nugget_name] = entry.cfg['function_built']
                    self.nugget_var_d[nugget_name] = "self.nugget_function_d['%s']" % nugget_name

            # see if we're done
            todo_var_l = [x for x in var_l if x not in self.nugget_var_d]
            progress = len(todo_var_l) < start_length
            if not progress or not todo_var_l:
                break

    def get_nugget_variables (self):
        """
        for dynamic Nugget expansions, which other Nuggets do we need to
        complete the expansion?
        Should this be something like get_nugget_dependencies?
        """
        variable_s = set()
        for nugget_name, entry in self.nugget_d.items():
            variable_s.update(entry.get_nugget_variables())
        return variable_s

    def finalize_polling_config (self):

        # add a keepalive?
        self.add_or_remove_keepalive()

        # add cli keepalive?
        self.add_or_remove_cli_keepalive()

        # add the update task
        if 'update' not in self.nugget_d:
            self.nugget_d['update'] = cfg.init_nugget(self, 'update',
                                                      cfg.ap_monitor_period,
                                                      counter = cfg.ap_monitor_period,
                                                      nugget_cfg = {'type': 'update'})

        # set the polling interval
        self.polling_interval = self.get_polling_interval()

    def trim_polling_config (self):
        #
        # check CLI
        if self.cli_session_required():
            if not self.cli.is_alive(): # invalid session
                # disable nuggets
                self.add_code('term_fail')
                for x in self.nugget_d.values():
                    if x.collect_type == "cli":
                        x.enabled = False
            else:
                # enable nuggets
                self.remove_code('term_fail')
                for x in self.nugget_d.values():
                    if x.collect_type == "cli":
                        x.enabled = True

        #
        # check SNMP
        if self.snmp_is_required():
            if not self.snmp.is_up(check=True):
                # disable nuggets
                for x in self.nugget_d.values():
                    if x.type == "snmp":
                        x.enabled = False
            else:
                # enable nuggets
                for x in self.nugget_d.values():
                    if x.type == "snmp":
                        x.enabled = True

    def start_polling_thread (self, offset=0):

        if not (self.get_address() and self.nugget_d):
            return

        # Start polling thread
        self.poll_thread = PeriodicThread.PeriodicThread(name=self.name,
                                                         interval=self.polling_interval,
                                                         action=self.poll,
                                                         quiet=True)
        if cfg.poll_bulk:
            # round the start time
            start_time = (self.polling_interval *
                          math.ceil((time.time() - self.poll_thread_offset) / self.polling_interval)
                          + self.poll_thread_offset)
            self.poll_thread.start(start_time)
        elif offset:
            start_time = time.time() + offset
            self.poll_thread.start(start_time)
        else:
            self.poll_thread.start()

    def stop_polling_thread (self):
        # Stop the polling thread
        if self.poll_thread:
            self.poll_thread.stop()

        # close the terminal session
        self.close_session()

    def needs_update (self):
        if hasattr(self, "query_nugget_vars"):
            now = int(time.time())
            self.nugget_vars_update = (now - self.last_nugget_vars_update) >= cfg.scan_period

        return (self.nugget_vars_update or
                'term_fail' in self.code_d or
                (not self.configured and ('down' in self.code_d or
                                         'snmp_down' in self.code_d)))

    def update (self):
        try:
            #
            # set device groups
            self.set_groups()
            DB.db.add_device(self)

            #
            # retry the terminal session
            if (self.cli_session_required() and
                not self.cli.is_alive()): # invalid session
                self.cli.set_session()

            #
            # update the nugget config?
            self.update_polling_config()

        except Exception as e:
            log.debug("Error in device update (%s): %s" % (self.name, e))

    def update_polling_config (self):
        if self.nugget_vars_update:
            if hasattr(self, "query_nugget_vars"):
                self.query_nugget_vars()

            # log.debug("updating %s" % self.name)
            self.gather_nugget_vars()
            self.expand_nugget_vars()
            self.nugget_vars_updated = False
            self.last_nugget_vars_update = int(time.time())

        self.trim_polling_config()
        self.finalize_polling_config()

    def add_code (self, code, quiet=False, txt=None, nugget_name=None):
        if code not in self.code_d and code not in self.get_code_overrides():
            code_entry = self.error_codes[code].copy()
            self.code_d[code] = code_entry
            self.code_d[code]['timestamp'] = int(time.time())
            # remove the codes that this one overrides
            for x in code_entry['overrides']:
                self.remove_code(x, quiet=True)

            if nugget_name:
                code_entry['nugget'] = nugget_name
            if txt:
                code_entry['msg_details'] = txt

            if not quiet:
                # log the code
                msg = code_entry['msg']
                if txt:
                    msg += ": %s" % txt

                log.log(msg, code_entry['type'], code_entry['sev'],
                        device=self, nugget_name=nugget_name)

    def remove_code (self, code, quiet=False):
        if not quiet and code in self.code_d:
            code_entry = self.code_d[code]
            if code_entry['msg_rm']:
                log.info(code_entry['msg_rm'], "device", device=self)

        try:
            del self.code_d[code]
        except KeyError: pass

    def get_code_overrides (self):
        override_l = set()
        for code,x in self.code_d.items():
            override_l.update(x['overrides'])
        return override_l

    def get_codes (self):
        override_l = self.get_code_overrides()
        return {x:y for x,y in self.code_d.items() if x not in override_l}

    def poll (self, once=False):
        # Skip if the device is down
        if not self.is_up():
            # re-check the device's up status
            if self.is_up(check=True):
                self.snmp.timeout_detected = 0

        # Check for SNMP timeouts
        if self.snmp_is_required():
            if self.snmp.is_up():
                if (time.time() - self.snmp.timeout_detected) < cfg.snmp_timeout_hold_time:
                    self.add_code('snmp_timeout')
                else:
                    self.remove_code('snmp_timeout')

        # look through the device's Nugget entry list
        nugget_d = {}
        nugget_d_by_type = {}
        for nugget_name, nugget_entry in self.nugget_d.items():
            if once:
                interval = 0
            else:
                interval = self.poll_thread.interval

            if nugget_entry.check_schedule(interval):
                nugget_d[nugget_name] = nugget_entry
                try:
                    nugget_d_by_type[nugget_entry.collect_type][nugget_name] = nugget_entry
                except KeyError:
                    nugget_d_by_type[nugget_entry.collect_type] = {nugget_name: nugget_entry}

        if not nugget_d:
            return

        #
        # Collect
        response_l = self.poll_collect(nugget_d_by_type)

        if response_l:
            #
            # Process
            response_l = self.poll_process(nugget_d, response_l)

            #
            # Split
            response_l = self.poll_split(nugget_d, nugget_d_by_type, response_l)

            #
            # Post-Process
            response_l = self.poll_post_process(nugget_d, response_l)

            #
            # Compute new Nuggets
            response_l, new_response_l = self.poll_compute(nugget_d, nugget_d_by_type, response_l)

            #
            # Store
            if once:
                return response_l
            else:
                self.poll_store(response_l)

        if 'update' in nugget_d and self.needs_update():
            self.update()

    def poll_collect (self, nugget_d):
        now = int(time.time())
        response_l = []

        #
        # Send Keepalive?
        if [x for x in nugget_d.keys() if x in ['cli', 'snmp', 'rest']]:
            touched = True
        else:
            touched = False
            if 'keepalive' in nugget_d:
                if not self.is_up(check=True):
                    return

        #
        # snmp query
        snmp_read = ('snmp' in nugget_d and
                     (self.snmp.is_up() or self.snmp.is_up(check=True)))
        if snmp_read:
            self.snmp.poll_queue(nugget_d['snmp'])

        #
        # cli query
        if 'cli' in nugget_d:
            response_l += self.cli.poll(nugget_d['cli'])
        elif 'cli_keepalive' in nugget_d:
            # send cli keepalive
            self.cli.session_keepalive()

        #
        # rest query
        if 'rest' in nugget_d:
            response_l += self.rest.poll(nugget_d['rest'])

        #
        # snmp read
        if snmp_read:
            response_l += self.snmp.poll_read(nugget_d['snmp'], now)

        # Null response? Check whether the device is down
        if touched and not response_l:
            self.is_up(check=True)

        return response_l

    def poll_split (self, nugget_d, nugget_d_by_type, response_l):
        """
        Split nuggets and store results
        """
        new_entry_l = []
        new_response_l = []
        for nugget_name, timestamp, value in response_l:
            nugget_entry = self.nugget_d[nugget_name]
            if nugget_entry.split:
                _new_entry_l, _new_response_l = self.split_nugget(nugget_entry, timestamp, value)
                new_entry_l += _new_entry_l
                new_response_l += _new_response_l
            else:
                new_response_l.append((nugget_name, timestamp, value))

        # add the new nugget where needed
        for entry in new_entry_l:
            nugget_d[entry.name] = entry
            nugget_d_by_type[entry.type][entry.name] = entry

        return new_response_l

    def split_nugget (self, nugget_entry, timestamp, value):
        """
        perform the split operation on a specified nugget and store the nugget timstamp/value
        """
        new_entry_l = []
        new_response_l = []

        # since we're going to split, remove this entry from all parents
        try:
            for parent in nugget_entry.parent_l:
                parent.child_l.remove(nugget_entry)
        except ValueError: pass

        if nugget_entry.split_method == "hierarchy":
            split_format = str(nugget_entry.cfg.get("split_format", "{nugget_name}:{index}"))
            depth = 1
            while ("{index_%d}" % depth) in split_format: depth += 1

            entry_l = utility.flatten_helper(value, depth)

            for path, value in entry_l:
                new_nugget_name = re.sub(r'{nugget_name}', nugget_entry.name, split_format)
                new_nugget_name = re.sub(r'{index}|{index_0}', path[0], new_nugget_name)
                for i in range(1, depth):
                    new_nugget_name = re.sub(r'{index_%s}' % i, path[i], new_nugget_name)

                # insert the new kpi
                new_nugget_entry = self.insert_split_nugget(nugget_entry, new_nugget_name)

                new_entry_l.append(new_nugget_entry)
                new_response_l.append([new_nugget_name, timestamp, value])

        elif nugget_entry.split_method == "object":
            if isinstance(value, list):
                for obj in value:
                    try:
                        new_nugget_name = obj['name']
                        value = obj['value']
                    except KeyError:
                        raise Exception("For object-based split, 'name' and 'value' must be defined!")

                    timestamp = obj.get("timestamp", timestamp)
                    index = obj.get("index")
                    if index:
                        new_nugget_name += ':' + index

                    # insert the new kpi
                    new_nugget_entry = self.insert_split_nugget(nugget_entry, new_nugget_name)

                    new_entry_l.append(new_nugget_entry)
                    new_response_l.append([new_nugget_name, timestamp, value])

            elif isinstance(value, dict):
                for new_nugget_name, obj in value.items():
                    try:
                        value = obj['value']
                    except KeyError:
                        raise Exception("For object-based split, 'value' must be defined!")

                    timestamp = obj.get("timestamp", timestamp)
                    index = obj.get("index")
                    if index:
                        new_nugget_name += ':' + index

                    # insert the new kpi
                    new_nugget_entry = self.insert_split_nugget(nugget_entry, new_nugget_name)

                    new_entry_l.append(new_nugget_entry)
                    new_response_l.append([new_nugget_name, timestamp, value])

        return new_entry_l, new_response_l

    def insert_split_nugget (self, parent, new_nugget_name):
        if new_nugget_name in self.nugget_d:
            new_nugget_entry = self.nugget_d[new_nugget_name]
        else:
            # create a new nugget entry to track this split nugget
            new_nugget_entry = cfg.init_nugget(self, new_nugget_name, None,
                                               nugget_cfg=self.nugget_cfg[parent.name],
                                               poll=False, split=False)

            # add as children into the parent
            parent.split_l.append(new_nugget_entry)

            # add new entries into the parent
            for p in parent.parent_l:
                p.child_l.append(new_nugget_entry)

            # add to the node nugget list
            self.nugget_d[new_nugget_name] = new_nugget_entry

        return new_nugget_entry

    def poll_process (self, nugget_d, response_l):
        new_response_l = []
        for nugget_name, timestamp, value in response_l:
            nugget_entry = nugget_d[nugget_name]
            value = nugget_entry.process(value)
            new_response_l.append([nugget_name, timestamp, value])

        return new_response_l

    def poll_post_process (self, nugget_d, response_l):
        new_response_l = []
        for nugget_name, timestamp, value in response_l:
            nugget_entry = nugget_d[nugget_name]

            if not nugget_entry.split:
                #
                # post_process
                timestamp, value = nugget_entry.post_process(timestamp, value)
            new_response_l.append([nugget_name, timestamp, value])

        return new_response_l

    def poll_compute (self, nugget_d, nugget_d_by_type, response_l, test_nugget = []):
        # convert response list to dictionary
        new_response_d = {}
        response_d = {}
        sample_d = {}
        for nugget_name, timestamp, value in response_l:
            nugget_entry = nugget_d[nugget_name]

            response_d[nugget_name] = {
                'timestamp': timestamp,
                'value': value,
                'sample_timestamp': nugget_entry.sample_timestamp
            }

            if nugget_entry.sample is not None:
                sample_d[nugget_name] = nugget_entry.sample

        # #
        # # aggregation Nuggets
        # for nugget_name, entry in self.nugget_d.items():
        #     if entry.aggregate and entry.indexes:
        #         method = entry.cfg.get('aggregate')
        #         if method == "sum":
        #             value = 0
        #         elif method == "dictionary":
        #             value = {}

        #         timestamp = 0
        #         for index in entry.indexes:
        #             try:
        #                 # add the value
        #                 if method == "sum":
        #                     value += response_d[index]['value']
        #                 elif method == "dictionary":
        #                     value[index] = response_d[index]['value']

        #                 timestamp = response_d[index]['timestamp']
        #                 sample_timestamp = response_d[index]['sample_timestamp']
        #             except TypeError: pass
        #             except KeyError: break

        #         if timestamp:
        #             entry.sample_timestamp = sample_timestamp
        #             new_response_d[nugget_name] = response_d[nugget_name] = {
        #                 'timestamp': timestamp,
        #                 'value': value,
        #                 'sample_timestamp': sample_timestamp
        #                 }


        #
        # calculate formula/group Nuggets
        if 'formula' in nugget_d_by_type or 'group' in nugget_d_by_type:
            nugget_l = list(nugget_d_by_type.get('formula', {}).keys()) + list(nugget_d_by_type.get('group', {}).keys())
            done = []
            while True:
                # track whether progress was made this iteration
                progress = False
                # get the list of nuggets left to process
                todo = [x for x in nugget_l if x not in done]
                for nugget_name in todo:
                    entry = self.nugget_d[nugget_name]
                    value = None
                    timestamp = None

                    if entry.type == 'group':
                        var_l = [x.name for x in entry.child_l]
                        if var_l:
                            method = entry.cfg.get("aggregate")
                            # initialize the value
                            if method == "sum":
                                value = 0
                            elif method == "dictionary":
                                value = {}

                            for child_name in var_l:
                                try:
                                    child_response = response_d[child_name]

                                    # add the value
                                    if method == "sum":
                                        value += child_response['value']
                                    elif method == "dictionary":
                                        value[child_name] = child_response['value']

                                    timestamp = child_response['timestamp']
                                    sample_timestamp = child_response['sample_timestamp']
                                except (TypeError, KeyError) as e:
                                    value = None
                                    break

                            if value is None:
                                continue
                    else:
                        # expand formula variables
                        formula = entry.cfg['formula_built']
                        var_l = entry.formula_var_l

                        # if any are missing, wait skip for now and wait till the next
                        # time we loop through
                        missing = [x for x in var_l if x not in response_d]
                        if missing:
                            continue

                        # pull the timestamp from the first variable (arbitrarily)
                        timestamp = response_d[var_l[0]]["timestamp"]
                        sample_timestamp = response_d[var_l[0]]["sample_timestamp"]
                        # verify that the timestamps match for all the variables
                        timestamps_match = all([response_d[x]["timestamp"] == timestamp for x in var_l])
                        if not timestamps_match or not timestamp:
                            continue

                        # create the formula string
                        formula = re.sub(cfg.nugget_var_re, r'response_d["\1"]["value"]', formula)
                        # evaluate the formula
                        try:
                            value = eval(formula)
                        except ZeroDivisionError:
                            value = entry.cfg.get("default_value")
                        except TypeError as e:
                            if 'NoneType' in str(e):
                                value = entry.cfg.get("default_value")
                            else:
                                raise
                        except (KeyError, TypeError) as e:
                            log.exception("Error in formula: %s" % e,
                                          "device", device=self, nugget_name=nugget_name)
                        except SyntaxError as e:
                            log.exception("Syntax error in formula: %s" % e,
                                          "device", device=self, nugget_name=nugget_name)


                    #
                    # store the new response in response_d
                    progress = True

                    # if we're running a nugget test, we don't want to process here
                    # this is so we can process step by step and shoe results
                    if not nugget_name in test_nugget:
                        # run the simple processing
                        value = entry.process(value)

                        # if we're going to split, post/incremental processing will occur after
                        if entry.split:
                            new_entry_l, new_response_l = self.split_nugget(entry, timestamp, value)
                            for split_entry, (split_name, split_timestamp, split_value) in zip(new_entry_l, new_response_l):
                                timestamp, value = split_entry.post_process(split_timestamp, split_value)
                                # store the result
                                response_d[split_name] = {
                                    'timestamp': timestamp,
                                    'value': value,
                                    'sample_timestamp': split_timestamp
                                }
                        else:
                            # incremental processing
                            timestamp, value = entry.post_process(sample_timestamp, value)
                            # store the result
                            entry.sample_timestamp = sample_timestamp
                            response_d[nugget_name] = {
                                'timestamp': timestamp,
                                'value': value,
                                'sample_timestamp': sample_timestamp
                            }
                    else:
                        # store the result
                        entry.sample_timestamp = sample_timestamp
                        response_d[nugget_name] = {
                            'timestamp': timestamp,
                            'value': value,
                            'sample_timestamp': sample_timestamp
                        }
                        # processing must be completed later
                        new_response_d[nugget_name] = response_d[nugget_name]

                    # remove this entry from the pending list
                    done.append(nugget_name)

                # if we haven't made any progress since last time, break out of the loop
                if not progress:
                    break

            # log when formulas are missing data
            todo = [x for x in nugget_l if x not in done]
            for nugget_name in todo:
                entry = self.nugget_d[nugget_name]
                if entry.type == 'group':
                    var_l = [x.name for x in entry.child_l]
                else:
                    var_l = entry.formula_var_l

                # gather missing variabes
                var_l_missing = [x for x in var_l if x not in response_d]

                if var_l_missing:
                    log.exception("Missing Nugget dependencies (%s)" % var_l_missing,
                                  "device", device=self, nugget_name=nugget_name)


        # convert back to a list
        response_l = []
        for nugget_name, x in response_d.items():
            if nugget_name not in new_response_d:
                response_l.append([nugget_name, x['timestamp'], x['value']])

        # find the list of newly computed Nuggets
        new_response_l = []
        for nugget_name, x in new_response_d.items():
            new_response_l.append([nugget_name, x['timestamp'], x['value']])

        return response_l, new_response_l

    def poll_store (self, response_l):
        # store everything
        for nugget_name, timestamp, value in response_l:
            # store the latest sample
            if value is not None:
                self.nugget_d[nugget_name].store_sample(timestamp, value)

    def get_address (self, required=False):
        addr = self.ip_address or self.hostname

        if required and not addr:
            raise ConfigError("Device has no configured IP address or hostname!")
        else:
            return addr

    def monitor_ssh (self):

        device_status = self.cli.ssh_is_up()

        if device_status:
            return 1
        else:
            return 0

