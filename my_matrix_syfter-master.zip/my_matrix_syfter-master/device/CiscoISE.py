import time
import json
from common import config as cfg
from common import logger as log
from .Device import Device
from .DeviceRest import DeviceRest, RestException

ctrl_url_prefix = '/pxgrid/control/'

class CiscoISE (Device):
    def init_rest (self):
        self.rest = CiscoPXGridRest(self)

class CiscoPXGridRest(DeviceRest):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.login_required = True

    def login (self):
        node = self.service_lookup("com.cisco.ise.session")

        # update the credentials for pxgrid
        self.password = self.access_secret(node)
        self.login_required = False

        return True

    def account_create (self):
        print("Creating account...")
        url = ctrl_url_prefix + 'AccountCreate'
        body = {'nodeName': cfg.tool_name}

        try:
            ret = self.post(url, body, auth=False)
        except RestException as e:
            if e.code == 409:
                print("Account already exists!")
                return False
            else:
                raise

        self.username = cfg.tool_name
        self.password = ret['password']
        return ret['password']

    def account_activate(self):
        print("Activating account...")
        url = ctrl_url_prefix + 'AccountActivate'
        body = {'nodeName': cfg.tool_name}

        while True:
            ret = self.post(url, body)
            if isinstance(ret, int):
                raise Exception(ret)

            if ret['accountState'] == 'ENABLED':
                break
            else:
                print("Account Pending: You must approve from the ISE WebUI!\n"+
                      "Will check again in 30 seconds...")
                time.sleep(30)

        print("Account activated!\n"+
              "Add the following to the device config:\n"
              "    rest_username: %s" % cfg.tool_name+
              "    rest_password: %s" % self.password)

    def service_lookup (self, name):
        url = ctrl_url_prefix + "ServiceLookup"
        body = {
            "name": name
        }
        ret = self.post(url, body)

        #return ret['services'][0]['properties']['restBaseUrl']
        return ret['services'][0]['nodeName']

    def access_secret (self, node):
        """retrieve the access secret (password) for another node """
        url = ctrl_url_prefix + "AccessSecret"
        body = {'peerNodeName': node}

        ret = self.post(url, body)
        return ret['secret']

