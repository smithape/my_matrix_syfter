import re
import ipaddress
from common import config as cfg
from common.Event import EventDetector

from .VirtualDevice import VirtualDevice

class IpRangeFilter (object):
    def __init__ (self, start_ip, end_ip):
        self.start_ip = ipaddress.ip_address(str(start_ip))
        self.end_ip = ipaddress.ip_address(str(end_ip))

    def match (self, device):
        try:
            device_ip = ipaddress.ip_address(str(device.get("ip_address")))
            return self.start_ip <= device_ip <= self.end_ip
        except ValueError:
            return False

class IpNetworkFilter (object):
    def __init__ (self, ip_network):
        self.ip_network = False
        try:
            self.ip_network = ipaddress.ip_network(str(ip_network))
        except ValueError: pass

    def match (self, device):
        try:
            device_ip = ipaddress.ip_address(str(device.get("ip_address")))
            return device_ip in self.ip_network
        except ValueError:
            return False

class NameFilter (object):
    def __init__ (self, filter_str=None):
        self.filter_re = None

        if filter_str:
            # remove whitespace
            filter_str = re.sub(r'\s', '', filter_str)
            # , treated as |
            filter_str = filter_str.replace(',', '|')
            self.filter_re = re.compile(filter_str, re.IGNORECASE)

    def match (self, device):
        return not self.filter_re or re.search(self.filter_re, device.name)

class ApGroupFilter (object):
    def __init__ (self, filter_str=None):
        self.filter_re = None

        if filter_str:
            # remove whitespace
            filter_str = re.sub(r'\s', '', filter_str)
            # , treated as |
            filter_str = filter_str.replace(',', '|')
            self.filter_re = re.compile(filter_str, re.IGNORECASE)

    def match (self, device):
        return (not self.filter_re or
                (hasattr(device, 'ap_group') and re.search(self.filter_re, device.ap_group)))

class ClientLocationFilter (object):
    def __init__ (self, filter_str=None):
        self.filter_re = None

        if filter_str:
            # remove whitespace
            filter_str = re.sub(r'\s', '', filter_str)
            # , treated as |
            filter_str = filter_str.replace(',', '|')
            self.filter_re = re.compile(filter_str, re.IGNORECASE)

    def match (self, device):
        return (not self.filter_re or
                (hasattr(device, 'location') and re.search(self.filter_re, device.location)))

class DeviceGroup (object):

    def __init__ (self, name, device_type, aggregate, event_detection,
                  db_index, filter_cfg, aggregate_ap_groups=False, parent=None):
        self.name = name
        self.device_type = device_type
        self.aggregate = aggregate
        self.event_detection = event_detection
        self.db_index = db_index
        self.parent = parent
        self.children = []
        if filter_cfg:
            self.device_filter_l, self.client_filter_l = self.init_filters(filter_cfg)
        else:
            self.device_filter_l = self.client_filter_l = []
        self.vdevice_d = self.init_vdevice_d()

        if not parent and aggregate_ap_groups:
            self.init_subgroups()

    def __repr__(self):
        s = self.name + "\n"
        for f in self.device_filter_l:
            s += "\t%s" % type(f).__name__

        return s

    def init_vdevice_d (self):
        vdevice_d = {}
        # create a new device object for group logging
        self.device = VirtualDevice("*"+self.name, self, aggregation = False, dtype = self.device_type)
        vdevice_d["*"+self.name] = self.device

        if self.aggregate:
            for x in ['Avg', 'Sum']:
                # build the vdevice name
                name = "*%s_%s" % (self.name, x)
                # create a new device object
                vdevice = VirtualDevice(name, self, dtype = self.device_type)
                # add the event detector to the vdevice
                if self.event_detection and x == 'Avg':
                    vdevice.event_detector = EventDetector(self, vdevice)
                # add to vdevice dictionary
                vdevice_d[name] = vdevice

        # set vdevice groups
        for vdevice_name, vdevice in vdevice_d.items():
            vdevice.group_d[self.name] = self
            if self.parent:
                vdevice.group_d[self.parent.name] = self.parent

        return vdevice_d

    def init_filters(self, filter_cfg):
        device_filter_l = []
        client_filter_l = []

        for ftype, fcfg in filter_cfg.items():
            # remove whitespace
            fcfg = re.sub(r'\s', '', fcfg)

            if ftype == "ip_range":
                entries = fcfg.split(',')
                for e in entries:
                    start_ip, end_ip = e.split('-')
                    f = IpRangeFilter(start_ip, end_ip)
                    device_filter_l.append(f)
            elif ftype in ["ip_network", "ip_subnet"]:
                entries = fcfg.split(',')
                for e in entries:
                    f = IpNetworkFilter(e)
                    device_filter_l.append(f)
            elif ftype == "name":
                f = NameFilter(fcfg)
                device_filter_l.append(f)
            elif ftype == "ap_group":
                f = ApGroupFilter(fcfg)
                device_filter_l.append(f)
            elif ftype == "client_location":
                f = ClientLocationFilter(fcfg)
                client_filter_l.append(f)

        return device_filter_l, client_filter_l

    def contains_device (self, device):
        if self.name in device.manual_group_l:
            return True

        if self.parent and not self.parent.contains_device(device):
            return False

        # check device type
        if self.device_type and self.device_type != device.type:
            return False

        # match filters
        for f in self.device_filter_l:
            if f.match(device):
                return True

        return False

    def contains_client (self, client):
        if self.parent and not self.parent.contains_client(client):
            return False

        # match filters
        for f in self.client_filter_l:
            if f.match(client):
                return True

        return False

    def device_list (self, dtype = None):
        if not dtype and self.device_type:
            dtype = self.device_type

        device_l = cfg.devices(dtype=dtype).values()

        if self.device_filter_l:
            device_l = [x for x in device_l if self.contains_device(x)]

        return device_l

    def as_dict (self):
        device_list = [x.name for x in self.device_list()]
        parent = None
        if self.parent:
            parent = self.parent.name

        return {
            "name" : self.name,
            'device_type' : self.device_type,
            'aggregate' : self.aggregate,
            'db_index' : self.db_index,
            'device_count' : len(device_list),
            'device_list' : device_list,
            'parent': parent,
            'children': [x.name for x in self.children],
            }

    def init_subgroups (self):
        #
        # add the ap_group groups
        ap_group_s = set()
        for ap in self.device_list(dtype="CiscoAP"):
            if ap.ap_group:
                ap_group_s.add(ap.ap_group)

        try:
            ap_group_s.remove("default")
        except KeyError: pass

        for ap_group in ap_group_s:
            grp_name = "%s:%s" % (self.name, ap_group)

            dg = DeviceGroup(grp_name, "CiscoAP", True, False, self.db_index,
                             {'ap_group': ap_group}, parent=self)
            self.children.append(dg)
            cfg.group_d[grp_name] = dg
