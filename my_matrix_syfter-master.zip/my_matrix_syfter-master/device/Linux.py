import time
import re
import xml.etree.ElementTree as ET
import xmltodict

from common import utility
from common import config as cfg
from common import logger as log
from common import parse

from .Device import Device
from .DeviceCli import DeviceCli


class Linux (Device):
    def init_cli (self):
        self.cli = LinuxCli(self)

class LinuxCli(DeviceCli):
    def __init__(self, device_name):
        super().__init__(device_name)

        # commands to run after connecting
        self.post_connect_commands = [
            'export PS1="[\h]# "',
        ]

class Linux_RHEL (Linux): pass

