"""
File: RootDevice.py
Class: RootDevice
Parent: Device

This module contains the class for the root/summary pseudo-device.
"""
import re
import numpy as np

from .Item import Item
from common import \
    config as cfg, \
    logger

class RootDevice(Item):
    def __init__(self):
        pass

    def aggregate_nugget (self, metric_name, device_l, method):
        vals = []

        for ap in device_l:
            if metric_name in ap.nugget_d:
                value = ap.nugget_d[metric_name].prev_value
                if value != None:
                    vals.append(value)

        if vals:
            method = method.lower()
            if method == "avg":
                return np.mean(vals)
            elif method == "sum":
                return np.sum(vals)

        # didn't work out :-/
        return None

    def percent_active (self, threshold=1):
        ap_count = 0
        active_count = 0

        for key, device in cfg.device_d.items():
            # only look at APs
            if hasattr(device, 'wlc'): # LEVY: not production, use device relationships
                ap_count += 1
                if ((device.nugget_d["clientCount_2.4GHz"].prev_value +
                     device.nugget_d["clientCount_5GHz"].prev_value) > threshold):
                    active_count += 1

        return (100 * active_count / ap_count)

    def top_devices (self, dtype, nugget_name, n):
        val_l = []
        for ap in cfg.devices(dtype=dtype).values():
            if nugget_name in ap.nugget_d:
                val = ap.nugget_d[nugget_name].prev_value
                if val:
                    val_l.append({'name': ap.name, 'val': val})

        val_l = sorted(val_l, key=lambda x: x['val'], reverse=True)[:n]

        return val_l

    def top_clientCount (self):
        val_l = []
        for ap in cfg.devices(dtype="CiscoAP").values():
            if "clientCount_2.4GHz" in ap.nugget_d and "clientCount_5GHz" in ap.nugget_d:
                val = 0;
                val1 = ap.nugget_d["clientCount_2.4GHz"].prev_value
                val2 = ap.nugget_d["clientCount_5GHz"].prev_value
                if val1 or val2:
                    val = (val1 or 0) + (val2 or 0)
                    val_l.append({'name': ap.name, 'val': val})

        val_l = sorted(val_l, key=lambda x: x['val'], reverse=True)[:10]

        return val_l

    def top_ethThroughput (self):
        val_l = []
        for ap in cfg.devices(dtype="CiscoAP").values():
            val = None
            if "ethThroughput" in ap.nugget_d:
                val = ap.nugget_d["ethThroughput"].prev_value
            elif "ethThroughputWLC" in ap.nugget_d:
                val = ap.nugget_d["ethThroughputWLC"].prev_value

            if val:
                val_l.append({'name': ap.name, 'val': val})

        val_l = sorted(val_l, key=lambda x: x['val'], reverse=True)[:10]

        return val_l
