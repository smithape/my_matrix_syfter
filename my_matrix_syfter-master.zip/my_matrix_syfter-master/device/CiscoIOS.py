"""
File: CiscoIOS.py
Class: CiscoIOS
Parent: CiscoDevice

This module supports devices that run Cisco IOS.
"""

import sys, time, operator, os, collections
import re
from pkg import pexpect

from common import utility
from common import config as cfg
from common import logger as log
from .CiscoDevice import CiscoDevice
from .Device import Device

class CiscoIOS(CiscoDevice):
    def __init__(self, device_name, device_type = None):
        super().__init__(device_name, device_type)
        self.supported_actions += [
            "reboot",
            "confbanner",
            "copyfrom",
            ]

        self.add_do_prefix_in_config_mode = True
        self.ap_l = []

    def clean_prompt (self, session):
        """For console, make sure there's no stale text on the line."""

        session.send('q')
        session.sendcontrol('u')
        # apparently, entering these commands when logged out prevents
        # a newline from registering for a time. The following two lines
        # will give a wait period if we are in the logged out state.
        session.send('\r')
        session.expect(["[#|>]", pexpect.TIMEOUT], timeout = 1)

    def clear_line (self, line_number):
        """Clear the line in question"""

        session = self.connect()
        translated_line_number = (int(line_number) - 2000)
        session.sendline("clear line %s\r" % translated_line_number)
        session.expect("[confirm]")
        session.send("\r")
        session.expect("#")
        session.close()
        return

    def config_is_unsaved (self, session):
        """determine whether the device has unsaved configuration"""

        self.term_enable(session, required=True)

        session.sendline("reload")
        ret = session.expect(["modified", "confirm"])
        if ret == 0:
            session.sendcontrol('c')
        session.sendcontrol('c')
        session.expect("#")

        if ret == 0:
            return True
        else:
            return False

    def get_cpu_utilization (self, session):
        """extract the CPU utilization"""

        session.sendline("show proc | inc CPU")

        ret = session.expect([": ([0-9]+)%",
                              pexpect.TIMEOUT], timeout=5)

        if ret == 0:
            print(session.match.group(0))
            return session.match.group(1)
        else:
            return None

    def reboot (self, session):
        """perform a soft reset or 'reload' on the device"""

        self.term_enable(session, required=True)
        session.sendline("reload")

        while True:
            ret = session.expect(["modified",
                                  "confirm"
                                  ])
            if ret == 0:
                if (not self.force
                    and not utility.prompt("The device has unsaved config!"
                                            + " Continue?")):
                    # back out
                    session.sendline('no')
                    session.send('n')
                    session.expect('#')
                    return
                else:
                    session.sendline('no')
            else:
                session.send('y')
                session.expect(["#", pexpect.EOF])
                return

    def get_port_dict (self):
        """
        Compile a dictionary consisting of termserver ports and the devices
        connected to them. This is for termservers.
        """

        port_dict = {}

        for key, device in cfg.device_tree.items():
            # get console
            [ts_hostname, ts_port] = device.get("console", size=2)
            if ts_hostname == self.name and ts_port:
                port_dict[ts_port] = device.name
            # get aux
            [ts_hostname, ts_port] = device.get("aux", size=2)
            if ts_hostname == self.name and ts_port:
                port_dict[ts_port] = device.name + " (aux)"

        return port_dict

    def show_ports (self):
        """
        Show a listing of termserver ports and connected devices.
        """

        output = ""

        port_dict = self.get_port_dict()
        line_list = utility.natural_sort(port_dict.keys())

        indent = 6
        output += "%s %s\n" % ("Port".ljust(indent), "Hostname")
        output += "%s %s\n" % ("====".ljust(indent), "========")
        for ts_port in line_list:
            device_name = port_dict[ts_port]
            output += "%s %s\n" % (ts_port.ljust(indent), device_name)

        return output

    def conf_banner (self, session):
        """
        Use data compiled from the configuration file to auto-generate
        a termserver banner and write it to the device. This will also
        configure 'ip host' aliases for termserver lines.
        """

        self.term_enable(session, required=True)
        ip_address = self.get("ip_address", True)

        session.sendline("terminal length 0")
        session.expect("#")

        #
        # Get the list of currently configured P# hosts
        #
        host_list = []
        session.sendline("show run | inc ip host p")
        while True:
            regex = "ip host p[0-9]+\s+2[0-9]{3}\s+[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+"
            ret = session.expect([regex, "#"])
            if ret == 0:
                host_list += [session.match.group(0)]
            else:
                break

        #
        # Get the port range for this termserver
        #
        regex = "\s*[0-9]+/[0-9]+/?[0-9]*\s+([0-9]+)\s+TTY\s+[0-9]+/[0-9]+[^\n]*\n"
        session.sendline("show line")
        session.expect(regex)
        low_port = int(session.match.group(1))
        while True:
            ret = session.expect([regex, "#"])
            if ret == 0:
                high_port = int(session.match.group(1))
            else:
                break

        low_port += 2000
        high_port += 2000

        port_dict = self.get_port_dict()

        #
        # Enter config mode
        #
        self.term_conf_t(session, required=True)

        #
        # Remove current host config
        #
        print("Cleaning existing 'ip host' entries...")
        for host_entry in host_list:
            session.sendline("no %s" % host_entry)
            session.expect("#")

        #
        # Add host configs
        #
        print("Configuring 'ip host' entries...")
        i = 0
        for port in range(low_port, high_port+1):
            session.sendline("ip host p%d %d %s" % (i, port, ip_address))
            session.expect("#")
            i += 1

        #
        # Build the banner
        #
        print("Configuring banner...")
        lab = self.get("lab")
        rack = self.get("rack")
        site_name = cfg.site_name
        admin = cfg.admin_email

        banner_string = ""
        banner_string += "**WARNING: This banner is auto-generated. Do not edit manually**\n"
        banner_string += "\n"
        if (site_name):
            banner_string += "Testbed: " + site_name + "\n"
        if (admin):
            banner_string += "Admin: " + admin + "\n"
        banner_string += "Lab: " + lab + "\n"
        banner_string += "Rack: " + rack + "\n"
        banner_string += "\n"
        banner_string += "Alias   Port    Hostname\n"
        banner_string += "=====   =====   =================\n"

        i = 0
        for port in range(low_port, high_port+1):
            banner_string += "p%s%s" % (str(i).ljust(7), str(port).ljust(8))
            if str(port) in port_dict:
                banner_string += "%s" % port_dict[str(port)]
            banner_string += "\n"
            i += 1

        session.sendline("banner motd ^")
        session.sendline(banner_string)
        session.sendline("^C")
        session.expect("#")
        session.sendline("end")
        session.expect("#")

    def get_int_desc_entries (self, session, ldm_signature_re):
        """
        Get the list of currently configured descriptions
        (those with the ldm_signature_re prepended).
        We use the output of the 'show int description' command to find this
        information.
        """

        session.sendline("show interface description")

        entries = collections.OrderedDict()
        while True:
            # this regex searches the output of the above command for
            # interfaces with descriptions including the ldm_signature_re prefix
            regex = "([^\s]+)[^\n]+%s([^\n]+)\n" % ldm_signature_re
            ret = session.expect([regex, "#"])
            if ret == 1:
                break
            description = session.match.group(2)
            entries[session.match.group(1)] = description

        return entries

    def copy_from (self, session, src_filepath, dst_filepath):
        """
        Copy a file from the device to the local file system.
        """

        filename = os.path.basename(dst_filepath)
        dirname = os.path.dirname(dst_filepath)

        server_ip = utility.get_local_ip()
        # spawn the http server that will recieve the file from the device
        # and write it to the specified directory
        server_port = utility.start_http2_server_thread(dirname)

        src = src_filepath
        dst = ("http://%s:%s/%s" % (server_ip, server_port, filename))

        self.copy(session, src, dst)

    def snmp_get_hostname (self):
        hostname = None

        snmp_query = self.oid_map['hostName']
        snmp_response = self.snmp_get([snmp_query], timeout=5, retries=1)

        if snmp_response:
            hostname, = snmp_response
            # change the name in the device dict
            try:
                del cfg.device_d[self.name]
                cfg.device_d[hostname] = self
            except KeyError: pass
            # set the new name
            self.name = hostname
            self.hostname = hostname
        else:
            self.snmp_is_up(check=True)

        return hostname

    def needs_scan (self):
        """
        determine if there are any APs connected to this switch that can't
        find their interface mapping in the ifindex_map
        """
        for ap in self.ap_l:
            if ap.switch_ifname not in self.ifindex_map:
                return True

        return False

    def set_ap_l (self):
        self.ap_l = [x for x in cfg.devices(dtype="CiscoAP").values()
                     if x.switch is self]

    def set_ap_ifindex (self):
        # init the ap list
        self.set_ap_l()

        if self.needs_scan():
            self.scan_ifindex_map()

        for ap in self.ap_l:
            if not ap.switch_ifindex:
                try:
                    ap.switch_ifindex = self.ifindex_map[ap.switch_ifname]
                except KeyError: pass

    def track_cfg (self):
        # get the config
        s = self.connect()
        s.send('term len 0\r')
        s.expect(self.prompt_re)
        s.send("show run\r")
        s.expect(self.prompt_re)
        cfg_str = s.before
        s.close()

        # remove the show command (1st line)
        cfg_str = cfg_str.split('\r', 2)[2]
        # remove carriage returns
        cfg_str = re.sub(r'\r', '', cfg_str)
        # remove empty lines
        cfg_str = re.sub(r'^\n', '', cfg_str, flags=re.MULTILINE)
        # edit out comments
        # cfg_str = re.sub(r'^\s*[:|!].*\n', '', cfg_str, flags=re.MULTILINE)

        # write the file
        filepath = "%s/%s.cfg" % (cfg.config_tracker_dir, self.name)
        with open (filepath, 'w') as f:
            f.write(cfg_str)
