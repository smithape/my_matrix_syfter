"""
File: CiscoSwitch.py
Class: CiscoSwitch
Parent: CiscoIOS

This module supports switches that run Cisco IOS.
"""

import time
import yaml

from nugget import Nugget
from common import utility
from common.exception import ConfigError
from common import config as cfg
from common import logger as log

from .CiscoIOS import CiscoIOS

class CiscoSwitch(CiscoIOS):
    def __init__(self, device_name, device_type = None):
        super().__init__(device_name, device_type)

        self.nugget_cfg_ap = Nugget.getNuggetConfig("CiscoAP")

        # the ap threads check this dict to see which Nuggets to poll
        self.ap_poll_time = 0
        self.ap_nugget_d = {}
        self.auto_discovery_bank = 0

    def load_snmp_cfg (self):
        """ pull new snmp configuration from the config files """

        # initialize the latest site config
        cfg_text = cfg.get_config_text("site")
        site_cfg = yaml.full_load(cfg_text) or {}

        options = ['snmp_version',
                   'snmp_community',
                   'snmp_username',
                   'snmp_seclevel',
                   'snmp_auth',
                   'snmp_priv']

        # first set global values
        if 'global' in site_cfg:
            glb_cfg = site_cfg['global']
            if 'switch0' in glb_cfg: # multiple banks
                # try iterating through all banks
                i = self.auto_discovery_bank
                while "switch%s" % i in glb_cfg:
                    block = glb_cfg['switch%s' % i]
                    for opt in options:
                        if opt in block:
                            setattr(self, opt, block[opt])
                    try:
                        if self.snmp_get([self.oid_map['sysDescr']]):
                            self.auto_discovery_bank = i
                            break
                    except ConfigError: pass

                    # increment i
                    if self.auto_discovery_bank:
                        if i == self.auto_discovery_bank:
                            i = 0 # restart at 0
                            continue
                        elif i + 1 == self.auto_discovery_bank:
                            i += 2 # skip this time
                            continue
                    i += 1
            else:
                for opt in options:
                    switch_opt = "switch_%s" % opt
                    if switch_opt in glb_cfg:
                        setattr(self, opt, glb_cfg[switch_opt])

        # overwrite with anything specific
        if self.name in site_cfg:
            block = site_cfg[self.name]
            for opt in options:
                if opt in block:
                    setattr(self, opt, block[opt])


    def init_polling_config (self):
        """ DESCRIBE """

        # call the parent function
        super(CiscoSwitch, self).init_polling_config()

        # Add the AP-centric Nuggets
        if cfg.poll_bulk:
            try:
                d = cfg.get_polling_interval_d()
                d = d['CiscoAP']
                for nugget_name, interval in d.items():
                    nugget = self.nugget_cfg_ap[nugget_name]

                    if nugget['type'] == "snmp@switch":
                        nugget_entry = cfg.init_nugget(self, nugget_name, interval, nugget_cfg=nugget)
                        for oid in nugget_entry.get_oid_list():
                            oid = oid.split("{", 1)[0][0:-1]
                            nugget_entry.oid.append(oid)
                        self.nugget_d[nugget_name] = nugget_entry
                        self.poll_thread_offset = -1
            except Exception as e:
                print(e)

    def trim_polling_config (self):
        # call the parent function
        super(CiscoSwitch, self).trim_polling_config()

        #
        # check SNMP@switch
        if self.polling_cfg_includes_type('snmp@switch'):
            if not self.snmp_is_up(check=True):
                # disable nuggets
                for x in self.nugget_d.values():
                    if x.type == "snmp@switch":
                        x.enabled = False
            else:
                # enable nuggets
                for x in self.nugget_d.values():
                    if x.type == "snmp@switch":
                        x.enabled = True
