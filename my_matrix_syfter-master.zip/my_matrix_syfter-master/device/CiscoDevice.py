"""
File: CiscoDevice.py
Class: CiscoDevice
Parent: Device

This module supports Cisco devices.
"""

import sys, os, time
from pkg import pexpect
import re

from common import utility
from common.exception import ConfigError
from common import logger as log
from .DeviceCli import DeviceCli
from .Device import Device

# supported action flags
supported_actions = [
    "confintdesc",
    "copyto",
    ]

class CiscoDevice(Device):
    def __init__(self, device_name, device_type = None):
        super().__init__(device_name, device_type)
        self.supported_actions += supported_actions

        # commands to run after connecting
        self.post_connect_commands = [
            'term len 0',
        ]

        # mapping between interface names and indexes
        self.ifindex_map = {}

    def init_cli (self):
        self.cli = CiscoDeviceCli(self)

    def get_device_d (self, full=False):
        d = super().get_device_d(full=full)

        # add device-specific stuff
        if full:
            d.update({
                'enable_password': self.get('enable_password')
                })

        return d

    def copy_to (self, session, src_filepath, dst_filepath):
        """copy a file to the device"""
        if not dst_filepath:
            dst_filepath = 'flash:/'

        filename = os.path.basename(src_filepath)
        dirname = os.path.dirname(src_filepath)

        server_ip = utility.get_local_ip()
        # spawn the http server that will serve out the directory
        server_port = utility.start_http_server_thread(dirname)

        src = ("http://%s:%s/%s" % (server_ip, server_port, filename))
        dst = dst_filepath

        # initiate the transaction from the device
        self.copy(session, src, dst)

    def copy (self, session, src, dst):
        """initiate a file download/upload from the device"""

        self.cli.term_enable(session, required=True)
        src_filename = os.path.basename(src)

        # execute the copy
        session.sendline("copy %s %s" % (src, dst))
        while True:
            ret = session.expect(["Address or name of remote host[^\n]*", #0
                                  "Source filename[^\n]*", #1
                                  "Destination filename \[([^\]]*)]\?", #2
                                  "Do you want to over write\?", #3
                                  "Accessing [a-zA-Z]+://[^\n]*\.\.\.", #4
                                  "\nStoring [a-zA-Z]+://[^\n]*", #5
                                  "\nLoading [a-zA-Z]+://[^\n]*", #6
                                  "\nWriting file [a-zA-Z0-9]*:/[^\n]*", #7
                                  "Cryptochecksum: [1-9a-f][^\n]*", #8
                                  "!", #9
                                  "[0-9]+ bytes copied in [0-9.]+ secs[^\n]*", #10
                                  "(?i)invalid input", #11
                                  pexpect.EOF, #12
                                  "(?i)\n[^\n]*error [^\n]+", #13
                                  "#", #14
                                  pexpect.TIMEOUT #15
                                  ],
                                 timeout=60
                                 )
            if ret <= 2: # some confirmations
                session.send("\r")
            elif ret == 3:
                # The file exists; prompt the user about overwriting
                if (not self.force and not
                    utility.prompt("File exists on the device. Overwrite?")):
                    session.sendcontrol('z')
                    return
                else:
                    session.send("\r")
            # LEVY: finish here
            elif 4 <= ret <= 5:
                print("Transferring...")
            elif ret == 6:
                pass
            elif ret == 7:
                print("\nWriting...")
            elif ret == 8:
                print(session.match.group(0))
            # elif 4 <= ret <= 8: # we want to print these lines
                # print(session.match.group(0))
            elif ret == 9: # '!' progress indicators
                sys.stdout.write(session.match.group(0))
                sys.stdout.flush()
            elif ret == 10: # 'bytes copied'
                print("\n"+session.match.group(0))
                break
            elif ret == 11:
                utility.error("Invalid input (filename not supported?)")
            elif ret == 12:
                utility.error("connection terminated!\n"
                              +"(this can happen when copying to running-config)")
            else: # some sort of error
                if ret == 13: # we got an error message
                    print(session.match.group(0))
                utility.error("copy failed!")

    def write_mem (self, session):
        """save the running config"""

        if not self.force and not utility.prompt("Write the config?"):
            return False

        session.sendline("wr") # save the config
        session.expect("[OK]")
        session.expect("#")
        return True

    def conf_int_desc (self, session, overwrite=False):
        """
        This funciton will use connection data from the config file
        to configure interface descriptions on the device.
        """

        ldm_signature = "[ldm] "
        ldm_signature_re = "\[ldm\] "

        self.cli.term_enable(session, required=True)
        session.sendline("terminal length 0")
        session.expect("#")

        # get the list of old entries (only ldm entries)
        # This is put into a function because the method differs
        # between IOS and ASA
        old_entries = self.get_int_desc_entries(session, ldm_signature_re)

        # go to configure mode
        self.cli.term_conf_t(session, required=True)

        #
        # Remove all of the old entries
        #
        if len(old_entries):
            print("\nRemoving old entries...")
        for local_if, description in old_entries.items():
            session.sendline("int %s" % local_if)
            session.expect('#')
            print("- %s <-> %s" % (local_if, description))
            session.sendline("no description")
            session.expect("#")

        #
        # Build the new interface dictionary
        #
        if_dict = self.get_interface_dict()

        # Sort the list
        sorted_if_list = utility.natural_sort(list(if_dict.keys()))

        #
        # Write the new descripton configs
        #
        print("\nAdding new entries...")
        for local_if in sorted_if_list:
            (remote_hostname, remote_if) = if_dict[local_if]
            if not remote_hostname:
                continue

            # get into the if config mode
            session.sendline("int %s" % local_if)
            ret = session.expect([self.conf_if_prompt_re,
                                  self.conf_prompt_re])
            if ret == 1: # this means the interface name wasn't valid
                print("Unknown Interface: " + local_if)
                continue

            if not overwrite:
                # make sure there is no existing description (we don't
                # want to overwrite manually configured descriptions)
                if self.add_do_prefix_in_config_mode:
                    session.sendline("do show run int %s | inc desc" % local_if)
                else:
                    session.sendline("show run int %s | inc desc" % local_if)

                ret = session.expect(["description", "#"])
                if ret == 0:
                    print("%s has a manual entry" % local_if)
                    session.expect("#")
                    continue

            # write the description
            description = remote_hostname
            if remote_if:
                description += ":" + remote_if

            print("+ %s <-> %s" % (local_if, description))
            session.sendline("description %s%s" % (ldm_signature, description))
            session.expect("#")

        session.sendcontrol('z')
        session.expect("#")

    def get_cpu_index (self):
        snmp_query = self.oid_map['cpmCPUTotal1minRev']
        snmp_response = self.snmp.walk(snmp_query)
        cpu_index = 1
        for oid, val in snmp_response.items():
            cpu_index = oid.rsplit('.', 1)[-1]

        return cpu_index

    def scan_ifindex_map (self):
        """
        scan the snmp mib to discover the oid-number <-> interface name mapping
        """
        snmp_query = self.oid_map['ifName']

        try:
            snmp_response = self.snmp.walk(snmp_query, timeout=5, retries=1)
        except ConfigError:
            log.error("Device not configured for SNMP", "config", self)
            return

        if not snmp_response:
            self.snmp.is_up(check=True)
            return

        for oid, val in snmp_response.items():
            if oid and val:
                self.ifindex_map[val.lower()] = oid.rsplit('.', 1)[-1]

    def get_poll_if_d (self):
        """ find the interfaces that are configured for throughput polling """

        # get list of names to poll
        poll_ifnames = self.get("poll_ifnames")

        if not poll_ifnames:
            return {}

        # condition the interface names
        poll_ifnames = re.sub(r'serial\s+', 'se', poll_ifnames, flags=re.I)
        poll_ifnames = re.sub(r'vlan\s+', 'vl', poll_ifnames, flags=re.I)
        poll_ifnames = re.sub(r'tengigabitethernet\s+', 'te', poll_ifnames, flags=re.I)
        poll_ifnames = re.sub(r'gigabitethernet\s+', 'gi', poll_ifnames, flags=re.I)
        poll_ifnames = re.sub(r'fastethernet\s+', 'fa', poll_ifnames, flags=re.I)
        poll_ifnames = re.sub(r'port-channel\s+', 'po', poll_ifnames, flags=re.I)
        poll_ifnames = [x.strip() for x in poll_ifnames.split(',')]

        if not self.ifindex_map:
            self.scan_ifindex_map()

        poll_if_d = {}
        for ifname in poll_ifnames:
            try:
                # split and strip whitespace
                alias, ifname = [x.strip() for x in ifname.split('=')]
                ifname = ifname.lower()
            except ValueError:
                ifname = ifname.lower()
                alias = ifname


            if "*" in ifname:
                ifname = ifname.replace('*', '.*')
                for ifname2, ifentry in self.ifindex_map:
                    if re.match(ifname, ifname2):
                        poll_if_d[ifname2] = ifentry
            elif ifname in self.ifindex_map:
                poll_if_d[alias] = self.ifindex_map[ifname]
            else:
                log.error("Interface not found: \"%s\"" % ifname, "config", device=self)

        return poll_if_d

class CiscoDeviceCli(DeviceCli):
    user_prompt_re = re.compile(b'[\n\r][^\r\n\s]+>')
    enable_prompt_re = re.compile(b'[\n\r][^\r\n\s]+#')
    conf_prompt_re = re.compile(b'[\n\r][^\r\n\s]+\(config\)#')
    conf_if_prompt_re = re.compile(b'[\n\r][^\r\n\s]+\(config-if\)#')
    any_conf_prompt_re = re.compile(b'[\n\r][^\r\n\s]+\(config[^)]*\)#')

    # the default
    prompt_re = re.compile(b'([\n\r])([^\n\s]+(?:\(?:[\w-]+\))?[#>])')

    def __init__(self, device):
        super().__init__(device)

        # for filtering CLI output
        self.filter_command = 'i'

    def connect_misc (self, session, required=True):
        """
        placeholder to perform platform-specific operations after a connection
        is made
        """
        super().connect_misc(session, required=True)

        self.term_enable(session, required=required)

    def init_webterm (self):
        try:
            self.session_read_to_end()
            self.session.sendcontrol('u')
        except Exception as e:
            # try to init the session
            if self.set_session():
                self.session.send('term len 0\r')
                self.session.expect(self.prompt_re)
            else:
                return False

        return True

    def term_enable (self, session, required=False):
        """try to get into enable mode"""

        session.send("\r")
        ret = session.expect([self.user_prompt_re,
                              self.enable_prompt_re,
                              self.any_conf_prompt_re,
                              pexpect.TIMEOUT], timeout=3)
        if ret == 1: # in enable mode, nothing to do
            return True
        elif ret == 2: # in configure mode
            session.sendcontrol('z')
            session.expect("#")
            return True
        elif ret == 3: # timeout...not at a prompt (eg. bootup)
            if required:
                utility.error("couldn't get into enable mode!")
            else:
                return False

        session.sendline("enable")
        password_entered = False
        retry = True
        while True:
            ret = session.expect([self.user_prompt_re,
                                  self.enable_prompt_re,
                                  "(?i)password: ",
                                  pexpect.TIMEOUT],
                                 timeout=3)
            if ret == 0: # failure
                if retry:
                    retry = False
                    continue
                else:
                    break
            if ret == 1: # success
                return True
            elif ret == 2:
                if not password_entered: # enter the password
                    enable_password = self.device.get("enable_password")
                    session.send("%s\r" % enable_password)
                    password_entered = True
                else: # failure
                    break
            elif ret == 3: # some sort of error
                break


        # we only get here if we failed to get to enable mode
        # first, back out of the enable attempt (send newlines
        # until we get a normal prompt
        while True:
            session.send("\r")
            ret = session.expect(["(?i)password: ",
                                  self.user_prompt_re,
                                  self.enable_prompt_re,
                                  pexpect.TIMEOUT],
                                 timeout=3)
            if ret == 2: # this only happens if the password is blank
                return True
            elif ret > 0:
                break

        if required:
            utility.error("couldn't get into enable mode!")
        else:
            return False

    def term_conf_t (self, session, required=False):
        """try to get into configure mode"""

        session.send("\r")
        ret = session.expect([self.user_prompt_re,
                              self.enable_prompt_re,
                              self.any_conf_prompt_re,
                              pexpect.TIMEOUT], timeout=3)
        if ret == 0: # in user mode
            self.term_enable(session, required=required)
        elif ret == 2: # in configure mode, nothing to do
            return True
        elif ret == 3: # timeout...not at a prompt (eg. bootup)
            if required:
                utility.error("couldn't get into configure mode!")
            else:
                return False

        session.sendline("conf t")
        ret = session.expect([self.conf_prompt_re,
                              pexpect.TIMEOUT], timeout=3)
        if ret == 0: # in configure mode
            return True
        else:
            if required:
                utility.error("couldn't get into configure mode!")
            else:
                return False
