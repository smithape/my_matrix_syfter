"""
File: CiscoWLC.py
Class: CiscoWLC
Parent: Device

This module supports devices that run Cisco WLC.
"""

import sys, os, time
from pkg import pexpect
import re
from threading import Thread
from subprocess import getstatusoutput
from multiprocessing.pool import Pool, ThreadPool

from nugget import Nugget
from common import config as cfg
from common import logger as log
from common import utility
from .Device import Device
from .CiscoAP import CiscoAPv1, CiscoAPv2
from .CiscoSwitch import CiscoSwitch
from .DeviceCli import DeviceCli

class CiscoWLC(Device):
    def __init__(self, device_name):
        super().__init__(device_name)

        self.nugget_cfg_ap = Nugget.getNuggetConfig("CiscoAP")

        # update interval for some of the SNMP counters
        self.stats_timer = 0
        # the ap threads check this dict to see which Nuggets to poll
        self.ap_poll_time = 0
        self.ap_nugget_d = {}
        self.ssid_d = {}
        self.ap_group_s = set()

        # offset for polling_thread timing
        self.poll_thread_offset = -1

    def init_cli (self):
        self.cli = CiscoWLCCli(self)

    def query_nugget_vars (self):
        #
        # get the new ssid map
        new_ssid_d = self.get_ssid_map()
        if new_ssid_d != self.ssid_d:
            # Assign if changed
            self.ssid_d = new_ssid_d
            if (int(time.time()) - self.last_nugget_vars_update) >= cfg.scan_period:
                # mark all of this WLCs APs as needing an update
                for ap in cfg.devices(dtype="CiscoAP").values():
                    if ap.wlc is self and 'ssid' in ap.nugget_var_d:
                        ap.nugget_vars_update = True

    def gather_nugget_vars (self):
        for var in self.get_nugget_variables():
            if var == "ssid":
                self.nugget_var_d[var] = self.ssid_d
                log.info("Found %d ssids" % len (self.ssid_d), "config", device=self)

    def get_ssid_map (self):
        # import yaml
        # text = cfg.get_config_text("site")
        # tmp_config = yaml.full_load(text) or {}
        # poll_ssid = tmp_config[self.name]['poll_ssid']

        poll_ssid = self.get("poll_ssid")
        if poll_ssid:
            poll_ssid = poll_ssid.split(',')
            poll_ssid = [x.strip() for x in poll_ssid]

        # get wlan-ssid mapping
        snmp_query = self.oid_map['bsnDot11EssSsid']
        snmp_response = self.snmp_walk(snmp_query)
        if not snmp_response:
            self.snmp_is_up(check=True)
            return

        ssid_d = {}
        for oid, val in snmp_response.items():
            # only consider valid responses
            if not val: continue
            ssid_name = val
            ssid_id = int(oid.rsplit('.', 1)[-1])
            ssid_d[ssid_name] = ssid_id

        if poll_ssid:
            ssid_d = {x:y for x,y in ssid_d.items() if x in poll_ssid}

        return ssid_d

    def switch_info_required (self):
        """
        Determine whether or not this WLC needs to scan for upstream
        switch information. In other words, are there any switch-required Nuggets
        configured?
        """
        # get the Nuggets that are in the polling config (including group children)
        poll_cfg_l = cfg.get_polling_cfg_names("CiscoAP")

        # get the comprehensive list of 'snmp@switch' type Nuggets
        switch_nugget_l = [x for x,y in Nugget.nugget_config['CiscoAP'].items()
                             if y['type'] == "snmp@switch"]

        for nugget_name in switch_nugget_l:
            if nugget_name in poll_cfg_l:
                return True

        return False

    # LEVY: Not sure about separating this out!
    def snmp_get_dot3_addr (self, oid, trailing=0):
        dot3_addr_re = "((?:[\d]+\.?){6})(?:[\d]+\.?){%d}$" % trailing
        match = re.search(dot3_addr_re, oid)

        return match.group(1).strip('.')

    ap_model_map = {
        1560: CiscoAPv2,
        1570: CiscoAPv2,
        1800: CiscoAPv2,
        2800: CiscoAPv2,
        3800: CiscoAPv2,
    }
    def ap_scan (self):
        log.debug("Scanning %s for APs" % self.name)

        ap_d = {}

        # find APs by name
        ap_name_d = {}
        snmp_query = self.oid_map['bsnAPName']
        snmp_response = self.snmp_walk(snmp_query)
        if snmp_response:
            for oid, val in snmp_response.items():
                dot3_addr = self.snmp_get_dot3_addr(oid)

                if val:
                    ap_name_d[dot3_addr] = val

        if not ap_name_d:
            if self.snmp_is_up(check=True):
                log.error("Scan returned nothing", "device", device=self)
            return {}

        # find model #
        snmp_query = self.oid_map['bsnAPModel']
        snmp_response = self.snmp_walk(snmp_query)
        for oid, val in snmp_response.items():
            dot3_addr = self.snmp_get_dot3_addr(oid)
            try:
                # find the ap name
                ap_name = ap_name_d[dot3_addr]
                # extract the model number from the longer string
                model = int(re.findall(r'\d+', val)[0]) // 10 * 10
                model_100s = model // 100 * 100
                # find the device type
                if model_100s in self.ap_model_map:
                    fn = self.ap_model_map[model_100s]
                elif model in self.ap_model_map:
                    fn = self.ap_model_map[model]
                else:
                    fn = CiscoAPv1

                # create a new object
                ap = fn(ap_name,
                        wlc=self,
                        dot3_addr=dot3_addr)
                ap.model = str(model)
                ap.lwapp_uptime = 0
                ap_d[dot3_addr] = ap
            except (KeyError, TypeError): continue

        # find interface types
        snmp_query = self.oid_map['bsnAPIfType']
        snmp_response = self.snmp_walk(snmp_query)
        for oid, val in snmp_response.items():
            dot3_addr = self.snmp_get_dot3_addr(oid, trailing=1)
            try:
                ap_d[dot3_addr].interfaces.append(val)
            except KeyError: continue

        # find IP addresses
        snmp_query = self.oid_map['bsnApIpAddress']
        snmp_response = self.snmp_walk(snmp_query)
        for oid, val in snmp_response.items():
            dot3_addr = self.snmp_get_dot3_addr(oid)
            try:
                ap_d[dot3_addr].ip_address = val
            except KeyError: continue

        # find mac addresses
        snmp_query = self.oid_map['bsnAPEthernetMacAddress']
        snmp_response = self.snmp_walk(snmp_query)
        for oid, val in snmp_response.items():
            dot3_addr = self.snmp_get_dot3_addr(oid)
            try:
                # returns the ip address in unencoded hex
                # (1) encode to hex
                # (2) split into list of 2-char chunks
                # (3) join the octets with :
                mac_address = ":".join([x for x in re.findall('.{2}', val.encode("hex"))])
                ap_d[dot3_addr].mac_address = mac_address
            except (KeyError, AttributeError): continue

        # find ap_group
        snmp_query = self.oid_map['bsnAPGroupVlanName']
        snmp_response = self.snmp_walk(snmp_query)
        for oid, val in snmp_response.items():
            dot3_addr = self.snmp_get_dot3_addr(oid)
            try:
                ap_d[dot3_addr].ap_group = val
                self.ap_group_s.add(val)
            except KeyError: continue

        # find location
        snmp_query = self.oid_map['bsnAPLocation']
        snmp_response = self.snmp_walk(snmp_query)
        for oid, val in snmp_response.items():
            dot3_addr = self.snmp_get_dot3_addr(oid)
            try:
                ap_d[dot3_addr].location = val
            except KeyError: continue

        # find the statsTimer
        snmp_query = self.oid_map['bsnAPStatsTimer']
        snmp_response = self.snmp_walk(snmp_query)
        for oid, val in snmp_response.items():
            dot3_addr = self.snmp_get_dot3_addr(oid)
            try:
                ap_d[dot3_addr].stats_timer = val
                self.stats_timer = max(self.stats_timer, val)
            except KeyError: continue

        # find the statsTimer
        snmp_query = self.oid_map['cLLwappUpTime']
        snmp_response = self.snmp_walk(snmp_query)
        for oid, val in snmp_response.items():
            dot3_addr = self.snmp_get_dot3_addr(oid)
            try:
                ap_d[dot3_addr].lwapp_uptime = int(val)//(100*60)
            except KeyError: continue

        # find the supported channels
        snmp_query = self.oid_map['bsnAPIfPhyChannelNumber']
        snmp_response = self.snmp_walk(snmp_query)
        for oid, val in snmp_response.items():
            dot3_addr = self.snmp_get_dot3_addr(oid,trailing=1)
            try:
                ap_d[dot3_addr].channels.append(val)
            except KeyError: continue

        # filter out unmatched APs if we're using group scope polling
        if cfg.scan_scope == "group":
            # first match groups
            for ap in ap_d.values():
                ap.set_groups()
            # then remove unmatched
            ap_d = {x:y for x,y in ap_d.items()
                    if [i for i in y.group_d.values()]}

        #
        # Scan switch info
        if self.switch_info_required():
            # find upstream switch IPs
            snmp_query = self.oid_map['clcCdpApCacheNeighAddress']
            snmp_response = self.snmp_walk(snmp_query)

            for oid, val in snmp_response.items():
                dot3_addr = self.snmp_get_dot3_addr(oid, trailing=1)
                try:
                    ap = ap_d[dot3_addr]
                except KeyError: continue

                # returns the ip address in unencoded hex
                # (1) encode to hex
                # (2) split into list of 2-char chunks
                # (3) convert the junks into integer (and then string)
                # (4) join the octets with dots
                switch_ip = ".".join([str(int(x, 16)) for x in re.findall('.{2}', val.encode("hex"))])

                try:
                    # see if the switch is already discovered
                    switch = cfg.device_by_ip_d[switch_ip]
                except KeyError:
                    # Initialize a new switch object
                    switch = CiscoSwitch(switch_ip) # temp name
                    switch.ip_address = switch_ip
                    # pull in the snmp configuration
                    switch.load_snmp_cfg()
                    # Get the FQDN switch name
                    snmp_query = "%s.%s.1" % (self.oid_map['clcCdpApCacheNeighName'], ap.dot3_addr)
                    switch.name, = self.snmp_get([snmp_query])
                    # Try to find the shorter name
                    #switch.name = switch.snmp_get_hostname() or switch.name

                    cfg.device_by_ip_d[switch_ip] = switch
                    cfg.device_d[switch.name] = switch

                ap.switch = switch

            # find upstream interface
            snmp_query = self.oid_map['clcCdpApCacheNeighInterface']
            snmp_response = self.snmp_walk(snmp_query)

            for oid, val in snmp_response.items():
                dot3_addr = self.snmp_get_dot3_addr(oid, trailing=1)
                try:
                    ap = ap_d[dot3_addr]
                except KeyError: continue

                ifname = val
                interface_re = "([\w]{2})\w*((?:[\d]+\/?){1,4})"
                match = re.search(interface_re, ifname)
                if match:
                    ifname = match.group(1) + match.group(2)

                if ifname:
                    ap.switch_ifname = ifname.lower()

        # complete the dictionary to return
        ret_ap_d = {}
        for ap in ap_d.values():
            if (ap.ip_address and
                ap.ip_address != "0.0.0.0" and
                ap.lwapp_uptime > 5):
                # set the username and password
                ap.username = self.get("ap_username")
                ap.password = self.get("ap_password")
                ap.enable_password = self.get("ap_enable_password") or ap.password
                # set the connect_method
                ap.connect_method = self.get("ap_connect_method")
                # add to the dictionary to return
                ret_ap_d[ap.name] = ap
                # break
            else:
                log.error("Unstable device", "config", device=ap)

        return ret_ap_d

    def get_cpuUtilization (self, timeout=1):
        ret_val = None
        s = self.cli.session
        s.send("show cpu\r")

        ret = s.expect(["SystemLoad ([0-9]+)%",
                        "Current CPU\(s\) load: ([0-9]+)%",
                        pexpect.TIMEOUT],
                       timeout=timeout)
        if ret <= 1:
            match = s.match.group(1)
            ret_val = int(match)

        return ret_val

    # LEVY: not using the CLI for AP-centric polling on WLC
    # def get_clientSNR (self, timeout=1):
    #     #self.session.logfile = sys.stdout
    #     response_d = {}
    #     s = self.session
    #     s.send("config paging disable\r")


    #     for ap in self.ap_l:
    #         s.send("show ap auto-rf 802.11b %s\r" % ap.name)

    #         ret = s.expect(["Client Signal To Noise Ratios(.*)Nearby APs",
    #                         pexpect.TIMEOUT],
    #                        timeout=timeout)
    #         if ret == 0:
    #             average = 0
    #             total_sum = 0
    #             total_count = 0
    #             match = s.match.group(1)
    #             for line in match.split('\n'):
    #                 m = re.search( r'([0-9]+).*([0-9]+) clients', line)
    #                 if m:
    #                     snr = int(m.group(1))
    #                     count = int(m.group(2))
    #                     total_count = total_count + count
    #                     total_sum = total_sum + snr * count

    #             if total_count:
    #                 average = total_sum / total_count
    #             response_d [ap.name] = average

    #     return response_d

    def init_polling_config (self):
        """ DESCRIBE """

        # call the parent function
        super(CiscoWLC, self).init_polling_config()

        # Add the AP-centric Nuggets
        if cfg.poll_bulk:
            try:
                d = cfg.get_polling_interval_d()
                d = d['CiscoAP']
                for nugget_name, interval in d.items():
                    nugget = self.nugget_cfg_ap[nugget_name]

                    if nugget['type'] == "snmp@wlc":
                        nugget_entry = cfg.init_nugget(self, nugget_name, interval, nugget_cfg=nugget)
                        for oid in nugget_entry.get_oid_list():
                            oid = oid.split("{", 1)[0][0:-1]
                            nugget_entry.oid.append(oid)
                        self.nugget_d[nugget_name] = nugget_entry
            except Exception as e:
                print(e)

    def track_cfg2 (self):
        password = utility.random_string(length=10)
        # set the sftp user password
        command = 'echo "sftpuser:%s" | chpasswd' % password
        (code, result) = getstatusoutput(command)

        # upload
        s = self.connect()
        s.sendline("transfer upload mode sftp")
        s.sendline("transfer upload datatype config")
        s.sendline("transfer upload filename %s.cfg" % self.name)
        s.sendline("transfer upload username %s" % cfg.sftp_username)
        s.sendline("transfer upload password %s" % password)
        s.sendline("transfer upload path %s" % cfg.config_tracker_dir)
        s.sendline("transfer upload serverip %s" % utility.get_local_ip())
        s.sendline('transfer upload start')
        s.expect('(y/N)')
        s.send('y')
        s.expect(self.prompt_re)
        s.close()

        #
        # edit out comments
        filepath = "%s/%s.b.cfg" % (cfg.config_tracker_dir, self.name)
        with open (filepath, "r") as f:
            cfg_str = f.read()
            # remove empty lines
            cfg_str = re.sub(r'^\n', '', cfg_str, flags=re.MULTILINE)
            # edit out comments
            cfg_str = re.sub(r'^[!|#].*\n', '', cfg_str, flags=re.MULTILINE)
            cfg_str = re.sub(r'^transfer.*\n', '', cfg_str, flags=re.MULTILINE)
        with open (filepath, "w") as f:
            f.write(cfg_str)


    def track_cfg (self):
        # get the config
        s = self.connect()
        s.sendline("config paging disable")
        s.expect(self.prompt_re)
        s.sendline("show run-config startup-commands")
        s.expect(self.prompt_re, timeout=120)
        cfg_str = s.before
        s.close()

        # remove carriage returns
        cfg_str = re.sub(r'\r', '', cfg_str)
        # remove empty lines
        cfg_str = re.sub(r'^\n', '', cfg_str, flags=re.MULTILINE)
        # remove the show command
        cfg_str = re.sub(r'^show.*\n', '', cfg_str, flags=re.MULTILINE)
        # edit out comments
        cfg_str = re.sub(r'^[!|#].*\n', '', cfg_str, flags=re.MULTILINE)
        # edit out "transfer" lines
        cfg_str = re.sub(r'^transfer.*\n', '', cfg_str, flags=re.MULTILINE)

        # write the file
        filepath = "%s/%s.cfg" % (cfg.config_tracker_dir, self.name)
        with open (filepath, 'w') as f:
            f.write(cfg_str)


    def get_max_concurrent_users(self, text=None, regex=None):

        lines_matched_length = None
        ssid = None
        wlan_id = None
        grep_regex = None

        # get ssid from site config
        ssid = self.get("ssid")

        # get wlan id for the ssid configured
        if ssid in self.ssid_d:
            wlan_id = self.ssid_d[ssid]

        if regex and text:
            lines_matched_length = len(re.findall(regex%wlan_id,text))

        return lines_matched_length

    def get_max_concurrent_users_2_4ghz(self, text=None):

        # regex for capturing records for 2.4 GHz
        grep_regex = r"[\w:]+\s+\S+\s+\d+\s+(Associated)\s+%s\s+(Yes)\s+(802.11(?:bg|n\(2.4\s*GHz\)))"
        max_concurrent_users = self.get_max_concurrent_users(text, grep_regex)

        return max_concurrent_users

    def get_max_concurrent_users_5ghz(self, text=None):

        # regex for capturing records for 5 GHz
        grep_regex = r"[\w:]+\s+\S+\s+\d+\s+(Associated)\s+%s\s+(Yes)\s+(802.11(?:ac\(5\s*GHz\)|n\(5\s*GHz\)|a))"
        max_concurrent_users = self.get_max_concurrent_users(text, grep_regex)

        return max_concurrent_users


class CiscoWLCCli(DeviceCli):
    def __init__(self, device):
        super().__init__(device)

        # prompt regex
        self.prompt_re = re.compile(b'\n\([^\n]+\)\s*>')

        # commands to run after connecting
        self.post_connect_commands = [
            "config paging disable"
        ]

    def init_webterm (self):
        try:
            self.read_to_end()
            self.session.sendcontrol('u')
        except Exception as e:
            # try to init the session
            if self.set_session():
                self.session.send('config paging disable\r')
                self.session.expect(self.prompt_re)
                if "Incorrect usage" in self.session.before:
                    return "Couldn't disable paging!"
            else:
                return False

        return True

