<?php
/**
 * Options for the authextdjango plugin
 *
 * @author Robert Weidlich <dev@robertweidlich.de>
 */


$meta['url'] = array('string');

