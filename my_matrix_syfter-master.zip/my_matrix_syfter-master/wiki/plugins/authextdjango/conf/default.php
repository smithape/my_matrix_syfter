<?php
/**
 * Default settings for the authextdjango plugin
 *
 * @author Robert Weidlich <dev@robertweidlich.de>
 */

$conf['url']    = 'https://localhost/extauth';
