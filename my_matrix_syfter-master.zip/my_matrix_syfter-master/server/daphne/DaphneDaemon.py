import os
import subprocess

from common import logger as log
from common import config as cfg

class DaphneDaemon():
    def __init__(self):
        self.stdin_path = '/dev/null'
        self.stdout_path = '/dev/tty'
        self.stderr_path = '/dev/tty'
        self.pidfile_path =  cfg.get_pidfile('daphne')
        self.logfile = cfg.get_logfile('daphne')
        self.pidfile_timeout = 1
        self.interrupt = False
        self.app_name = "%s.asgi:application" % cfg.tool_name
        self.sockfile = cfg.get_sockfile('daphne')

        self.app_args = (
            ''
            #+ "--root-path %s" % proj_dir
            + " --unix-socket %s" % self.sockfile
            + " --websocket_timeout -1"
            #+ " --access-log %s" % self.logfile
            + " --verbosity 0"
            + " %s" % self.app_name
        )


    def run(self):
        try:
            os.environ["PYTHONPATH"] = cfg.proj_dir
            command = "daphne %s" % self.app_args
            output = subprocess.check_output(command.split(), stderr=subprocess.STDOUT)
        except Exception as e:
            log.debug("error: %s" % e)
        finally:
            try:
                log.debug("Stopping Daphne")
            except:
                log.debug("exception in daphne shutdown")

    def terminate(self, signal_number, stack_frame):
        (code, result) = subprocess.getstatusoutput("pkill -9 daphne")
        self.interrupt = True

