#!/usr/bin/env python
"""
This file handles all CLI inputs
"""

import os, sys
# initialize django
import django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "syfter.settings")
# levy hack for strange import problem?
os.environ["PYTHON_EGG_CACHE"] = "/tmp/.python-eggs/"
django.setup()
from django.db import connection
from django.contrib.auth.models import User
import shutil, traceback
import time
from datetime import datetime
import argparse
from tempfile import NamedTemporaryFile
from collections import OrderedDict
from subprocess import getstatusoutput
import subprocess
import multiprocessing
from getpass import getpass
import re
import json
import urllib

from twisted.internet import reactor
from pkg import pexpect
import lockfile
import signal

from pkg.daemon import runner
from common.models import \
    Device as Device_db, \
    Nugget as Nugget_db, \
    Event as Event_db
from common import \
    DB, utility, \
    textIO, \
    logger as log, \
    config as cfg

HEADER = '\033[95m'
OKBLUE = '\033[94m'
OKGREEN = '\033[92m'
WARNING = '\033[93m'
FAIL = '\033[91m'
ENDC = '\033[0m'
BOLD = '\033[1m'
UNDERLINE = '\033[4m'

def OK (string):
    return OKGREEN + string + ENDC

def Fail (string):
    return FAIL + string + ENDC

def usage (command=None):
    """
    Return the usage string.

    The string will differ depending on the command.
    """
    # find the command argument, if one was entered
    if not command:
        try:
            command = args.command
        except NameError:
            pass

    # alter the usage message based on the command argument
    if (command == "connect"
        or command == "console"
        or command == "telnet"
        or command == "ssh"):
        return (
            "\n"
            "Usage: {0} connect|console|telnet|ssh <device> [-f]\n"
            "\n"
            "Description:\n"
            "    These commands allow you to connect to devices.\n"
            "\n"
            "Options:\n"
            "    -f,--force     For console connections, clear the line first.\n"
            .format(cfg.tool_name))
    elif command == "show":
        return (
            "\n"
            "Usage: {0} show [<device>] [-v,-f filter_string]\n"
            "\n"
            "Description:\n"
            "    This command will display device information.\n"
            "\n"
            "Options:\n"
            "    <device>                  Show detailed information about a specific device\n"
            "    -f,--filter x             Filter the list displayed.\n"
            "                              (1) search specific device attributes:\n"
            "                                  Example: -f name=5505\n"
            "                                  Example: -f rack=e05\n"
            "                              (2) search through all configured attributes:\n"
            "                                  Example: -f 5505\n"
            "                              (3) use multiple filters (creating an AND relationship)\n"
            "                                  Example: -f rack=e05,5505\n"
            "    -v,--verbose              Show more information...give it a try!\n"
            .format(cfg.tool_name))
    elif command == "show_log":
        return (
            "\n"
            "Usage: {0} {1} <daemon_name>\n"
            "\n"
            "Description:\n"
            "    This command will display the latest log file for a specified daemon.\n"
            "\n"
            "Options:\n"
            "    <daemon_name>             Options: poller|server|monitor\n"
            "                              Default: poller\n"
            "    -t,--tail                 Watch the tail of the file.\n"
            .format(cfg.tool_name, command))
    elif command == "loadconfig":
        return (
            "\n"
            "Usage: {0} loadconfig <device> <file>\n"
            "\n"
            "Description:\n"
            "    This command will load the config from the specified file\n"
            "    onto the device. It uses/requires a console connection.\n"
            "\n"
            "Supported Types:\n"
            "    CiscoASA\n"
            .format(cfg.tool_name))
    elif command == "copy":
        return (
            "\n"
            "Usage: {0} copy [<device>:]src_filepath [<device>:]dst_filepath\n"
            "\n"
            "Description:\n"
            "    This command will copy files between the local server and the\n"
            "    remote device. The syntax mimics that of the 'scp' program (see\n"
            "    examples below).\n"
            "\n"
            "    There is some tricky stuff going on in the backgorund for this command:\n"
            "      (1) {0} spawns a temporary ftp/http server (protocol depends on the\n"
            "          device type) on the local server.\n"
            "      (2) {0} logs onto the device and uploads/downloads files from the server.\n"
            "\n"
            "Options:\n"
            "    -p,--proto      Specify the connection method (console|telnet|ssh)\n"
            "    -f,--force      Overwrite existing files without prompting\n"
            "\n"
            "Supported Types:\n"
            "    CiscoRouter, CiscoSwitch, CiscoTermserver, CiscoASA\n"
            "\n"
            "Examples:\n"
            "    {0} copy jw-asa5520-4:run .\n"
            "    {0} copy jw-asa5520-4:start jw-asa5520-config\n"
            "    {0} copy cdisk.asa jw-asa5520-4:\n"
            "    {0} copy cdisk.asa jw-asa5520-4:flash:/dev.asa\n"
            .format(cfg.tool_name))
    elif command == "reboot":
        return (
            "\n"
            "Usage: {0} reboot <device>\n"
            "\n"
            "Description:\n"
            "    This command will reboot the device using software.\n"
            "\n"
            "Options:\n"
            "    -p,--proto      Specify the connection method (console|telnet|ssh)\n"
            "    -f,--force      Suppress all prompting (say yes to all)\n"
            "\n"
            "Supported Types:\n"
            "    CiscoRouter, CiscoSwitch, CiscoTermserver, CiscoASA\n"
            .format(cfg.tool_name))
    elif command in services:
        return (
            "\n"
            "Usage: {0} {1} <action>\n"
            "\n"
            "Actions:\n"
            "    start           Start the daemon\n"
            "    stop            Stop the daemon\n"
            "    restart         Restart the daemon\n"
            "    log             Show the daemon logs\n"
            "\n"
            "Log Options:\n"
            "    -t,--tail       Watch the tail of the file.\n"
            "\n"
            .format(cfg.tool_name, command))
    elif command == "install":
        return (
            "\n"
            "Usage: {0} {1} [opt]\n"
            "\n"
            "Description:\n"
            "    This will install {0} components/dependencies. If [opt]\n"
            "    isn't specified, the standard install will run, otherwise the\n"
            "    specific componant will be installed.\n"
            "\n"
            "Options:\n"
            "    [opt]       Currently only 'pmacct'\n"
            .format(cfg.tool_name, command))
    elif command == "edit":
        return (
            "\n"
            "Usage: {0} edit [<device>]\n"
            "\n"
            "Description:\n"
            "    This command allows you to edit the {0} configuration.\n"
            "\n"
            "Options:\n"
            "    -e,--editor      Specify a text editor to use\n"
            .format(cfg.tool_name))
    elif command == "update":
        return (
            "\n"
            "Usage: {0} {1}\n"
            "\n"
            "Description:\n"
            "    Update the {0} tool to the latest version.\n"
            "\n"
            "Options:\n"
            "    -l,--local      If updating from a local repo, give the path (otherwise origin is used)\n"
            "    -i,--install    Install the tool after updating\n"
            "    -r,--restart    Restart the tool after updating\n"
            "\n"
            "Examples:\n"
            "    {0} {1} -ir\n"
            .format(cfg.tool_name, command))
    elif command == "backup":
        DB.init()
        storage_dir = DB.db.dir.rsplit('/', 1)[0]
        filepath = '%s/%s.dump' % (storage_dir, cfg.tool_name)
        return (
            "\n"
            "Usage: {0} {1}\n"
            "\n"
            "Description:\n"
            "    Create a backup of {0} data (stored here: {2}).\n"
            "\n"
            "Options:\n"
            "    -d,--dates x     A comma-sperated list of dates and date ranges to dump\n"
            "                     (date syntax is YYYY/MM/DD)\n"
            "    -e,--events x    A comma-sperated list of event IDs and ID ranges to dump\n"
            "                     (find event IDs using the 'show_events' command)\n"
            "\n"
            "Examples:\n"
            "    {0} {1} -e 12,13,18-20\n"
            "    {0} {1} -d 2015/12/01,2015/12/05-2015/12/10\n"
            .format(cfg.tool_name, command, filepath))
    elif command == "restore":
        return (
            "\n"
            "Usage: {0} {1} <filepath>\n"
            "\n"
            "Description:\n"
            "    Restore {0} data from a dump.\n"
            "\n"
            "Options:\n"
            "    -j, --jobs x     Specify how many threads to use while restoring. The default\n"
            "                     is cpu_count/2, but if this causes problems, you might want to\n"
            "                     try using -j 1.\n"
            "\n"
            "Examples:\n"
            "    {0} {1} /path/to/{0}.dump\n"
            .format(cfg.tool_name, command))
    else:
        return (
            "usage: {0} <command> [options]\n"
            "For detailed help about commands, try '{0} <command> --help'\n"
            "\n"
            "Daemon                            Options = start | stop | restart | kill | log\n"
            "    <opt>                         Manage all {0} daemons\n"
            "    poller <opt>                  Manage the {0} polling engine\n"
            "    monitor <opt>                 Manage the {0} monitor service\n"
            "    db <opt>                      Manage the {0} db service\n"
            "    server <opt>                  Manage the {0} web server\n"
            "    netflow <opt>                 Manage the {0} netflow collector service\n"
            "Display\n"
            "    show                          Display a list of configured devices\n"
            "    show <device>                 Display detailed information about a specific device\n"
            "    show_events                   Display a list of events\n"
            "    show_log <daemon>             Display the latest daemon logs\n"
            "Connectivity\n"
            "    connect <device>              Connect to a device via the default method (usually ssh)\n"
            "    console <device>              Connect to a device via the console\n"
            "    telnet <device>               Connect to a device via telnet\n"
            "    ssh <device>                  Connect to a device via ssh\n"
            "Test\n"
            "    test_snmp <device>            Test the SNMP connectivity to a device\n"
            "Other\n"
            "    menu                          Run the {0} interactive menu\n"
            "    status                        Show up/down status of {0} services\n"
            "    update                        Download the latest code\n"
            "    install [opt]                 Install {0} components\n"
            "    edit                          Edit the {0} site configuration\n"
            "    clear_config                  Clear all {0} configurations\n"
            "    clear_logs                    Clear all {0} logs\n"
            "    clear_data                    Clear all {0} data\n"
            "    clear_db                      Clear all {0} data/configs/passwords (everything)\n"
            "    backup                        Backup the database to a dump file\n"
            "    restore <filepath>            Restore the database from a dump file\n"
            "    run_script <name>             Run a special install script\n"
            "\n"
            "Universal Options:\n"
            "    --help                        Show help information\n"
            "    --version                     Show version information\n"
            .format(cfg.tool_name))

def usage_exit (string="", err_code=0):
    """
    Print usage information, then exit.

    Args:
        string -- the error string (reason for exiting)
    """

    if string:
        sys.stderr.write("\n%s\n\n" % string)
        err_code = 1

    print(usage())
    sys.exit(err_code)

def check_action_support(device, action):
    """
    Determine whether a device supports a specified action.

    Each device has a 'supported_actions' list variable that contains the
    supported actions. If the action in question is not supported, then we
    exit.

    Args:
      device -- the device to check
      action -- the action in question
    """

    if not action in device.supported_actions:
        type = device.get("type")
        utility.error("This action is not supported for the %s device type." % type)

def check_is_locked (device):
    """Exit if the device has the 'locked' option configured to True"""

    if device.is_locked():
        utility.error("The action was not completed because this device is locked")

def check_ownership (device):
    """
    Print a warning message if the device is owned by another user.

    Args:
      device -- a device object
    """

    # if the force flag is set, bail
    if hasattr(args, "force") and args.force:
        return

    (owner,
     reserved_until,
     ownership_origin,
     partially_owned) = device.get_ownership()

    if owner and os.getlogin() != owner:
        print("\n")
        print("***********************************************************")
        print("***********************************************************")
        print("WARNING: This Device is owned by %s" % owner)
        print("***********************************************************")
        print("***********************************************************")
        print("\n")

        if not textIO.prompt("This device is not yours! Continue?"):
            sys.exit()

def clear_config ():
    if textIO.prompt("This will delete all current configs! Continue?"):
        cfg.clear_config()

def clear_logs ():
    DB.init()
    if textIO.prompt("This will delete all {0} logs! Continue?" % cfg.tool_name):
        DB.db.clear_logs()

def clear_data ():
    DB.init()
    if textIO.prompt("This will delete all {0} data! Continue?" % cfg.tool_name):
        DB.db.clear_data()

def clear_db ():
    DB.init()
    if textIO.prompt("This will delete all {0} configs/data! Continue?" % cfg.tool_name):
        DB.db.clear_db()

def edit_config ():
    """
    Edit the config file.

    This function will open up the config file in an editor
    and allow the user to edit it. A patch of the changes will then
    be created and applied to the config file.
    """
    config_name = args.device_name or "site"

    # read in the current state of the config file
    cfg_now = cfg.get_config_text(config_name)

    # create a temporary file
    tmp_f = NamedTemporaryFile()
    # write the config to the tmp file
    tmp_f.write(cfg_now)
    # update the fd
    tmp_f.read()
    # save the state of the config file
    cfg_before = cfg_now

    # open the tmp file with an editor
    editor = args.editor
    if not editor:
        editor = os.getenv('EDITOR', 'vi')
    ret = os.spawnlp(os.P_WAIT, editor, editor, tmp_f.name)
    if ret != 0:
        sys.exit("Error: could not open a text editor")

    # move to the start of the temp file
    tmp_f.seek(0)
    cfg_after = tmp_f.read()

    # get the current state of the cfg file (it could have changed since we
    # opened it)
    cfg_now = cfg.get_config_text(config_name)

    # patch the current config
    patched_string = utility.three_way_merge(cfg_before, cfg_after, cfg_now)

    # write patched config file
    cfg.save_config_text(config_name, patched_string)

def setup_pxgrid ():
    command = args.command
    device_name = args.device_name
    device = cfg.device_d[device_name]
    if device.type == "CiscoISE":
        if device.rest.account_create():
            device.rest.account_activate()
    else:
        print("Error: This isn't an ISE device!")

def connect ():
    """Handle the 'connect' cli option."""
    command = args.command
    device_name = args.device_name
    device = cfg.device_d[device_name]


    if command == "connect":
        command = device.get("connect_method",
                                     default=cfg.connect_method)
    if command == "console" and args.force:
        device.cli.clear_my_line()
    session = device.cli.connect(access_method=command, interact=True)

    if not session:
        print("Connection Failed!")
        if command == "console":
            if textIO.prompt("Would you like to clear the line and try again?"):
                device.cli.clear_my_line()
                session = device.cli.connect(access_method=command, interact=True)
    else:
        session.close()


def power_ctrl ():
    """Handle the 'power*' cli options."""
    command = args.command
    device_name = args.device_name
    device = cfg.device_d[device_name]

    check_action_support(device, "power")
    check_is_locked(device)
    check_ownership(device)

    # strip off the 'power' from the command (eg. 'poweron'-->'on')
    action = command.replace("power", "")

    if textIO.prompt("Are you sure you want to power %s '%s'?" % (action, device_name)):
        device.power_ctrl(action)

def show_list (root_name, filters):
    """
    Show the condensed device list.

    Args:
        root_name -- devices are organized as a tree. Only children of
                     'root_name' will be printed.
        filters -- a list object containing strings for
                   filtering the device list.
    """

    if filters: # if there's a filter, we want to expand children
        args.expand = -1

    columns = [
        ('Name', "name"), # there is no "name" attribute
        ('Type', "type"),
        ('Model', "model"),
        ('IP Address', "ip_address"),
        ]

    # if the verbose flag is set, we use a simpler (but more verbose)
    # method of printing the list
    if args.verbose:
        for device in cfg.device_d.values():
            show_device(device)
        return
    ##
    # Build the output table
    ##
    lines = []

    # add the header line
    line = []
    for column in columns:
        line.append(column[0])
    lines.append(line)

    # add the underline for the header line
    line = []
    for column in columns:
        underline = "=" * len(column[0])
        line.append(underline)
    lines.append(line)

    # add the device lines
    for device in cfg.device_d.values():
        line = []
        for column in columns:
            header = column[0]
            attribute = column[1]
            line.append(str(device.get(attribute)))
        lines.append(line)

    # finally, print the table
    print(textIO.print_table(lines))
    return

def device_sort (root):
    """
    show_list (-verbose) helper for parsing the device tree.

    This is a recursive function that returns devices sorted in a list
    that is ordered according to the tree structure.
    """

    device_list = []
    for device in root.children:
        if not device.filtered:
            device_list.append(device)
        if device.children:
            device_list += device_sort(device)

    return device_list

def show_device (device, verbose=True):
    """Show device attributes"""
    rjust_val = 20
    output = ""
    output += "[%s]\n" % device.name

    # description
    val = device.get("description")
    if (val):
        header = "Description"
        output += "%s: %s\n" % (header.rjust(rjust_val), val)

    # IP address
    val = device.get("ip_address")
    if (val):
        header = "IP Address"
        output += "%s: %s\n" % (header.rjust(rjust_val), val)

    # debug IP address
    val = device.get("debug_ip_address")
    if (val):
        header = "Debug IP Address"
        output += "%s: %s\n" % (header.rjust(rjust_val), val)

    # console access
    [val, val2] = device.get("console", size=2)

    if (val and val2):
        val2 = str(int(val2))
        header = "Console"
        output += "%s: %s:%s\n" % (header.rjust(rjust_val), val, val2)

    # aux access
    [val, val2] = device.get("aux", size=2)
    if (val and val2):
        val2 = str(int(val2))
        header = "Aux"
        output += "%s: %s:%s\n" % (header.rjust(rjust_val), val, val2)

    # power
    i = 0
    first_pass = True
    header = "Power"
    while (True):
        [hostname,  outlet] = device.get("rpc%s" % i, size=2)

        if hostname and outlet:
            if first_pass:
                output += "%s: " % header.rjust(rjust_val)
            else:
                output += "%s  " % "".rjust(rjust_val)

            output += "%s:%s\n" % (hostname, outlet)
            first_pass = False
            i += 1
        else:
            break

    # username/password
    val = device.get("username")
    val2 = device.get("password")
    if (val or val2):
        header = "Username/Password"
        output += "%s: %s/%s\n" % (header.rjust(rjust_val), val, val2)

    (owner,
     reserved_until,
     ownership_origin,
     partially_owned) = device.get_ownership()

    # ownership
    val = owner
    if (val):
        header = "Owner"
        output += "%s: %s\n" % (header.rjust(rjust_val), val)

    # reserved till
    val = reserved_until
    if val:
        time_left = utility.time_remaining_string(val)
        val = utility.convert_time_str_to_tz(val)
        val += " (%s)" % time_left
        header = "Reserved Until"
        output += "%s: %s\n" % (header.rjust(rjust_val), val)

    # location
    val = device.get("lab")
    val2 = device.get("rack")
    if (val): #LEVY: think about this
        header = "Location"
        output += "%s: %s" % (header.rjust(rjust_val), val)
        if (val2):
            output += " %s" % (val2)
        output += "\n"

    # model_number
    val = device.get("model_number")
    if (val):
        header = "Model Number"
        output += "%s: %s\n" % (header.rjust(rjust_val), val)

    # asset_tag_number
    if verbose:
        val = device.get("asset_tag_number")
        if (val):
            header = "Asset Tag Number"
            output += "%s: %s\n" % (header.rjust(rjust_val), val)

    # serial_number
    if verbose:
        val = device.get("serial_number")
        if (val):
            header = "Serial Number"
            output += "%s: %s\n" % (header.rjust(rjust_val), val)

    # other
    val = device.get("other")
    if (val):
        header = "Other"
        lines = val.split('\n')
        i = 0
        for line in lines:
            if not i:
                output += "%s: %s\n" % (header.rjust(rjust_val), line)
            else:
                output += "%s  %s\n" % ("".rjust(rjust_val), line)
            i += 1


    print(output)
    return

def show_ifs ():
    device_name = args.device_name
    device = cfg.device_d[device_name]
    device.scan_ifindex_map()
    print(json.dumps(sorted(list(device.ifindex_map.keys())), indent=4))

def show_interfaces (device):
    """Show the list of configured connections relating to this device"""

    print(device.show_interfaces())

def show_ports(device):
    """Show a list of configured line connections relating to this Termserver"""

    print(device.show_ports())

def show ():
    """Handle the 'show' cli command."""

    device_name = args.device_name
    verbose = args.verbose
    modifier = args.modifier
    device = None
    root_name = ""

    # if the device_name corresponds to a standard device,
    # then we want to show the device details
    if (device_name != None
        and device_name != "all"
        and device_name != "mine"
        and device_name != "free"):

        root_name = device_name
        device = cfg.device_d[device_name]


        if modifier.startswith("p"):
            show_ports(device)
        elif modifier.startswith("i"):
            show_interfaces(device)
        else:
            # show full device info
            show_device(device, verbose=True)

    ##
    # compile the list of filters
    ##
    filters = []
    if device_name == "mine":
        filters += ["owner=%s" % os.getlogin()]
    elif device_name == "free":
        filters += ["owner="]

    if args.filter_string:
        filters += args.filter_string.split(',')

    show_list(root_name, filters)

def tftp_copy ():
    """
    Handle the 'tftpcopy' cli command.

    Note: currently, this action assumes a common tftp directory
    for everybody that uses this testbed (with username subdirectories).
    Example: /tftpboot/levmason
    """

    device_name = args.device_name
    filepath = args.filepath
    device = cfg.device_d[device_name]
    tftpserver_dir = cfg.get("tftpserver_dir") # root dir of the tftp server
    filename = os.path.basename(filepath)

    check_ownership(device)

    # generate a random extention (for a temp file)
    random_ext = utility.random_string(6)
    tmp_filename = "%s.%s" % (filename, random_ext)
    tmp_filepath = "%s/%s/%s" % (tftpserver_dir, os.getlogin(), tmp_filename)
    tftp_relative_tmp_filepath = "%s/%s" % (os.getlogin(), tmp_filename)

    # copy the file to a temp file in the tftpboot directory
    shutil.copyfile(filepath, tmp_filepath)

    # wrap this part in a try-block so we can use the 'finally'
    # statement to clean up the temp file
    try:
        # start the session
        session = device.connect(access_method=args.proto)
        # session.logfile = sys.stdout
        print("downloading...")

        # execute the copy
        device.tftp_copy(session, tftp_relative_tmp_filepath, filename)

    finally:
        os.remove(tmp_filepath) # clean up

def load_config ():
    """Handle the 'loadconfig' cli command."""

    device_name = args.device_name
    filepath = args.filepath
    device = cfg.device_d[device_name]

    check_action_support(device, "loadconfig")
    # make sure the device isn't locked
    check_is_locked(device)

    # verify the filepath
    utility.verify_file(filepath)

    check_ownership(device)
    if not textIO.prompt("Are you sure you want to load '%s' onto '%s'?"
                          % (filepath, device_name)):
        sys.exit()

    print("loading config...")
    session = device.connect("console")
    device.load_config(session, filepath)
    device.write_mem(session)

def copy ():
    """Handle the 'copy' cli command"""

    src_filepath = args.src_filepath
    dst_filepath = args.dst_filepath
    # Verify the input
    #
    if not (src_filepath and dst_filepath):
        usage_exit("Error: You must give source and destination!")

    if (not utility.is_remote_path(src_filepath) and
        utility.is_remote_path(dst_filepath)):
        copy_direction = "todevice"
    elif (utility.is_remote_path(src_filepath) and
          not utility.is_remote_path(dst_filepath)):
        copy_direction = "fromdevice"
    elif (utility.is_remote_path(src_filepath) and
          utility.is_remote_path(dst_filepath)):
        usage_exit("Error: You can't specify two remote paths!")
    else:
        usage_exit("Error: You can't specify two local paths!")


    if copy_direction == "todevice":
        dst_filepath_split = dst_filepath.split(':', 1)
        device_name = dst_filepath_split[0]
        dst_filepath = dst_filepath_split[1]
        src_filepath = os.path.abspath(src_filepath)
        if os.path.isdir(src_filepath):
            src_filepath += '/'

        device = cfg.device_d[device_name]
        check_action_support(device, "copyto")
        # verfiy the owner
        check_ownership(device)

        dst_filename = os.path.basename(dst_filepath)
        if not dst_filename:
            dst_filepath = dst_filepath+os.path.basename(src_filepath)
            dst_filename = os.path.basename(dst_filepath)

        # verify the filepath
        utility.verify_file(src_filepath)

        # start the session
        session = device.cli.connect(access_method=args.proto)
        #session.logfile = sys.stdout

        # execute the copy
        device.force = args.force
        device.copy_to(session, src_filepath, dst_filepath)

    elif copy_direction == "fromdevice":
        src_filepath_split = src_filepath.split(':', 1)
        device_name = src_filepath_split[0]
        src_filepath = src_filepath_split[1]
        src_filename = os.path.basename(src_filepath)
        dst_filepath = os.path.abspath(dst_filepath)
        if os.path.isdir(dst_filepath):
            dst_filepath += '/' + src_filename

        device = cfg.device_d[device_name]
        check_action_support(device, "copyfrom")



        # check to see if the file exists on the local server
        if not args.force:
            if os.path.isfile(dst_filepath):
                if not textIO.prompt("File '%s' exists. Overwrite?"
                                       % dst_filepath):
                    return
            elif os.path.isdir(dst_filepath):
                print("'%s' is a directory" % dst_filepath)
                utility.error("You can't overwrite a directory!")
                return

        # start the session
        session = device.connect(access_method=args.proto)
        #session.logfile = sys.stdout

        # execute the copy
        device.force = args.force
        device.copy_from(session, src_filepath, dst_filepath)

def reboot ():
    """handle the 'reboot' cli command"""

    device_name = args.device_name
    device = cfg.device_d[device_name]

    check_action_support(device, "reboot")
    check_is_locked(device)
    check_ownership(device)

    if (not args.force
        and not textIO.prompt("Are you sure you want to reboot '%s'?"
                               % device_name)):
        return

    session = device.connect(access_method=args.proto)
    #session.logfile = sys.stdout
    device.force = args.force
    device.reboot(session)

def backup ():
    DB.init()
    span_l = []
    event_l = []

    # parse the arguments
    if args.dates:
        span_l = utility.parse_date_list(args.dates)
    if args.events:
        event_l = utility.parse_number_list(args.events)

    DB.db.backup(span_l, event_l)

def restore ():
    DB.init()

    # hardcoded options
    if not args.filepath:
        print("Error: must specify a dump file!")
        sys.exit(-1)
    if not args.jobs:
        args.jobs = multiprocessing.cpu_count() // 2

    if not textIO.prompt("This will delete the current database! Continue?"):
        sys.exit()

    # check if services are running
    for d in services:
        if daemon_is_running(d):
            print("Error: '%s' is running!\n" % d+
                  "Error: All %s services must be stopped before restoring (e.g. '%s stop')"
                  % (cfg.tool_name, cfg.tool_name))
            sys.exit(-1)

    if DB.db.restore(args.filepath, args.jobs):
        print("Database restoration successful!")
    else:
        print("Error: restore failed :-(")

def sys_uuid():
    print(utility.get_system_uuid())

def update ():
    git_args = "--git-dir=%s/.git --work-tree=%s/" % (cfg.proj_dir, cfg.proj_dir)

    # get the build_date
    build_date_A = utility.get_build_date()

    # see if we're updating from a local repo
    if args.repo:
        # see if it's a tar file
        if '.tar' not in args.repo.lower():
            repo = args.repo
        else:
            repo_tmp_dir = '/tmp/.syfter.repo/'

            # we'll need to extract the tar file
            if args.repo.lower().endswith(".tar.gz"):
                tar_args = '-xzf'
            elif args.repo.lower().endswith(".tar"):
                tar_args = '-xf'
            else:
                print("File type not supported (must be .tar or .tar.gz)")
                return

            # clean the directory
            shutil.rmtree(repo_tmp_dir, ignore_errors=True)
            os.makedirs(repo_tmp_dir)

            # extract the tar file
            command = 'tar %s %s -C %s' % (tar_args, args.repo, repo_tmp_dir)
            (code, result) = getstatusoutput(command)
            if code:
                print(result)
                return

            # find the repo directory
            command = "dirname `find %s -name .git | head -n 1`" % repo_tmp_dir
            (code, result) = getstatusoutput(command)
            if code:
                print(result)
                return

            repo = result

        fetch_command = 'git %s fetch %s' % (git_args, repo)
        reset_command = 'git %s reset --hard FETCH_HEAD' % git_args
    else:
        fetch_command = 'git %s fetch origin' % git_args
        reset_command = 'git %s reset --hard origin/master' % git_args

    # fetch
    (code, result) = getstatusoutput(fetch_command)
    if code:
        print(result)
        return

    # reset head
    (code, result) = getstatusoutput(reset_command)
    if code:
        print(result)
        return

    # get the build date
    build_date_B = utility.get_build_date()

    # did we update?
    if build_date_A != build_date_B:
        print("Update Successful :)")
    else:
        print("No Updates Found :(")
        return

    # set the permissions
    command = '%s/install/misc_install.sh' % cfg.proj_dir
    subprocess.call(command.split())

    # install
    if args.install:
        command = '%s/install/install.py' % cfg.proj_dir
        subprocess.call(command.split())

    # restart
    if args.restart:
        print('')
        service_handler(action = "stop")

        print("\nRestarting postgresql...")
        postgresql_handler("restart")

        print("\nRestarting nginx...")
        command = 'service nginx restart'
        subprocess.call(command.split())

        print('')
        command = '%s start' % cfg.tool_name
        subprocess.call(command.split())

install_d = {}

def install ():
    name = args.device_name
    if name:
        try:
            script_name = install_d[name]
        except KeyError:
            script_name = name + '.sh'

        command = "%s/install/%s" % (cfg.proj_dir, script_name)
    elif args.full:
        command = '%s/install/install.py -f' % cfg.proj_dir
    else:
        command = '%s/install/install.py' % cfg.proj_dir

    subprocess.call(command.split())

services = [
    'daphne',
    'db',
    'gunicorn',
    'monitor',
    'netflow',
    'poller',
    'snmptrap',
    ]

def status ():
    # check if services are running
    l = sorted(services + ['nfacctd'])
    for d in l:
        if getattr(cfg, "%s_enabled" % d, True):
            sys.stdout.write("%s: " % d)
            if daemon_is_running(d):
                print(OK("UP"))
            else:
                print(Fail("DOWN"))

def service_handler (action = None, services = services):
    if not action:
        action = args.command

    # informative output
    output_str = "%sing services..." % action.capitalize()
    output_str = output_str.replace("toping", "topping")
    print(output_str)

    # for each service
    for service in services:
        is_running = daemon_is_running(service)
        if (getattr(cfg, "%s_enabled" % service, True) and
            ((action == "stop" and is_running) or
             (action == "start" and not is_running) or
             (action == "restart"))):

            print("    %s" % (service))
            command = '%s %s %s' % (cfg.tool_name, service, action)
            getstatusoutput(command)

    # keep alive until the docker container is stopped
    if action != "stop" and args.block:
        try:
            command = 'tail -f /dev/null'
            subprocess.run(command, shell=True)
        except KeyboardInterrupt:
            service_handler("stop", services)

def postgresql_handler (action = None):
    if not action:
        action = args.action

    # informative output
    output_str = "%sing postgresql..." % action.capitalize()
    output_str = output_str.replace("toping", "topping")
    print(output_str)

    if cfg.distro in ['ubuntu', 'debian']:
        svc_name = "postgresql"
    else:
        # fancy command to extract the postgres version number
        (code, result) = getstatusoutput("psql -V | egrep -o '[0-9]{1,}\.[0-9]{1,}'")
        svc_name = "postgresql-%s" % result

    command = 'service %s %s' % (svc_name, action)
    subprocess.call(command.split())

def server ():
    service_handler(action=args.action, services=['gunicorn', 'daphne'])

def gunicorn ():
    app_name = "%s.wsgi" % cfg.tool_name
    sockfile = cfg.get_sockfile('gunicorn')
    pidfile = cfg.get_pidfile('gunicorn')
    logfile = cfg.get_logfile('gunicorn')

    gunicorn_args = (
        "--chdir %s" % cfg.proj_dir
        + " --bind unix:%s" % sockfile
        + " --workers %s" % args.workers
        + " --user root"
        + " --group root"
        + " --timeout 300"
        + " --daemon"
        + " --pid %s" % pidfile
        + " --error-logfile %s" % logfile
        + " %s" % app_name
        )

    if args.action == "start":
        (code, result) = getstatusoutput("gunicorn %s" % gunicorn_args)
    elif args.action == "stop":
        (code, result) = getstatusoutput("kill `cat %s`" % pidfile)
        while (os.path.isfile(pidfile)):
            time.sleep(1)
    elif args.action == "restart":
        (code, result) = getstatusoutput("kill `cat %s`" % pidfile)
        while (os.path.isfile(pidfile)):
            time.sleep(1)
        (code, result) = getstatusoutput("gunicorn %s" % gunicorn_args)
    elif args.action == "kill":
        (code, result) = getstatusoutput("kill `cat %s`" % pidfile)

def daemon_is_running (daemon_name):
    if daemon_name == "nfacctd":
        (code, result) = getstatusoutput('pgrep nfacctd')
    else:
        (code, result) = getstatusoutput('ps -p `cat %s`' % cfg.get_pidfile(daemon_name))
    return code == 0

def daemon_handler ():
    command = args.command
    action = args.action

    if action == "log":
        show_log(command)
    elif action == "restart":
        (code, result) = getstatusoutput("%s %s stop" %
                                             (cfg.tool_name, command))
        (code, result) = getstatusoutput("%s %s start" %
                                             (cfg.tool_name, command))
    elif action == "kill":
        (code, result) = getstatusoutput("pkill -9 -f '%s %s (start|stop|restart)'" %
                                             (cfg.tool_name, command))
    else:
        log.debug("%s %s" % (command, action))

        # Some daemons require others to be running
        if action == "start" and command in ['poller']:
            if not daemon_is_running("db"):
                (code, result) = getstatusoutput("%s db start" % cfg.tool_name)
            if not daemon_is_running("monitor"):
                (code, result) = getstatusoutput("%s monitor start" % cfg.tool_name)

        start_daemon(command)

def start_daemon (command):
    from poller.Poller import PollerDaemon
    from monitor.Monitor import MonitorDaemon
    from netflow.Netflow import NetflowDaemon
    from termserver.Termserver import TermserverDaemon
    from server.daphne.DaphneDaemon import DaphneDaemon
    from snmptrapd.SNMPTrap import SNMPTrapDaemon as SnmptrapDaemon
    from common.DB import DbDaemon

    # find FDs to preserve into the daemon
    files_preserve = []
    # the logging file
    files_preserve.append(log.fh.stream)

    # Twisted FDs (this was hard; don't delete!)
    for x, y in reactor._selectables.items():
        files_preserve += [y.i, y.o]
    files_preserve.append(reactor._poller.fileno())

    # need to treat the subcommand as the first argument
    if len(sys.argv) > 2:
        sys.argv = sys.argv[1:]

    # can't carry the connection into daemon mode
    connection.close()

    app = locals()['%sDaemon' % command.capitalize()]()
    daemon_runner = runner.DaemonRunner(app)
    daemon_runner.daemon_context.files_preserve=files_preserve
    daemon_runner.daemon_context.signal_map = {
        signal.SIGTTIN: None,
        signal.SIGTTOU: None,
        signal.SIGTSTP: None,
        signal.SIGTERM: app.terminate,
        }
    try:
        daemon_runner.do_action()
    except runner.DaemonRunnerStopFailureError as e:
        if "PID" not in e.message:
            print(e)
        sys.exit (-1)
    except lockfile.LockTimeout as e:
        print("%s already running" % command)
        sys.exit (-1)

def run_script ():
    script_name = args.device_name
    filepath = "%s/install/%s" % (cfg.proj_dir, script_name)

    command = [filepath] + sys.argv[1:]
    subprocess.call(command)

def show_log (daemon_name = None):
    if not daemon_name:
        daemon_name = args.device_name or "poller"

    filepath = "%s/%s.log" % (cfg.log_dir, daemon_name)

    if args.tail:
        command = 'stty size'
        (code, result) = getstatusoutput(command)
        rows, cols = result.split()
        command = 'tail -f -n%s %s' % (int(rows) - 4, filepath)
        subprocess.call(command, shell=True)
    else:
        with open (filepath, "r") as f:
            print(f.read())

def show_events ():
    event_l = Event_db.objects.all().values()
    rows = []

    rows.append(['id', 'start', 'end'])
    for x in event_l:
        start = datetime.fromtimestamp(x['start_timestamp'])
        start_str = start.strftime("%Y/%m/%d %H:%M %p")
        end = datetime.fromtimestamp(x['end_timestamp'])
        end_str = end.strftime("%Y/%m/%d %H:%M %p")

        row = [str(x['id']), start_str, end_str]
        rows.append(row)
    print(utility.print_table(rows))

def test_snmp ():
    try:
        device = cfg.device_d[args.device_name]
    except KeyError:
        print("Invalid device name!")
        return

    if device.snmp and device.snmp.is_up(check=True, quiet=True):
        print("PASS")
    else:
        print("FAIL")

def test_email ():
    utility.send_email("test email", "test message")

def set_networking ():
    os.system('clear')
    print("====================\n"
          "Configure Networking\n"
          "====================")

    #
    # interface config
    filepath = '/etc/network/interfaces'

    # read current values
    ip_address = None
    netmask = None
    gateway = None
    with open (filepath, "r") as f:
        cfg_str = f.read()
        # find ip address
        match = re.search(r'address\s+([0-9\.]+)', cfg_str)
        if match:
            ip_address = match.group(1)
        # find netmask
        match = re.search(r'netmask\s+([0-9\.]+)', cfg_str)
        if match:
            netmask = match.group(1)
        # find gateway
        match = re.search(r'gateway\s+([0-9\.]+)', cfg_str)
        if match:
            gateway = match.group(1)

    # Input IP Address
    while True:
        response = menu_input("IP address [%s]: " % ip_address) or ip_address
        if utility.is_valid_ip_address(response):
            ip_address = response
            break
        else:
            print("Invalid!")

    # Input Netmask
    while True:
        response = menu_input("Netmask [%s]: " % netmask) or netmask
        if utility.is_valid_netmask(response):
            netmask = response
            break
        else:
            print("Invalid!")

    # Input Gateway
    while True:
        response = menu_input("Gateway [%s]: " % gateway) or gateway
        if utility.is_valid_ip_address(response):
            gateway = response
            break
        else:
            print("Invalid!")

    #
    # edit the file
    with open (filepath, "r") as f:
        cfg_str = f.read()
        cfg_str = re.sub(r'(address\s+)(?:[0-9\.]+)?\n', '\g<1>%s\n' % ip_address, cfg_str)
        cfg_str = re.sub(r'(netmask\s+)(?:[0-9\.]+)?\n', '\g<1>%s\n' % netmask, cfg_str)
        cfg_str = re.sub(r'(gateway\s+)(?:[0-9\.]+)?\n', '\g<1>%s\n' % gateway, cfg_str)
    with open (filepath, "w") as f:
        f.write(cfg_str)

    #
    # edit the hosts file
    filepath = "/etc/hosts"
    with open (filepath, "r") as f:
        cfg_str = f.read()
        cfg_str = re.sub(r'[\.\d]+(\s+%s)\n', '%s\g<1>\n' % (cfg.tool_name, ip_address), cfg_str)
    with open (filepath, "w") as f:
        f.write(cfg_str)

    #
    # DNS
    filepath = '/etc/resolv.conf'

    # find the current dns entry
    dns = None
    with open (filepath, "r") as f:
        for line in f:
            match = re.search(r'nameserver\s+([\w\.\d]+)', line)
            if match:
                dns = match.group(1)
                break

    while True:
        dns_tmp = menu_input("DNS server [%s]: " % dns).lower() or dns
        if utility.is_valid_ip_address(dns_tmp):
            dns = dns_tmp
            break
        else:
            print("Invalid!")

    # write the file
    with open (filepath, "w") as f:
        f.write("nameserver %s\n" % dns)

    #
    # proxy

    # read current config values
    proxy_server = cfg.proxy_server
    use_proxy_authentication = 'n'
    proxy_username = cfg.proxy_username
    proxy_password = cfg.proxy_password

    if proxy_server:
        use_proxy = "y"
    else:
        use_proxy = "n"

    if proxy_username:
        use_proxy_authentication = "y"
    else:
        use_proxy_authentication = "n"

    # use a proxy?
    while True:
        response = menu_input("Use a proxy server? [%s]: " % use_proxy).lower() or use_proxy
        if response == 'y':
            use_proxy = True
            break
        elif response == 'n':
            proxy_server = None
            use_proxy = False
            break

    if use_proxy:
        # Authenticate proxy?
        while True:
            response = menu_input("Use a proxy authentication? [%s]: " % use_proxy_authentication).lower() or use_proxy_authentication
            if response == 'y':
                use_proxy_authentication = True
                break
            elif response == 'n':
                use_proxy_authentication = False
                proxy_username = None
                proxy_password = None
                break

        # set username and password
        if use_proxy_authentication:
            while True:
                proxy_username = menu_input("Proxy Username [%s]: " % proxy_username) or proxy_username
                if proxy_username:
                    break

            while True:
                proxy_password = menu_input("Proxy Password [%s]: " % proxy_password) or proxy_password
                if proxy_password:
                    break

        # set the proxy
        while True:
            response = menu_input("Proxy server [%s]: " % proxy_server) or proxy_server
            if response:
                match = re.search(r'(?:https?:\/\/)?([^:]+:\d+)', response)
                if match:
                    proxy_server = match.group(1)
                    break
                else:
                    print("Invalid! Required format: host:port")
            else: break

    set_proxy(proxy_server, proxy_username, proxy_password)

    #
    # restart networking
    print("\n"
          "==================\n"
          "Restart Networking\n"
          "==================")
    command = "service networking stop"
    subprocess.call(command.split())
    command = "service networking start"
    subprocess.call(command.split())

    #
    # ping test
    print("\n"
          "===============\n"
          "Test Networking\n"
          "===============")
    ping_d = OrderedDict([
            ('gateway', gateway),
            ('DNS server', dns),
            ('proxy server', (proxy_server or "").split(':')[0]),
            ('www.google.com', 'www.google.com')])

    with open (os.devnull, "w") as devnull:
        for name, ip in ping_d.items():
            if not ip: continue
            sys.stdout.write("Pinging %s: " % name)
            sys.stdout.flush()
            command = 'ping -c 1 -w 5 %s' % ip

            try:
                code = subprocess.check_call(command.split(),
                                             stdout=devnull,
                                             stderr=devnull,
                                             timeout=5)
                print("OK")
            except (subprocess.TimeoutExpired, subprocess.CalledProcessError):
                print("Fail")

def set_proxy (proxy_server, proxy_username, proxy_password):

    # edit the current ram value
    cfg.proxy_server = proxy_server
    cfg.proxy_username = proxy_username
    cfg.proxy_password = proxy_password

    # edit the tool root config
    with open (cfg.root_cfg_file, "r") as f:
        cfg_str = f.read()
        # remove the lines
        cfg_str = re.sub(r'\n#?\s*proxy_server[\s:]+[\w\.:]*', '', cfg_str)
        cfg_str = re.sub(r'\n#?\s*proxy_username[\s:]+.*', '', cfg_str)
        cfg_str = re.sub(r'\n#?\s*proxy_password[\s:]+.*', '', cfg_str)
        # append lines to the end
        if proxy_server:
            cfg_str += "proxy_server: %s\n" % proxy_server

            if proxy_username:
                cfg_str += "proxy_username: %s\n" % proxy_username
                cfg_str += "proxy_password: %s\n" % proxy_password

    with open (cfg.root_cfg_file, "w") as f:
        f.write(cfg_str)

    # Add username and password in proxy before updating system root config files
    if proxy_username:
        proxy_server = '%s:%s@%s' % (urllib.quote_plus(proxy_username), urllib.quote_plus(proxy_password), proxy_server) # Convert the special characters to hex if present
    cfg.full_proxy = proxy_server

    #
    # add env variables
    proxy_str = ''
    if proxy_server:
        http_proxy_str = "export http_proxy=http://%s" % proxy_server
        https_proxy_str = "export https_proxy=https://%s" % proxy_server
        proxy_str = '%s\n%s\n' % (http_proxy_str, https_proxy_str)

        # for current session
        os.environ["http_proxy"] = "http://%s" % proxy_server
        os.environ["https_proxy"] = "https://%s" % proxy_server

    else:
        (code, result) = getstatusoutput('unset http_proxy')
        (code, result) = getstatusoutput('unset https_proxy')

    with open ("/root/.bash_proxy", "w") as f:
        f.write(proxy_str)

    # set the proxy in apt.conf if proxy authentication configured
    if proxy_username:
        apt_http_proxy_str = 'Acquire::http::Proxy "%s";' % proxy_server
        apt_https_proxy_str = 'Acquire::https::Proxy "%s";' % proxy_server
        apt_proxy_str = '%s\n%s\n' % (apt_http_proxy_str, apt_https_proxy_str)
        with open ('/etc/apt/apt.conf', 'w') as f:
            f.write(apt_proxy_str)
    else:
        # unset proxy configuration if apt.conf exists
        if os.path.exists('/etc/apt/apt.conf'):
            with open ('/etc/apt/apt.conf', "r") as f:
                apt_cfg_str = f.read()
                # remove the lines
                apt_cfg_str = re.sub(r'#?\s*Acquire::http::Proxy\s+.*', '', apt_cfg_str)
                apt_cfg_str = re.sub(r'#?\s*Acquire::https::Proxy\s+.*', '', apt_cfg_str)
                # append lines to the end
                apt_http_proxy_str = 'Acquire::http::Proxy "false";'
                apt_https_proxy_str = 'Acquire::https::Proxy "false";'
                apt_cfg_str += '%s\n%s\n' % (apt_http_proxy_str, apt_https_proxy_str)
        
            with open ('/etc/apt/apt.conf', "w") as f:
                f.write(apt_cfg_str)


def get_dns ():
    dns_l = []

    with open ("/etc/resolv.conf", "r") as f:
        for line in f:
            match = re.search(r'nameserver\s+(.+)', line)
            if match:
                dns_l.append(match.group(1))

    return dns_l

def set_dns (dns_l):

    #
    # edit /etc/resolv.conf
    dns_str = ''
    for dns in dns_l:
        dns_str += 'nameserver %s\n' % dns

    with open ("/etc/resolv.conf", "w") as f:
        f.write(dns_str)

#
# Menu
def menu ():
    os.system('clear')
    print(
        "===========================================================\n"
        "================= %s Interactive Menu =================\n" % cfg.tool_name.capitalize() +
        "===========================================================\n"
        "                                          build: %s\n" % VERSION +
        "\n"
        "Select an action:\n"
        "\n"
        "          stop       stop the {0} tool\n"
        "         start       start the {0} tool\n"
        "       restart       restart the {0} tool\n"
        "        update       update the {0} tool\n"
        "\n"
        "       network       configure server networking\n"
        "          time       set the server time\n"
        "     passwords       set {0} passwords\n"
        "\n"
        "          quit       quit this menu\n"
        .format(cfg.tool_name))

    try:
        choice = menu_input("> ")
        menu_exec(choice)
    except (KeyboardInterrupt, EOFError):
        print('')
        sys.exit()

def menu_input (text=""):
    return input(text).strip()

def menu_exec (choice):
    os.system('clear')
    ch = choice.lower()

    try:
        menu_actions[ch]()
        print("\n---Press Enter To Return---")
        menu_input()
        menu()
    except (KeyError, KeyboardInterrupt, EOFError):
        menu()

#
# Menu Functions
def menu_stop ():
    service_handler("stop")

def menu_start ():
    service_handler("start")

def menu_restart ():
    service_handler("restart")

def menu_update ():
    args.install = True
    args.restart = True
    update()
    connection.close()

def menu_time ():
    #
    # set timezone
    command = 'dpkg-reconfigure tzdata'
    subprocess.call(command.split())

    #
    # NTP setup
    filepath = '/etc/ntp.conf'
    ntp_l = []
    with open (filepath, "r") as f:
        for line in f:
            match = re.search(r'^server\s+([\w\.\d]+)\s+(?:iburst)?', line)
            if match:
                ntp_l.append(match.group(1))


    with open (os.devnull, "w") as devnull:
        timeout=60
        print("\n"
              "==========\n"
              "NTP Config\n"
              "==========\n"
              "The {0} tool requires correct time in order to timestamp the\n"
              "collected data. It is good to have NTP configured so the clock\n"
              "won't drift over time. The following NTP test will timeout after\n"
              "{0} seconds. In some cases, however, NTP sync takes longer than\n"
              "that, so you might need to try the same NTP server multiple\n"
              "times. If you don't have NTP, it's a good idea to make sure the\n"
              "time is set correctly on the VMware host.".format(cfg.tool_name, timeout)
        )

        ntp_up = False
        while True:
            sys.stdout.write("\nTrying NTP sync, please wait...")
            sys.stdout.flush()

            try:
                getstatusoutput("service ntp stop")
                code = subprocess.check_call(['ntpd', '-gq'],
                                             stdout=devnull,
                                             stderr=devnull,
                                             timeout=timeout)
                print("OK")
                break
            except (subprocess.TimeoutExpired, subprocess.CalledProcessError):
                print("Fail")
                if textIO.prompt("\nDo you want to reconfigure NTP and try again?"):
                    ntp_server = menu_input("NTP Server: ")
                    # edit the config file
                    with open (filepath, "r") as f:
                        cfg_str = f.read()
                        cfg_str = re.sub(r'\nserver\s+[\w\.\d]+\s+iburst?', '', cfg_str)
                        cfg_str += "\nserver %s iburst" % ntp_server
                    with open (filepath, "w") as f:
                        f.write(cfg_str)
                    continue
                else:
                    break
            finally:
                getstatusoutput("service ntp start")

    (code, result) = getstatusoutput('date')
    print("\nLocal time is now:      %s\n" % result)

    # manually set time
    while not textIO.prompt ("Is the time correct?"):
        date_str = menu_input("\nInput the date/time string in the format shown above: ")
        date_str = date_str.strip('.')
        (code, result) = getstatusoutput('date --set "%s"' % date_str)
        if code:
            print(result + '\n')
        else:
            print("\nLocal time is now:      %s\n" % result)

def menu_passwd ():

    # server pwd
    username = os.listdir('/home')[0] # there should be only one user
    print('The "UNIX Password" is used to log into this linux interface')
    if textIO.prompt("Change the UNIX Password?"):
        command = "passwd %s" % username
        subprocess.call(command.split())

    # admin pwd
    print('\nThe "ADMIN Password" is used to log into the Web Interface as \'admin\'')
    if textIO.prompt("Change the ADMIN Password?"):
        while True:
            pwd = getpass('Enter new ADMIN Password: ')
            pwd2 = getpass('Retype new ADMIN Password: ')
            if pwd and pwd == pwd2:
                u,c = User.objects.get_or_create(username='admin')
                u.set_password(pwd)
                u.save()
                print("password updated successfully")
                break
            elif pwd != pwd2:
                print("Password Mismatch!")
            else:
                print("Password Empty!")

    # user pwd
    print('\nThe "User Password" is used to log into the Web Interface as \'user\'')
    if textIO.prompt("Change the USER Password?"):
        while True:
            pwd = getpass('Enter new USER Password: ')
            pwd2 = getpass('Retype new USER Password: ')
            if pwd and pwd == pwd2:
                u,c = User.objects.get_or_create(username='user')
                u.set_password(pwd)
                u.save()
                print("password updated successfully")
                break
            elif pwd != pwd2:
                print("Password Mismatch!")
            else:
                print("Password Empty!")


# def menu_test_snmp ():
#     args.device_name = menu_input("Enter Device Name:  ")
#     test_snmp()

menu_actions = {
    'stop' : menu_stop,
    'start' : menu_start,
    'restart' : menu_restart,
    'update' : menu_update,
    'network' : set_networking,
    'time' : menu_time,
    'passwords' : menu_passwd,
    'quit' : exit,
    'q': exit
}

def build_parser ():
    """
    Build the ArgumentParser tree.

    The parser will change depending on the command.
    """

    parser = argparse.ArgumentParser(usage=usage(), conflict_handler='resolve', add_help=False)
    parser.add_argument('-h', '--help', action='store_true', dest='help')
    parser.add_argument('-v', '--version', action='version', version=VERSION)
    parser.add_argument('-d', '--debug', action='store', dest="debug_lvl", default="critical")
    #parser.add_argument('--config-file', action='store', dest='config_file')
    parser.add_argument('command', nargs='?', default=None)

    # stop here and figure out the subcommand
    (args, leftover) = parser.parse_known_args()

    # check for invalid command
    if args.command and args.command not in commands.keys():
        usage_exit("Invalid Command: %s" % args.command)

    # check for help flag
    if args.help or not args.command:
        print(usage(args.command))
        sys.exit()

    command = args.command
    parser.usage = usage(command)

    if command not in ["copy", "restore", "backup"]:
        parser.add_argument('device_name', nargs='?', default=None)

    if command in ["update"]:
        parser.add_argument("-i", "--install",
                            action="store_true", dest="install")
        parser.add_argument("-r", "--restart",
                            action="store_true", dest="restart")

    if command in ["update"]:
        parser.add_argument("-l", "--local",
                            action="store", dest="repo")

    if command in ["install"]:
        parser.add_argument("-f", "--full",
                            action="store_true", dest="full")

    if command in ['backup']:
        parser.add_argument("-e", "--events",
                            action="store", dest="events")
        parser.add_argument("-d", "--dates",
                            action="store", dest="dates")

    if (command == "console"
        or command =="connect"
        or command =="reboot"
        or command =="copy"):
        parser.add_argument("-f", "--force",
                            action="store_true", dest="force")

    if command == "show":
        parser.add_argument('modifier', nargs='?', default="")
        parser.add_argument("-f", "--filter",
                             action="store", dest="filter_string")
        parser.add_argument('-v', '--verbose',
                            action='store_true', dest='verbose')
        parser.add_argument('-e', '--expand',
                            type=int, nargs='?', default=0, const=-1,
                            action='store', dest='expand')

    if command in ["loadconfig", "restore"]:
        parser.add_argument('filepath', nargs='?', action="store")

    if command in ["restore"]:
        parser.add_argument('-j', '--jobs',
                            type=int, default=0,
                            action="store", dest="jobs")

    if (command == "copy"):
        parser.add_argument('src_filepath', nargs='?', action="store")
        parser.add_argument('dst_filepath', nargs='?', action="store")

    if (command =="copy"
        or command == "reboot"
        or command == "confintdesc"
        or command == "confbanner"):
        parser.add_argument('-p', '--proto', default=None,
                            choices=["console", "telnet", "ssh"],
                            action="store", dest="proto")

    if command == "confintdesc":
        parser.add_argument("-o", "--overwrite",
                            action="store_true", dest="overwrite")

    if command in (['start', 'restart']):
        parser.add_argument('-b', '--block',
                            action="store_true", dest="block")

    if command in (services + ['postgresql', 'server']):
        parser.add_argument('action', default=None,
                            choices=['start', 'stop', 'restart', 'kill', 'log'])
        parser.add_argument('-b', '--block',
                            action="store_true", dest="block")

    if command == "gunicorn":
        parser.add_argument('-w', '--workers',
                            type=int, default=4,
                            action="store", dest="workers")

    if command == "poller":
        parser.add_argument('-p', '--port',
                            type=int, default=8000,
                            action="store", dest="port")

    if command == "edit":
        parser.add_argument('-e', '--editor',
                            nargs='?', action="store", dest="editor")

    if command in (services + ["show_log"]):
        parser.add_argument("-t", "--tail",
                            action="store_true", dest="tail")

    args = parser.parse_args()
    return args

from pkg.snmp.snmp import Session
def test ():
    """ function for testing random functionality  """

    print(len(cfg.device_type_l))
    print(cfg.device_type_d)
    return
    print(cfg.devices(dtype="Linux", include_children=True))
    return
    with open ("/root/sandbox/10", "r") as f:
        table = f.read()
        key = None
        if len(sys.argv) > 2:
            key = sys.argv[2]
        #js = textIO.parse_table(table, headers=["unit", "load", "active", "sub", "description"])
        #js = textIO.parse_keyval(table, primary_key="Product Name", key_filter=['Version','Status'])
        js = parse.parse_keyval(table)
        print(json.dumps(js, indent=4))
    return
    mse = cfg.device_d['CMX_Presence']
    #print(mse.get_clientPresenceDetails())
    from common.Client import ClientManager
    client_mgr = ClientManager(None)
    client_mgr.monitor()
    for client in client_mgr.client_d.values():
        try:
            print(client.group.name, client.db_index, client.location)
            print(json.dumps(client.presence_data, indent=4))
            break
        except: pass
    return
    #mse.get_clientDetails(int(time.time() - 6000), int(time.time()))
    #mse.get_clientProbingDetails(1)
    wlc = cfg.device_d['WLC']
    wlc.track_cfg()
    #track_config()

def test_help():
    proxy = Session(ip = "10.162.255.11",
                    community = 'matrix',
                    version = 2)

    # proxy = Session(ip = "10.162.255.11",
    #                 version = 3,
    #                 retries = 1,
    #                 timeout = 5000000,
    #                 sec_name = "matrix-v3",
    #                 sec_level = 3,
    #                 auth_proto = "MD5",
    #                 auth_pass = "Kcr_3_2q9213",
    #                 priv_proto = "AES",
    #                 priv_pass = "Kcr_3_2q9213")

    #community = "matrix",
    #version = 2)
    oid_l = ['.1.3.6.1.2.1.1.1.0',
             '.1.3.6.1.2.1.1.55.0']
    d = proxy.get(oid_l)
    d.addCallback(lambda x: saveProxy(proxy, x))
    d.addErrback(lambda x: aww_man(x, oid_l))
    d.addBoth(stop)
    return d

def aww_man(err, oid_l):
    err.trap(Exception)

def saveProxy(proxy, results):
    """
    Save proxy into the current object.
    @return: the proxy
    """
    for oid, val in results.items():
        print(oid, val, type(val))

def stop(results):
    reactor.stop()
##
# GLOBALS
##
VERSION = str(utility.epoch_to_datetime(utility.get_build_date()).date())

commands = {
    'show' :show,
    'poweron' : power_ctrl,
    'poweroff' : power_ctrl,
    'powercycle' : power_ctrl,
    'clear_config' : clear_config,
    'clear_data' : clear_data,
    'clear_logs' : clear_logs,
    'clear_db' : clear_db,
    'connect' : connect,
    'console' : connect,
    'ssh' : connect,
    'telnet' : connect,
    'edit' : edit_config,
    'loadconfig' : load_config,
    'reboot' : reboot,
    'copy' : copy,
    'show_events' : show_events,
    'show_log' : show_log,
    'show_interfaces': show_ifs,
    'test_snmp' : test_snmp,
    'set_networking' : set_networking,
    'test_email' : test_email,
    'update' : update,
    'install' : install,
    'kill' : service_handler,
    'stop' : service_handler,
    'start' : service_handler,
    'restart' : service_handler,
    'backup' : backup,
    'restore' : restore,
    'menu' : menu,
    'monitor' : daemon_handler,
    'netflow' : daemon_handler,
    'db' : daemon_handler,
    'poller': daemon_handler,
    'postgresql' : postgresql_handler,
    'server' : server,
    'gunicorn': gunicorn,
    'daphne' : daemon_handler,
    'snmptrap' : daemon_handler,
    'status': status,
    'sys_uuid': sys_uuid,
    'run_script': run_script,
    'setup_pxgrid': setup_pxgrid,
    'test': test
    }

# initialize the configuration module
try:
    cfg.init_config()
except Exception as e:
    print("\nError: Problem initializing config!")
    print(traceback.format_exc())

# build the parser
args = build_parser()

# initialize the logger
if args.command in services:
    log_name = "%s.log" % args.command
else:
    log_name = "syfter.log"

log.init(log_name, args.debug_lvl)

# find the command function
command_fn = commands[args.command]

try:
    # run the command!
    command_fn()
except KeyboardInterrupt:
    print('')
    sys.exit()
except pexpect.EOF as e:
    print("\nError: Connection terminated unexpectedly!")
    sub = "before (last 100 chars): "
    start = str(e).rfind(sub)
    start += len (sub)
    end = str(e).find ("after:")
    print(str(e)[start:end])
except Exception as e:
#    print(sys.exc_info()[0]
    print(traceback.format_exc())
#    print(e)
    sys.exit()
