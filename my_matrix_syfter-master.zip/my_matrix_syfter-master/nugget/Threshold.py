import re, time

from .RingBuffer import NumpyRingBuffer
from common import utility
from common import logger as log

class Threshold(object):
    #thresh_conf_re = re.compile(r'(\w+)\s+if\s+(?:\w+\s+)?(\w+)\s*([>|<|=])'+
    #                            '\s*(-?[\d\.]+)(?:\s+for\s*(\w*))?')
    thresh_conf_re = re.compile(r'(\w+)\s+if\s+(?:\w+\s+)?(\w+)\s*(>|<|=|is|!=)\s*(-?[\d\.]+|static|previous)(?:\s+for\s*(\w*))?',
               re.IGNORECASE)

    def __init__ (self, nugget_entry):
        self.nugget_entry = nugget_entry
        self.severity = None
        self.value = None
        self.value_type = None
        self.text = None
        self.msg = None
        self.state = "off"
        self.timestamp = 0
        self.buffer = None
        self.duration = None
        self.compare = None
        self.use_prev = False

    def set_msg (self, value):
        if isinstance(value, float):
            value = round(value, 2)

        if re.sub(r'\s', '', self.text) == "value!=previous":
            self.msg = "value changed from %s to %s" % (self.value, value)
        else:
            self.msg = self.text.replace(self.value_type, "%s (%s)" % (self.value_type, value))
            if self.use_prev and "previous" in self.text:
                self.msg = self.msg.replace("previous", "previous (%s)" % self.value)

    def configure (self, config_str):
        config_str = config_str.lower()
        config_str = re.sub(r'avg([^\w])', r'average\1', config_str)
        config_str = re.sub(r'val([^\w])', r'value\1', config_str)
        config_str = re.sub(r' changes', r' != previous', config_str)

        #
        # parse the config string
        try:
            # run the regex
            match = re.search(Threshold.thresh_conf_re, config_str)

            # extract parameters
            severity = log.sev_id[match.group(1).lower()]
            value_type = match.group(2).lower()
            comparator = match.group(3)
            value_str = match.group(4)
            duration_str = match.group(5)
            text = config_str.split(' if ')[1]

            # set the comparator value
            try:
                value = float(value_str)
            except ValueError:
                if value_str in ["static", "previous"]:
                    self.use_prev = True
                    value = None
                else:
                    raise

        except Exception as e:
            log.error("Invalid Nugget threshold configuration: %s" % e, "config")
            return False

        # set params
        self.severity = severity
        self.value = value
        self.value_type = value_type
        self.text = text

        # set the compare function
        if comparator == "<":
            self.compare = self.lt
        elif comparator == ">":
            self.compare = self.gt
        elif comparator in ["=", "is"]:
            self.compare = self.eq
        elif comparator in ["!="]:
            self.compare = self.ne
        else:
            log.error("Invalid Nugget threshold comparator: %s" % e, "config")
            return False

        # add an look-back buffer if needed
        if self.value_type == "average":
            avg_duration = 0
            avg_duration_re = r'(\w+)\s+%s' % value_type
            match = re.search(avg_duration_re, config_str)
            if match:
                avg_duration_str = match.group(1).lower()
                avg_duration = utility.get_time_seconds(avg_duration_str)

            if avg_duration:
                if 'min' in self.nugget_entry.cfg:
                    fill = self.nugget_entry.cfg['min']
                else:
                    fill = 0

            size = avg_duration // self.nugget_entry.interval or 1
            self.buffer = NumpyRingBuffer(size, fill=fill)

        # add a duration if needed
        if duration_str:
            self.duration = utility.get_time_seconds(duration_str)

        return True

    def gt (self, value):
        return value > self.value

    def lt (self, value):
        return value < self.value

    def eq (self, value):
        return value == self.value

    def ne (self, value):
        return self.value is not None and value != self.value

    def update (self, timestamp, value):
        # find the value to compare with

        if self.value_type == 'value':
            compare_val = value
        elif self.value_type == 'average':
            # add the value to our ring buffer
            self.buffer.add(value)
            compare_val = self.buffer.mean()

        # get the comparison result
        compare_result = self.compare(compare_val)

        #
        # the state machine
        if self.state == "off":
            if compare_result:
                if self.duration:
                    self.start_time = timestamp
                    self.state = "starting"
                else:
                    self.state = "on"
                    self.timestamp = int(time.time())
                    self.set_msg(compare_val)
        elif self.state == "starting":
            if not compare_result:
                self.state = "off"
            elif (timestamp - self.start_time) >= self.duration:
                self.state = "on"
                self.timestamp = int(time.time())
                self.set_msg(compare_val)
        elif self.state == "on":
            if not compare_result:
                self.state = "off"

        # remember for next update
        if self.use_prev:
            self.value = value
