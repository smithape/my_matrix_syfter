import re
import io
from .Nugget import Nugget
try:
    from textfsm import TextFSM
except: pass
from common import parse
from common import logger as log
import traceback

class NuggetCli (Nugget):
    formula_key = 'command'
    required_opts = ['command']

    def filter_by_line (self, text):
        lines = self.cfg.get("lines", "auto")
        if lines == "all":
            return text
        elif lines == "auto":
            command_l = self.cfg.get('command_built').split('\n')
            start_ptr = len([x for x in command_l if x not in ['exit', 'end']]) - 1
            end_ptr = len([x for x in command_l if x in ['exit', 'end']]) * -1 or ""
            if start_ptr or end_ptr:
                # convert to list of lines
                line_l = text.split('\n')
                # filter the lines
                if start_ptr and end_ptr:
                    line_l = line_l[start_ptr:end_ptr]
                elif start_ptr:
                    line_l = line_l[start_ptr:]
                elif end_ptr:
                    line_l = line_l[:end_ptr]
                # convert back to string
                return '\n'.join(line_l)
            else:
                return text
        else:
            filter_l = self.cfg.get("lines_built")
            ret = []
            line_l = text.splitlines()
            for f in filter_l:
                ret += f(line_l)

            return '\n'.join(ret)

    def compile_expr (self):
        # parser
        parser = self.cfg.get('parser')
        if parser:
            # get the parser options
            opt = self.cfg.get(parser)
            if opt:
                if parser == "textfsm":
                    # remove extra whitespace from the template
                    template = opt.get("template").strip()

                    # read the textfsm template (as a file)
                    opt['fsm'] = TextFSM(io.StringIO(template))
                elif parser == "regex":
                    opt['expression'] = re.compile(opt.get('expression'))
                expression = 'parse.%s(_x_, **nugget_cfg["%s"])' % (parser, parser)
            else:
                expression = 'parse.%s(_x_)' % parser

            self.cfg['parse_built'] = eval('lambda _x_, nugget_cfg: ' + expression)

        # filter
        if 'filter' in self.cfg:
            self.cfg['filter'] = self.cfg['filter'].split('|')

        # line filter
        lines = str(self.cfg.get("lines", "auto"))
        if lines not in ["all", "auto"]:
            filter_l = []
            for f in lines.split(','):
                try:
                    val = int(f)
                    if val > 0:
                        val -= 1
                    fn = eval('lambda _x_: [_x_[%d]]' % val)
                except ValueError:
                    start, end = f.split('-', 1)
                    start = int(start) - 1
                    fn = eval('lambda _x_: _x_[%s:%s]' % (start, end))
                    
                filter_l.append(fn)
                    
            self.cfg['lines_built'] = filter_l

        super().compile_expr()

class NuggetFile (NuggetCli):
    formula_key = 'path'
    required_opts = ['path']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.collect_type = "cli"

    def compile_expr (self):
        command = 'sed '
        if self.cfg.get('comment_style'):
            command += "-e'/^\s*%s/d' " % self.cfg['comment_style']
        command += "-e'/^$/d' " + self.cfg['path_built']
        self.cfg['command_built'] = command

        super().compile_expr()
