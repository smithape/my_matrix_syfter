from .Nugget import Nugget

class NuggetRest (Nugget):
    formula_key = 'url'
    required_opts = ['url']
