import os, sys
import re
import math
import json
import time
from types import FunctionType
from datetime import datetime

import yaml

from common import utility
from common import config as cfg
from common import logger as log
from common import DB
from common import parse

from .Threshold import Threshold
from .RingBuffer import RingBuffer

oid_map = {
    'Device' : {
        'sysDescr' : '.1.3.6.1.2.1.1.1.0',
        'sysName'  : '.1.3.6.1.2.1.1.5.0',
        },
    'CiscoDevice' : {
        'ifName' : '.1.3.6.1.2.1.31.1.1.1.1',
        'hostName' : '.1.3.6.1.4.1.9.2.1.3.0',
        'cpmCPUTotal1minRev' : '.1.3.6.1.4.1.9.9.109.1.1.1.1.7',
        },
    'CiscoWLC': {
        'bsnDot11EssSsid' : '.1.3.6.1.4.1.14179.2.1.1.1.2',
        'bsnAPStatsTimer' : '.1.3.6.1.4.1.14179.2.2.1.1.12',
        'bsnAPName' : '.1.3.6.1.4.1.14179.2.2.1.1.3',
        'bsnAPModel' : '.1.3.6.1.4.1.14179.2.2.1.1.16',
        'bsnApIpAddress' : '.1.3.6.1.4.1.14179.2.2.1.1.19',
        'bsnAPEthernetMacAddress' : '.1.3.6.1.4.1.14179.2.2.1.1.33',
        'bsnAPLocation' : '.1.3.6.1.4.1.14179.2.2.1.1.4',
        'bsnAPGroupVlanName': '.1.3.6.1.4.1.14179.2.2.1.1.30',
        'bsnAPIfType' : '.1.3.6.1.4.1.14179.2.2.2.1.2',
        'bsnAPIfDBNoisePower' : '.1.3.6.1.4.1.14179.2.2.15.1.21',
        'cLLwappUpTime': '.1.3.6.1.4.1.9.9.513.1.1.1.1.7',
        'clcCdpApCacheNeighName' : '.1.3.6.1.4.1.9.9.623.1.3.1.1.6',
        'clcCdpApCacheNeighAddress' : '.1.3.6.1.4.1.9.9.623.1.3.1.1.8',
        'clcCdpApCacheNeighInterface' : '.1.3.6.1.4.1.9.9.623.1.3.1.1.9',
        'bsnAPIfPhyChannelNumber' : '.1.3.6.1.4.1.14179.2.2.2.1.4',
        },
    'CiscoASR': {
        'cpuUsageUser' : '.1.3.6.1.4.1.8164.1.10.1.1.3',
        'cpuUsageSystem' : '.1.3.6.1.4.1.8164.1.10.1.1.4',
        'cpuUsageIO' : '.1.3.6.1.4.1.8164.1.10.1.1.7',
        'cpuUsageRQ' : '.1.3.6.1.4.1.8164.1.10.1.1.8',
        },
    'Linux': {
        'hrProcessorLoad': '.1.3.6.1.2.1.25.3.3.1.2',
        },
    'CiscoUCS': {
        'numOfCPUs': '.1.3.6.1.4.1.9.9.719.1.41.9.1.2',
        }
    }

nugget_config = {}

unit_cfg = {
    'Miscellaneous': {
        'number': {
            'axis_label': 'Number',
            'min': 0,
        },
        'percentage': {
            'unit': '%',
            'axis_label': 'Percentage',
            'min': 0,
            'max': 100,
            'ceiling': 100,
            'label_suffix': '%'
        },
        'boolean': {
            'axis_label': 'True/False',
            'min': 0,
            'max': 1
        },
    },
    'Throughput': {
        'kbps': {
            'unit': ' Kbps',
            'axis_label': 'Kbps',
            'min': 0,
        },
        'mbps': {
            'unit': ' Mbps',
            'axis_label': 'Mbps',
            'min': 0,
        },
        'gbps': {
            'unit': ' Gbps',
            'axis_label': 'Gbps',
            'min': 0,
        },
    },
    'Data Size': {
        'bytes': {
            'unit': 'B',
            'axis_label': 'Bytes',
            'min': 0,
        },
        'kilobytes': {
            'unit': 'KB',
            'axis_label': 'Kilobytes',
            'min': 0,
        },
        'megabytes': {
            'unit': 'MB',
            'axis_label': 'Megabytes',
            'min': 0,
        },
        'gigabytes': {
            'unit': 'GB',
            'axis_label': 'Gigabytes',
            'min': 0,
        },
    },
    'RF': {
        'snr': {
            'label': 'SNR',
            'axis_label': 'SNR',
            'min': 0,
            'max': 45
        },
        'noise': {
            'label': 'Noise (dBm)',
            'unit': ' dBm',
            'axis_label': 'dBm',
            'min': -100,
            'max': 0
        },
    },
    'Time': {
        'milliseconds': {
            'unit': 'ms',
            'axis_label': 'Milliseconds',
            'min': 0,
        },
        'seconds': {
            'unit': 's',
            'axis_label': 'Seconds',
            'min': 0,
        },
        'minutes': {
            'unit': 'm',
            'axis_label': 'Minutes',
            'min': 0,
        },
        'hours': {
            'unit': 'hr',
            'axis_label': 'Hours',
            'min': 0,
        },
    },
    'Rate': {
        'per_second': {
            'label': 'x/sec',
            'unit': 'x/sec',
            'axis_label': 'Rate',
            'min': 0,
            'label_suffix': '/sec',
        },
        'per_minute': {
            'label': 'x/min',
            'unit': 'x/min',
            'axis_label': 'Rate',
            'min': 0,
            'label_suffix': '/min',
        },
        'per_hour': {
            'label': 'x/hour',
            'unit': 'x/hour',
            'axis_label': 'Rate',
            'min': 0,
            'label_suffix': '/hour',
        },
        'per_day': {
            'label': 'x/day',
            'unit': 'x/day',
            'axis_label': 'Rate',
            'min': 0,
            'label_suffix': '/day',
        },
    }
}

def init_config ():
    load_nugget_config()

def load_nugget_config ():
    # then load from user-defined
    user_d = {}
    for dtype in cfg.device_type_l:
        dtype = dtype.strip()
        cfg_name = "nugget/%s" % dtype
        dtype_cfg = yaml.full_load(cfg.get_config_text(cfg_name))
        if dtype_cfg:
            user_d[dtype] = dtype_cfg

    for dtype, dtype_cfg in user_d.items():
        if dtype in nugget_config:
            nugget_config[dtype].update(dtype_cfg)
        else:
            nugget_config[dtype] = dtype_cfg

def getNuggetConfig(type_str):
    try:
        return nugget_config[type_str]
    except KeyError:
        return {}

def getOIDMap(type_str):
    try:
        return oid_map[type_str]
    except KeyError:
        return {}

def getNuggetByFlag (flag, dtype=None):
    nugget_d = {}

    if dtype:
        dtypes = [dtype]
    else:
        dtypes = list(nugget_config.keys())

    for dtype in dtypes:
        for nugget_name in nugget_config[dtype]:
            nugget_cfg = nugget_config[dtype][nugget_name]
            if flag in nugget_cfg.get('flags', []):
                nugget_d[nugget_name] = nugget_cfg
    return nugget_d

def getNuggetByDataType (datatype, dtype=None, exclude=False):
    if isinstance(datatype, str):
        datatype = [datatype]

    nugget_d = {}

    if dtype:
        dtypes = [dtype]
    else:
        dtypes = list(nugget_config.keys())

    for dtype in dtypes:
        for nugget_name in nugget_config[dtype]:
            nugget_cfg = nugget_config[dtype][nugget_name]
            if ((not exclude and nugget_cfg.get("datatype") in datatype) or
                (exclude and nugget_cfg.get("datatype") not in datatype)):
                    nugget_d[nugget_name] = nugget_cfg
    return nugget_d

def parseSNMP(nugget_name, record_l):
    if not record_l:
        print("snmp returned null for Nugget: %s" % nugget_name)
        return None

    if nugget_name.startswith("rf_clientSNR"):
        has_data = [int(v) != 0 for v in record_l]
        if True in has_data:
            #return ",".join(record_l)
            return ",".join(str(x) for x in record_l)
        else:
            return None
    else:
        return ",".join(record_l)

def parseDataSample(nugget_name, record):
    if nugget_name.startswith("rf_clientSNR"):
        vals = [int (n) for n in record.split(',')]
        if nugget_config[nugget_name]['plot_type'] == 'line':
            # configure for average and line-plot
            count = 0
            total_sum = 0
            for i, val in enumerate(vals):
                count += val
                total_sum += val * i * 5

            average = total_sum / count
            return [average]
        else:
            # configure for box-plot

            count = 0
            for i, val in enumerate(vals):
                count += val

            if count:
                low = -1
                low_quartile = -1
                median = -1
                high_quartile = -1
                high = -1

                low_quartile_i = count * 0.25
                median_i = count * 0.5
                high_quartile_i = count * 0.75

                tally = 0
                for i, val in enumerate(vals):
                    tally += val
                    snr = i*5
                    if low < 0 and tally > 0:
                        low = snr
                    if low_quartile < 0 and tally > low_quartile_i:
                        low_quartile = snr
                    if median < 0 and tally > median_i:
                        median = snr
                    if high_quartile < 0 and tally > high_quartile_i:
                        high_quartile = snr
                    if high < 0 and tally == count:
                        high = snr

                return [low, low_quartile, median, high_quartile, high]
            else:
                return None
    else:
        return None

class Nugget (object):
    # config option used for dynamic Nuggets
    formula_key = None
    # list of required options
    required_opts = []
    # list of variable options
    variable_opts = []

    def __init__(self, device, nugget_name, schedule, counter=0,
                 nugget_cfg=None, store=True, poll=True, split=None):
        self.device = device
        self.name = nugget_name
        self.name_root = nugget_name.split(":")[0]
        self.indexes = []
        self.index = ""
        try:
            self.index = nugget_name.split(":", 1)[1]
        except: pass
        self.enabled = True
        self.parent_l = []
        self.child_l = []
        self.split_l = []

        # get the nugget config
        self.cfg = nugget_cfg

        # validate the config
        self.validate_cfg()

        #
        # configured parameters
        self.type = self.collect_type = self.cfg['type']
        self.datatype = self.cfg.get("datatype")
        self.flags = self.cfg.get('flags', [])
        self.event_detect = 'ED' in self.flags
        self.poll_always = self.cfg.get('poll_always', False)
        self.aggregate = self.cfg.get('aggregate', False)

        # should we split into multiple Nuggets?
        if split is not None:
            self.split = split
        else:
            self.split = self.cfg.get("split")
        # how to split
        if self.split:
            self.split_method = self.cfg.get('split_method', "hierarchy")

        # do we store samples in the DB?
        self.store_setting = store
        self.store = store and not self.split

        # do we poll this Nugget?
        self.poll = poll

        self.counter = counter
        self.schedule = schedule
        self.periodic = schedule and isinstance(schedule, int)
        if not self.periodic:
            self.last_scheduled = 0

        # set the storage precision
        self.precision = cfg.data_precision

        # for log list tracking
        if self.cfg.get("incremental_process") == "timestamped_entries":
            try:
                self.latest_log_timestamp = json.loads(
                    DB.redis.get("%s/%s" %
                                 (self.device.name, self.name)
                    ).decode())
            except AttributeError:
                self.latest_log_timestamp = 0

        # sample storage
        self.prev_timestamp = None
        self.prev_value = None
        self.sample_timestamp = None
        self.sample = None
        self.trace_record = None
        if self.store and self.periodic:
            self.init_buffer()

        # thresholds
        self.threshold_cfg = None
        self.thresholds = []
        self.active_threshold = None

    def validate_cfg (self):
        for x in self.required_opts:
            if not self.cfg.get(x):
                raise Exception("Missing required parameter: %s" % x)

    def init_buffer (self):
        # how many entries in the buffer?
        # how many samples to meet the minimum duration?
        by_time = cfg.data_buffer_duration // self.schedule
        # factor in the minimum buffer size
        entry_count = max(by_time, cfg.data_buffer_min_size)

        self.buffer = RingBuffer(entry_count, fill=None)

    def get_status (self):
        sev = 0
        val = None

        val = self.prev_value
        try:
            val = round(val, 2)
        except TypeError: pass

        if self.active_threshold:
            sev = self.active_threshold.severity

        return {
            'val' : val,
            'sev' : sev,
            }

    def replace_vars (self, formula):
        for var in re.findall(cfg.nugget_var_re, formula):
            value = self.device.get_nugget_var(var)
            if value is None or isinstance(value, (list, dict)):
                continue

            formula = re.sub(r'{%s}' % var, str(value), formula)

        # un-escape any escaped brackets
        formula = formula.replace("\{", "{").replace("\}", "}")

        return formula

    def get_nugget_variables (self):
        variable_s = set()

        # add formula variables
        for x in [self.formula_key, "process", "post_process"]:
            if self.cfg.get(x):
                for var in re.findall(cfg.nugget_var_re, self.cfg[x]):
                    variable_s.add(var)

        # add variable options
        for x in self.variable_opts:
            if self.cfg.get(x):
                variable_s.add(self.cfg.get(x).strip("{}"))

        return variable_s

    def compile_function (self, fn_str, kwvals = ()):
        # compile into a code object
        fn_obj = compile(fn_str, "<string>", "exec")
        # find the code object
        fn_code = [x for x in fn_obj.co_consts if type(x).__name__ == "code"][0]
        # cast into a function
        fn = FunctionType(fn_code, globals(), "fn", kwvals)
        return fn

    def compile_expr (self):
        # generic options
        for key in ['pre_process_built', 'process_built', 'post_process_built']:
            if key in self.cfg:
                expression = self.cfg[key]
                expression = re.sub(r'{x}', '_x_', expression)
                expression = re.sub(r'{[\'|"](\w+)[\'|"]}', '_x_["\g<1>"]', expression)
                expression = re.sub(r'{(\d+)}', '_x_[\g<1>]', expression)
                try:
                    self.cfg[key] = eval('lambda self, _x_: ' + expression)
                except:
                    expression_lines = expression.split("\n")
                    # build the function
                    fn_str = "def function(self, _x_):\n"
                    for line in expression_lines:
                        fn_str += "    %s\n" % line
                    self.cfg[key] = self.compile_function(fn_str)

    def build (self):
        """ replace any nugget variables with their values """
        fields = [self.formula_key, "process", "post_process"]

        # first replace variables
        for x in fields:
            if x in self.cfg:
                formula = self.cfg[x]
                formula = self.replace_vars(formula)
                self.cfg[x + "_built"] = formula

        self.compile_expr()

        # check for unresolved variables
        missing_vars = set()
        for formula in [self.cfg[x + "_built"] for x in fields if x in self.cfg]:
            try:
                missing_vars.update(re.findall(cfg.nugget_var_re, formula))
            except TypeError: continue

        return missing_vars

    def get_update_period (self):
        update_period = None

        if 'update_period' in self.cfg:
            update_period = self.cfg['update_period']
            try:
                update_period = int(update_period)
            except ValueError:
                update_period = getattr(self.device, update_period, None)

        return update_period

    def check_schedule (self, increment=0):
        scheduled = False
        if self.poll:
            if self.periodic:
                if self.counter <= 0:
                    # mark it to run
                    scheduled = True

                    # reset the counter
                    self.counter = self.schedule

                # decrement the counter
                self.counter -= increment
            else:
                # scheduled polls
                next_scheduled = self.get_next_scheduled()
                if next_scheduled != self.last_scheduled:
                    # use timezone naive (ie. match local timezone)
                    now = datetime.now().replace(second=0, microsecond=0)
                    if now == next_scheduled:
                        self.last_scheduled = next_scheduled
                        scheduled = True

        # Include Nugget with poll_always to nugget_d even when the device is down.
        return (scheduled and self.enabled and (self.poll_always or self.device.is_up()))

    def get_next_scheduled (self):
        schedule_l = [utility.parse_time(x) for x in self.schedule]
        schedule_l.sort()
        return schedule_l[0]

    def schedule_adjust (self):
        period_l = []

        p = self.get_update_period()
        if p: period_l.append(p)

        if self.aggregate or self.type == "formula":
            for c in self.child_l:
                p = c.get_update_period()
                if p: period_l.append(p)

        if period_l:
            update_period = utility.lcm(period_l)
            self.schedule = update_period * int(math.ceil(self.schedule / update_period))
            # new_schedule = update_period * int(math.ceil(self.schedule / update_period))
            # if new_schedule != self.schedule:
            #     print(self.name, "%s -> %s" % (self.schedule, new_schedule))
            #     self.schedule = new_schedule

    def init_thresholds (self, config=None):
        if config:
            self.threshold_cfg = config
        else:
            if self.threshold_cfg:
                config = self.threshold_cfg
            else:
                return

        for config_str in config:
            t = Threshold(self)
            if t.configure(config_str):
                self.thresholds.append(t)

        # need to sort by severity low-->high
        self.thresholds = sorted(self.thresholds, key=lambda x: x.severity)

    # def values_equal (self, v1, v2):

    #     # round for floats
    #     if isinstance(v1, float):
    #         try:
    #             return (round(v1, 2) == round(v2, 2))
    #         except TypeError: pass

    #     # default
    #     return v1 == v2

    def process (self, value):
        process_fn = self.cfg.get('process_built')
        if process_fn:
            try:
                value = process_fn(self.device, value)
            except Exception as e:
                log.exception("Nugget Error in processing phase: %s" % e,
                              "device", device=self.device, nugget_name=self.name)
                return None

        return value

    def post_process (self, sample_timestamp, sample):

        timestamp = sample_timestamp
        value = sample

        try:
            # check incremental processing method
            incremental_process = self.cfg.get("incremental_process")
            if incremental_process in ['counter', 'counter32', 'counter64']:
                # calculate the rate
                value = (sample - self.sample) / (sample_timestamp - self.sample_timestamp)

                # Check for overflow
                if value < 0:
                    if incremental_process == "counter":
                        # we can't handle rollover if we don't know the size
                        value = None
                    else:
                        # handle rollover
                        if incremental_process == 'counter32':
                            # 4294967295 is the maximum value for a 32-bit counter
                            max_val = 4294967295
                        else:
                            # 18446744073709551615 is the maximum value for a 64-bit counter
                            max_val = 18446744073709551615

                        value = (sample - (self.sample - max_val)) / (sample_timestamp - self.sample_timestamp)

                # shift the timestamp back
                timestamp = self.sample_timestamp

            elif incremental_process in ['delta', 'counter_delta', 'counter32_delta', 'counter64_delta']:
                # calculate the rate
                value = (sample - self.sample)

                # Check for overflow
                if value < 0 and incremental_process in ['counter_delta', 'counter32_delta', 'counter64_delta']:
                    if incremental_process == "counter_delta":
                        # we can't handle rollover if we don't know the size
                        value = None
                    else:
                        # handle rollover
                        if incremental_process == 'counter32_delta':
                            # 4294967295 is the maximum value for a 32-bit counter
                            max_val = 4294967295
                        else:
                            # 18446744073709551615 is the maximum value for a 64-bit counter
                            max_val = 18446744073709551615

                        value = (sample - (self.sample - max_val))

            elif incremental_process == "timestamped_entries":
                # filter out old logs
                value = [x for x in value if x["timestamp"] > self.latest_log_timestamp]
                # remember the latest timestamp
                timestamp_list = [x['timestamp'] for x in value] + [self.latest_log_timestamp]
                self.latest_log_timestamp = max(timestamp_list)

        except (ZeroDivisionError, TypeError):
            value = None
            timestamp = None

        if value:
            process = self.cfg.get('post_process_built')
            if process:
                value = process(value)

        # remember these for next iteration
        self.sample_timestamp = sample_timestamp
        self.sample = sample

        return timestamp, value

    def store_sample (self, timestamp, value):
        #
        # round off the value
        if isinstance(value, float):
            value = round(value, self.precision)

        #
        # how do we store the value?
        if self.store and timestamp and timestamp != self.prev_timestamp:
            if self.cfg.get('compress'):
                #
                # Hourly record
                if utility.epoch_same_hour(timestamp, self.prev_timestamp) is False:
                    # new hour
                    hourstamp = utility.epoch_to_hour(timestamp)
                    # make sure we're not duping the standard record
                    if hourstamp != timestamp or value == self.prev_value:
                        # create a new record at the hour mark
                        r = (hourstamp, self.device.name, self.name, self.prev_value)
                        cfg.poller.sample_q.put(r)

                #
                # Standard update
                if value != self.prev_value:
                    # create a new record
                    r = (timestamp, self.device.name, self.name, value)
                    cfg.poller.sample_q.put(r)
                    self.trace_record = None
                else:
                    # save the trace
                    self.trace_record = [timestamp, value]
            else:
                #
                # Standard update
                r = (timestamp, self.device.name, self.name, value)
                cfg.poller.sample_q.put(r)

            if self.periodic:
                # store in the temporary buffer
                self.buffer.add([timestamp, value])

                # if we shifted the timestamp (ie for throughput), then we need to add a
                # trace record to show the value is still what it was
                if (self.sample_timestamp and self.sample_timestamp != timestamp and
                    self.schedule > cfg.series_decode_period):
                    r = [self.sample_timestamp - cfg.series_decode_period, value]
                    self.trace_record = r
                    self.buffer.add(r)

        #
        # remember values
        self.prev_timestamp = timestamp
        self.prev_value = value

        #
        # check the thresholds
        if timestamp is not None and value is not None:
            active_threshold = None
            for t in self.thresholds:

                t.update(timestamp, value)
                if t.state == "on":
                    active_threshold = t

            #
            # log the thresholds
            if active_threshold is not self.active_threshold:
                if active_threshold:
                    # active condition
                    severity = active_threshold.severity
                    message = active_threshold.msg
                    log.log(message, "nugget", severity, self.device, self.name)
                elif self.active_threshold.severity > 20:
                    # condition cleared
                    log.log("Threshold Condition Cleared", "nugget", "info",
                            self.device, self.name)

            self.active_threshold = active_threshold
