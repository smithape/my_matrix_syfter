import re
from .Nugget import Nugget

class NuggetFunction (Nugget):
    formula_key = 'code'

    def compile_expr (self):
        args = self.cfg['arguments']

        # find the keyword args and default vals
        kwargs = re.findall(r'(\w+)\s*=', args)
        kwvals = []
        for i, x in enumerate(kwargs):
            try:
                next_arg = ",\s*%s" % kwargs[i + 1]
            except IndexError:
                next_arg = "\s*$"

            regex = r"%s\s*=\s*(.*)%s" % (x, next_arg)
            kwvals.append(eval(re.search(regex, args).group(1)))

        # build the function string
        fn_str = self.cfg['code']
        fn_lines = fn_str.split('\n')

        fn_str = "def %s(%s):\n" % (self.name, args)
        # add indentation
        for line in fn_lines:
            fn_str += "    %s\n" % line

        self.cfg["function_built"] = self.compile_function(fn_str, tuple(kwvals))

        super().compile_expr()
