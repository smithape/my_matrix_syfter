import os
import time
from channels.generic.websocket import WebsocketConsumer
from threading import Thread
from collections import OrderedDict
import queue
import html
import json
import yaml
import re
import traceback

from pkg import pexpect
import requests
from common import DB
from common import config as cfg
from common import logger as log
from common import utility
from common import SNMPEngine

# initialize the logger
log.init("nugget_test.log")
log.raise_exceptions = True

# initialize the config
cfg.init_config()

# initialize the snmp engine
snmpEngine = SNMPEngine.SNMPEngine()
cfg.snmpEngine = snmpEngine

# start the snmp engine
snmpEngine.start()

def code_block (text):
    return '<div class="code">%s</div>' % text

def pretty (label, value, multiple=False):
    """
    format the value for sending to the web UI
    """
    # get the data type
    type_str = type(value).__name__

    # sort dictionaries by key
    if isinstance(value, dict):
        if multiple:
            type_str = type(value[next(iter(value))]).__name__
            # round if the values are floats
            if type_str == "float":
                try:
                    value = {x:round(y, 2) for x,y in value.items()}
                except TypeError as e: pass

        value = OrderedDict(sorted(value.items(),
                                   key=lambda x: str(x[0])))
    elif isinstance(value, float):
        value = round(value, 2)

    # pretty print if it's json
    if not isinstance(value, str):
        value_str = json.dumps(value, indent=4)
    else:
        value_str = value

    value_str = html.escape(value_str)

    return '%s: <b>&lt;%s&gt;</b>%s' % (label, type_str, code_block(value_str))

def pretty_results (label, data, nugget_name):
    if len(data) > 1 or list(data.keys())[0] != nugget_name:
        return pretty(label + " results (%d nuggets)" % len(data), data, multiple=True)
    else:
        if len(data) == 1:
            x = data[next(iter(data))]
        else:
            x = None
        return pretty(label + " result", x)

class NuggetPollConsumer(WebsocketConsumer):
    def connect (self):
        self.accept()

    def respond (self, text):
        self.send(text_data=text)

    def error (self, msg, e=None):
        if e:
            self.respond('%s: %s' % (msg, code_block(str(e))))
        else:
            self.respond(msg)

        self.respond('done')

    def receive (self, text_data):
        query = json.loads(text_data)
        device_name = query['device_name']
        nugget_name = query['nugget_name']

        try:
            device = cfg.get_device(device_name)
        except Exception as e:
            self.error('Error initializing device', e)
            return

        if nugget_name not in device.nugget_cfg:
            self.respond("Nugget not found")
            return

        # initialize polling config
        device.init_polling_config({nugget_name: 3600})

        # get the nugget entry
        nugget = device.nugget_d[nugget_name]

        # determine if the nugget was expanded
        expanded_l = [x for x in device.nugget_d.keys()
                      if x.startswith((nugget.cfg.get("alias") or nugget_name)+":")]

        # query the nugget
        response_l = device.poll(once=True)
        child_l = [x.name for x in nugget.child_l]
        split_l = [x.name for x in nugget.split_l]

        # look through for the nugget in question
        result = []
        for name, timestamp, value in response_l:
            if ((not nugget.split and name == nugget.name) or
                (nugget.split and name in split_l) or
                name in expanded_l or
                (nugget.type == "group" and
                 not nugget.aggregate and name in child_l)):
                result.append({
                    'timestamp': timestamp,
                    'nugget': name,
                    'value': value
                })

        self.respond(json.dumps(result))

class NuggetTestConsumer(WebsocketConsumer):
    def connect (self):
        self.accept()
        self.cache = {}

    def disconnect (self, close_code):
        pass

    def receive (self, text_data):
        query = json.loads(text_data)
        device_name = query['device_name']
        nugget_name = query['nugget_name']
        nugget_cfg_full = query['nugget_cfg_full']
        nugget_cfg = query['nugget_cfg']


        # initialize the device
        try:
            self.respond("Initializing device...")
            device = cfg.get_device(device_name, reset=True)
        except Exception as e:
            self.error('Error initializing the device', e)
            return

        # initialize the nugget config
        try:
            self.respond("Building nugget...")

            # insert the new nugget configs
            for x in device.ancestor_l:
                device.nugget_cfg.update(nugget_cfg_full.get(x) or {})

            # insert the test nugget config
            device.nugget_cfg[nugget_name] = nugget_cfg

            # fake adding to a polling config
            try:
                device.init_polling_config({nugget_name: 3600})
            except KeyError as e:
                self.error('Nugget %s not available for this device!' % e)
                return

            expanded_l = [x for x in device.nugget_d.keys() if x.startswith((nugget_cfg.get("alias") or nugget_name)+":")]
            if expanded_l:
                self.respond('Expanding into %d nuggets...' % len(expanded_l))

            dependency_l = [x for x in device.nugget_d.keys() if x not in expanded_l and x != nugget_name]
            if dependency_l:
                self.respond('Including %d dependencies...' % len(dependency_l))

        except Exception as e:
            self.error('Error building the nugget', e)
            return

        # get the built nugget_cfg
        nugget_entry = device.nugget_d[nugget_cfg.get("alias") or query['nugget_name']]
        nugget_type = nugget_cfg.get("type")

        # prepare the dictionaries
        nugget_d = {}
        nugget_d_by_type = {}
        for name, entry in device.nugget_d.items():
            if not entry.check_schedule():
                continue
            else:
                nugget_d[name] = entry
                try:
                    nugget_d_by_type[entry.collect_type][name] = entry
                except KeyError:
                    nugget_d_by_type[entry.collect_type] = {name: entry}


        if nugget_type in ["formula", "group"] or nugget_cfg.get("aggregate"):
            #
            # Collect
            try:
                self.respond("Collecting dependencies (%d)..." % len(dependency_l))
                response_l = device.poll_collect(nugget_d_by_type)
            except Exception as e:
                self.error('Error collecting dependencies', e)
                return


            if response_l:
                #
                # Process dependencies
                self.respond("Processing dependencies (%d)..." % len(dependency_l))
                try:
                    response_l = device.poll_process(nugget_d, response_l)
                except Exception as e:
                    self.error('Error processing dependencies', e)
                    return

                #
                # Split dependencies
                length = len(response_l)
                try:
                    response_l = device.poll_split(nugget_d, nugget_d_by_type, response_l)
                    if len(response_l) > length:
                        self.respond("Splitting dependencies into %d nuggets..." % len(response_l))
                except Exception as e:
                    self.error('Error splitting dependencies', e)
                    return

                #
                # read the cache (for dependencies)
                cache_required = False
                for name, entry in nugget_d.items():
                    if name != nugget_entry.name:
                        cache_required = not(self.read_cache(name, entry)) or cache_required

                #
                # Post-Process dependencies
                response_l = device.poll_post_process(nugget_d, response_l)

                try:
                    response_d = {}
                    self.respond("Calculating %s..." % nugget_type)
                    # start with the original nugget name
                    test_nugget = [nugget_entry.name] + expanded_l
                    response_l, new_response_l = device.poll_compute(nugget_d, nugget_d_by_type, response_l,
                                                                     test_nugget = test_nugget)

                    response_l.extend(new_response_l)

                    # find the relavent nugget list
                    name_l = expanded_l + [nugget_entry.name]
                    if (nugget_type == "group" and not nugget_entry.aggregate):
                        name_l += [x.name for x in nugget_entry.child_l]

                    # convert to dictionary
                    for nugget_name, timestamp, value in response_l:
                        if nugget_name in name_l:
                            response_d[nugget_name] = value

                    if not cache_required:
                        self.respond(pretty_results(nugget_type.capitalize(), response_d, nugget_entry.name))
                except Exception as e:
                    self.error('Error calculating %s' % nugget_type, e)
                    return

                #
                # write the cache (for dependencies)
                for name, entry in nugget_d.items():
                    if name != nugget_entry.name:
                        self.write_cache(name, entry)

                if cache_required:
                    self.error("Incremental Processing Required! Run the test again!")
                    return

                if response_d:
                    self.process_data(nugget_entry, response_d)
        else:
            for nugget_name, nugget_entry in nugget_d.items():
                # nugget_name header
                if len(device.nugget_d) > 1:
                    self.respond('\n<div style="border-bottom: 1px solid black">[%s]</div>' % nugget_name)

                nugget_cfg = nugget_entry.cfg

                # collect
                nugget_type = nugget_cfg.get("type")
                data = None
                if nugget_type in ["cli", "file"]:
                    data = self.process_cli(device, nugget_entry)
                elif nugget_type == "snmp":
                    data = self.process_snmp(device, nugget_entry)
                elif nugget_type == "rest":
                    data = self.process_rest(device, nugget_entry)
                elif nugget_type == "grpc":
                    data = self.process_grpc(device, nugget_entry)
                else:
                    self.respond('Error: Nugget type not supported :-(')

                if data is not None:
                    self.process_data(nugget_entry, {nugget_name: data})

        self.respond("done")

    def process_grpc (self, device, nugget_entry):
        nugget_cfg = nugget_entry.cfg

        # initialize the channel
        device.grpc.init_channel()

        # send the query
        try:
            self.respond("Sending query...")
            data = nugget_entry.get()
        except Exception as e:
            self.error('Error sending query', e)

        # show the response
        self.respond(pretty("Response", data))

        return data

    def process_rest (self, device, nugget_entry):
        nugget_cfg = nugget_entry.cfg

        # login to the device
        try:
            device.rest.login()
        except Exception as e:
            self.error('Error logging in', e)
            return

        # send the query
        try:
            self.respond("Sending query...")
            start = time.time()
            cache = {}
            data = device.rest.nugget_get(nugget_cfg, cache)

            # show the response
            self.respond(pretty("Response (%ss)" % round(time.time() - start, 2), data))
        except Exception as e:
            self.error('Error sending query', e)

        return data

    def process_snmp (self, device, nugget_entry):
        nugget_cfg = nugget_entry.cfg

        try:
            oid = nugget_cfg['oid_built']

            time_start = time.time()
            query_type = nugget_cfg.get('query_type', "get")
            if query_type in ['walk', 'bulkwalk']:
                q_name = "%s/%s" % (device.name, oid)
                opt = {
                    'query_type': query_type,
                    'oid': oid,
                    'timeout': nugget_cfg.get('timeout', cfg.snmp_timeout),
                    'retries': nugget_cfg.get('retries', cfg.snmp_retries),
                    'max_repititions': nugget_cfg.get('max_repititions', cfg.snmp_bulkwalk_reps),
                }
            else:
                q_name = device.name
                opt = {
                    'oid_l': [oid.encode()],
                    'timeout': nugget_cfg.get('timeout', cfg.snmp_timeout),
                    'retries': nugget_cfg.get('retries', cfg.snmp_retries),
                }

            self.respond("Sending query...")
            snmpEngine.add(q_name, device, opt, fn_name=query_type)

            try:
                self.respond("Waiting for response...")
                timestamp, response_d = snmpEngine.read(q_name)
            except SNMPEngine.SNMPEngineTimeout:
                self.error('SNMP Error: SNMP Engine Timeout')
                return

            log.debug("SNMP Query took: %s" % round(time.time() - time_start, 3))

            if 'Error' in response_d:
                self.respond('SNMP Error: %s' % response_d["Error"])
                return
            else:
                if query_type in ['walk', 'bulkwalk']:
                    response = SNMPEngine.process(response_d, oid,
                                                  nugget_cfg.get("oid_style"),
                                                  nugget_cfg.get("index_decoder_built"),
                                                  nugget_cfg.get("type_filter"))
                else:
                    response = response_d.get(oid)['value']

                self.respond(pretty("Response", response))
                return response
        except Exception as e:
            self.error('Error in snmp query', e)
            return

    def process_cli (self, device, nugget_entry):
        nugget_cfg = nugget_entry.cfg

        # connect to the device
        try:
            device.cli.set_session()
            s = device.cli.session
        except Exception as e:
            self.error('Error initializing the session', e)
            return

        if not device.cli.is_alive():
            e = device.code_d.get("term_fail") or device.code_d.get("term_down")
            self.error('Error initializing the session', e.get("msg"))
            return

        # finish building the command
        if nugget_cfg.get('filter'):
            command = "%s | %s %s" % (nugget_cfg['command_built'], device.cli.filter_command, '|'.join(nugget_cfg['filter']))
            self.respond('Full Command: %s' % code_block(command))
        else:
            command = nugget_cfg['command_built']

        if nugget_cfg['type'] == "cli" and command != nugget_cfg['command']:
            self.respond(pretty("Command built", command))

        # send the command
        try:
            self.respond("Sending command...")
            text = device.cli.get_response(command, nugget_cfg.get('timeout', cfg.cli_timeout))
            if text is pexpect.TIMEOUT:
                # extract the command response text
                text = s.before.decode().split('\n', 1)[1]
                self.error(pretty("CLI Timeout", text))
                return
        except Exception as e:
            self.error('Error sending command', e)
            return

        # initialize the text list
        data = text

        # line filter
        try:
            data = nugget_entry.filter_by_line(data)
        except Exception as e:
            self.error('Error in line filtering', e)
            return

        # show the response text
        self.respond(pretty("Response", data))

        # extract/parse the value(s)
        parse = nugget_cfg.get('parse_built')
        if parse:
            try:
                data = parse(data, nugget_cfg)
                self.respond(pretty("Parser output", data))
            except Exception as e:
                self.error('Error in parse phase', e)
                return

        # try to convert string to number
        data = utility.convert_type(data)

        return data

    def process_data (self, nugget_entry, response_d):
        nugget_name = nugget_entry.name
        nugget_cfg = nugget_entry.cfg
        timestamp = int(time.time())

        # process the data
        process = nugget_cfg.get('process_built')
        if process:
            new_response_d = {}

            try:
                for nugget_name, value in response_d.items():
                    new_response_d[nugget_name] = process(nugget_entry.device, value)

                response_d = new_response_d

                self.respond(pretty_results("Process", response_d, nugget_entry.name))
            except Exception as e:
                self.error('Error in processing phase', e)
                return

        # split the data (into multiple Nuggets)
        if nugget_cfg.get('split'):
            try:
                new_response_l = []
                for nugget_name, value in response_d.items():
                    entry_l, response_l = nugget_entry.device.split_nugget(nugget_entry, timestamp, value)
                    new_response_l += response_l

                # convert the to a dictionary
                response_d = {name:value for name, timestamp, value in new_response_l}
                self.respond(pretty_results("Split", response_d, nugget_entry.name))
            except Exception as e:
                self.error('Error in split phase', e)
                return

        # post-process the split data
        if nugget_cfg.get('incremental_process') or nugget_cfg.get("post_process_built"):
            try:
                new_response_d = {}
                cache_required = False
                for nugget_name, value in response_d.items():
                    # for incremental processing, cache the previous values
                    cache_required = not self.read_cache(nugget_name, nugget_entry) or cache_required

                    if nugget_cfg.get("incremental_process") == "timestamped_entries":
                        start_length = len(value)

                    # run the post process (reuse the same nugget entry over and over)
                    ts, value = nugget_entry.post_process(timestamp, value)

                    if nugget_cfg.get("incremental_process") == "timestamped_entries":
                        if len(value) < start_length:
                            self.respond("Filtering %s stale entries..." % (start_length - len(value)))

                    # cache for incremental processing
                    self.write_cache(nugget_name, nugget_entry)

                    # store the response
                    new_response_d[nugget_name] = value

                if cache_required:
                    self.error("Incremental Processing Required! Run the test again!")
                    return

                response_d = new_response_d
                self.respond(pretty_results("Post-processed", response_d, nugget_entry.name))
            except Exception as e:
                self.error('Error in post-processing phase', e)
                return

    def read_cache (self, key, entry):
        incremental_process = entry.cfg.get("incremental_process")
        if incremental_process:
            if incremental_process == "timestamped_entries":
                if key in self.cache:
                    entry.latest_log_timestamp = self.cache[key]
            else:
                if key in self.cache:
                    entry.sample_timestamp, entry.sample = self.cache[key]
                else:
                    return False

        return True

    def write_cache (self, key, entry):
        incremental_process = entry.cfg.get("incremental_process")
        if incremental_process:
            if incremental_process == "timestamped_entries":
                self.cache[key] = entry.latest_log_timestamp
            else:
                self.cache[key] = (entry.sample_timestamp, entry.sample)

    def respond (self, text):
        self.send(text_data=text)

    def error (self, msg, e=None):
        if e:
            self.respond('%s: %s' % (msg, code_block(str(e))))
        else:
            self.respond(msg)

        self.respond('done')
