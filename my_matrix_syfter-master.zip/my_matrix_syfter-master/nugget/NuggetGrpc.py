import sys
sys.path.append("/opt/cisco/syfter/grpc/Thanos/")
from importlib import import_module
from google.protobuf.json_format import MessageToJson
import subprocess
import re
import json

from .Nugget import Nugget

from common import logger as log
from common import config as cfg

class NuggetGrpc (Nugget):
    formula_key = 'args'
    required_opts = ['proto', 'rpc']

    rpc_re = r'\s*rpc\s+(\w+)\((\w+)\)\s+returns\s+\(\s*(stream)?\s*(\w+)\s*\)\s*;'
    def build_proto (self, proto_text):
        # extract the package name
        package_name = re.search(r'\n\s*package\s*(\w+)', proto_text).group(1)
        # extract the package name
        service_name = re.search(r'\n\s*service\s*(\w+)', proto_text).group(1)
        rpc_list = re.findall(self.rpc_re, proto_text)
        rpc_d = {}
        for name, request, stream, response in rpc_list:
            rpc_d[name] = {
                'stream': (stream != ''),
                'request': request,
                'response': response
            }

        rpc_list = re.findall(self.rpc_re, proto_text)

        # find the imports
        import_l = re.findall(r'import "(.*)"', proto_text)

        # write the proto file
        proto_filepath = "%s%s/%s.proto" % (cfg.grpc_build_dir, self.device.type, package_name)
        with open (proto_filepath, 'w') as f:
            f.write(proto_text)

            
        # compile the grpc code
        # command = ("python -m grpc_tools.protoc -I%s --python_out=%s --grpc_python_out=%s %s"
        #            % (cfg.grpc_build_dir,
        #               cfg.grpc_build_dir,
        #               cfg.grpc_build_dir,
        #               proto_filepath))
        # subprocess.call(command.split())

        return package_name, service_name, rpc_d, import_l
        
    def compile_expr (self):
        # call the parent function
        super().compile_expr()

        proto = self.cfg['proto']
        package_name, service_name, rpc_d, import_l = self.build_proto(proto)
        self.rpc_d = rpc_d[self.cfg['rpc']]

        self.module = module = import_module("%s_pb2" % package_name)
        self.grpc_module = grpc_module = import_module("%s_pb2_grpc" % package_name)

        # import add required types
        message_types_d = self.module._sym_db.GetMessages(files=import_l)
        message_types_d = {x.split('.')[-1]:y for x,y in message_types_d.items()}
        locals().update(message_types_d)

        stub_fn = getattr(grpc_module, "%sStub" % service_name)
        self.device.grpc.init_channel()
        self.stub = stub_fn(self.device.grpc.channel)
        self.rpc = getattr(self.stub, self.cfg["rpc"])

        request_class = getattr(module, self.rpc_d['request'])
        arg_types = {}
        for x in request_class.DESCRIPTOR.fields:
            arg_types[x.name] = {}
            if x.message_type:
                for y in x.message_type.fields:
                    arg_types[x.name][y.name] = {}

        # get the arguments
        try:
            self.args = eval("request_class(%s)" % self.cfg.get('args', ''))
            self.cfg['args_built'] = self.args
        except Exception as e:
            log.debug(e)

    def get (self):
        response = self.rpc(self.args, timeout=10)

        if self.rpc_d['stream']:
            r = []
            try:
                for s in response:
                    r.append(json.loads(MessageToJson(s)))
            except Exception as e:
                log.debug(e)
            return r
        else:
            return json.loads(MessageToJson(response))
