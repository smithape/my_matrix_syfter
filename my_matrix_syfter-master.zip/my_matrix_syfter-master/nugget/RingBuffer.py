import numpy as np

class RingBuffer (object):
    "A ring buffer"
    def __init__(self, size, fill=0):
        self.size = int(size)
        self.index = 0
        self.init_array(fill)

    def init_array (self, fill):
        self.data = [fill]*self.size

    def add (self, x):
        "adds number to the ring buffer"
        # write the value
        self.data[self.index] = x;
        # update the index pointer
        self.index = (self.index + 1) % self.size;

    def get (self):
        "Returns the data array (ordered correctly by FIFO)"
        ret_l = []
        for x in range(self.size):
            i = (x + self.index) % self.size
            ret_l.append(self.data[i])

        return ret_l

class NumpyRingBuffer (RingBuffer):
    "A ring buffer using numpy arrays"
    def __init__(self, size, entry_size=1, fill=0):
        self.entry_size = entry_size
        super(NumpyRingBuffer, self).__init__(size, fill=fill)

    def init_array (self, fill):
        if self.entry_size > 1:
            size = [self.size, self.entry_size]
        else:
            size = self.size

        # initialize the numpy array
        self.data = np.empty(size)
        self.data.fill(fill)

    def mean (self):
        "returns the average/mean of the array"
        return self.data.mean()

    def get (self):
        "Returns the data array (ordered correctly by FIFO)"
        idx = (self.index + np.arange(self.size)) % self.size
        return self.data[idx]

class AvgNumpyRingBuffer (NumpyRingBuffer):
    "1-dimension Ring Buffer to be used for maintaining an average"
    def __init__(self, size, fill=0):
        super(AvgNumpyRingBuffer, self).__init__(size, entry_size=1, fill=fill)
        self.avg = self.data.mean()

    def add (self, x):
        "adds number to the ring buffer"
        # update the avg calculation
        self.avg += (x - self.data[self.index]) / self.size;
        # write the value
        self.data[self.index] = x;
        # update the index pointer
        self.index = (self.index + 1) % self.size;

    def mean (self):
        "returns the average/mean of the array"
        return self.avg
