from .Nugget import Nugget

class NuggetGroup (Nugget):
    required_opts = ['members']

    def __init__(self, *args, **kwargs):
        # get the nugget config
        self.cfg = kwargs.get('nugget_cfg')

        # do we aggregate group children?
        self.aggregate = self.cfg.get('aggregate', False)
        # if groups aren't aggregated, then they will not require polling or storing,
        # so we disable before calling the parent __init__
        if not self.aggregate:
            # do we poll this group nugget?
            kwargs['poll'] = False
            # do we store this nugget?
            kwargs['store'] = False

        # run the parent init
        super().__init__(*args, **kwargs)

        # get the member nuggets
        self.members = [x.replace("*", self.name) for x in self.cfg.get("members", [])]
