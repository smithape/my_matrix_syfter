from common import SNMPEngine
from .Nugget import Nugget

class NuggetSnmp (Nugget):
    formula_key = 'oid'
    required_opts = ['oid']
    variable_opts = ['index_decoder']

    def compile_expr (self):
        # bild the oid
        self.cfg['oid_built'] = SNMPEngine.format_oid(self.cfg['oid_built'])

        # build the index decoder
        if self.cfg.get('index_decoder'):
            self.cfg['index_decoder_built'] = self.device.get_nugget_var(self.cfg['index_decoder'].strip("{}"))

        super().compile_expr()
