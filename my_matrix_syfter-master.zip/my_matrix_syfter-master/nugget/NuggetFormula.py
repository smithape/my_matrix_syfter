import re
from .Nugget import Nugget
from common import config as cfg
from common import logger as log

class NuggetFormula (Nugget):
    formula_key = 'index'

    def compile_expr (self):
        #
        # build the formula
        formula = self.cfg['formula']

        # remove commented lines
        formula = re.sub(r'(?m)^ *#.*\n?', '', formula)

        # check whether any of the formula variables need aliasing
        for var in re.findall(cfg.nugget_var_re, formula):
            var_cfg = self.device.nugget_cfg.get(var) or {}
            alias = var_cfg.get('alias')
            if alias:
                # replace the original var with it's alias
                formula = re.sub(r'{%s}' % var, r'{%s}' % alias, formula)

        # if this nugget is the result of a index expansion, adjust the formula
        # variables accordingly
        if self.index:
            # rename the formula variables (add index)
            formula = re.sub(r'{(\w+)}', r'{\1:%s}' % self.index, formula)

        # try expanding an indexed child into a dictionary
        for var in re.findall(cfg.nugget_var_re, formula):
            var_entry = self.device.nugget_d.get(var)
            if var_entry and var_entry.indexes:
                expanded = '{'
                for idx_name in var_entry.indexes:
                    idx_entry = self.device.nugget_d[idx_name]
                    idx = idx_entry.index
                    expanded += '"%s": {%s},' % (idx, idx_name)
                expanded += '}'
                formula = re.sub('{%s}' % var, expanded, formula)

        # save the list of nugget vars
        self.formula_var_l = re.findall(cfg.nugget_var_re, formula)

        self.cfg['formula_built'] = formula

        #
        # build the index? I don't fully understand this. I guess the
        # syntax requires brackets
        if self.cfg.get('index'):
            self.cfg['index_built'] = '{%s}' % self.cfg['index']

        super().compile_expr()
