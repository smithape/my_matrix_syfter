from channels.generic.websocket import WebsocketConsumer
from threading import Thread
from pkg import pexpect
import queue
import html
import json
import re

from common import DB
from common import config as cfg
from common import logger as log

# initialize the logger
log.init("termserver.log")

# initialize the config
cfg.init_config()

class TSConsumer(WebsocketConsumer):
    def connect (self):
        log.debug("connect")
        self.accept()

    def disconnect (self, close_code):
        log.debug("disconnect")
        #pass

    def receive (self, text_data):
        data = json.loads(text_data)
        command = data['command']
        device_name = data['device']

        try:
            self.send_command(command)
        except Exception as e:
            self.init_device(device_name)
            self.send_command(command)

    def init_device (self, device_name):
        self.device = cfg.get_device(device_name, reset=True)

        if not self.device.cli.init_webterm():
            self.send(text_data="\nCouldn't establish a session :-(")

        # start the responder
        Thread(target=self.send_response, args=[self.device.cli.session]).start()

    def send_command (self, command):
        self.device.cli.session.send(command)

        if command.endswith("?"):
            self.device.cli.session.sendcontrol('u')

    def send_response (self, s):
        while True:
            try:
                ret = html.escape(s.readline().decode())
            except pexpect.TIMEOUT: continue

            self.send(text_data=ret)
