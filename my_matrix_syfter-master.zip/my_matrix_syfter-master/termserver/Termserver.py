"""
This file was deprecated in favor of using a websocket consumer (found in
consumers.py)
"""

import sys
import time
import traceback
import json
import re
from subprocess import getstatusoutput
from threading import Thread
from twisted.internet import reactor, threads, protocol as p
from pkg import pexpect

from common.PeriodicThread import PeriodicThread
from common import \
    utility, \
    config as cfg, \
    logger as log, \
    DB

# the termserver
ts = None
def init ():
    global ts
    ts = TermServer()

class TermserverDaemon():
    def __init__(self):
        self.stdin_path = '/dev/null'
        self.stdout_path = '/dev/tty'
        self.stderr_path = '/dev/tty'
        self.pidfile_path =  '/var/run/%s_termserver.pid' % cfg.tool_name
        self.pidfile_timeout = 1
        self.interrupt = False
        self.server_t = Thread(target=reactor.run, kwargs={'installSignalHandlers': 0})

    def run(self):
        init()
        reactor.listenTCP(cfg.termserver_port, TermServerServer())
        try:
            self.server_t.start()
            ts.start()
            while not self.interrupt:
                time.sleep(1)
        except Exception as e:
            print(traceback.format_exc())
        finally:
            try:
                ts.stop()
                reactor.callFromThread(reactor.stop)
            except:
                log.debug("exception in termserver shutdown")
                log.debug(traceback.format_exc())
            finally:
                # hacky way to make sure we die
                getstatusoutput('pkill -9 -f "python\s.*%s\s*start"'
                                % sys.argv[0])

    def terminate(self, signal_number, stack_frame):
        self.interrupt = True

class TermServerServer (p.Factory):
    def buildProtocol(self, addr):
        return RequestHandler()

class RequestHandler (p.Protocol):
    delimiter = b'\n'

    def __init__(self):
        self.ibuffer = bytearray()

    def dataReceived(self, data):
        # add new data to the buffer
        self.ibuffer.extend(data)
        # delimiter marks the end of the message
        if data[-1] == self.delimiter[-1]:
            try:
                # parse the message into json
                request = json.loads(self.ibuffer.decode())
                # process the request
                self.process_request(request)
            except Excpetion as e:
                log.error("Invalid Request (cannot parse)", "system")
            finally:
                # clear the buffer
                self.ibuffer = bytearray()

    def process_request (self, request):
        device_name = request['device_name']

        if 'command' in request:
            command = request['command']
        else:
            command = "\r"

        response = self.query(device_name, command)

        if response:
            self.respond(response)

    def respond (self, response):
        if not isinstance(response, str):
            response = json.dumps(response)

        response = response.encode() + self.delimiter
        self.transport.write(response)
        self.transport.loseConnection()

    def query (self, device_name, command):
        d = threads.deferToThread(ts.query, device_name, command)
        d.addCallback(self.respond)

class TermServer (object):
    def __init__ (self):
        self.device_d = {}
        self.monitor_t = None

    def start (self):
        # Start the monitor thread
        self.monitor_t = PeriodicThread(name="monitor",
                                        interval=600, # 10 minutes
                                        action=self.monitor,
                                        daemon=True)
        self.monitor_t.start(time.time() + 60)

    def stop (self):
        # stop the monitor thread
        if self.monitor_t:
            self.monitor_t.stop()

        log.debug("Closing sessions...")
        thread_l = []
        for device in self.device_d.values():
            t = Thread(target=device.close_session)
            thread_l += [t]
            t.start()
        for t in thread_l:
            t.join()

    def monitor (self):
        now = int(time.time())

        for device in list(self.device_d.values()):
            if now - device.last_access > cfg.termserver_hold_time:
                self.remove_device(device.name)

    def add_device (self, device_name):
        log.debug("Connect: %s" % device_name)

        # read from redis
        device_d = json.loads(DB.redis.get("device_d_full").decode())
        device = device_d[device_name]
        device_obj = cfg.init_device_object(device_name, device['class'])
        for key in device:
            setattr(device_obj, key, device[key])
        self.device_d[device_name] = device_obj

    def remove_device (self, device_name):
        log.debug("Disconnect: %s" % device_name)
        try:
            device = self.device_d[device_name]
            device.close_session()
            del self.device_d[device_name]
            return True
        except KeyError:
            return False

    def query (self, device_name, command):
        try:
            device = self.device_d[device_name]
        except KeyError:
            # initialize the session
            try:
                # refresh the device list
                self.add_device(device_name)
                device = self.device_d[device_name]
                if not device.init_webterm():
                    msg = "\nCouldn't establish a session :-("
                    return json.dumps(msg)
            except KeyError:
                msg = "\nCouldn't find device :-("
                return json.dumps(msg)

        device.last_access = int(time.time())

        s = device.session
        s.send(command)
        # ret = s.expect_list([device.prompt_re,
        #                      pexpect.TIMEOUT], timeout=30)
        # if ret == 0:
        #     bfr = s.before + s.after
        # elif ret == 1:
        #     bfr = s.before

        ret = bytearray()
        while True:
            try:
                ret += s.read_nonblocking(timeout=1)
            except pexpect.TIMEOUT:
                break

        try:
            ret = ret.decode()
            ansi_escape = re.compile(r'(\x1b\[|\x9b)[^@-_]*[@-_]|\x1b[@-_]', re.I)
            ret = ansi_escape.sub('', ret)
        except Exception as e:
            log.debug(e)
        return json.dumps(ret)

