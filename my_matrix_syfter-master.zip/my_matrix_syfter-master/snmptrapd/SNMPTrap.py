import time
from threading import Thread
from pysnmp.entity import engine, config
from pysnmp.entity.rfc3413 import ntfrcv
#import asyncio
#from pysnmp.carrier.asyncio.dgram import udp
from twisted.internet import reactor
from pysnmp.carrier.twisted.dgram import udp
import json
from common import config as cfg
from common import logger as log
from common import utility
from common import SNMPEngine


class SNMPTrapDaemon():
    def __init__(self):
        self.stdin_path = '/dev/null'
        self.stdout_path = '/dev/tty'
        self.stderr_path = '/dev/tty'
        self.pidfile_path =  cfg.get_pidfile('snmptrap')
        self.pidfile_timeout = 1
        self.interrupt = False
        self.server_t = Thread(target=reactor.run, kwargs={'installSignalHandlers': 0})

    def run(self):
        # Create SNMP engine with autogenernated engineID and pre-bound
        # to socket transport dispatcher
        self.snmpEngine = engine.SnmpEngine()

        # Transport setup
        # UDP over IPv4, first listening interface/port
        try:
            config.addTransport(
                self.snmpEngine,
                udp.domainName,
                udp.UdpTwistedTransport().openServerMode(('0.0.0.0', cfg.snmptrap_port))
            )
        except Exception as e:
            log.debug(traceback.format_exc())
            return

        # SNMPv1/2c setup
        self.init_v2()

        # Register SNMP Application at the SNMP engine
        ntfrcv.NotificationReceiver(self.snmpEngine, self.trap_callback)

        try:
            self.server_t.start()
            while not self.interrupt:
                time.sleep(1)
        except Exception as e:
            log.debug(traceback.format_exc())
        finally:
            try:
                reactor.callFromThread(reactor.stop)
            except:
                log.debug("exception in snmptrap shutdown")
                log.debug(traceback.format_exc())


    def terminate(self, signal_number, stack_frame):
        self.interrupt = True

    def init_v2 (self):
        # SecurityName <-> CommunityName mapping
        config.addV1System(self.snmpEngine, 'my-area', cfg.snmptrap_community)

    # Callback function for receiving notifications
    def trap_callback(self, snmpEngine, stateReference, contextEngineId, contextName,
                      varBinds, cbCtx):
        # trap_source = snmpEngine.observer.getExecutionContext(
        #     'rfc3412.receiveMessage:request'
        # )['transportAddress']
        transportDomain, trap_source = snmpEngine.msgAndPduDsp.getTransportInfo(stateReference)
        source_ip = trap_source[0]

        # try to get the device name using the source ip
        try:
            device_name = cfg.device_by_ip_d.get(source_ip).name
        except:
            device_name = source_ip

        varbind_d = {str(x):{'value': str(y)} for x,y in varBinds}
        varbind_d = SNMPEngine.process(varbind_d, style="name")

        # build the trap entry
        trap = {
            # convert to device_name
            'host': device_name,
            # does the trap itself contain a timestamp?
            'timestamp': int(time.time()),
            # convert OIDS to object names
            'data': varbind_d
        }
        # submit to the DB engine
        query = {
            'name': 'snmptrap_insert',
            'options': {
                'trap_data': trap
            }
        }
        utility.db_query(query)

#trap = SNMPTrapDaemon()
# Run Twisted main Loop
#reactor.run()

# Get the event loop for this thread
#loop = asyncio.get_event_loop()
#loop.run_forever()
