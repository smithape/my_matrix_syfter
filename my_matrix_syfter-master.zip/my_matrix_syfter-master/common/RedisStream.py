import os
import time
from datetime import datetime
import json
from threading import Thread, Lock
import queue
import redis

from .PeriodicThread import PeriodicThread
from . import DB
from . import logger as log
from . import utility
from . import config as cfg

class RedisStream (DB.DBObject):
    flush_period = 60

    def __init__ (self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.send_buffer = queue.Queue()
        self.send_buffer_lock = Lock()
        self.up = True
        self.redis = redis.StrictRedis(host=cfg.redis_host,
                                       port=cfg.redis_port,
                                       username=cfg.redis_username,
                                       password=cfg.redis_password)
        # self.sub = self.redis.pubsub(ignore_subscribe_messages=True)
        # self.sub.subscribe('syfter.status')

        if not os.path.exists(cfg.redis_dump_dir):
            os.makedirs(cfg.redis_dump_dir, 0o755)

        now = int(time.time())
        self.tstamp_d = {
            'send_dump': 0,
            'send_config': 0,
            'flush': now,
            }


    def start (self):
        try:
            self.redis.client_list()
        except redis.ConnectionError as e:
            self.up = False
            self.status = "connection error"
            log.error("Redis connection error: %s" % e, "system")

        # Start the monitor thread
        self.monitor_t = PeriodicThread(name="redis_stream/monitor",
                                        interval=10,
                                        action=self.monitor,
                                        daemon=True)
        self.monitor_t.start(time.time())

    def stop (self):
        # stop the monitor thread
        if self.monitor_t:
            self.monitor_t.stop()

    def monitor (self):
        now = int(time.time())
        day = utility.epoch_to_day(now)
        local_hour = datetime.now().hour

        # get the redis interface status
        try:
            sub_count = self.redis.pubsub_numsub("%s.data" % cfg.tool_name)[0][1]
            if not sub_count:
                self.status = None
            else:
                self.status = self.redis.get("%s.status" % cfg.tool_name).decode()
        except AttributeError:
            self.status = None
        except redis.ConnectionError:
            self.up = False
            self.status = "connection error"

        # send device data
        if self.up:
            if now - self.tstamp_d['send_config'] >= cfg.redis_config_update_period:
                self.send_config()
                self.tstamp_d['send_config'] = now

            # send dump
            if now - self.tstamp_d['send_dump'] >= 3600:
                self.send_dump()
                self.tstamp_d['send_dump'] = now

            # flush the send buffer
            if now - self.tstamp_d['flush'] >= self.flush_period:
                self.flush()
                self.tstamp_d['flush'] = now

    def maintenance (self):
        """
        This function is run by the monitor service during the nightly maintenance hour
        """

        if not self.up:
            utility.send_email("Redis destination is down!",
                               message=("You should fix this, or disable Redis as a destination. "+
                                        "Data is being buffered locally, and could flood the disk."))

    def flush (self):
        buffer_l = list(self.send_buffer.queue)

        if buffer_l:
            data = list(self.send_buffer.queue)
            self.send_buffer.queue.clear()
            self.send_data(data, '%s.data' % cfg.tool_name)

    def send_config (self):
        config = {
            'company': cfg.company,
            'timezone': cfg.timezone,
            'nugget': DB.db.nugget_cfg_d,
            'device': DB.db.device_d
        }

        self.redis.set('%s.config' % cfg.tool_name, json.dumps(config))

    def send_data (self, data, channel, dump=True):
        if data:
            if not isinstance(data, str):
                data = json.dumps(data)
                #data = json.dumps(data, indent=4)

            try:
                self.redis.publish(channel, data)
                #self.dump(data)
                return True
            except Exception as e:
                log.error("Redis push error: %s" % e, "system")

            # push failed, dump the backup
            if dump:
                self.dump(data)

            self.up = False
            return False

    def dump (self, data):
        # find the filepath
        filepath_root = filepath = "%s/%s" % (cfg.redis_dump_dir, int(time.time() * 1000))
        # make sure the filepath is unique
        i = 0
        while os.path.exists(filepath):
            filepath = "%s.%s" % (filepath_root, i)
            i += 1
        # write the dump
        with open (filepath, "w") as f:
            f.write(data)

    def create_sample (self, timestamp, device_name, nugget_name, value):
        sample = {
            'timestamp': timestamp,
            'device': device_name,
            'nugget': nugget_name,
            'value': value
        }

        return sample

    def send_dump (self):
        # remove expired dumps
        now = int(time.time())
        for filename in sorted(os.listdir(cfg.redis_dump_dir)):
            timestamp = int(filename.split('.')[0]) // 1000
            if timestamp < (now - cfg.json_dump_hold_days * 86400):
                filepath = os.path.join(cfg.redis_dump_dir, filename)
                os.remove(filepath)
            else: break

        # send
        if self.up:
            for filename in os.listdir(cfg.redis_dump_dir):
                filepath = os.path.join(cfg.redis_dump_dir, filename)
                with open (filepath, "r") as f:
                    data = f.read()
                    success = self.send_data(data, '%s.data' % cfg.tool_name, dump=False)

                if success:
                    os.remove(filepath)
                else:
                    break

    def bulk_insert (self, sample_l):
        for timestamp, device_name, nugget_name, value in sample_l:
            e = self.create_sample(timestamp, device_name, nugget_name, value)
            self.send_buffer.put(e)

        # At this time, I think it best to flush to redis immediately instead of
        # waiting and collecting data
        self.flush()

    def snmptrap_insert (self, trap):
        self.send_data(trap, '%s.snmptrap' % cfg.tool_name)

    def nugget_cfg (self, data):
        # send full (updated) config
        self.send_config()
        # send new nugget data
        self.send_data(data, '%s.nugget_cfg' % cfg.tool_name)

    def log_insert (self, log_tuple):
        timestamp, device_name, nugget_name, severity, log_type, message = log_tuple

        e = {
            'time': timestamp,
            'source': cfg.tool_name,
            'sourcetype': 'log',
            'index': self.get_index(device_name),
            'event': {
                'severity': log.sev_name[severity],
                'log_type': log.log_type_name[log_type],
                'message': message
            }
        }

        # add other parameters if they exists
        if cfg.splunk_site_name:
            e['event']['site'] = cfg.splunk_site_name
        if device_name:
            e['event']['device'] = device_name
        if nugget_name:
            e['event']['nugget'] = nugget_name

        self.send_buffer.put(e)

    def diff_insert (self, diff_tuple):
        timestamp, device_name, diff = diff_tuple

        e = {
            'time': timestamp,
            'source': cfg.tool_name,
            'sourcetype': 'diff',
            'index': self.get_index(device_name),
            'event': {
                'device': device_name,
                'diff': diff
            }
        }

        self.send_buffer.put(e)

    def nf_insert (self, field, timestamp, data_l):

        for entry in data_l:
            host = entry['device']

            # find the device name using the host ip
            try:
                device_name = DB.db.device_ip_d[host]['name']
            except KeyError:
                device_name = DB.db.add_to_device_list(host)

            e = {
                'time': timestamp,
                'source': cfg.tool_name,
                'sourcetype': 'netflow',
                'index': self.get_index(device_name),
                'event': {
                    field: entry[field],
                    'flows': entry['flows'],
                    'packets': entry['packets'],
                    'bytes': entry['bytes'],
                }
            }

            self.send_buffer.put(e)

    def syslog_insert (self, log_d):
        host = log_d['host']

        # find the device name using the host ip
        try:
            device_name = DB.db.device_ip_d[host]['name']
        except KeyError:
            device_name = DB.db.add_to_device_list(host)

        event_d = log_d.copy()
        del event_d['timestamp']
        del event_d['host']

        e = {
            'type': 'syslog',
            'timestamp': log_d['timestamp'],
            'event': event_d,
        }


        # add device and nugget if they exists
        if device_name:
            e['event']['device'] = device_name

        self.send_buffer.put(e)

    def send_report (self, report_d):
        e = {
            'time': int(time.time()),
            'source': cfg.tool_name,
            'sourcetype': 'report',
            #'index': 'main',
            'event': report_d
            }

        self.send_data(json.dumps(e))

    def client_report_insert (self, timestamp, client_l):
        for client in client_l:
            index = client.pop('db_index', None) or cfg.splunk_index
            e = {
                'time': timestamp,
                'source': cfg.tool_name,
                'sourcetype': 'cmx_client',
                'index': index,
                'event': {
                    'mac_address': client['mac_address'],
                    'vc': client['vc'],
                    'location': client['location'],
                    'presence': client['presence'],
                }
            }
            event_str = json.dumps(e)
            self.add_event(event_str)
