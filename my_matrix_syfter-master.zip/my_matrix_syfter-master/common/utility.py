"""
File: utility.py

This module is used to house functions that are shared between other
modules.
"""
import sched, time, calendar, pytz
from datetime import datetime, timedelta
import sys, os, math, string, random, re
import socket
import json
from threading import Thread, Timer
import smtplib
from email.mime.text import MIMEText
import subprocess
from subprocess import getstatusoutput
import readline
from fractions import gcd
from dateutil import parser
from dateutil.tz import gettz, tzlocal
from tempfile import NamedTemporaryFile

from pkg import pexpect
from django.utils import timezone
from twisted.web.server import Site
from twisted.internet import reactor
from twisted.web.static import File
from twisted.protocols.ftp import FTPFactory #, FTPRealm
from twisted.cred.portal import Portal
from twisted.cred.checkers import AllowAnonymousAccess, FilePasswordDB, InMemoryUsernamePasswordDatabaseDontUse

from . import Server
from .ftp import FTPRealm
from . import config as cfg
from . import logger as log
from . import exception
from functools import reduce

def debug (string):
    if 'server' not in sys.argv:
        print(string)

def error (string):
    """Print an error string and exit"""

    raise exception.LDMError ("\nError: %s" % string)

def cfg_error (device_name, option, syntax="", example=""):
    """Inform the user of a confiuration error"""

    str = "\nError: Device config option missing or invalid!\n\n"
    str += "Option:\n\t%s\n" % option
    if syntax:
        str += "Syntax:\n\t%s\n" % syntax
    if example:
        str += "Example:\n\t%s\n" % example

    raise exception.ConfigError (str)

def is_frozen():
    """Determine whether we are running within a pyinstaller single file"""

    return hasattr(sys, "_MEIPASS")

def resource_path(relative):
    """Find a resource path (frozen or not)"""

    if hasattr(sys, "_MEIPASS"):
        return os.path.join(sys._MEIPASS, relative)
    else:
        return os.path.join(os.path.dirname(os.path.abspath(__file__)), relative)

def time_remaining_string (time_string):
    """
    This function takes in a time string (sometime in the future),
    and returns the time delta between NOW and that time.
    (used to show time remaining on reservations)
    """

    WEEK = 604800
    DAY = 86400
    HOUR = 3600
    MINUTE = 60

    seconds_since_epoch = time_str_to_secs(time_string)
    ctime_secs = time.time()
    delta = seconds_since_epoch - ctime_secs

    weeks_left = delta / WEEK
    days_left = delta / DAY
    hours_left = delta / HOUR
    minutes_left = delta / MINUTE

    ret = ""
    if weeks_left >= 2:
        ret += "%.1f weeks" % weeks_left
    elif days_left >= 2:
        ret += "%.01f days" % days_left
    elif hours_left >= 1:
        ret += "%.1f hrs" % hours_left
    else:
        ret += "%.1f mins" % minutes_left

    return ret

def convert_time_str_to_tz (time_string):
    """convert a time string to the timezone of user (eg. UTC-->EST)"""

#     if not time_string:
#         return ""

    time_secs = time_str_to_secs(time_string)

    if time.daylight and time.localtime().tm_isdst:
        tz_time_secs = time_secs - time.altzone
    else:
        tz_time_secs = time_secs - time.timezone

    return time_secs_to_str(tz_time_secs, True)

def date_str_to_secs (date_string, local=False):
    """convert a date string into seconds since the epoch"""
    date_string = re.sub(r'[\-/]', ' ', date_string)

    date_struct = time.strptime(date_string, "%Y %m %d")
    if local:
        ts = int(time.mktime(date_struct))
    else:
        ts = calendar.timegm(date_struct)

    return ts

def time_str_to_secs (time_string):
    """convert a time string into seconds since the epoch"""

    time_struct = time.strptime(time_string, "%b %d %Y, %H:%M")
    return calendar.timegm(time_struct)

def time_secs_to_str (time_secs, include_timezone = False):
    """convert time in seconds from the epoch into a string representation"""

    time_struct = time.gmtime(time_secs)
    format_string = "%b %d %Y, %H:%M"
    if include_timezone:
        format_string += " %Z"
    return time.strftime(format_string, time_struct)

def parse_number_list (string):
    number_l = {int(x) for x in re.findall(r'\d+', string)}

    ranges = [sorted([int(x), int(y)]) for x,y in re.findall(r'(\d+)-(\d+)', string)]
    for x,y in ranges:
        number_l.update(list(range(x, y + 1)))

    return sorted(number_l)

def parse_date_list (string):
    span_l = []
    string_l = string.split(',')

    for date_str in string_l:
        match = re.search(r'(\d+/\d+/\d+)-(\d+/\d+/\d+)', date_str)
        if match:
            # date range
            start_date_str = match.group(1)
            end_date_str = match.group(2)
            try:
                start = date_str_to_secs(start_date_str, local=True)
                end = date_str_to_secs(end_date_str, local=True) + 86400 - 1
                span_l.append([start, end])
            except ValueError: continue

        elif re.search(r'\d+/\d+/\d+', date_str):
            # single date
            try:
                start = date_str_to_secs(date_str, local=True)
                end = start + 86400 - 1
                span_l.append([start, end])
            except ValueError: continue

    return span_l

def random_string(length=6):
    """return a random string of a specified length"""

    chars = string.ascii_lowercase + string.digits
    return ''.join(random.choice(chars) for x in range(length))

def convert_type (x, round_floats=True):
    # try to convert string to number
    if isinstance(x, (str, bytes)):
        try: # try INT
            x = int(x)
        except:
            try: # try FLOAT
                x = float(x)
                if round_floats:
                    x = round(x, 2)
            except Exception as e: pass

    return x

def str_is_int(string):
    """Determine whether a string represents an integer value"""

    try:
        int(string)
        return True
    except ValueError:
        return False

def is_valid_ip_address(string):
    """Determine whether a string represents a valid ip address"""
    try:
        socket.inet_aton(string)
        return True
    except (socket.error, TypeError):
        return False

def is_valid_netmask (string):
    match = re.search(r'(\d+)\.(\d+)\.(\d+)\.(\d+)', string)
    if match:
        for octet in match.groups():
            if octet not in ['0', '128', '192', '224', '240',
                             '240', '248', '252', '254', '255']:
                return False

        return True

    return False

def verify_file(filepath):
    """Verify that a filepath refers to a real file"""

    if not filepath:
        error("you must specify a file!")
    if os.path.isdir(filepath):
        error("Filepath cannot be a directory: %s" %  filepath)
    if not os.path.isfile(filepath):
        error("File not found: %s" %  filepath)

def get_ephemeral_port():
    """Return a random port number from the ephemeral range"""

    return random.randrange(49152, 65535)

def start_http_server_thread (dirname):
    """Spawn a thread with a standard http server in a specified directory"""

    # configure the http server
    resource = File(dirname)
    factory = Site(resource)

    for i in range (5):
        try:
            server_port = get_ephemeral_port()
            reactor.listenTCP(server_port, factory)
            break
        except:
            if i == 4:
                utility.error("couldn't grab a network port!")

    thread = Thread(target=reactor.run, kwargs={'installSignalHandlers':0})
    thread.daemon = True
    # start the server thread
    thread.start()

    return server_port

def start_http2_server_thread (dirname):
    """
    Spawn a thread with an http server in a specified directory.

    This server is uniquely created to receive HTTP PUT commands (for uploads
    from IOS).
    """

    # configure the http server
    resource = Server.FileServer(dirname)
    factory = Site(resource)

    for i in range (5):
        try:
            server_port = get_ephemeral_port()
            reactor.listenTCP(server_port, factory)
            break
        except:
            if i == 4:
                utility.error("couldn't grab a network port!")

    thread = Thread(target=reactor.run, kwargs={'installSignalHandlers':0})
    thread.daemon = True
    # start the server thread
    thread.start()

    return server_port

def start_ftp_server_thread (dirname, username="lab", password="lab"):
    """Spawn a thread with a standard http server in a specified directory"""

    # configure the ftp server
    p = Portal(FTPRealm(dirname),
               [AllowAnonymousAccess()])
    factory = FTPFactory(p)

    for i in range (5):
        try:
            server_port = get_ephemeral_port()
            reactor.listenTCP(server_port, factory)
            break
        except:
            if i == 4:
                utility.error("couldn't grab a network port!")

    thread = Thread(target=reactor.run, kwargs={'installSignalHandlers':0})
    thread.daemon = True
    # start the server thread
    thread.start()

    return server_port

def get_local_ip ():
    """Get the ip address of the local server"""

    return socket.gethostbyname(socket.gethostname())

def is_remote_path (filepath):
    """
    For the 'copy' command, determine whether the filepath is intended to
    be remote
    """

    if re.search("^[^/]*:.*", filepath):
        return True
    else:
        return False

def natural_sort(l):
    """ Sort the given list in the way that humans expect."""

    convert = lambda text: int(text) if text.isdigit() else text.lower()
    alphanum_key = lambda key: [ convert(c) for c in re.split('([0-9]+)', key) ]
    return sorted(l, key = alphanum_key)

def three_way_merge (before, after1, after2):
    """
    Three-way merge between 3 strings.

    before: the original state
    after1: the first modified version
    after2: the second modified version
    """

    try:
        # create tmp files
        before_f = NamedTemporaryFile()
        after1_f = NamedTemporaryFile()
        after2_f = NamedTemporaryFile()

        # write to tmp files
        before_f.write(before.encode())
        after1_f.write(after1.encode())
        after2_f.write(after2.encode())

        # flush the writes
        before_f.flush()
        after1_f.flush()
        after2_f.flush()

        command = ('merge -p %s %s %s' % (after1_f.name, before_f.name, after2_f.name))
        return subprocess.check_output(command.split(), stdin=subprocess.PIPE).decode()

    except Exception as e: error(e)
    finally:
        # close the tmp files
        before_f.close()
        after1_f.close()
        after2_f.close()

def get_parser_section_contents (parser, section):
    """
    Return the contents of a specific section in the config file.

    This function is used when editing device blocks from the config file.
    """

    ret = ""
    for name, value in parser.items(section):
        ret += "%s = " % name
        value_lines = value.split("\n")
        i = 0
        for line in value_lines:
            if i > 0:
                ret += "\t"
            ret += "%s\n" % line
            i += 1

    return ret

def time_function(f):
    def wrap(*args):
        time1 = time.time()
        ret = f(*args)
        time2 = time.time()
        print('%s function took %0.3f ms' % (f.__name__, (time2-time1)*1000.0))
        return ret
    return wrap

def get_last_time_occurence (hours=0, minutes=0):
    secs = (hours*3600 + minutes*60)

    # start with the current time
    t = time.time()
    # adjust for the timezone
    t -= time.altzone
    # adjust the time by the desired hour and minute (this will move
    # us into the correct day
    t -= secs
    # now we're in the correct day, go to 12am of that day
    t = (t // 86400) * 86400

    # now advance up to the desired time
    t += secs + time.altzone

    return t


def get_time_seconds (time_string):
    regex = r'(\d+)([a-zA-Z]*)'

    match = re.search(regex, time_string)
    if match:
        value = float(match.group(1))
        unit = match.group(2)
        if unit.lower() in ['s', 'sec', 'secs', 'second', 'seconds']:
            return value
        elif unit.lower() in ['m', 'min', 'mins', 'minute', 'minutes']:
            return value * 60
        elif unit.lower() in ['h', 'hr', 'hrs', 'hour', 'hours']:
            return value * 3600
        elif unit.lower() in ['d', 'day', 'days']:
            return value * 86400

    return None

def get_system_timezone ():
    command = 'timedatectl | grep -i "time zone"'
    (code, result) = getstatusoutput(command)
    result = result.split(":")[1].strip().split()[0]
    return result

tz_info = {
    'PST': gettz("America/Los Angeles"),
    'PDT': gettz("America/Los Angeles"),
    'MST': gettz("America/Phoenix"),
    'MDT': gettz("America/Denver"),
    "CST": gettz("America/Chicago"),
    "CDT": gettz("America/Chicago"),
    'EDT': gettz("America/New York"),
    'EST': gettz("America/New York")
}
def parse_time (string):
    return parser.parse(string, tzinfos=tz_info)

#
# Epoch/Datetime conversions
epoch = datetime.fromtimestamp(0, pytz.UTC)
def datetime_to_epoch (dt, local=False):
    if local:
        return int(time.mktime(dt.timetuple()))
    else:
        return int((dt - epoch).total_seconds())

def epoch_to_datetime (ts, local=False, aware=True):
    if local:
        return datetime.fromtimestamp(ts, timezone.get_default_timezone())
    elif aware:
        return datetime.fromtimestamp(ts, pytz.UTC)
    else:
        return datetime.fromtimestamp(ts)

#
# Datetime fns
def datetime_same_hour (dt1, dt2):
    try:
        return (datetime_to_hour(dt1) == datetime_to_hour(dt2))
    except:
        return None

def datetime_to_hour (dt, next=False):
    ret = dt.replace(minute=0, second=0, microsecond=0)
    if next and ret != dt:
        ret += timedelta(0, 3600)
    return ret

def datetime_to_day (dt, next=False):
    return dt.replace(hour=0, minute=0, second=0, microsecond=0)

#
# Epoch fns
def epoch_same_hour (ts1, ts2):
    try:
        return (epoch_to_hour(ts1) == epoch_to_hour(ts2))
    except:
        return None

def epoch_same_day (ts1, ts2):
    return (epoch_to_day(ts1) == epoch_to_day(ts2))

def epoch_to_hour (ts, next=False):
    ret = (ts//3600) * 3600
    if next and ret != ts:
        ret += 3600
    return ret

def epoch_to_day (ts, next=False):
    ret = (ts//86400) * 86400
    if next and ret != ts:
        ret += 86400
    return ret

def epoch_delta_str (ts1, ts2):
    """
    This function takes in a time string (sometime in the future),
    and returns the time delta between NOW and that time.
    (used to show time remaining on reservations)
    """

    WEEK = 604800
    DAY = 86400
    HOUR = 3600
    MINUTE = 60

    delta = ts2 - ts1

    weeks = delta / WEEK
    days = delta / DAY
    hours = delta / HOUR
    minutes = delta / MINUTE

    ret = ""
    if weeks >= 2:
        ret += "%.1f weeks" % weeks
    elif days >= 2:
        ret += "%.01f days" % days
    elif hours >= 1:
        ret += "%.1f hrs" % hours
    else:
        ret += "%.1f mins" % minutes

    return ret

def send_email (subject, message="", mailto=None):

    # find the destination address
    if not mailto:
        mailto = cfg.admin_email

    # remove whitespace
    mailto = re.sub(r'\s', '', mailto)
    if not mailto:
        log.error("Can't send email: Administrator email not configured", "config")
        return
    elif ',' in mailto:
        mailto = mailto.split(',')
    else:
        mailto = [mailto]

    mailfrom = "%s <root@%s.cisco.com>" % (cfg.tool_name, cfg.tool_name)
    # add the site name to the subject
    site_name = cfg.site_name
    if site_name:
        subject = "%s: %s" % (site_name, subject)

    # prepare the email
    msg = MIMEText(message, 'html')
    msg['Subject'] = subject
    msg['From'] = mailfrom
    msg['To'] = ",".join(mailto)

    # send the email
    s = smtplib.SMTP('localhost')
    s.sendmail(mailfrom, mailto, msg.as_string())
    s.quit()

def get_system_uuid ():
    """ return the system unique identifier """

    try:
        command = 'dmidecode -s system-uuid 2> /dev/null'
        result = subprocess.check_output(command.split())
    except:
        try:
            command = 'cat /sys/class/dmi/id/product_uuid'
            result = subprocess.check_output(command.split())
        except:
            log.exception("Could not get system UUID", "system")
            sys.exit(-1)

    return result.decode().strip()

def get_build_date ():
    # so we can do this from any directory
    git_args = "--git-dir=%s/.git --work-tree=%s/" % (cfg.proj_dir, cfg.proj_dir)

    # get the commit date
    command = "git %s show -s --format=%%ct" % git_args
    (code, result) = getstatusoutput(command)

    try:
        ret = int(result)
    except:
        ret = 0

    return ret

def daemon_query (query, port, buffer_size=2048):
    host, port = "localhost", port
    response = ""

    # Create a socket (SOCK_STREAM means a TCP socket)
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    try:
        # Connect to server and send data

        sock.connect((host, port))
        data = json.dumps(query) + '\n'
        sock.sendall(data.encode())

        # Receive data from the server and shut down

        while True:
            data = sock.recv(buffer_size).decode()
            response += data;
            if not data:
                break
    except socket.error:
        pass
    finally:
        sock.close()

    return response

def poller_query (query):
    return daemon_query(query, cfg.poller_server_port).strip()

def termserver_query (query):
    return daemon_query(query, cfg.termserver_port).strip()

def db_publish (channel, data):
    return db_query({
        'name': channel,
        'options': data
    })

def db_query (query):
    return daemon_query(query, cfg.db_server_port, buffer_size=8192).strip()

def val_counter (val, d):
    if val:
        if val not in d:
            d[val] = 1
        else:
            d[val] += 1

def lcm(numbers):
    """Return lowest common multiple."""
    def lcm(a, b):
        return (a * b) // gcd(a, b)

    return reduce(lcm, numbers, 1)

def flatten_helper (value, depth = None, entry_l = None, path = None):
    if entry_l is None: entry_l = []
    if path is None: path = []

    if depth == 0:
        entry_l.append((path, value))
        return
    elif isinstance(value, dict):
        iterator = value.items()
    elif isinstance(value, list):
        iterator = enumerate(value)
    else:
        entry_l.append((path, value))
        return

    if depth is not None:
        depth -= 1;

    for index, value in iterator:
        flatten_helper(value, depth, entry_l, path + [str(index)])

    return entry_l

def flatten (value, delimiter = " >> ", depth = None):
    entry_l = flatten_helper(value, depth = depth)
    return {delimiter.join(x):y for x,y in entry_l}

def convert_to_dictionary (list, key):
    return {x[key]:{y:z for y,z in x.items() if y != key} for x in list}

def filter_by_key (d, key_list, exclude = False):
    key_list = [x.lower() for x in key_list]
    if isinstance(d, dict):
        if exclude:
            d = {x:y for x,y in d.items() if x.lower() not in key_list}
        else:
            d = {x:y for x,y in d.items() if x.lower() in key_list}
    elif isinstance(d, list):
        new_d = []
        for z in d:
            if exclude:
                new_d.append({x:y for x,y in z.items() if x.lower() not in key_list})
            else:
                new_d.append({x:y for x,y in z.items() if x.lower() in key_list})
        d = new_d

    return d
