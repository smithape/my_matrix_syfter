import os
import time
from datetime import datetime
import requests, json
from threading import Thread, Lock
import queue

from .PeriodicThread import PeriodicThread
from . import DB
from . import logger as log
from . import utility
from . import config as cfg

class JSONStream (DB.DBObject):
    def __init__ (self):

        self.send_buffer = queue.Queue()
        self.send_buffer_lock = Lock()
        self.last_send = int(time.time())
        self.up = True

        self.auth = None
        if cfg.json_username and cfg.json_password:
            self.auth = (cfg.json_username, cfg.json_password)

        if not os.path.exists(cfg.json_dump_dir):
            os.makedirs(cfg.json_dump_dir)

        now = int(time.time())
        self.tstamp_d = {
            'send_dump': 0,
            'send_device_d': 0,
            'flush': now,
            'maintenance': now - cfg.maintenance_hour * 3600 - time.altzone,
            }


    def start (self):
        # Start the monitor thread
        self.monitor_t = PeriodicThread(name="monitor",
                                        interval=60,
                                        action=self.monitor,
                                        daemon=True)
        self.monitor_t.start(time.time() + 60)

    def stop (self):
        # stop the monitor thread
        if self.monitor_t:
            self.monitor_t.stop()

    def monitor (self):
        now = int(time.time())
        day = utility.epoch_to_day(now)
        local_hour = datetime.now().hour

        # send device data
        if now - self.tstamp_d['send_device_d'] >= 3600:
            self.send_device_d()
            self.tstamp_d['send_device_d'] = now

        # send dump
        if now - self.tstamp_d['send_dump'] >= 3600:
            self.send_dump()
            self.tstamp_d['send_dump'] = now

        # flush the send buffer
        if now - self.tstamp_d['flush'] >= 60:
            self.flush()
            self.tstamp_d['flush'] = now

        # maintenance
        last_day = utility.epoch_to_day(self.tstamp_d['maintenance'])
        if (local_hour == cfg.maintenance_hour and last_day != day):
            self.tstamp_d['maintenance'] = now
            if not self.up:
                utility.send_email("JSON destination is down!",
                                   message=("You should fix this, or disable JSON as a destination. "+
                                            "Data is being buffered locally, and could flood the disk."))


    def flush (self):
        buffer_l = list(self.send_buffer.queue)

        if buffer_l:

            data = {
                #'device': DB.db.device_d,
                'nugget': list(self.send_buffer.queue)
            }
            self.send_buffer.queue.clear()
            self.send_data(json.dumps(data))

    def send_device_d (self):

        data = {
            'device': DB.db.device_d
        }
        self.send_data(json.dumps(data))

    def send_data (self, data, dump=True):
        if data:
            try:
                r = requests.post(cfg.send_url,
                                  verify=False,
                                  auth=self.auth,
                                  data=data, timeout=cfg.json_push_timeout)
                if (r and r.status_code == 200):
                    self.up = True
                    return True
                else:
                    msg = "%s: %s" % (r.status_code, r.text)
                    log.error("JSON push failed: %s" % msg, "system")
            except Exception as e:
                log.error("JSON push error: %s" % e, "system")

            # push failed, dump the backup
            if dump:
                self.dump(data)

            self.up = False
            return False

    def dump (self, data):
        # find the filepath
        filepath_root = filepath = "%s/%s" % (cfg.json_dump_dir, int(time.time() * 1000))
        # make sure the filepath is unique
        i = 0
        while os.path.exists(filepath):
            filepath = "%s.%s" % (filepath_root, i)
            i += 1
        # write the dump
        with open (filepath, "w") as f:
            f.write(data)

    def create_sample (self, timestamp, device_name, nugget_name, value):
        if isinstance(value, str):
            _type = 'text'
        else:
            _type = 'metric'

        sample = {
            'type': _type,
            'timestamp': timestamp,
            'device': device_name,
            'nugget': nugget_name,
            'value': value
        }

        return sample

    def send_dump (self):
        # remove expired dumps
        now = int(time.time())
        for filename in sorted(os.listdir(cfg.json_dump_dir)):
            timestamp = int(filename.split('.')[0]) // 1000
            if timestamp < (now - cfg.json_dump_hold_days * 86400):
                filepath = os.path.join(cfg.json_dump_dir, filename)
                os.remove(filepath)
            else: break

        # send
        if self.up:
            for filename in os.listdir(cfg.json_dump_dir):
                filepath = os.path.join(cfg.json_dump_dir, filename)
                with open (filepath, "r") as f:
                    data = f.read()
                    success = self.send_data(data, dump=False)

                if success:
                    os.remove(filepath)
                else:
                    break

    def bulk_insert (self, sample_l):
        for timestamp, device_name, nugget_name, value in sample_l:
            e = self.create_sample(timestamp, device_name, nugget_name, value)
            self.send_buffer.put(e)

    def log_insert (self, log_tuple):
        timestamp, device_name, nugget_name, severity, log_type, message = log_tuple

        e = {
            'time': timestamp,
            'source': cfg.tool_name,
            'sourcetype': 'log',
            'index': self.get_index(device_name),
            'event': {
                'severity': log.sev_name[severity],
                'log_type': log.log_type_name[log_type],
                'message': message
            }
        }

        # add other parameters if they exists
        if cfg.splunk_site_name:
            e['event']['site'] = cfg.splunk_site_name
        if device_name:
            e['event']['device'] = device_name
        if nugget_name:
            e['event']['nugget'] = nugget_name

        self.send_buffer.put(e)

    def diff_insert (self, diff_tuple):
        timestamp, device_name, diff = diff_tuple

        e = {
            'time': timestamp,
            'source': cfg.tool_name,
            'sourcetype': 'diff',
            'index': self.get_index(device_name),
            'event': {
                'device': device_name,
                'diff': diff
            }
        }

        self.send_buffer.put(e)

    def nf_insert (self, field, timestamp, data_l):

        for entry in data_l:
            host = entry['device']

            # find the device name using the host ip
            try:
                device_name = DB.db.device_ip_d[host]['name']
            except KeyError:
                device_name = DB.db.add_to_device_list(host)

            e = {
                'time': timestamp,
                'source': cfg.tool_name,
                'sourcetype': 'netflow',
                'index': self.get_index(device_name),
                'event': {
                    field: entry[field],
                    'flows': entry['flows'],
                    'packets': entry['packets'],
                    'bytes': entry['bytes'],
                }
            }

            self.send_buffer.put(e)

    def syslog_insert (self, log_d):
        host = log_d['host']

        # find the device name using the host ip
        try:
            device_name = DB.db.device_ip_d[host]['name']
        except KeyError:
            device_name = DB.db.add_to_device_list(host)

        event_d = log_d.copy()
        del event_d['timestamp']
        del event_d['host']

        e = {
            'type': 'syslog',
            'timestamp': log_d['timestamp'],
            'event': event_d,
        }


        # add device and nugget if they exists
        if device_name:
            e['event']['device'] = device_name

        self.send_buffer.put(e)

    def send_report (self, report_d):
        e = {
            'time': int(time.time()),
            'source': cfg.tool_name,
            'sourcetype': 'report',
            #'index': 'main',
            'event': report_d
            }

        self.send_data(json.dumps(e))

    def client_report_insert (self, timestamp, client_l):
        for client in client_l:
            index = client.pop('db_index', None) or cfg.splunk_index
            e = {
                'time': timestamp,
                'source': cfg.tool_name,
                'sourcetype': 'cmx_client',
                'index': index,
                'event': {
                    'mac_address': client['mac_address'],
                    'vc': client['vc'],
                    'location': client['location'],
                    'presence': client['presence'],
                }
            }
            event_str = json.dumps(e)
            self.add_event(event_str)

    def query_series (self, start, end, device_name, nugget_name):
        """ not really used right now """
        kwargs_blockingsearch = {
            "earliest_time": start,
            "latest_time": end,
            "time_format": "%s",
            "output_mode": "json",
            "count": 0
        }
        searchquery_blocking = 'search source="matrix@KCR" device="%s" nugget=%s | fields _time, value' % (device_name, nugget_name)

        res = self.cn.jobs.oneshot(searchquery_blocking, **kwargs_blockingsearch)
        res = json.loads(res.read())['results']

        values = []
        for x in res:
            try:
                value = float(x['value'])
            except:
                value = None

            timestamp = utility.epoch_to_datetime(int(x['_time']))
            values.append((timestamp, value))

        return values
