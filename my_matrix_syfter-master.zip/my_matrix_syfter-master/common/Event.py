
import time
from collections import OrderedDict
import json
import pickle
from datetime import datetime, timedelta
from threading import Timer
import traceback

import numpy as np
import pandas as pd
from django.db.models import Q
from django.utils import timezone

from .models import \
    Event as Event_db, \
    State as State_db
from .PeriodicThread import PeriodicThread
from . import Report
from . import utility
from . import config as cfg
from . import logger as log
from . import DB
from nugget import Nugget

class EventDetector (object):
    def __init__(self, group, device):
        self.group = group
        self.device = device
        self.baseline_calc_t = None
        self.baseline_d = {}
        self.start_time = 0
        self.end_time = 0
        #self.autosave_t = None
        self.state = "off"

        # load any saved saved state
        self.load_state()

    # def start (self):
    #     # Start the baseline
    #     self.baseline_calc_t = PeriodicThread(name="baseline_calc",
    #                                         interval=cfg.baseline_period,
    #                                         action=self.set_baseline)
    #     self.baseline_calc_t.start()

    def save (self):
        # stop the autosave thread
        # if self.autosave_t:
        #     self.autosave_t.cancel()

        # save the state
        self.save_state()

        # # stop the baseline calc thread
        # if self.baseline_calc_t:
        #     self.baseline_calc_t.stop()

    def load_state (self):
        try:
            s = State_db.objects.get(name="eventDetector/%s" % self.group.name)
        except State_db.DoesNotExist: return

        state_d = pickle.loads(str(s.value))
        try:
            self.start_time = state_d['start_time']
            self.end_time = state_d['end_time']
            self.baseline_d = state_d['baseline_d']
            if (timezone.now() - s.timestamp).total_seconds() < 43200:
                self.state = state_d['state']
        except KeyError: pass

    def save_state (self):
        # prepare the dict for storage
        state_d = {
            'state': self.state,
            'start_time': self.start_time,
            'end_time': self.end_time,
            'baseline_d': self.baseline_d
            }

        db_row = {
            'timestamp': timezone.now(),
            'value': pickle.dumps(state_d)
            }

        s, created = State_db.objects.update_or_create(name="eventDetector/%s" % self.group.name,
                                                       defaults=db_row)


    def voteOn (self, nugget_d):
        """
        Determine whether the values contained in the nugget_d should be indicators
        of an event starting. The values in nugget_d will be compared to those in
        baseline_d to reach this conclusion
        """

        if not self.baseline_d: return 0

        score = 0
        for nugget_name, value in nugget_d.items():
            try:
                if value > self.baseline_d[nugget_name]:
                    score += 1
            except KeyError: continue

        return (score > 0)
        #return (score >= len(nugget_d)/2)

    def voteOn_str (self, nugget_d):
        """
        Determine whether the values contained in the nugget_d should be indicators
        of an event starting. The values in nugget_d will be compared to those in
        baseline_d to reach this conclusion
        """

        if not self.baseline_d: return 0

        score = []
        for nugget_name, value in nugget_d.items():
            try:
                if value > self.baseline_d[nugget_name]:
                    score.append("%s > %s" % (nugget_name, self.baseline_d[nugget_name]))
            except KeyError: continue

        return score

    def detect (self):
        start_holdtime = 3600 # in seconds
        end_holdtime = 3600 # in seconds
        time_buffer = 3600 # in seconds

        nugget_d = {}

        for nugget_name, nugget_entry in self.device.nugget_d.items():
            if 'ED' in nugget_entry.flags:
                nugget_d[nugget_name] = nugget_entry.prev_value

        # auto-detect events!
        timestamp = int(time.time())
        if self.state == "off":
            if self.voteOn(nugget_d):
                self.start_time = timestamp
                self.state = "starting"
                log.info("Event starting (%s)" % str(self.voteOn_str(nugget_d)), "system", device=self.group.device)
        elif self.state == "starting":
            if not self.voteOn(nugget_d):
                log.info("Event false start", "system", device=self.group.device)
                self.state = "off"
            elif (timestamp - self.start_time) >= start_holdtime:
                log.info("Event started", "system", device=self.group.device)
                #utility.send_email("Event Started")
                self.state = "on"
        elif self.state == "on":
            if not self.voteOn(nugget_d):
                self.end_time = timestamp
                self.state = "stopping"
        elif self.state == "stopping":
            if self.voteOn(nugget_d):
                self.state = "on"
            elif (timestamp - self.end_time) >= end_holdtime:
                log.info("Event ended", "system", device=self.group.device)
                event = create_event(self.start_time - time_buffer, timestamp, group=self.group.name, save=True)
                recipients = cfg.event_email
                try:
                    Report.send_report("Event Report", event, 'network', mailto=recipients)
                except Exception as e:
                    log.error("Report Failed: %s" % e, "system")
                self.state = "off"

    def set_baseline (self):
        #start_time = time.time() * 1000
        end = utility.epoch_to_hour(time.time())
        start = (end - cfg.baseline_lookback)

        # get the list of nuggets to use for event detection
        nugget_d = {}
        for dtype in Nugget.nugget_config:
            for nugget_name, nugget_entry in Nugget.nugget_config[dtype].items():
                if ('flags' in nugget_entry and
                    'ED' in nugget_entry['flags']):
                    nugget_d[nugget_name] = nugget_entry

        # query the DB for pertinent metrics in the last cfg.baseline_lookback
        # days
        filter_d = {
            'device': self.device.name,
            'nugget_list': list(nugget_d.keys())
            }
        data_d = DB.db.query_metric(start, end, filter_d)

        #start_process_time = time.time() * 1000

        for nugget_name, data in data_d.items():
            ds = DB.decodeSeries(data, start, end)
            ds = ds.round(decimals=1)
            median = ds.median()
            sd = ds.std()
            try:
                mode = ds.mode()[0]
            except IndexError: continue

            # set threshold as the sum of the mode and the configured offset
            self.baseline_d[nugget_name] = mode + nugget_d[nugget_name]['ed_offset']
            log.debug("%s: [%s] mode=%s, median=%s, sd=%s" % (self.group.name, nugget_name, mode, median, sd))

        # end_time = time.time() * 1000
        # if cfg.query_debug:
        #     log.debug("set baseline: query/process: %s/%s" % (
        #         int(start_process_time - start_time),
        #         int(end_time - start_process_time),
        #     ))


def get (event_id):
    try:
        event_db = Event_db.objects.get(pk=event_id)
        return pickle.loads(str(event_db.data))
    except Event_db.DoesNotExist:
        return None

def get_all ():
    columns = ['id', 'name', 'group', 'start_timestamp', 'end_timestamp']
    event_l = list(Event_db.objects.all().values(*columns))
    return event_l

def save_event (event):
    e, created = Event_db.objects.get_or_create(start_timestamp = event['start_timestamp'],
                                                end_timestamp = event['end_timestamp'],
                                                group = event['group'])
    # store the group
    e.group = event['group']
    # store the data
    e.data = pickle.dumps(event)
    # save to DB
    e.save()

    return {'id': e.id,
            'group': e.group,
            'name': e.name,
            'start_timestamp': e.start_timestamp,
            'end_timestamp': e.end_timestamp,
            'created': created
        }

def name_event (event_id, event_name):
    event = Event_db.objects.get(pk=event_id)
    event.name = event_name
    event.save()
    return event_id

def create_event (start, end, group=None, save=False):
    query = {
        'name' : "metric_summary",
        'options' : {
            "start": start,
            "end": end,
            "group": group
        }
    }
    event = json.loads(utility.db_query(query))
    if save:
        save_event(event)
    return event

def delete (event_id):
    try:
        Event_db.objects.get(pk=event_id).delete()
        return event_id
    except Event_db.DoesNotExist:
        log.error("can't find matching event to delete", "system")

def get_event_spans (start=None, end=None):
    if start and end:
        qs = Event_db.objects.filter(Q(start_timestamp__range=(start, end)) |
                                     Q(end_timestamp__range=(start, end)))
    elif end:
        qs = Event_db.objects.filter(start_timestamp__lt=end)
    else:
        qs = Event_db.objects.all()

    values = qs.values_list("start_timestamp", "end_timestamp")
    values = sorted(values, key=lambda x: x[0])

    return values

def get_oldest_event ():
    qs = Event_db.objects.all()
    values = list(qs.values_list("start_timestamp"))
    values = sorted([x[0] for x in values])
    oldest = None
    try:
        oldest = Event_db.objects.get(start_timestamp=values[0])
    except IndexError: pass
    return oldest
