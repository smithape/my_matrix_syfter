import sys
import json
import multiprocessing
import subprocess
import traceback

from django.shortcuts import render, redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.decorators import user_passes_test
from django.urls import reverse
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.db import ProgrammingError
import psutil

from . import config as cfg
from . import DB
from . import utility
from . import logger as log
from . import License as lic

if "gunicorn" in sys.argv[0] or 'runserver' in sys.argv[1]:
    # initialize the logger
    log.init("server.log")
    # initialize the config
    cfg.init_config()
    # initialize the database
    DB.init()

@login_required
def index (request):
    # re-initialize
    cfg.init_config()

    if lic.is_licensed():
        return render(request, 'index.html',
                      {'site_name': cfg.site_name,
                       'standalone': request.GET.get('standalone'),
                       'config_errors': cfg.get_global('config_errors')})
    else:
        logout(request)
        return redirect(license_view)

def license_view (request):
    if request.method == 'GET':
        valid = lic.check_key()
        license_info = lic.get_license_info()
        if license_info:
            # show the license info page
            return render(request, 'license_info.html', {
                    'site_name': cfg.site_name,
                    'valid': valid,
                    'license_name': license_info['license_name'],
                    'license_user': license_info['license_user'],
                    'exp_date': license_info['exp_date']
                    })
        else:
            failed = False
            try:
                failed = request.GET['failed']
            except KeyError: pass

            print(failed)
            # show the registration page
            return render(request, 'license.html', {
                'site_name': cfg.site_name,
                'failed': failed,
                })
    else:
        if 'unregister' in request.POST:
            lic.unregister()
        else:
            site_name = request.POST['site_name'].strip()
            key = request.POST['key'].strip()
            if not lic.register(site_name, key):
                redirect(license_view)
                url = request.META['QUERY_STRING'].replace('failed=True', '')+'failed=True'
                return redirect('/license?'+url)

        return redirect(license_view)

def logout_view (request):
    logout(request)
    return redirect('index')

def login_view(request):
    if request.method == 'GET':
        invalid = False
        if ('invalid' in request.GET and
            request.GET['invalid'] == 'True'):
            invalid = True

        if not lic.is_licensed():
            return redirect(license_view)

        # show the login page
        return render(request, 'login.html',
                      {'site_name': cfg.site_name,
                       'invalid': invalid,
                       'site_name': cfg.site_name})

    else:
        if 'username' in request.POST and 'password' in request.POST:
            # Login attempt
            username = request.POST['username']
            password = request.POST['password']

            user = authenticate(username=username, password=password)

            if user is not None and user.is_active:
                login(request, user)
                # Redirect to a success page.
                return redirect(request.GET['next'])

            # Return an 'invalid login' error message.
            url = request.META['QUERY_STRING'].replace('&invalid=True', '')+'&invalid=True'
            login_url = reverse('login_view')
            return redirect('%s?%s' % (login_url, url))

@user_passes_test(lambda u: u.is_staff)
def terminal (request, device_name):
    return render(request, 'terminal.html', {'site_name': cfg.site_name,
                                             'device_name' : device_name})

@user_passes_test(lambda u: u.is_staff)
def nugget_manager (request, device_name=None):
    return render(request, 'nugget_manager.html', {'site_name': cfg.site_name})

@user_passes_test(lambda u: u.is_staff)
def websocket_test (request):
    return render(request, 'websocket_test.html', {'site_name': cfg.site_name})
