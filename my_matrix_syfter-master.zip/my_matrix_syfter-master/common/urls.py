from django.urls import path

from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('login/', views.login_view, name='login_view'),
    path('logout/', views.logout_view, name='logout_view'),
    path('license/', views.license_view, name='license_view'),
    path('term/<str:device_name>/', views.terminal, name='term'),
    path('websocket_test/', views.websocket_test, name='websocket_test'),
    path('nugget_manager/', views.nugget_manager, name='nugget_manager'),
    path('nugget_manager/<str:device_name>/', views.nugget_manager, name='nugget_manager'),
]
