from xml.sax.saxutils import escape, unescape
from collections import OrderedDict
import traceback
import json

import numpy as np
from django.utils import timezone

from . import \
    utility, \
    config as cfg, \
    logger as log, \
    DB

from .ReportTXT import report_txt
from .ReportHTML import report_html

report_cfg_d = {
    'admin' : ['conditions', 'device_issues', 'syslogs'],
    'network' : ['throughput', 'clientCount', 'visitors', 'zero_clients', 'device_issues']
}

# def series_summary (start, end, device_name, nugget_name):
#     query = {
#             'name' : "series_summary",
#             'options' : {
#                 "start": start,
#                 "end": end,
#                 "device": device_name,
#                 "nugget": nugget_name
#             }
#         }

#     return json.loads(utility.db_query(query))

def get_throughput_d (report_d, data):
    start = report_d['start']
    end = report_d['end']
    group = report_d['group']

    delta = end - start
    tput_d = {}

    try:
        tput_cfg = cfg.get_polling_cfg("global", "throughput")
        device, nugget = tput_cfg.split('/', 1)
    except Exception:
        device = "*AP_Sum"
        nugget = "ethThroughput"

    #
    # get the throughput summary values
    try:
        for child in ['rx', 'tx']:
            # find the child name
            if ':' in nugget:
                prefix, suffix = nugget.rsplit(':', 1)
                nugget_name = "%s_%s:%s" % (prefix, child.upper(), suffix)
            else:
                nugget_name = "%s_%s" % (nugget, child.upper())

            # levy: we no longer go to the DB
            # min, max, avg = series_summary(start, end,
            #                                device,
            #                                nugget_name)

            d = data['device_d'][device]['nugget_d'][nugget_name]

            tput_d[child] = {}
            # aggregate throughput (in GB)
            tput_d[child]['total'] = (d['avg'] * delta)/(8*1000)
            tput_d[child]['peak'] = d['max']
    except (KeyError, TypeError): pass

    if tput_d:
        report_d['throughput'] = tput_d

def get_clientCount_d (report_d, data):
    start = report_d['start']
    end = report_d['end']
    group = report_d['group']

    clientCount_d = {}

    #
    # clientCount
    if group:
        device = "*%s_Sum" % group
        nugget = "clientCount"
    else:
        try:
            config = cfg.get_polling_cfg("global", "clientCount")
            device, nugget = config.split('/', 1)
        except Exception:
            device = "*AP_Sum"
            nugget = "clientCount"

    try:
        for child in ['total', '2.4GHz', '5GHz']:
            if child != 'total':
                nugget_name = "%s_%s" % (nugget, child)
            else:
                nugget_name = nugget
            # levy: we no longer go to the DB
            # min, max, avg = series_summary(start, end, device, nugget_name)
            d = data['device_d'][device]['nugget_d'][nugget_name]
            clientCount_d[child + '_peak'] = d['max']
    except (TypeError, KeyError): pass

    #
    # clientCount_probing
    try:
        config = cfg.get_polling_cfg("global", "clientCount_probing")
        device, nugget = config.split('/', 1)
    except Exception:
        device = "MSE"
        nugget = "clientCount_probing"
    try:
        #min, max, avg = series_summary(start, end, device, nugget)
        d = data['device_d'][device]['nugget_d'][nugget]
        clientCount_d['probing_peak'] = d['max']
    except KeyError: pass
    except TypeError: pass

    if clientCount_d:
        report_d['clientCount'] = clientCount_d

def get_visitors_d (report_d):
    visitors_d = {}
    mse = None

    # try the first MSE
    for device in cfg.devices(dtype="CiscoMSE").values():
        mse = device
        break

    if mse:
        ret = mse.get_visitors()

        if ret:
            visitors_d['new'] = ret['newVisitors']
            visitors_d['repeat'] = ret['repeatVisitors']
            visitors_d['total'] = ret['visitors']

    if visitors_d:
        report_d['visitors'] = visitors_d

def get_device_issues_d_sort_helper(x, sev_name):
    if sev_name in x:
        return x[sev_name]
    else:
        return 0

def get_device_issues_d (report_d):
    start = report_d['start']
    end = report_d['end']
    group = report_d['group']

    #
    # get the system logs
    columns = ['device', 'severity']
    log_type = log.log_type_id['device']
    sev_id = log.sev_id['warning']
    values = DB.db.query_logs(start, end, columns, type=log_type,
                              sev_gte=sev_id, group=group)
    data_d = {}
    sev_id_l = set()
    for device_id, sev_id in values:
        device_name = DB.db.get_device(id=device_id).name
        sev_name = log.sev_name[sev_id]
        sev_id_l.add(sev_id)
        try:
            data_d[device_name][sev_name] += 1
        except KeyError:
            if device_name not in data_d:
                data_d[device_name] = {sev_name: 1}
            else:
                data_d[device_name][sev_name] = 1

    if data_d:
        # sort the dictionary once per severity
        for sev_id in sorted(sev_id_l):
            sev_name = log.sev_name[sev_id]
            data_d = OrderedDict(
                sorted(data_d.items(), key=lambda x:
                       get_device_issues_d_sort_helper(x[1], sev_name),
                       reverse=True)
                )

        report_d['device_issues'] = {
            'data': data_d,
            'sev_id_l': sorted(sev_id_l)
            }

def get_conditions (_type, min_severity, group):

    query = {
        'name' : "conditions",
        'options' : {
            'type' : _type,
            'min_severity' : min_severity,
            'group': group
            }
        }

    return utility.poller_query(query)

def get_condition_l (report_d):

    try:
        condition_d = get_conditions("config", log.sev_id['warning'], report_d['group'])
        condition_d = json.loads(condition_d)
    except ValueError: return

    if condition_d:
        report_d['conditions'] = condition_d

def get_syslog_l (report_d):
    start = report_d['start']
    end = report_d['end']
    group = report_d['group']

    logs = []

    #
    # get the system logs
    columns = ['timestamp', 'severity', 'message']
    log_type = log.log_type_id['system']
    sev_id = log.sev_id['warning']
    values = DB.db.query_logs(start, end, columns, type=log_type, device_name=False,
                              sev_gte=sev_id, group=group)
    for timestamp, sev_id, message in values:
        timestamp_local = timezone.localtime(timestamp)
        timestamp_str = timestamp_local.strftime('%X')
        sev_str = log.sev_name[sev_id]
        logs.append([timestamp_str, sev_str, message])

    if logs:
        report_d['syslogs'] = logs

def get_zero_clients (report_d, data):
    start = report_d['start']
    end = report_d['end']
    devices_d = data['device_d']
    zero_d = {
        'total' : [],
        '2.4GHz' : [],
        '5GHz' : []
        }
    for device_name, device_d in devices_d.items():
        if device_d['type'] == "CiscoAP":
            nugget_d = device_d['nugget_d']
            try:
                if nugget_d['clientCount']['max'] == 0:
                    zero_d['total'].append(device_name)
                elif nugget_d['clientCount_2.4GHz']['max'] == 0:
                    zero_d['2.4GHz'].append(device_name)
                elif nugget_d['clientCount_5GHz']['max'] == 0:
                    zero_d['5GHz'].append(device_name)
            except KeyError:
                log.debug("device has no clientCount nugget: %s" % device_name)

    report_d['zero_clients'] = zero_d

def get_report_d (data):
    report_d = {'start': data['start_timestamp'],
                'end': data['end_timestamp'],
                'group': data['group']}

    # process categories
    get_throughput_d(report_d, data)
    get_clientCount_d(report_d, data)
    get_visitors_d(report_d)
    get_condition_l(report_d)
    get_syslog_l(report_d)
    get_device_issues_d(report_d)
    get_zero_clients(report_d, data)

    return report_d

def send_report (name, data, report_name, fmt="text", mailto=None):

    report_d = get_report_d(data)
    if report_d:
        report_cfg = report_cfg_d[report_name]
        if fmt == "text":
            text = report_txt(report_d, report_cfg)
            text = '<PRE style="font-size:medium">' + text + '</PRE>'
        elif fmt == "html":
            text = report_html(report_d, report_cfg)

        # don't send the syslogs to the DB report
        if 'syslogs' in report_d:
            del report_d['syslogs']

        # store in DB
        DB.db.send_report(report_d)

        # email
        if mailto:
            utility.send_email(name, text, mailto=mailto)
