import time
import json
from elasticsearch import Elasticsearch, helpers

from . import DB
from . import logger as log
from . import utility
from . import config as cfg

class ElasticSearch (DB.DBObject):
    def __init__ (self):
        # initialize the connection
        self.es = Elasticsearch([cfg.es_host])

        # for initializing the data schema
        mappings = {
            "sample" : {
                "properties" : {
                    'timestamp' : {"type" : "date"},
                    'device': {"type": "integer"},
                    'nugget': {"type": "integer"},
                    'value': {"type": "short"}
                }
            }
        }

        index = {
            "mappings" : mappings
            }

        #self.es.indices.delete(index="metric")
        #self.es.indices.create(index="metric", body=index)

        #self.es.indices.put_mapping(index="metric", doc_type="sample", body=mappings)

    def create_sample (self, timestamp, device_name, nugget_name, value):
        # find the device/nugget DB objects
        nugget_id = DB.db.get_nugget(name=nugget_name).id
        device_id = DB.db.get_device(name=device_name).id

        return {
            '_index': 'metric',
            '_type': "sample",
            '_source': {
                'timestamp': timestamp,
                'device': device_id,
                'nugget': nugget_id,
                'value': value
                }
            }

    def send_data (self, sample_l):
        try:
            helpers.bulk(self.es, sample_l)
        except Exception as e:
            log.debug(e)

    def bulk_insert (self, sample_l):

        es_sample_l = []
        for timestamp, device_name, nugget_name, value in sample_l:
            s = self.create_sample(timestamp, device_name, nugget_name, value)
            es_sample_l.append(s)

        self.send_data(es_sample_l)

    def query_series (self, start, end, device_name, nugget_name):
        # find the device/nugget DB objects
        nugget_id = DB.db.get_nugget(name=nugget_name).id
        device_id = DB.db.get_device(name=device_name).id

        query = {
            'filter': {
                'bool': {
                    'must': [
                        {'range': {
                            'timestamp': {
                                'gte': start,
                                'lt': end
                            }
                        }},
                        {'term': {'device': device_id}},
                        {'term': {'nugget': nugget_id}}
                    ]
                },
            }
        }

        res = self.es.search(index="metric", doc_type="sample", body=query, _source=['timestamp', 'value'],
                             track_scores=False, explain=False, size=4096)

        values = []
        for hit in res['hits']['hits']:
            value = hit['_source']['value']
            timestamp = utility.epoch_to_datetime(hit['_source']['timestamp'])
            values.append((timestamp, value))

        return values

def test ():
    es = Elasticsearch(['10.162.248.63'])
    # es_sample_l = []
    # for i in xrange(10):
    #     s = create_sample(int(time.time()), "levydev", "levikpi", i)
    #     es_sample_l.append(s)

    #send_data(es_sample_l)

    search_doc = {
        "query": {
            "match_all": {}
            }
    }
    res = es.search(index="metric", doc_type="sample", body=search_doc)

    for hit in res['hits']['hits']:
        print(hit["_source"])

