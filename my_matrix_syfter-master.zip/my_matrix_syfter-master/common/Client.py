
import re, time
import json
from django.utils import timezone

from .models import State as State_db
from . import utility
from . import logger as log
from . import config as cfg
from . import DB

class ClientManager(object):

    def __init__ (self, poller):
        self.poller = poller
        self.client_d = {}

    def json_client_d (self):
        return {mac_addr:client.__dict__ for mac_addr, client in self.client_d.items()}

    def restore_state (self):
        now = int(time.time())
        try:
            s = State_db.objects.get(name="client_data")
            client_d = json.loads(s.data) or {}
            for mac_address, client in client_d.items():
                self.client_d[mac_address] = Client(mac_address, client)

            self.purge()
        except (TypeError, State_db.DoesNotExist) as e:
            pass

    def save_state (self):
        db_row = {
            'timestamp': timezone.now(),
            'data': json.dumps(self.json_client_d())
        }
        s, created = State_db.objects.update_or_create(name="client_data", defaults=db_row)

    def monitor (self):
        if cfg.client_monitor_vc:
            self.monitor_vc()

        if cfg.client_monitor_location:
            self.monitor_location()

        if cfg.client_monitor_presence:
            self.monitor_presence()

        self.purge()

        for client in self.client_d.values():
            client.set_group()

    def monitor_vc (self):
        end = int(time.time())
        start = end - cfg.client_monitor_period

        mse_d = {x:y for x,y in cfg.devices(dtype="CiscoMSE").items()
                 if 'cmx' in y.modules}

        for mse_name, mse in mse_d.items():
            client_l = mse.get_clientVCDetails(start, end)
            for client in client_l:
                mac_address = client['macAddress']
                if mac_address not in self.client_d:
                    c = self.client_d[mac_address] = Client(mac_address)
                else:
                    c = self.client_d[mac_address]

                # store the parameters
                c.db_index = mse.db_index
                c.from_VCData(client)

            if client_l: break

    def monitor_location (self):
        now = int(time.time())

        mse_d = {x:y for x,y in cfg.devices(dtype="CiscoMSE").items()
                 if 'location' in y.modules}

        for mse_name, mse in mse_d.items():
            client_l = mse.get_clientLocationDetails()
            for client in client_l:
                mac_address = client['macAddress']
                if mac_address not in self.client_d:
                    c = self.client_d[mac_address] = Client(mac_address)
                else:
                    c = self.client_d[mac_address]

                # store the parameters
                c.db_index = mse.db_index
                c.from_LocationData(client)

            if client_l: break

    def monitor_presence (self):
        now = int(time.time())

        mse_d = {x:y for x,y in cfg.devices(dtype="CiscoMSE").items()
                 if 'presence' in y.modules}

        for mse_name, mse in mse_d.items():
            client_l = mse.get_clientPresenceDetails()
            err_count = 0
            for client in client_l:
                mac_address = client['macAddress']
                if mac_address not in self.client_d:
                    c = self.client_d[mac_address] = Client(mac_address)
                else:
                    c = self.client_d[mac_address]

                # store the parameters
                c.db_index = mse.db_index
                try:
                    c.from_PresenceData(client)
                except Exception as e:
                    err_count += 1

            log.error("from_PresenceData error: %s" % err_count, "system")

            if client_l: break

    def purge (self):
        now = int(time.time())
        self.client_d = {mac:client for mac,client in self.client_d.items()
                         if max(client.last_login_time, client.last_located_time) >= (now - cfg.client_hold_hrs * 3600)}

    def report (self, start, end):
        client_l = []
        log.debug("full client_l: %s" % len(self.client_d))
        for mac_address, client in self.client_d.items():
            if start <= client.last_login_time <= end or start <= client.last_located_time <= end:
                client_l.append(client.for_splunk())

        if client_l:
            log.debug("trimmed client_l: %s" % len(client_l))
            query = {
                'name' : "client_report",
                'options' : {
                    "timestamp": start,
                    "client_l": client_l
                }
            }
            utility.db_query(query)
            #DB.db.send_client_report(client_l, start)

class Client(object):

    def __init__ (self, mac_address, d=None):
        self.mac_address = mac_address
        self.ip_address = None
        self.location = None
        self.group = None
        self.db_index = ''
        # VC params
        self.vc_data = {}
        self.device_type = None
        self.os = None
        self.carrier = None
        self.state = None
        self.last_login_time = None
        self.state = None
        # location params
        self.location_data = {}
        self.manufacturer = None
        self.ssid = None
        self.rf_band = None
        self.dot11_status = None
        self.last_located_time = None
        # presence params
        self.presence_data = {}

        if d:
            self.from_dict(d)

    def __repr__ (self):
        ret = {self.mac_address: self.__dict__}
        return json.dumps(ret, sort_keys=True, indent=4)

    def for_splunk (self):
        return {
            'mac_address' : self.mac_address,
            'vc': self.vc_data,
            'location': self.location_data,
            'presence': self.presence_data,
            'db_index' : self.db_index,
            }

    def as_dict (self):
        d = {
            'mac_address': self.mac_address,
            'ip_address': self.ip_address,
            'group': self.group,
            'ssid': self.ssid
            }

        return d

    def from_dict (self, d):
        for key, value in d.items():
            setattr(self, key, value)

    def set_group (self):
        for group_name, group in cfg.group_d.items():
            if group.parent is None and group.contains_client(self):
                self.group = group.name
                if group.db_index:
                    self.db_index = group.db_index
                break

    def from_VCData (self, client):
        try:
            self.vc_data = client
            self.device_type = client['device']
            self.last_login_time = client.pop('last_login_time', None)
            self.os = client['operatingSystem']
            self.state = client['state']
            self.location = client['location/Site']
        except KeyError as e:
            log.error("Parameter missing from VC Data: %s" % e, "system")

        try:
            self.carrier = client['Carrier']
        except KeyError: pass

    def from_LocationData (self, client):
        self.manufacturer = client['manufacturer']
        self.ssid = client['ssId']
        self.rf_band = client['band']
        self.dot11_status = client['dot11Status']
        if client['ipAddress']:
            self.ip_address = client['ipAddress'][0]
        self.last_located_time = int(time.time())

        # populate the raw loccation_data
        params = ['manufacturer',
                  'bytesReceived',
                  'bytesSent',
                  'apMacAddress',
                  'band',
                  'dot11Status',
                  'ipAddress',
                  'ssId']

        for param in params:
            if client[param] is not None:
                self.location_data[param] = client[param]

        self.location_data['lastLocatedTime'] = client['statistics']['lastLocatedTime']
        self.location_data['firstLocatedTime'] = client['statistics']['firstLocatedTime']

    def from_PresenceData (self, client):
        self.ip_address = client['ipv4Address']
        self.ssid = client['ssid']
        self.location = client['currentSiteName']
        self.last_located_time = int(time.time())

        # populate the raw loccation_data
        params = ['status',
                  'changedOn',
                  'changedOnTimeStamp',
                  'bytesReceived',
                  'bytesSent',
                  'lastApMacAddress',
                  'currentApMacAddress',
                  'lastApName',
                  'currentApName',
                  'lastSiteName',
                  'currentSiteName',
                  'lastSiteId',
                  'currentSiteId',
                  'ipv4Address',
                  'ipv6Address',
                  'rssi',
                  'ssid']

        for param in params:
            if client[param] is not None:
                self.presence_data[param] = client[param]

