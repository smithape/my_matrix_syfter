from twisted.web.resource import Resource

#
# This class is NOT part of the LDM web interface.
# it is used for the 'ldm copy' command
#
class FileServer(Resource):
    """Wait for a put request and write its content to a file"""

    isLeaf = True

    def __init__(self, dirname):
        self.dirname = dirname
        Resource.__init__(self)

    def render_PUT(self, request):
        #levy DEBUG
        #for key, val in request.args.items():
        #    print("%s = %s" % (key, val))

        # TODO: can you pass a number into read and
        # just read a bit at a time?
        data = request.content.read() #getvalue()
        filepath = self.dirname + request.uri

        try:
            f = open(filepath, 'w')
            f.write(data)
        except IOError as e:
            print(e)
            return

        return "success"
