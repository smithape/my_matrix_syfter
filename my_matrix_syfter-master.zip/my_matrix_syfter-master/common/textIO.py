
#
# Output
#
def print_table (table):
    """
    Print a correctly indented (column-aligned) table.

    Args:
      table - should be a list of lines, where each line is a list of entries
              (columns) for that line
    """

    # determine the number of lines and columns
    num_lines = len(table)
    num_cols = 0
    for line in table:
        val = len(line)
        if num_cols < val:
            num_cols = val

    # determine the size of the indents
    indents = []
    for x in range(num_cols):
        indents.insert(x,0)
    for line in table:
        i = 0
        for column in line:
            val = len(column)
            if val > indents[i]:
                indents[i] = val
            i += 1
    for x in range(num_cols):
        indents[x] += 4

    output = ""
    for line in table:
        for (column, indent) in zip(line, indents):
            output += column.ljust(indent)
        output += "\n"

    return output

def indent (string, level):
    ret = ''
    for line in string.splitlines():
        ret += "%s%s\n" % (" "*level, line)
    return ret

def prompt (string):
    """Prompt the user with a yes/no question"""

    answer = input(string + " [y/n]: ")

    if answer.lower() == 'y':
        return True
    elif answer.lower() == 'n':
        return False
    else:
        return prompt(string)

HEADER = '\033[95m'
OKBLUE = '\033[94m'
OKGREEN = '\033[92m'
WARNING = '\033[93m'
FAIL = '\033[91m'
ENDC = '\033[0m'
BOLD = '\033[1m'
UNDERLINE = '\033[4m'

def warning (string):
    return("%s%s%s" % (WARNING, string, ENDC))
def error (string):
    return("%s%s%s" % (FAIL, string, ENDC))
def fail (string):
    return("%s%s%s" % (FAIL, string, ENDC))
def success (string):
    return("%s%s%s" % (OKGREEN, string, ENDC))
