import os, sys
import logging
import socket
import time
from datetime import datetime
from queue import Queue
import threading

from django.utils import timezone

from . import utility
from . import config as cfg
from . import DB

log_file = None
logger = None # should this go in utility?
log_q = Queue()
fh = None
signal = False
raise_exceptions = False

# log severity mappings
sev_id = {
    "critical": 50,
    "crit": 50,
    "error": 40,
    "warning": 30,
    "warn": 30,
    "info" : 20,
    "debug" : 10
}
sev_name = {
    50: "critical",
    40: "error",
    30: "warning",
    20: "info",
    10: "debug"
}

# log type mappings
log_type_name = {
    0: "config",
    1: "system",
    2: "device",
    3: "nugget",
}
log_type_id = {
    "cfg": 0,
    "config": 0,
    "sys": 1,
    "system": 1,
    "dev": 2,
    "device": 2,
    "nugget": 3,
}

def init (filename, debug_lvl="critical"):
    global logger, fh

    debug_lvl = eval("logging." + debug_lvl.upper())

    # init the log directory
    log_dir = cfg.get_global("log_dir", default=cfg.log_dir)
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    log_file = "%s/%s" % (log_dir, filename)

    # create logger
    logger = logging.getLogger("main")
    logger.setLevel(logging.DEBUG)
    logger.propagate = False

    # create formatter
    fmt = logging.Formatter(fmt = "%(asctime)s\t%(levelname)s/%(module)s\t%(message)s",
                            datefmt = "%Y-%m-%d_%H:%M:%S")

    #
    # create file handler
    fh = logging.handlers.RotatingFileHandler(log_file,
                                              maxBytes=100*1024,
                                              backupCount=5)
    # set log level
    fh.setLevel(logging.DEBUG)
    # add formatter to handler
    fh.setFormatter(fmt)
    # add handler to logger
    logger.addHandler(fh)


    #
    # create console handler
    ch = logging.StreamHandler()
    # set log level
    ch.setLevel(debug_lvl)
    # add handler to logger
    logger.addHandler(ch)

def start():
    """
    Use this thread to store to the database SO THAT we're logging
    from a single thread.
    """
    t = threading.Thread(name="logger queue", target=store_q)
    t.daemon = True
    t.start()

def stop():
    global signal
    signal = True

def store_q ():
    "Watch the log_q and save incomming logs to the DB."
    while not signal:
        log_data = log_q.get()
        if sys.argv[0] == "db":
            DB.db.log_insert(log_data)
        else:
            query = {
                'name' : "log_insert",
                'options' : {
                    "log_data": log_data
                }
            }
            utility.db_query(query)

def log (message, log_type, severity, device=None, nugget_name=None):
    timestamp = int(time.time())

    device_name = None
    if device:
        if isinstance(device, str):
            device_name = device
        else:
            device_name = device.name
        # check whether the device is being suppressed
        if device_name in cfg.suppress_logs:
            return

    # find the type id if needed
    if not isinstance(log_type, int):
        log_type=log_type_id[log_type]

    # find the severity id if needed
    if not isinstance(severity, int):
        severity=sev_id[severity]

    l = (timestamp, device_name, nugget_name, severity, log_type, message)

    # Queue the log
    if threading.current_thread().name == "MainThread":
        DB.db.log_insert(l)
    else:
        log_q.put(l)

def debug (message, device=None, nugget_name=None):
    logger.debug(message)

def info (message, log_type, device=None, nugget_name=None):
    log(message, log_type, "info", device=device, nugget_name=nugget_name)

    if not device:
        logger.info(message)

def warning (message, log_type, device=None, nugget_name=None):
    log(message, log_type, "warning", device=device, nugget_name=nugget_name)

    if not device:
        logger.warning(message)

def error (message, log_type, device=None, nugget_name=None):
    log(message, log_type, "error", device=device, nugget_name=nugget_name)
    if not device:
        logger.error(message)

def critical (message, log_type, device=None, nugget_name=None):
    log(message, log_type, "critical", device=device, nugget_name=nugget_name)
    if not device:
        logger.critical(message)

def exception (message, log_type, device=None, nugget_name=None):
    if raise_exceptions:
        # Raise the exception for situations where we aren't using the logger
        # (ie. for anything other than the poller I think). I don't think device
        # info needs to be included here
        if nugget_name:
            message += " [nugget: %s]" % nugget_name

        raise Exception(message)

    log(message, log_type, "critical", device=device, nugget_name=nugget_name)
    if not device:
        logger.exception(message)
