"""
Here, we override the FTPRealm class from twisted in order to allow
anonymous users to have write priviledges to the FTP server.
"""

from twisted.protocols.ftp import BaseFTPRealm, IFTPShell, FTPShell

class FTPRealm(BaseFTPRealm):

    def requestAvatar(self, avatarId, mind, *interfaces):
        for iface in interfaces:
            if iface is IFTPShell:
                avatar = FTPShell(self.anonymousRoot)
                return (IFTPShell, avatar,
                        getattr(avatar, 'logout', lambda: None))
        raise NotImplementedError(
            "Only IFTPShell interface is supported by this realm")
