from django.db.models import fields

class SmallFloatField(fields.FloatField):

    def db_type(self, connection):
        engine = connection.settings_dict['ENGINE']

        if engine == 'django.db.backends.postgresql_psycopg2':
            return "REAL"
        else:
            return super(SmallFloatField, self).db_type(connection)

class BigAutoField(fields.AutoField):

    def db_type(self, connection):
        engine = connection.settings_dict['ENGINE']

        if engine == 'django.db.backends.mysql':
            return "bigint AUTO_INCREMENT"
        elif engine == 'django.db.backends.oracle':
            return "NUMBER(19)"
        elif engine == 'django.db.backends.postgresql_psycopg2':
            return "bigserial"
        elif engine == 'django.db.backends.sqlite3':
            return super(BigAutoField, self).db_type(connection)
        else:
            raise NotImplemented

    def get_internal_type(self):
        return 'BigAutoField'

    def to_python(self, value):
        if value is None:
            return value
        try:
            return int(value)
        except (TypeError, ValueError):
            raise exceptions.ValidationError(
                _("This value must be a long integer."))
