import time
import json
import requests
import urllib3
urllib3.disable_warnings()
import pickle
from django.utils import timezone
from django.contrib.sessions.models import Session

from . import config as cfg
from . import utility
from .models import \
    State as State_db

def register (site_name, key):
    if not cfg.license_server:
        return False

    reg_d = {
        'site_name': site_name,
        'sys_id': utility.get_system_uuid(),
        'license_key': key
        }
    url = "https://%s/api/register" % (cfg.license_server)

    try:
        r = requests.post(url, data=reg_d, timeout=1, verify=False, proxies=proxy())
    except (requests.exceptions.InvalidURL, requests.exceptions.ConnectionError) as e:
        print(e)
        return False

    if r.ok:
        site_id = r.json()['site_id']
        key = r.json()['key']
        set_license_key(site_id, key)
        license_name = r.json()['license_name']
        license_user = r.json()['license_user']
        exp_date = r.json()['exp_date']
        set_license_info(license_name, license_user, exp_date)
        return True

    return False

def unregister ():
    try:
        site_id, key = get_key()
    except TypeError:
        return False

    url = "https://%s/api/unregister/%s/%s/%s" % (cfg.license_server, site_id,
                                                  utility.get_system_uuid(), key)
    r = None
    try:
        r = requests.post(url, timeout=1, verify=False, proxies=proxy())
    except (requests.exceptions.InvalidURL, requests.exceptions.ConnectionError) as e:
        return False

    # remove license information from the DB
    delete_license()

    # end all web sessions
    Session.objects.all().delete()

    return r.ok

def is_licensed ():
    if not cfg.license_required:
        return True

    #
    # first see if it's been validated in the last N days
    try:
        s = State_db.objects.get(name="license_timestamp")
        last_ts = utility.datetime_to_epoch(s.timestamp)
        if (time.time() - last_ts) < cfg.license_hold_days * 86400:
            return True
    except: pass

    #
    # If that didn't work, check the license server
    return check_key()

def check_key ():
    if not cfg.license_server:
        return False

    try:
        site_id, key = get_key()
    except TypeError:
        return False

    url = "https://%s/api/license_check/%s/%s/%s" % (cfg.license_server, site_id,
                                                     utility.get_system_uuid(), key)

    # add build date
    params = None
    try:
        params = {'build': str(utility.epoch_to_datetime(utility.get_build_date()).date())}
    except: pass

    try:
        r = requests.get(url, params=params, timeout=1, verify=False, proxies=proxy())
    except (requests.exceptions.InvalidURL, requests.exceptions.ConnectionError) as e:
        return None

    if r.ok:
        # store the license info
        license_name = r.json()['license_name']
        license_user = r.json()['license_user']
        exp_date = r.json()['exp_date']
        set_license_info(license_name, license_user, exp_date)
        # check validity
        valid = r.json()['valid']
        if valid:
            set_license_timestamp()

        return valid

    return False

def get_license_info ():
    try:
        s = State_db.objects.get(name="license_info")
        lic = pickle.loads(str(s.value))
        return lic
    except State_db.DoesNotExist:
        return None

def get_key ():
    try:
        s = State_db.objects.get(name="license_key")
        lic = pickle.loads(str(s.value))
        site_id = lic['site_id']
        key = lic['key']

        return (site_id, key)
    except State_db.DoesNotExist:
        return None

def delete_license ():
    try:
        State_db.objects.get(name="license_key").delete()
        State_db.objects.get(name="license_info").delete()
    except State_db.DoesNotExist:
        return

def set_license_timestamp ():
    db_row = {
        'timestamp': timezone.now(),
        }

    s, created = State_db.objects.update_or_create(name="license_timestamp", defaults=db_row)

def set_license_key (site_id, key):
    data = {
        'site_id': site_id,
        'key': key,
        }

    db_row = {
        'timestamp': timezone.now(),
        'value': pickle.dumps(data)
        }

    s, created = State_db.objects.update_or_create(name="license_key", defaults=db_row)

def set_license_info (license_name, license_user, exp_date):
    data = {
        'license_name': license_name,
        'license_user': license_user,
        'exp_date': exp_date
        }

    db_row = {
        'timestamp': timezone.now(),
        'value': pickle.dumps(data)
        }

    s, created = State_db.objects.update_or_create(name="license_info", defaults=db_row)

def proxy ():
    # update proxy with credentials
    if cfg.full_proxy:
        return {
            'https': 'https://%s' % cfg.full_proxy
            }
