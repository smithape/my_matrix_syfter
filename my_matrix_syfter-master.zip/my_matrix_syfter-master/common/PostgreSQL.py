import sys, os
import multiprocessing
from multiprocessing.pool import ThreadPool
from threading import Thread, Lock
from collections import OrderedDict
from datetime import datetime
from subprocess import getstatusoutput
import time, calendar
import operator
import re
from functools import reduce

from django.conf import settings
from django.db import connection, IntegrityError, ProgrammingError
from django.utils import timezone
from django.conf import settings
from django.db.models import Q
import numpy as np
import pandas as pd
import psutil

from . import utility
from . import config as cfg
from . import logger as log
from . import DB
from .PeriodicThread import PeriodicThread
from . import Event
from .models import \
    Device as Device_db, \
    Nugget as Nugget_db, \
    SampleHourly as SampleHourly_db, \
    Log as Log_db, \
    Event as Event_db, \
    State as State_db
from nugget import Nugget

class PostgreSQL (DB.DBObject):
    def __init__ (self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.status = "ok"
        self.db_user = "postgres"
        self.db_name = "syfter"
        # cache for device id / name mapping
        self.device_d = {}
        # cache for DB objects
        self.device_by_name = {}
        self.device_by_id = {}
        self.nugget_by_name = {}
        self.nugget_by_id = {}
        self.cache = {}
        self.monitor_t = None

        try:
            self.init_cache()
        except ProgrammingError: pass

        # initialize the thread pool
        self.pool = ThreadPool(processes=multiprocessing.cpu_count())

        self.dir = self.get_dir()
        self.storage_dir = self.dir.rsplit('/', 1)[0]
        self.cache_file = '%s/cache.dump' % (self.storage_dir)

    def start (self):
        # load the cache
        self.restore_cache()

        # Start the monitor thread
        self.monitor_t = PeriodicThread(name="postgresql/monitor",
                                        interval=60,
                                        action=self.monitor,
                                        daemon=True)
        self.monitor_t.start(time.time() + 60)

    def stop (self):
        # stop the monitor thread
        if self.monitor_t:
            self.monitor_t.stop()
        else:
            # LEVY: remove this at some point!
            self.monitor()

        self.dump_cache()

    def dump_cache (self):
        t1 = time.time()

        db_row = {
            'timestamp': timezone.now(),
            'data': self.cache
        }
        s, created = State_db.objects.update_or_create(name="db_cache", defaults=db_row)

        log.debug("json cache dump: %s" % (time.time() - t1))

    def restore_cache (self):
        t1 = time.time()
        try:
            s = State_db.objects.get(name="db_cache")
            cache_json = s.data or {}
        except State_db.DoesNotExist as e:
            return

        # convert keys to ints
        self.cache = {}
        for hourstamp, device_d in cache_json.items():
            new_device_d = {}
            for device_id, nugget_d in device_d.items():
                new_nugget_d = {int(k):v for k,v in nugget_d.items()}
                new_device_d[int(device_id)] = new_nugget_d
            self.cache[int(hourstamp)] = new_device_d

        log.debug("json cache read: %s" % (time.time() - t1))

    def monitor (self):
        #
        # Cache Writeback
        min_hourstamp = utility.epoch_to_hour(time.time() - 300)
        for hourstamp, data in list(self.cache.items()):
            if cfg.days_to_keep_data:
                if hourstamp < min_hourstamp:
                    # writeback
                    log.debug("cache_writeback: %s" % hourstamp)
                    t1 = time.time()
                    try:
                        self.cache_writeback(hourstamp, data)
                    except Exception as e:
                        log.debug("problem with writeback: %s" % e)
                    log.debug("...(%s)" % (time.time() - t1))
                    # drop old data
                    try:
                        del self.cache[hourstamp]
                    except KeyError: pass
            else:
                if hourstamp < (min_hourstamp - 3600):
                    # drop old data
                    try:
                        del self.cache[hourstamp]
                    except KeyError: pass

    def get_dir (self):
        # find the DB directory
        with connection.cursor() as cursor:
            cursor.execute("SELECT setting FROM pg_settings WHERE name = 'data_directory';")
            db_dir, = cursor.fetchone()

        return db_dir

    def get_disk_usage (self):
        """ Get table/index database usage numbers """
        with connection.cursor() as cursor:
            # find the reported DB size (including dead rows)
            cursor.execute("SELECT pg_database_size('%s');" %
                           settings.DATABASES['default']['NAME'])
            db_size, = cursor.fetchone()

            # get list of tables in the DB
            tables = connection.introspection.table_names()
            # start assuming nothing is dead
            total_table_space = 0
            total_index_space = 0
            for table in tables:
                # find the space used for the table
                cursor.execute("SELECT pg_table_size('%s');" % table)
                table_space, = cursor.fetchone()
                # find the space used for the index
                cursor.execute("SELECT pg_indexes_size('%s');" % table)
                index_space, = cursor.fetchone()
                # Add to the totals
                total_table_space += table_space
                total_index_space += index_space

        return (db_size, total_table_space, total_index_space)

    def init_cache(self):
        # initialize the device cache
        device_l = Device_db.objects.all()
        for d in device_l:
            self.device_by_name[d.name] = d
            self.device_by_id[d.id] = d

        # add Nugget object to the DB
        for category in Nugget.nugget_config:
            for nugget_name in Nugget.nugget_config[category]:
                Nugget_db.objects.get_or_create(name=nugget_name)

        # initialize the Nugget cache
        nugget_l = Nugget_db.objects.all()
        for k in nugget_l:
            self.nugget_by_name[k.name] = k
            self.nugget_by_id[k.id] = k

    def add_device (self, device):
        d, created = Device_db.objects.get_or_create(name=device.name)
        # set/update the values
        d.type = device.type
        if device.ip_address:
            d.ip_address = device.ip_address
        d.group_l = list(device.group_d.keys())
        d.save()

        # put into the mapping dicts
        self.device_by_name[d.name] = d
        self.device_by_id[d.id] = d

        # remember the DB entry
        device.db_entry = d

        return d

    def get_device (self, name = "", id = ""):
        if name:
            try:
                return self.device_by_name[name]
            except KeyError:
                d, created = Device_db.objects.get_or_create(name=name)
                self.device_by_name[d.name] = d
                self.device_by_id[d.id] = d
                return d
        elif id:
            try:
                return self.device_by_id[id]
            except KeyError:
                d = Device_db.objects.get(pk=id)
                self.device_by_name[d.name] = d
                self.device_by_id[d.id] = d
                return d

    def get_nugget (self, name = "", id = ""):
        if name:
            try:
                return self.nugget_by_name[name]
            except KeyError:
                d, created = Nugget_db.objects.get_or_create(name=name)
                self.nugget_by_name[d.name] = d
                self.nugget_by_id[d.id] = d
                return d
        elif id:
            try:
                return self.nugget_by_id[id]
            except KeyError:
                try:
                    d = Nugget_db.objects.get(pk=id)
                    self.nugget_by_name[d.name] = d
                    self.nugget_by_id[d.id] = d
                    return d
                except Nugget_db.DoesNotExist:
                    log.debug("Invalid Nugget id: %s" % id)

################################################################################
# Write Functions
################################################################################

    def log_insert (self, log_tuple):
        timestamp, device_name, nugget_name, severity, log_type, message = log_tuple

        # find the device/nugget DB objects
        device = None
        nugget = None
        if device_name:
            device = self.get_device(name=device_name)
            if nugget_name:
                nugget = self.get_nugget(name=nugget_name)

        # convert timestamp to datetime
        timestamp_dt = utility.epoch_to_datetime(timestamp)

        # create the record
        Log_db(timestamp=timestamp_dt,
               device=device,
               nugget=nugget,
               severity=severity,
               type=log_type,
               message=message).save()


    def bulk_insert (self, sample_l):
        self.cache_update(sample_l)

    def cache_update (self, sample_l):

        # add to the cache
        for timestamp, device_name, nugget_name, value in sample_l:
            hourstamp = utility.epoch_to_hour(timestamp)
            device = self.get_device(name=device_name).id
            nugget = self.get_nugget(name=nugget_name).id
            try:
                self.cache[hourstamp][device][nugget].append((timestamp, value))
            except KeyError:
                try:
                    self.cache[hourstamp][device][nugget] = [(timestamp, value)]
                except KeyError:
                    try:
                        self.cache[hourstamp][device] = {nugget: [(timestamp, value)]}
                    except KeyError:
                        self.cache[hourstamp] = {device: {nugget: [(timestamp, value)]}}

    def cache_writeback (self, hourstamp, data_d):
        start = hourstamp
        end = start + 3600

        sample_l = []
        for device_id, device_d in data_d.items():
            for nugget_id, data in device_d.items():
                # find summary values
                try:
                    _min, _max, _avg = DB.crunchSeries(data, start, end)
                except TypeError: continue

                # prepare the samples
                timestamp_dt = utility.epoch_to_datetime(start)
                id = int(str(start) + ("%04d" % nugget_id) + ("%04d" % device_id))

                # the aggregation sample
                s = SampleHourly_db(id=id,
                                    timestamp=timestamp_dt,
                                    device_id=device_id,
                                    nugget_id=nugget_id,
                                    avg=_avg,
                                    min=_min,
                                    max=_max,
                                    data=data
                                )
                sample_l.append(s)

        # aggregation samples
        try:
            SampleHourly_db.objects.bulk_create(sample_l)
        except IntegrityError as e: pass


################################################################################
# Read Functions
################################################################################

    # logs
    ############################################################################
    def query_logs (self, start, end, fields, type=None, sev=None, sev_gte=None,
                    group=None, device_name=None, nugget_name=None):
        device = None
        nugget = None

        qs = Log_db.objects

        # filter by type
        if type:
            qs = qs.filter(type=type)

        # filter by group
        if group is not None:
            qs = qs.filter(device__group_l__contains=[group])

        # filter by device name
        if device_name is not None:
            device = self.get_device(name=device_name)
            qs = qs.filter(device=device)
        elif device_name is False:
            qs = qs.filter(device=None)

        # filter by nugget_name
        if nugget_name is not None:
            nugget = self.get_nugget(name=nugget_name)
            qs = qs.filter(nugget=nugget)
        elif nugget_name is False:
            qs = qs.filter(nugget=None)

        # filter by severity
        if sev:
            qs = qs.filter(severity=sev)
        elif sev_gte:
            qs = qs.filter(severity__gte=sev_gte)

        values = self.query(qs, start, end, fields)

        return values

    # metrics
    ############################################################################
    def query_metric_cache (self, spans, filter_d={}, organize_by_id=False, presence=False):
        """ access the ram cache """

        hourstamps = list(self.cache.keys())
        # find the hourstamps required
        hourstamps_required = []
        for hourstamp in hourstamps:
            for start, end in spans:
                start = utility.epoch_to_hour(start)
                if start <= hourstamp <= end:
                    hourstamps_required.append(hourstamp)

        if not hourstamps_required:
            return [], spans

        # find the remaining spans
        leftover_spans = []
        for start, end in spans:
            leftover_spans += DB.get_leftover_spans(start, end, hourstamps, datetime=False)

        # we only want to check metric presence? (no min/max/avg)
        if presence:
            pairs = set()
            device_id_l = self.filter_device_l(filter_d)
            nugget_id_l = self.filter_nugget_l(filter_d)
            for hourstamp in hourstamps_required:
                device_d = self.cache[hourstamp]
                for device_id, nugget_d in device_d.items():
                    if device_id_l is None or device_id in device_id_l:
                        for nugget_id, pts in nugget_d.items():
                            if nugget_id_l is None or nugget_id in nugget_id_l:
                                pairs.add((device_id, nugget_id))
            return pairs, leftover_spans

        multi_device = 'device' not in filter_d
        multi_nugget = 'nugget' not in filter_d

        values = []
        if not multi_device and not multi_nugget:
            device_id = self.get_device(name=filter_d['device']).id
            nugget_id = self.get_nugget(name=filter_d['nugget']).id
            for hourstamp in hourstamps_required:
                try:
                    values += self.cache[hourstamp][device_id][nugget_id]
                except KeyError: continue

        elif multi_device and multi_nugget:
            device_id_l = self.filter_device_l(filter_d)
            nugget_id_l = self.filter_nugget_l(filter_d)
            for hourstamp, device_d in self.cache.items():
                if hourstamp in hourstamps_required:
                    for device_id, nugget_d in device_d.items():
                        if device_id_l is None or device_id in device_id_l:
                            for nugget_id, pts in nugget_d.items():
                                if nugget_id_l is None or nugget_id in nugget_id_l:
                                    for timestamp, value in pts:
                                        values.append((device_id, nugget_id, timestamp, value))
        elif multi_device:
            device_id_l = self.filter_device_l(filter_d)
            nugget_id = self.get_nugget(name=filter_d['nugget']).id
            for hourstamp, device_d in self.cache.items():
                if hourstamp in hourstamps_required:
                    for device_id, nugget_d in device_d.items():
                        if device_id_l is None or device_id in device_id_l:
                            try:
                                for timestamp, value in nugget_d[nugget_id]:
                                    values.append((device_id, timestamp, value))
                            except KeyError: continue
        elif mutli_nugget:
            device_id = self.get_device(name=filter_d['device']).id
            nugget_id_l = self.filter_nugget_l(filter_d)
            for hourstamp, device_d in self.cache.items():
                if hourstamp in hourstamps_required:
                    try:
                        for nugget_id, pts in device_d[device_id].items():
                            if nugget_id_l is None or nugget_id in nugget_id_l:
                                for timestamp, value in pts:
                                    values.append((nugget_id, timestamp, value))
                    except KeyError: continue

        return values, leftover_spans

    def query_metric (self, start, end, filter_d, threaded=False, organize_by_id=False):
        return self.query_metric_spans([(start, end)], filter_d,
                                       threaded=threaded, organize_by_id=organize_by_id)

    def query_metric_spans (self, spans, filter_d, threaded=False, organize_by_id=False):
        """
        query metric data from spans specified. This accesses all raw
        (non-summary) data sources.
        """

        multi_device = 'device' not in filter_d
        multi_nugget = 'nugget' not in filter_d

        # cache query
        values, leftover_spans = self.query_metric_cache(spans, filter_d)

        # hourly query
        if leftover_spans:
            qs = self.qs_filter(SampleHourly_db.objects, filter_d)

            # set the fields
            fields = []
            if multi_device:    fields += ['device']
            if multi_nugget:       fields += ['nugget']

            values_hr, leftover_spans = self.query_metric_hr(qs, leftover_spans, fields)
            values = values_hr + values

        return self.organize_metrics(values, multi_device, multi_nugget, by_id=organize_by_id)

    def query_metric_hr (self, qs, spans, fields):
        """ get the raw metrics from the hourly table """

        qs =  qs.filter(data__isnull=False)

        # find the data
        data = self.query_spans(qs, spans, fields+['timestamp', 'data'], hourly=True)
        values = []
        hourstamps = set()
        if fields:
            for row in data:
                hourstamp = row[-2]
                json_data = row[-1]
                hourstamps.add(hourstamp)
                for timestamp, value in json_data:
                    new_row = (row[:-2] + (timestamp, value))
                    values.append(new_row)
        else:
            for hourstamp, json_data in data:
                hourstamps.add(hourstamp)
                values += json_data

        leftover_spans = []
        for start, end in spans:
            leftover_spans += DB.get_leftover_spans(start, end, hourstamps)

        return values, leftover_spans

    def query_metric_hr_summary (self, qs, start, end, fields):
        """ get the metric summaries from the hourly table """

        # for hourly summaries, only consider hours that are fully contained
        # in the time span
        adjusted_end = utility.epoch_to_hour(end)

        # find the data
        data = self.query(qs, start, adjusted_end, fields+['timestamp'])

        values = []
        hourstamps = set()
        for row in data:
            hourstamps.add(row[-1]) # timestamp
            values.append(row[0:-1]) # results

        leftover_spans = DB.get_leftover_spans(start, end, hourstamps)

        return values, leftover_spans

    def filter_device_l (self, filter_d):
        """ filter the list of devices down using the filter_d parameters """

        d = filter_d

        # if not ("device_list" in d or
        #         "device_type" in d or
        #         "device_type_l" in d or
        #         "device_filter" in d or
        #         "group" in d):
        #     return None

        device_id_l = []
        if d.get('device_list'):
            for device_name in d['device_list']:
                device_id_l.append(self.get_device(name=device_name).id)

        map_d = self.device_by_id
        device_l = device_id_l or list(map_d.keys())

        if d.get('device_type'):
            device_l = [x for x in device_l if map_d[x].type == d['device_type']]

        if d.get('device_type_l'):
            device_l = [x for x in device_l if map_d[x].type in d['device_type_l']]

        if d.get('group'):
            group = d['group']
            device_l = [x for x in device_l if group in map_d[x].group_l]

        if d.get('device_filter'):
            filter_re = re.compile(d['device_filter'], re.IGNORECASE)
            device_l = [x for x in device_l if re.search(filter_re, map_d[x].name)]

        return device_l

    def filter_nugget_l (self, filter_d):
        """ filter the list of nuggets down using the filter_d parameters """

        d = filter_d

        if 'nugget_list' in d:
            nugget_id_l = []
            for nugget_name, nugget_obj in self.nugget_by_name.items():
                if nugget_name in d['nugget_list']:
                    nugget_id_l.append(nugget_obj.id)
            return nugget_id_l
        elif 'nugget_prefix_list' in d:
            nugget_id_l = []
            for nugget_name, nugget_obj in self.nugget_by_name.items():
                nugget_prefix = nugget_name.split(':')[0]
                if nugget_prefix in d['nugget_prefix_list']:
                    nugget_id_l.append(nugget_obj.id)
            return nugget_id_l

        return None

    def qs_filter (self, qs, filter_d):
        """ filter the query set down using filter_d parameters """

        d = filter_d
        if 'group' in d:
            qs = qs.filter(device__group_l__contains=[d['group']])
        if 'device_type' in d:
            qs = qs.filter(device__type=d['device_type'])
        if 'device_type_l' in d:
            qs = qs.filter(device__type__in=d['device_type_l'])
        if 'device_filter' in d:
            qs = qs.filter(device__name__iregex=d['device_filter'])
        if 'device' in d:
            device_id = self.get_device(name=d['device']).id
            qs = qs.filter(device=device_id)
        elif 'device_list' in d:
            device_id_l = []
            for device_name in d['device_list']:
                device_id_l.append(self.get_device(name=device_name).id)
            qs = qs.filter(device__in=device_id_l)
        if 'nugget' in d:
            nugget_id = self.get_nugget(name=d['nugget']).id
            qs = qs.filter(nugget=nugget_id)
        elif 'nugget_list' in d:
            nugget_id_l = []
            for nugget_name, nugget_obj in self.nugget_by_name.items():
                if nugget_name in d['nugget_list']:
                    nugget_id_l.append(nugget_obj.id)
            qs = qs.filter(nugget__in=nugget_id_l)
        elif 'nugget_prefix_list' in d:
            nugget_id_l = []
            for nugget_name, nugget_obj in self.nugget_by_name.items():
                nugget_prefix = nugget_name.split(':')[0]
                if nugget_prefix in d['nugget_prefix_list']:
                    nugget_id_l.append(nugget_obj.id)
            qs = qs.filter(nugget__in=nugget_id_l)

        return qs

    def organize_metrics (self, values, by_device=False, by_nugget=False, by_id=False):
        """ compile metric rows into appropriate data structure """

        # # levy: required?
        # values.sort(key=lambda x: x[-2])

        # Device + Nugget
        if by_device and by_nugget:
            data_d = {}
            for device_id, nugget_id, timestamp, value in values:
                sample = (timestamp, value)
                # find index values
                if by_id:
                    device = device_id
                    nugget = nugget_id
                else:
                    device = self.get_device(id=device_id).name
                    nugget = self.get_nugget(id=nugget_id).name
                try:
                    data_d[device][nugget].append(sample)
                except KeyError:
                    try:
                        data_d[device][nugget] = [sample]
                    except KeyError:
                        data_d[device] = {nugget : [sample]}
            return data_d
        # Device
        elif by_device:
            data_d = {}
            for device_id, timestamp, value in values:
                sample = (timestamp, value)
                # find index values
                if by_id:
                    device = device_id
                else:
                    device = self.get_device(id=device_id).name
                try:
                    data_d[device].append(sample)
                except KeyError:
                    data_d[device] = [sample]
            return data_d
        # Nugget
        elif by_nugget:
            data_d = {}
            for nugget_id, timestamp, value in values:
                sample = (timestamp, value)
                # find index values
                if by_id:
                    nugget = nugget_id
                else:
                    nugget = self.get_nugget(id=nugget_id).name
                try:
                    data_d[nugget].append(sample)
                except KeyError:
                    data_d[nugget] = [sample]
            return data_d
        # single series
        else:
            return values

    def query_series (self, start, end, device_name, nugget_name):
        """ query a single time series """
        filter_d = {
            'device': device_name,
            'nugget': nugget_name
            }
        return self.query_metric(start, end, filter_d)

    def query_series_hr (self, start, end, device_name, nugget_name):
        """ time series using the hourly summary as points """
        # find the device/nugget DB objects
        device = self.get_device(name=device_name)
        nugget = self.get_nugget(name=nugget_name)

        qs = device.samplehourly_set.filter(nugget=nugget)
        columns = ['timestamp','avg','min','max']
        values = self.query(qs, start, end, columns, hourly=True)

        return values

    def query_metric_presence (self, start, end, group=None):
        """ find all Device/Nugget pairs for this time range """
        values = set()
        query_start_time = int(time.time() * 1000)

        # determine the filters
        nugget_l = [x for x,y in DB.db.nugget_cfg_d.items() if y['datatype'] == 'time_series']
        filter_d = {
            'nugget_prefix_list': nugget_l
        }
        if group:
            filter_d['group'] = group

        # initialize the queryset
        qs = SampleHourly_db.objects
        qs = self.qs_filter(qs, filter_d)

        # query the hourly table
        columns = ['device', 'nugget']
        values = self.query(qs, start, end, columns, hourly=True, distinct=True)

        # find the hours that are present in the hourly table
        columns = ['timestamp']
        hourstamps = self.query(qs, start, end, columns, hourly=True, distinct=True)
        hourstamps = [x for x, in hourstamps]
        leftover_spans = DB.get_leftover_spans(start, end, hourstamps)

        # query the raw sample cache
        if leftover_spans:
            values_raw, leftover_spans = self.query_metric_cache(leftover_spans, filter_d=filter_d, presence=True)
            values.update(values_raw)

        process_start_time = int(time.time() * 1000)

        # prepare the event dictionary
        event = {}
        event['start_timestamp'] = start
        event['end_timestamp'] = end
        event['device_d'] = {}
        event['state'] = None
        event['group'] = group

        # prepare the device/nugget dict
        device_d = {}
        nugget_s = set()
        device_type_s = set()
        for device_id, nugget_id in values:
            # lookup the device/Nugget object from the ID
            device = self.get_device(id=device_id)
            nugget = self.get_nugget(id=nugget_id)

            # add to the overall nugget list
            nugget_s.add(nugget.name)
            device_type_s.add(device.type)

            if device.name not in device_d:
                device_d[device.name] = {}
                device_d[device.name]['type'] = device.type
                device_d[device.name]['nugget_d'] = {}

            if nugget.name not in device_d[device.name]['nugget_d']:
                device_d[device.name]['nugget_d'][nugget.name] = {}

        # sort the devices
        event['device_d'] = OrderedDict(sorted(device_d.items(),
                                              key=lambda x: x[0]))
        event['nugget_l'] = list(nugget_s)
        event['nugget_l'].sort()
        event['device_type_l'] = list(device_type_s)
        event['device_type_l'].sort()

        end_time = int(time.time() * 1000)

        if cfg.query_debug:
            log.debug("Metric Presence: query/process/total: %s/%s/%s" %
                      (process_start_time - query_start_time,
                       end_time - process_start_time,
                       end_time - query_start_time))

        event['state'] = "partial"

        return event

    def query_metric_summary (self, start, end, group=None):
        """ find min/max/avg for every Device/Nugget pair in this time range """
        df_hourly = None
        df_raw = None

        # a quick load will give us ALL Nuggets (even those that don't have numeric
        # min/max/avg
        event = self.query_metric_presence(start, end, group=group)
        if not event:
            return None

        query_start_time = int(time.time() * 1000)

        # read the nugget_config to determine the list of Nuggets to read
        nugget_l = [x for x,y in DB.db.nugget_cfg_d.items() if y['datatype'] == 'time_series']
        filter_d = {
            'nugget_prefix_list': nugget_l
        }
        if group:
            filter_d['group'] = group

        # initialize the queryset
        qs = SampleHourly_db.objects
        qs = self.qs_filter(qs, filter_d)

        # query the hourly table
        spans = None
        try:
            columns = ['device', 'nugget', 'min', 'max', 'avg']
            values_hourly, spans = self.query_metric_hr_summary(qs, start, end, columns)
            df_hourly = pd.DataFrame(values_hourly, columns=columns)
            df_hourly['delta'] = 3600 # each is 1 hour of data
        except ValueError: pass

        process_start_time = int(time.time() * 1000)

        if spans:
            # query for raw samples
            try:
                data_d = self.query_metric_spans(spans, filter_d,
                                                 threaded=True,
                                                 organize_by_id=True)
                if data_d:
                    index_l = []
                    data_l = []
                    for device_id, device_d in data_d.items():
                        for nugget_id, data in device_d.items():
                            try:
                                min, max, avg = DB.crunchSeries_spans(data, spans)
                            except TypeError: continue

                            # add to lists
                            index_l.append((device_id, nugget_id))
                            data_l.append((min, max, avg))

                    # put data into dataframe
                    index = pd.MultiIndex.from_tuples(index_l, names=['device', 'nugget'])
                    df_raw = pd.DataFrame(data_l, index=index, columns=['min', 'max', 'avg'])

                    # the total number of seconds contained in raw spans
                    delta = sum([y-x for x,y in spans])
                    df_raw['delta'] = delta

            except ValueError: pass

        # prepare the dataframes
        if df_hourly is not None:
            df = df_hourly

            if df_raw is not None:
                # append the raw data
                df = df.append(df_raw.reset_index())

            # need to weight the average by the 'delta' (number of seconds)
            df['sum'] = df['avg'] * df['delta']

            group = df.groupby(['device', 'nugget'])

            df = group.sum()
            df['avg'] = df['sum'] / df['delta']
            df['min'] = group.min()['min']
            df['max'] = group.max()['max']
        elif df_raw is not None:
            df = df_raw
        else:
            return event

        for (device_id, nugget_id), row in df.iterrows():
            # lookup the device/nugget objects from the ID
            device = self.get_device(id=device_id)
            nugget = self.get_nugget(id=nugget_id)

            # get the right dict
            d = event['device_d'][device.name]['nugget_d'][nugget.name]

            d['min'] = round(row['min'], 2)
            d['max'] = round(row['max'], 2)
            d['avg'] = round(row['avg'], 2)


        end_time = int(time.time() * 1000)

        if cfg.query_debug:
            log.debug("Metric Summary: query/process/total: %s/%s/%s" %
                      (process_start_time - query_start_time,
                       end_time - process_start_time,
                       end_time - query_start_time))

        event['state'] = "full"
        return event

    def top_devices (self, start, end, device_type_l, nugget_name, device_filter=None,
                     device_group=None, n=0, resample_period=0):
        # get the nugget object
        nugget = self.get_nugget(name=nugget_name)

        # set the filters
        filter_d = {
            'device_type_l': device_type_l,
            'nugget': nugget_name,
        }
        if device_filter:
            filter_d['device_filter'] = device_filter
        if device_group:
            filter_d['group'] = device_group

        # determine our method
        if not resample_period:
            return self.top_devices_simple(start, end, filter_d, n)
        else:
            # define the bucket spans
            bkt_spans = []
            bkt_start = start
            bkt_end = start + resample_period
            while bkt_end <= end:
                bkt_spans.append((bkt_start, bkt_end))
                bkt_start += resample_period
                bkt_end += resample_period

            if start % 3600 == 0 and resample_period % 3600 == 0:
                # use the hourly summaries
                return self.top_devices_hr(start, end, bkt_spans, filter_d, n)
            else:
                # use raw data
                return self.top_devices_raw(start, end, bkt_spans, filter_d, n)

    def top_devices_sort (self, device_d, n=0):
        # sort the list by average:
        if n:
            # get the top-n-by-average, then add in any of the top-n-by-max that weren't
            # in the top-n-by-average.
            top_devices_d = OrderedDict(
                sorted(device_d.items(), key=lambda x: x[1]['avg'], reverse=True)[:n] +
                sorted(device_d.items(), key=lambda x: x[1]['max'], reverse=True)[:n]
            )
        else:
            top_devices_d = OrderedDict(
                sorted(device_d.items(), key=lambda x: x[1]['avg'], reverse=True)
            )

        return top_devices_d

    def top_devices_simple (self, start, end, filter_d, n=0):
        """ aggregate to find top devices for a particular Nugget """
        df_hourly = None
        df_raw = None

        query_start_time = int(time.time() * 1000)

        # query the hourly table
        qs = self.qs_filter(SampleHourly_db.objects, filter_d)
        columns = ['device', 'avg', 'max']
        values_hourly, spans = self.query_metric_hr_summary(qs, start, end, columns)
        if values_hourly:
            df_hourly = pd.DataFrame(values_hourly, columns=columns)
            df_hourly['delta'] = 3600 # each is 1 hour of data

        raw_query_start_time = int(time.time() * 1000)
        process_start_time = int(time.time() * 1000)

        if spans:
            try:
                data_raw_d = self.query_metric_spans(spans, filter_d,
                                                     threaded=True,
                                                     organize_by_id=True)

                process_start_time = int(time.time() * 1000)

                device_l = []
                data_l = []
                for device_name, data in data_raw_d.items():

                    # find summary values
                    try:
                        min, max, avg = DB.crunchSeries_spans(data, spans)
                    except TypeError: continue

                    # add to lists
                    device_l.append(device_name)
                    data_l.append((max, avg))

                # put data into dataframe
                df_raw = pd.DataFrame(data_l, index=device_l, columns=['max', 'avg'])
                df_raw.index.name = 'device'

                # the total number of seconds contained in raw spans
                delta = sum([y-x for x,y in spans])
                df_raw['delta'] = delta

            except ValueError: pass

        # prepare the dataframe
        if df_hourly is not None:
            df = df_hourly
            if df_raw is not None:
                # append the raw data
                df = df.append(df_raw.reset_index())

            # need to weight the average by the 'delta' (number of seconds)
            df['sum'] = df['avg'] * df['delta']
            # group the rows by device
            group = df.groupby(['device'])
            # calculate avg and max
            df = group.sum()
            df['avg'] = df['sum'] / df['delta']
            df['max'] = group.max()['max']
        elif df_raw is not None:
            df = df_raw
        else:
            return None

        devices_d = {}
        for (device_id), row in df.iterrows():
            # lookup the device objects from the ID
            device_name = self.get_device(id=device_id).name

            devices_d[device_name] = {
                'avg': round(row['avg'], 2),
                'max': round(row['max'], 2)
                }

        top_devices_d = self.top_devices_sort(devices_d, n)

        end_time = int(time.time() * 1000)
        if cfg.query_debug:
            log.debug("Top Devices: hr_query/raw_query/process/total: %s/%s/%s/%s" %
                      (raw_query_start_time - query_start_time,
                       process_start_time - raw_query_start_time,
                       end_time - process_start_time,
                       end_time - query_start_time))

        return top_devices_d
        # return {
        #     'start': start * 1000,
        #     'end': end * 1000,
        #     'data': top_devices_d
        # }

    def top_devices_hr (self, start, end, bkt_spans, filter_d, n):
        """ aggregate to find top devices for a particular Nugget """

        query_start_time = int(time.time() * 1000)

        # query the hourly table
        qs = self.qs_filter(SampleHourly_db.objects, filter_d)
        columns = ['timestamp', 'device', 'avg', 'max']
        values_hourly, spans = self.query_metric_hr_summary(qs, start, end, columns)
        if not values_hourly:
            return []

        # convert to dataframe
        df = pd.DataFrame(values_hourly, columns=columns)
        df = df.set_index(['timestamp']) #.values.astype(np.int64) // 10**9)
        df = df.set_index(df.index.astype(np.int64) / 10 ** 9)

        process_start_time = int(time.time() * 1000)

        ret_l = []
        for bkt_start, bkt_end in bkt_spans:
            bkt_df = df[(df.index >= bkt_start) & (df.index < bkt_end)]
            if bkt_df.empty:
                continue

            # group the rows by device
            group = bkt_df.groupby(['device'])
            # calculate avg and max
            bkt_df = group.mean()
            bkt_df['max'] = group.max()['max']

            devices_d = {}
            for (device_id), row in bkt_df.iterrows():
                # lookup the device objects from the ID
                device_name = self.get_device(id=device_id).name

                devices_d[device_name] = {
                    'avg': round(row['avg'], 2),
                    'max': round(row['max'], 2)
                }

            top_devices_d = self.top_devices_sort(devices_d)

            ret_l.append({
                'start': bkt_start * 1000,
                'end': bkt_end * 1000,
                'data': top_devices_d
            })

        end_time = int(time.time() * 1000)
        if cfg.query_debug:
            log.debug("Top Devices: query/process/total: %s/%s/%s" %
                      (process_start_time - query_start_time,
                       end_time - process_start_time,
                       end_time - query_start_time))

        return ret_l

    def top_devices_raw (self, start, end, bkt_spans, filter_d, n):
        """ aggregate to find top devices for a particular Nugget """

        query_start_time = int(time.time() * 1000)


        # query the raw data
        data_d = self.query_metric(start, end, filter_d,
                                       threaded=True,
                                       organize_by_id=True)

        process_start_time = int(time.time() * 1000)

        ret_l = []
        for bkt_start, bkt_end in bkt_spans:
            devices_d = {}
            for device_name, data in data_d.items():
                # find summary values
                try:
                    min, max, avg = DB.crunchSeries(data, bkt_start, bkt_end)
                except TypeError: continue

                devices_d[device_name] = {
                    'avg': round(avg, 2),
                    'max': round(max, 2)
                    }

            top_devices_d = self.top_devices_sort(devices_d, n)

            ret_l.append({
                'start': bkt_start * 1000,
                'end': bkt_end * 1000,
                'data': top_devices_d
            })

        end_time = int(time.time() * 1000)
        if cfg.query_debug:
            log.debug("Top Devices: query/process/total: %s/%s/%s" %
                      (process_start_time - query_start_time,
                       end_time - process_start_time,
                       end_time - query_start_time))

        return ret_l

    # generic root query functions
    ############################################################################
    def query (self, qs, start, end, columns, hourly=False, threaded=False, distinct=False, asdict=False):
        return self.query_spans(qs, [(start, end)],
                                columns, hourly=hourly, threaded=threaded, distinct=distinct, asdict=asdict)

    def query_spans (self, qs, spans, columns, hourly=False, threaded=False, distinct=False, asdict=False):
        """ the master query function """
        values = []

        if hourly:
            spans = [(utility.epoch_to_hour(start), end) for start,end in spans]

        if threaded:
            values = self.query_spans_threaded(qs, spans, columns, distinct=distinct, asdict=asdict)
        else:
            values = self.query_spans_standard(qs, spans, columns, distinct=distinct, asdict=asdict)

        if distinct:
            return set(values)
        else:
            return values

    def query_spans_standard (self, qs, spans, columns, distinct=False, asdict=False):
        values = []

        # build the Q
        q_l = []
        for start, end in spans:
            q_l.append(Q(timestamp__range=(
                utility.epoch_to_datetime(start),
                utility.epoch_to_datetime(end-1))
                ))

        qs = qs.filter(reduce(operator.or_, q_l))

        # assign the query to a thread
        if asdict:
            values += self.query_helper_dict(qs, distinct, *columns)
        else:
            values += self.query_helper_list(qs, distinct, *columns)

        return values

    def query_spans_threaded (self, qs, spans, columns, distinct=False, asdict=False):
        values = []
        res_l = []

        bkt_count = multiprocessing.cpu_count() // len(spans) or 1

        for start, end in spans:
            # set the initial values
            bkt_size = (end - start) // bkt_count
            bkt_start = start
            bkt_end = bkt_start + bkt_size
            for i in range(bkt_count):
                if (i == bkt_count-1):
                    bkt_end = end
                # prepare the bucket qs
                qs_i = qs.filter(
                    timestamp__range=(
                        utility.epoch_to_datetime(bkt_start),
                        utility.epoch_to_datetime(bkt_end-1))
                    )

                # assign the query to a thread
                args = [qs_i, distinct] + columns
                if asdict:
                    res = self.pool.apply_async(self.query_helper_dict, args)
                else:
                    res = self.pool.apply_async(self.query_helper_list, args)
                res_l.append(res)

                bkt_start += bkt_size
                bkt_end += bkt_size

        for r in res_l:
            values += r.get()

        return values

    def query_helper_list (self, qs, distinct, *columns):
        """ query helper for returning list """
        if distinct:
            ret = list(qs.values_list(*columns).distinct())
        else:
            ret = list(qs.values_list(*columns))
        #connection.close()
        return ret

    def query_helper_dict (self, qs, distinct, *columns):
        """ query helper for returning dict """
        if distinct:
            ret = list(qs.values(*columns).distinct())
        else:
            ret = list(qs.values(*columns))

        #connection.close()
        return ret

################################################################################
# Maintenence Functions
################################################################################

    def hourly_agg (self):
        # find the hour start/end
        now = int(time.time())
        end = utility.epoch_to_hour(now)
        start = end - 3600 * cfg.hourly_agg_lookback

        while start < end:
            if not SampleHourly_db.objects.filter(timestamp=utility.epoch_to_datetime(start)).exists():
                self.hourly_agg_helper(start)
            start += 3600

    def reindex_table (self, table_name, cursor):
        """
        Performs a concurrent reindex on the table
        """

        log.info("Reindexing table: %s" % table_name, "system")

        # find all indexes for the table
        cursor.execute("SELECT indexname FROM pg_indexes where tablename = '%s';" % table_name)
        index_l = [x for x, in cursor.fetchall()]

        junk_index_l = [x for x in index_l if x.endswith('_')]
        index_l = [x for x in index_l if not x.endswith('_')]

        # remove leftover tmp indexes leftover from unfinished reindexes
        for index_name in junk_index_l:
            if index_name.endswith('_'):
                # drop the junk index
                log.warning("Removing junk index: %s" % index_name, "system")
                cursor.execute("DROP INDEX %s;" % index_name)

        for index_name in index_l:
            # extract the columns from the index name
            cols = re.sub(r'^%s_' % table_name, '', index_name)
            cols = re.sub(r'_idx$', '', cols)
            if cols == "pkey": # it's the primary key
                # create a duplicate index
                cursor.execute("CREATE UNIQUE INDEX CONCURRENTLY %s_ ON %s (id);"
                                     % (index_name, table_name))
                # reassign the primary key to the new table (old is removed)
                cursor.execute("ALTER TABLE %s DROP CONSTRAINT %s, ADD CONSTRAINT %s PRIMARY KEY USING INDEX %s_;"
                               % (table_name, index_name, index_name, index_name))
            else:
                cols = re.findall(r'([a-z]+(?:_id)?)', cols)
                # create a duplicate index
                cursor.execute("CREATE INDEX CONCURRENTLY %s_ ON %s (%s);"
                               % (index_name, table_name, ', '.join(cols)))
                # drop the original table
                cursor.execute("DROP INDEX %s;" % index_name)
                # rename the new table
                cursor.execute("ALTER INDEX %s_ RENAME TO %s;" % (index_name, index_name))

    def drop_partitions (self, p_filter = None):
        """ drop all time-based partitions """

        table_l, part_d = self.get_tables()

        with connection.cursor() as cursor:
            for name in part_d.keys():
                if p_filter is None or p_filter in name:
                    cursor.execute("DROP TABLE %s;" % name)

    def drop_tables (self):
        """ drop all tables """

        table_l, part_d = self.get_tables()

        with connection.cursor() as cursor:
            for name in table_l:
                cursor.execute("DROP TABLE %s CASCADE;" % name)

    def clear_tables (self):
        """ clear all tables """

        table_l, part_d = self.get_tables()

        with connection.cursor() as cursor:
            for name in table_l:
                cursor.execute("DELETE FROM %s;" % name)

    def partitions_in_span (self, start, end, part_d=None):
        """ find the partitions that contain data pertinent to a timespan """

        if not part_d:
            table_l, part_d = self.get_tables()

        # included if...
        # (1) start or end is in the partition span
        # (2) start-end encompasses the whole partition
        return {x:y for x,y in part_d.items()
                if y['start'] <= start <= y['end']
                or y['start'] <= end <= y['end']
                or start < y['start'] and end > y['end']}

    def get_tables (self):
        """
        return two lists:
            (1) standard tables
            (2) partitions
        """

        # get list of tables in the DB
        full_table_l = connection.introspection.table_names()
        # select only syfter tables
        full_table_l = [x for x in full_table_l if x.startswith("mtx_")]

        #
        # get the list of partitions
        table_l = []
        part_d = {}
        partition_re = r'^(\w+)_y(\d+)([d|w])(\d+)$'
        for table_name in full_table_l:
            match = re.search(partition_re, table_name)
            if not match:
                # it's a regular table
                table_l.append(table_name)
            else:
                # it's a partition
                # Extract values from partition name
                parent = match.group(1)
                year = int(match.group(2))
                type = match.group(3)

                partition = {
                    'name' : table_name,
                    'parent' : parent,
                    'type' : type,
                    }

                # find partition start/end times
                if type == 'w':
                    week = int(match.group(4))
                    partition['start'] = calendar.timegm(
                        time.strptime("%s/%s/1" % (year, week), "%Y/%W/%w"))
                    partition['end'] = partition['start'] + 604800
                elif type == 'd':
                    day = int(match.group(4))
                    partition['start'] = calendar.timegm(
                        time.strptime("%s/%s" % (year, day), "%Y/%j"))
                    partition['end'] = partition['start'] + 86400

                part_d[table_name] = partition

        # sort the list of partitions by end time
        part_d = OrderedDict(sorted(part_d.items(), key=lambda p: p[1]['end']))

        return table_l, part_d

    def get_partition_state (self):
        state_d = {}

        # load the partition state
        try:
            s = State_db.objects.get(name="partition")
            state_d = s.data or {}
        except State_db.DoesNotExist: pass

        return state_d

    def save_partition_state (self, state_d):

        db_row = {
            'timestamp': timezone.now(),
            'data': state_d,
            }

        s, created = State_db.objects.update_or_create(name="partition", defaults=db_row)

    def maintenance (self):
        # reset the cursor
        self.partition_maintenance()

    def partition_maintenance (self):
        """
        Perform a number of partition maintenance operations

        1) reindex recently completed partitions
        2) drop (if no event) or archive (if event) old partitions
            Archival:
                1) delete non-event data
                2) perform a full_vacuum
        3) drop old partitions if we're short on disk space
        """

        log.debug("Partition Maintenance")

        # partitions use UTC time
        now = int(time.time())
        day_start = utility.epoch_to_day(now)
        time_cutoff = day_start - cfg.days_to_keep_data*86400

        # define the list of archivable tables, and the associated model classes
        tables_to_archive = {
            "mtx_samplehr" : SampleHourly_db,
            "mtx_log" : Log_db
            }

        # retrieve the list of partitions
        table_l, part_d = self.get_tables()

        # load the partition state
        reindexed = []
        archived = []
        state_d = self.get_partition_state()

        if state_d:
            # clear out records for dropped partitions
            if 'reindexed' in state_d:
                reindexed = [x for x in state_d['reindexed'] if x in part_d]
            if 'archived' in state_d:
                archived = [x for x in state_d['archived'] if x in part_d]

        # open a connection to the DB
        with connection.cursor() as cursor:
            #
            # archive partitions
            try:
                for name, p in part_d.items():
                    try:
                        # determine whether the partition is for a table we archive
                        if p['parent'] in tables_to_archive:
                            p['to_archive'] = True
                            p['model_class'] = tables_to_archive[p['parent']]
                        else:
                            p['to_archive'] = False

                        if p['end'] <= time_cutoff: # old partition?
                            #
                            # Event-based archival
                            if cfg.event_detection:
                                # See if an event lies in the partition
                                qs = Event_db.objects.filter(Q(start_timestamp__range=(p['start'], p['end'])) |
                                                             Q(end_timestamp__range=(p['start'], p['end'])))
                                p['contains_event'] = qs.exists()

                                #
                                # take action
                                if p['contains_event'] and p['to_archive']:
                                    if name not in archived:
                                        #
                                        # Archive (trim and compress) the partition
                                        log.debug("Archiving partition: %s" % name)
                                        events = qs.values_list("id", "start_timestamp", "end_timestamp")
                                        p['events'] = sorted(events, key=lambda x: x[1])
                                        # delete excess data
                                        self.trim_partition(p)
                                        # vacuum (this compresses a bit)
                                        if not self.vacuum_partition(p, cursor):
                                            continue
                                        # mark the partition as archived
                                        archived.append(name)
                                else:
                                    # No event found, so drop the partition
                                    log.debug("Dropping expired partition: %s (no event found)" % name)
                                    cursor.execute("DROP TABLE %s;" % name)
                                    continue
                            #
                            # No event detection (simply drop expired data)
                            else:
                                # Drop the partition
                                log.debug("Dropping expired partition: %s" % name)
                                cursor.execute("DROP TABLE %s;" % name)
                                continue

                        #
                        # Reindex the partition
                        if name not in reindexed and now > p['end']:
                            try:
                                self.reindex_table(name, cursor)
                            except Exception as e:
                                log.exception("Partition reindex failed: %s\n%s" % (name, e), "system")
                                continue

                            # mark the partition as reindexed
                            reindexed.append(name)

                    except Exception as e:
                        log.exception("Partition maintenance failed: %s\n%s" % (name, e), "system")

            finally:
                # save the parititon state
                state_d['reindexed'] = reindexed
                state_d['archived'] = archived
                self.save_partition_state(state_d)

            #
            # Next remove old partitions if we need disk space
            # LEVY TODO: Also delete associated events?
            for name in part_d.keys():
                if psutil.disk_usage(self.dir).percent > cfg.disk_usage_threshold:
                    log.warning("Disk Space Low: Dropping partition: %s" % name, "system")
                    cursor.execute("DROP TABLE %s;" % name)
                else:
                    break

    def trim_partition (self, partition):
        """
        Remove rows that are not included in an event
        """
        #
        # find the devices associated with each event
        event_d = {}
        for event_id, event_start, event_end in partition['events']:
            e_data = Event.get(event_id)
            event_d[event_id] = {
                'start': event_start,
                'end': event_end,
                'device_l': list(e_data['device_d'].keys())
                }

        #
        # clean out unused data hour-by-hour
        hour_start = partition['start']
        while hour_start < partition['end']:
            hour_end = hour_start + 3600
            device_l = set()
            for event_id, event in event_d.items():
                if (event['start'] <= hour_start < event['end'] or
                    hour_start <= event['start'] < hour_end):
                    # add the event device list to the set
                    device_l.update(event['device_l'])

            qs = partition['model_class'].objects
            device_id_l = [self.get_device(name=x).id for x in device_l]
            if device_id_l:
                qs = qs.exclude(device__id__in=device_id_l)
                qs = qs.exclude(device__isnull=True)

            # delete unused data for this hour
            qs = qs.filter(
                timestamp__range=(
                    utility.epoch_to_datetime(hour_start),
                    utility.epoch_to_datetime(hour_end-1)
                )
            ).delete()

            # move to next hour
            hour_start += 3600

    def vacuum_partition (self, partition, cursor):
        name = partition['name']
        parent = partition['parent']

        log.debug("Vacuuming partition: %s" % name)
        try:
            # remove the partition from parent
            cursor.execute("ALTER TABLE %s NO INHERIT %s;" % (name, parent))
        except: pass
        try:
            # vacuum the partition
            cursor.execute("VACUUM FULL ANALYZE %s;" % name)
        except Exception as e:
            log.exception("Partition vacuum failed: %s\n%s" % (name, e), "system")
            return False
        finally:
            # reattach the partition to the parent
            cursor.execute("ALTER TABLE %s INHERIT %s;" % (name, parent))

        log.debug("Vacuuming partition: done")
        return True

################################################################################
# Backup/Restore
################################################################################
    def dump_table_includes (self, span_l, event_l):
        if not (span_l or event_l):
            return "-t 'mtx_*'"

        if event_l:
            event_db_l = Event_db.objects.filter(id__in=event_l)
            for event in event_db_l:
                span_l.append([event.start_timestamp, event.end_timestamp])

        table_l, part_d = self.get_tables()

        filtered_part_l = set()
        for start, end in span_l:
            span_part_l = list(self.partitions_in_span(start, end, part_d).values())
            filtered_part_l.update([x['name'] for x in span_part_l])
        filtered_part_l = sorted(filtered_part_l)

        table_l.extend(filtered_part_l)

        return "-t '(%s)'" % ('|'.join(table_l))

    def backup (self, span_l, event_l):
        # hardcoded options
        storage_dir = self.dir.rsplit('/', 1)[0]
        #filepath = '%s/%s.dump' % (storage_dir, self)
        filepath = '%s/%s.dump' % (cfg.tool_name, storage_dir) # LEVY: maybe don't hardcode

        if os.path.exists(filepath):
            if not utility.prompt("There is already a backup present in %s. Overwrite?" % filepath):
                return

        includes = self.dump_table_includes(span_l, event_l)

        # run the dump
        command = ("sudo -u %s pg_dump -Fc %s %s > %s" %
                   (self.db_user, includes, self.db_name, filepath))

        (code, result) = getstatusoutput(command)

        if code:
            print(result)
            print("Error: backup failed :-(")
            sys.exit(-1)
        else:
            print("Database backup successful: %s" % filepath)

    def restore (self, filepath, jobs):

        # clear out all the partition data
        self.drop_partitions()
        self.drop_tables()

        # restore
        command = ('sudo -u %s pg_restore -ec --if-exists -j %s -d %s %s' %
                   (self.db_user, jobs, self.db_name, filepath))
        (code, result) = getstatusoutput(command)

        if code:
            print(result)
            return False
        else:
            return True

    def clear_logs (self):
        self.drop_partitions(p_filter="mtx_log")

    def clear_data (self):
        self.drop_partitions()

    def clear_db (self):
        self.drop_partitions()
        self.clear_tables()
