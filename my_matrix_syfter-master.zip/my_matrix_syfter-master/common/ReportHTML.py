from . import utility
from . import logger as log

def header (title):
    return ("<tr><th colspan=10>%s</th></tr>" % title)

def report_html (report_d, report_cfg):
    text = '<html><table style="border: 1px solid gray; border-collapse: collapse">';
    text += header('%s - %s' %
                   (utility.epoch_to_datetime(report_d['start'], local=True).strftime('%m-%d-%Y %H:%M %Z'),
                    utility.epoch_to_datetime(report_d['end'], local=True).strftime('%m-%d-%Y %H:%M %Z')))


    report_d = {x:y for x,y in report_d.items() if x in report_cfg}

    if 'throughput' in report_d:
        tput_d = report_d['throughput']

        text += header("Throughput")

        if 'rx' in tput_d:
            text += '<tr><th style="text-align: right">Download Total</th></td>%.2f GB</td></tr>' % tput_d['rx']['total']
            text += '<tr><th>Download Peak</th></td>%.2f Mbps</td></tr>' % tput_d['rx']['peak']
        if 'tx' in tput_d:
            text += '<tr><th>Upload Total</th></td>%.2f GB</td></tr>' % tput_d['tx']['total']
            text += '<tr><th>Upload Peak</th></td>%.2f Mbps</td></tr>' % tput_d['tx']['peak']

    text += '</table></html>'

    return text
