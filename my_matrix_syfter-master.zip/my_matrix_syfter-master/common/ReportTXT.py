import time

from . import utility
from . import logger as log

def header (title):
    return ("\n"
            "================================\n"
            "%s\n" % title +
            "================================\n")

def report_txt (report_d, report_cfg):
    text = "start: %s\n" % utility.epoch_to_datetime(report_d['start'], local=True).strftime('%m-%d-%Y %H:%M %Z')
    text += "end: %s\n" % utility.epoch_to_datetime(report_d['end'], local=True).strftime('%m-%d-%Y %H:%M %Z')
    if report_d['group']:
        text += "end: %s\n" % report_d['group']

    report_d = {x:y for x,y in report_d.items() if x in report_cfg}

    if 'throughput' in report_d:
        tput_d = report_d['throughput']

        text += header("Throughput")

        if 'rx' in tput_d:
            text += "Download Total: %.2f GB\n" % tput_d['rx']['total']
            text += "Download Peak: %.2f Mbps\n" % tput_d['rx']['peak']
        if 'tx' in tput_d:
            text += "Upload Total: %.2f GB\n" % tput_d['tx']['total']
            text += "Upload Peak: %.2f Mbps\n" % tput_d['tx']['peak']

    if 'clientCount' in report_d:
        clientCount_d = report_d['clientCount']

        text += header("Client Count")

        if 'total_peak' in clientCount_d:
            text += "Total Peak: %d clients\n" % clientCount_d['total_peak']
        if '2.4GHz_peak' in clientCount_d:
            text += "2.4GHz Peak: %d clients\n" % clientCount_d['2.4GHz_peak']
        if '5GHz_peak' in clientCount_d:
            text += "5GHz Peak: %d clients\n" % clientCount_d['5GHz_peak']
        if 'probing_peak' in clientCount_d:
            text += "Probing Peak: %d clients\n" % clientCount_d['probing_peak']

    if 'zero_clients' in report_d:
        zero_d = report_d['zero_clients']
        text += header("Zero Clients")

        categories = ['total', '2.4GHz', '5GHz']
        for category in categories:
            # total
            if len(zero_d[category]):
                text += "%s:\n" % category
                for device_name in zero_d[category]:
                    text += "\t%s\n" % device_name

    if 'visitors' in report_d:
        visitors_d = report_d['visitors']

        text += header("Visitors")

        text += "New: %d\n" % visitors_d['new']
        text += "Repeat: %d\n" % visitors_d['repeat']
        text += "Total: %d\n" % visitors_d['total']

    if 'conditions' in report_d:
        d = report_d['conditions']

        columns = ["Device", "Severity", "Message", "Duration"]

        lines = []

        # add the header line
        lines.append(columns)

        # add the underline for the header line
        line = []
        for column in columns:
            underline = "=" * len(column)
            line.append(underline)
        lines.append(line)

        for x in d:
            lines.append([x['device'],
                          log.sev_name[x['severity']],
                          x['message'],
                          utility.epoch_delta_str(x['timestamp']/1000, time.time())])

        text += header("Current Conditions")
        text += utility.print_table(lines)

    if 'device_issues' in report_d:
        d = report_d['device_issues']['data']
        sev_id_l = report_d['device_issues']['sev_id_l']
        sev_id_l = sorted(sev_id_l, reverse=True)

        columns = ["Device"]
        for sev_id in sev_id_l:
            sev_name = log.sev_name[sev_id]
            columns.append(sev_name.capitalize() + "s")

        lines = []

        # add the header line
        lines.append(columns)

        # add the underline for the header line
        line = []
        for column in columns:
            underline = "=" * len(column)
            line.append(underline)
        lines.append(line)

        for device_name, device_d in d.items():
            line = [device_name]
            for sev_id in sev_id_l:
                sev_name = log.sev_name[sev_id]
                if sev_name in device_d:
                    line.append(str(device_d[sev_name]))
                else:
                    line.append("-")

            lines.append(line)

        text += header("Device Issues")
        text += utility.print_table(lines)

    if 'syslogs' in report_d:
        logs = report_d['syslogs']
        columns = ["Timestamp", "Severity", "Message"]

        lines = []

        # add the header line
        lines.append(columns)

        # add the underline for the header line
        line = []
        for column in columns:
            underline = "=" * len(column)
            line.append(underline)
        lines.append(line)

        # table_body
        lines += logs

        text += header("System Logs")
        text += utility.print_table(lines)

    return text
