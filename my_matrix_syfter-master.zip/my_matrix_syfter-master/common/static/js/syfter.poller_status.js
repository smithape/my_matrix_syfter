function loadSystemStatusPopup()
{
    var html_text = '';
    html_text += '<div id="system_status">';
    html_text += getSystemStatusHTML();
    html_text += '</div>';

    fancybox(html_text);

    $('#system_status').css({
    	'max-height': window.innerHeight * 0.9 - 100
    });
}

function getSystemStatusHTML() {
   var sys_status = getJSON(utility.api_url('system_status'));

    /* system status */
    var html = '<table class="popup_table">'+
	'<tr><th colspan=12 class="label1">Server Status</th></tr>'+
	'<tr><th colspan=12 class="label2">CPU</th></tr>'+
	'<tr>'+
	'<th colspan=3 class="col-hdr">Cores</th>'+
	'<th colspan=3 class="col-hdr">1m Usage</th>'+
	'<th colspan=3 class="col-hdr">5m Usage</th>'+
	'<th colspan=3 class="col-hdr">15m Usage</th>'+
	'</tr>'+
	'<tr>'+
	'<td colspan=3>'+sys_status.cpu.count+'</td>'+
	'<td colspan=3>'+sys_status.cpu.usage_1m+'%</td>'+
	'<td colspan=3>'+sys_status.cpu.usage_5m+'%</td>'+
	'<td colspan=3>'+sys_status.cpu.usage_15m+'%</td>'+
	'</tr>'+
	'<tr><th colspan=12 class="label2">Memory</th></tr>'+
	'<tr>'+
	'<th colspan=3 class="col-hdr">Usage</th>'+
	'<th colspan=3 class="col-hdr">Total</th>'+
	'<th colspan=3 class="col-hdr">Used</th>'+
	'<th colspan=3 class="col-hdr">Free</th>'+
	'</tr>'+
	'<tr>'+
	'<td colspan=3>'+sys_status.memory.usage+'%</td>'+
	'<td colspan=3>'+sys_status.memory.total+' GB</td>'+
	'<td colspan=3>'+sys_status.memory.used+' GB</td>'+
	'<td colspan=3>'+sys_status.memory.free+' GB</td>'+
	'</tr>'+
	'<tr><th colspan=12 class="label2">Disk</th></tr>'+
	'<tr>'+
	'<th colspan=3 class="col-hdr">Usage</th>'+
	'<th colspan=3 class="col-hdr">Total</th>'+
	'<th colspan=3 class="col-hdr">Used</th>'+
	'<th colspan=3 class="col-hdr">Free</th>'+
	'</tr>'+
	'<tr>'+
	'<td colspan=3>'+sys_status.disk.usage+'%</td>'+
	'<td colspan=3>'+sys_status.disk.total+' GB</td>'+
	'<td colspan=3>'+sys_status.disk.used+' GB</td>'+
	'<td colspan=3>'+sys_status.disk.free+' GB</td>'+
	'</tr>'+
	'<tr><th colspan=12 class="label2">Database</th></tr>'+
	'<tr>'+
	'<th colspan=4 class="col-hdr">Total</th>'+
	'<th colspan=4 class="col-hdr">Table</th>'+
	'<th colspan=4 class="col-hdr">Index</th>'+
	'</tr>'+
	'<tr>'+
	'<td colspan=4>'+sys_status.db.total+' GB</td>'+
	'<td colspan=4>'+sys_status.db.table+' GB</td>'+
	'<td colspan=4>'+sys_status.db.index+' GB</td>'+
	'</tr>'+
	'</table>';

    return html
}

function getPollerStatusHTML () {
    if (glb.status_data == false) return no_connection_str;
    else if ($.isEmptyObject(glb.status_data)) return no_status_str;
    var html = "";

    /* write performance */
    var poll_timer = glb.status_data.stats.poll_timer;
    var poll_rate = glb.status_data.stats.poll_rate;
    var write_rate = glb.status_data.stats.write_rate;
    var uptime = getTimeDiffString(glb.status_data.start_time, undefined, undefined, false);
    // html += '<div style="background-color:#ccc;">'+
    // 	'<h2 style="color:#424242;">Performance</h2>'+
    html += '<table class="popup_table">'+
	'<tr><th colspan=2 class="label1">Polling Engine Status</th></tr>'+
	'<tr><th colspan=2 class="label2">Performance</th></tr>'+
	'<tr><th class="row-hdr">Uptime</th><td id="poller_status_uptime">'+uptime+'</td></tr>'+
	'<tr><th class="row-hdr">Poll Time</th><td id="poller_status_poll_time">'+poll_timer+'s</td></tr>'+
	'<tr><th class="row-hdr">Poll Rate</th><td id="poller_status_poll_rate">'+poll_rate+' sample/s</td></tr>'+
	'<tr><th class="row-hdr">Write Rate</th><td id="poller_status_write_rate">'+write_rate+' sample/s</td></tr>'+
	'<tr><th class="row-hdr">Poll:Write</th><td id="poller_status_poll_write">'+(poll_rate/write_rate).toLocaleString()+'</td></tr>'+
	'</table>';

    /*
     * DB Status
     */
    html += '<table class="popup_table">'+
	'<tr><th colspan=10 class="label2">DB Status</th></tr>';

    var db_status_d = glb.status_data.db_status;

    for (var key in db_status_d) {
	var status = db_status_d[key];
	var status = glb.status_data.db_status[key];
	var cls = 'green_shade';
	if (['ok'].indexOf(status) < 0) {
	    cls = 'error_light';
	}

	html += '<tr class="'+cls+'"><th class="row-hdr">'+key+'</th>'+
	    '<td>'+(status || "down")+'</td></tr>';
    }

    /*
     * Device Count
     */
    var counters = glb.status_data.counters;
    var dtype_l = Object.keys(counters);

    html += '<table class="popup_table">'+
	'<tr><th colspan=10 class="label2">Device Count</th></tr>';

    // set the header
    html += '<tr>';
    for (var i = 0; i < dtype_l.length; i++) {
	html += '<tr><th class="row-hdr">'+dtype_l[i]+'</th>'+
	    '<td>'+counters[dtype_l[i]]+'</td></tr>';
    }
    html += '</tr>';
    // html += '<tr>';
    // // add counts
    // for (var i = 0; i < dtype_l.length; i++) {
    // 	if (i > 4) {
    // 	    html += '</tr><tr>';
    // 	}
    // 	html += '<td>'+counters[dtype_l[i]]+'</td>';
    // }
    // html += '</tr>'+
    html += '</table>';

    /*
     * Issues
     */
    var issue_d = glb.status_data['issues'];
    var issue_l = [];
    for (var key in issue_d) {
	var issue = issue_d[key];
	issue_l.push({
	    'sev': issue['sev'],
	    'msg': issue['msg'],
	    'count': issue['devices'].length,
	    'devices': issue['devices']
	});
    }
    issue_l.sort(function(a, b) {return b['sev'] - a['sev'];});
    /* error messages */
    if (issue_l.length) {
	html += '<div id="status_msg"><table id="issues_tbl" class="popup_table">'+
	    '<tr><th colspan=3 class="label2">Issues</th></tr>';
	for (var i = 0; i < issue_l.length; i++) {
	    var issue = issue_l[i];
	    var msg = issue['msg'];
	    var count = issue['count'];
	    var sev = issue['sev'];
	    var cls = '';

	    var img_html = ''
	    switch (sev) {
	    case 30: // warning
		cls = 'warning_light';
		img_html += '<svg height="10" width="10">'+
		    '<circle cx="5" cy="5" r="5" fill="yellow"/></svg>';
		break;
	    case 40: // error
		cls = 'error_light';
		img_html += '<svg height="10" width="10">'+
		    '<circle cx="5" cy="5" r="5" fill="red"/></svg>';
		break;
	    case 50: // critical
		cls = 'error';
		img_html += '<svg height="10" width="10">'+
		    '<circle cx="5" cy="5" r="5" fill="red"/></svg>';
		break;
	    }

	    html += '<tr class="'+cls+' clickable"><td class="minify noborder" style="background: #bbb">' + img_html +
		'</th><td class="minify">'+count+'&times</td>'+
		'<td style="text-align:left">'+msg+'</td></tr>';
	    // html += '<tr class="noborder" hidden>';
	    // html += '<td colspan=2 /><td style="text-align:left"><ul>';

	    /* is the device list visible? */
	    var visible = $('#issues_tbl td').filter(function() {
		return $(this).text() == msg;
	    }).closest('tr').next().is(':visible');

	    issue['devices'].sort();
	    for (var j = 0; j < issue['devices'].length; j++) {
		var device_name = issue['devices'][j];
		html += '<tr class="noborder minify"';
		if (!visible) {
		    html += ' hidden';
		}

		html += '><td class="minify" colspan=2><td style="text-align:left">';
		// make the device_name a link?
		if (device_name in glb.device_d) {
		    html += '<span class="device_popup">'+device_name+'</span>';
		} else {
		    html += device_name;
		}
		html += '</td></tr>';
	    }
	    html += '</ul></td>';
	}
	html += "</table></div>";
    }

    return html
}

function getPollerCtrlHTML() {
    var html = '';
    if (glb.status_data) {
	if (glb.status_data.status == "running") {
	    html += '<button class="std_button wide poller_ctrl" id="stop_btn" value="poller_stop">Stop</button>';
	    html += '<button class="std_button wide poller_ctrl" id="restart_btn" value="poller_restart">Restart</button>';
	}
    } else {
	html += '<button class="std_button wide poller_ctrl" id="start_btn" value="poller_start">Start</button>';
    }
    return html;
}

function loadPollerStatusPopup()
{
    var html = '';

    try {
	status = glb.status_data.status
    } catch (err) {}
    html += '<div id="poller_status">';

    /* status logic */
    if (glb.status_data == false) {
	html += no_connection_str;
    } else if (glb.status_data) {
	if (glb.status_data.status == "running") {
	    if (!glb.poller_query_pending) {
		html += getPollerStatusHTML();
	    }
	} else {
	    html += getStatusString(glb.status_data.status);
	}
    } else if (!glb.poller_query_pending) {
	html += no_status_str;
    }

    html += '</div>';
    /* buttons */
    html += '<div id="poller_ctrl" class="center" style="padding-top: 10px">';
    html += getPollerCtrlHTML();
    html += '</div>';

    fancybox(html)

    $('#poller_status').css({
    	'max-height': window.innerHeight * 0.9 - 100
    });
}

function getStatusString(status) {
    var str = '';

    if (status) {
	return status + "...";
    } else {
	return "";
    }
}

function updatePollerStatus (){
    try {
	clearTimeout(glb.poller_status_timer);
    } catch (err) {}

    var url = utility.api_url("poller_status");
    $.getJSON(url)
	.done(function(status_data) {
	    /* store the status data */
	    glb.status_data = status_data;
	    if (status_data) { // POLLER RESPONDED

		// check if we're restarting and haven't gone down yet
		if (glb.poller_query_pending && glb.status_data.start_time == glb.poller_start_time) {
		    return;
		} else {
		    /* the poller query has completed */
		    glb.poller_query_pending = null;
		    glb.poller_start_time = status_data.start_time;
		}

		// set the circle green
		$("#status_btn").attr("src", static_root+"/img/circle_g.svg");

		if (status_data.status == "running") {
		    /* update the device list */
		    if (glb.update_required) {
			deviceListUpdate();
			conditionsUpdate();
			glb.update_required = false;
		    }
		    /* reset to a longer refresh period */
		    refresh_period = 10000;
		    /* set the status color */
		    // first, the write ratio
		    var ratio = status_data.stats.poll_rate / status_data.stats.write_rate;
		    // next, the db status
		    var db_issue = false;

		    for (var key in glb.status_data.db_status) {
			var status = glb.status_data.db_status[key];
			if (['ok'].indexOf(status) < 0) {
			    db_issue = true;
			    break;
			}
		    }

		    if (ratio > 1 || db_issue) {
			$("#status_btn").attr("src", static_root+"/img/circle_r.svg");
		    } else if (ratio > 0.9) {
			$("#status_btn").attr("src", static_root+"/img/circle_y.svg");
		    }
		    /* update status (if popup exists) */
		    if ($("#poller_status").length) {
			$("#poller_status").html(getPollerStatusHTML());
			$.fancybox.update();
		    }
		} else {
		    /* set the device list update flag */
		    glb.update_required = true;
		    /* decrease refresh period for more frequent upates */
		    refresh_period = 1000;
		    /* update status (if popup exists) */
		    if ($("#poller_status").length) {
			$("#poller_status").html(getStatusString(status_data.status));
			$.fancybox.update();
		    }
		}
	    } else { // POLLER NO RESPONSE
		if (!glb.poller_query_pending || glb.poller_query_pending == "stop") {
		    /* the poller query has completed */
		    glb.poller_query_pending = null;
		    /* set the device list update flag */
		    glb.update_required = true;
		    /* reset to a longer refresh period */
		    refresh_period = 10000;
		    /* update status (if popup exists) */
		    if ($("#poller_status").length) {
			$("#poller_status").html(no_status_str);
			$.fancybox.update();
		    }
		    $("#status_btn").attr("src", static_root+"/img/circle_w.svg");
		}
	    }
	})
	.fail(function() { // SERVER NO RESPONSE
	    glb.status_data = false;
	    /* set the device list update flag */
	    glb.update_required = true;
	    /* reset to a longer refresh period */
	    refresh_period = 10000;
	    if ($("#poller_status").length) {
		$("#poller_status").html(no_connection_str);
		$.fancybox.update();
	    }
	    $("#status_btn").attr("src", static_root+"/img/circle_w.svg");
	})
	.always(function() {
	    /* update buttons */
	    if (!glb.poller_query_pending) {
		$("#poller_ctrl").html(getPollerCtrlHTML());
	    }
	    /* schedule the next iteration */
	    glb.poller_status_timer = setTimeout(updatePollerStatus, refresh_period);
	})
}

$(document).ready(function(){
    /* start the poller status poller */
    updatePollerStatus();

    /* issues table */
    $(document).on('click', '#issues_tbl tr.clickable', function() {
	var row = $(this).next('tr');
	if (row.is(':visible')) {
	    $(this).nextUntil('tr:not(.noborder)').hide();
	} else {
	    $(this).nextUntil('tr:not(.noborder)').show();
	}
 	$.fancybox.update();
    });

    $(document).on('click', '#sys_status_btn', function(e) {
	loadSystemStatusPopup();
    });

    $(document).on('click', '#status_btn', function(e) {
	loadPollerStatusPopup();
    });

    /* poller start/stop/restart */
    $(document).on('click', '#start_btn, #stop_btn, #restart_btn', function() {
	var id = $(this).attr('id');
	var query = id.replace("_btn", "");

	// prevent updating
	clearTimeout(glb.poller_status_timer);
	// update the popup
	if ($("#poller_status").length) {
	    $("#poller_status").html(getStatusString("submitting request"));
	    $('#poller_ctrl').html('');
	    $('#status_btn').attr("src", static_root+"/img/circle_w.svg");
	    $.fancybox.update();
	}
	glb.poller_query_pending = query;
	var url = utility.api_url("poller_control", [query]);
	$.post(url);
	/* decrease refresh period for more frequent upates */
	refresh_period = 1000;
	/* update after a short delay */
	setTimeout(
	    function() {
		updatePollerStatus();
	    }, 1000)
    });
});

no_status_str = "The polling engine is not running";
no_connection_str = "No connection";
refresh_period = 10000;
