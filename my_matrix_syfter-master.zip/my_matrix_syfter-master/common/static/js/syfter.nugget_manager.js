/*
 * Initialize the module options
 */
var nugget_browser = {
    cache: [],
    show_unused: false,
    device_name: "",
    dtype: "Device",
    device_l: [],
    device_d: {},
    nugget: {},
    yaml: '',
    raw: false,
    shade: null,
    sock: null,
    sock_url: utility.ws_url('nugget_test'),
    option_cfg: {
	type: {
	    type: 'select',
	    help: "Select which type of Nugget...<br>"+
		"<b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;cli</b>: Run a CLI command and parse the response<br>"+
		"<b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;rest</b>: Send a REST query and parse the response<br>"+
		"<b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;snmp</b>: Send an SNMP query (GET/WALK) and parse the response<br>"+
		"<b>&nbsp;&nbsp;formula</b>: Combine multiple Nuggets using a formula<br>"+
		"<b>&nbsp;&nbsp;&nbsp;&nbsp;group</b>: Group multiple Nuggets (used for brevity in the polling policy",
	    options: ['cli', 'file', 'snmp', 'rest', 'grpc', 'group', 'formula', 'constant', 'function'],
	    options_d: {
		cli: ['command', 'lines', 'parser', 'timeout'],
		file: ['path', 'comment_style', 'parser'],
		snmp: ['oid', 'query_type', 'timeout', 'retries'],
		rest: ['url', 'http_method', 'timeout'],
		grpc: ['proto', 'rpc', 'args'],
		formula: ['formula', 'index', 'dependencies', 'default_value'],
		group: ['members', 'aggregate'],
		constant: ['value'],
		function: ['arguments', 'code'],
	    },
	    nest_color: '#bbdecc',
	    nest_header: function(nugget) {return pretty_name[nugget.type] + ' Settings'},
	    nest_advanced: function (nugget) {return ['cli', 'rest', 'grpc', 'snmp'].includes(nugget.type)},
	    reset_form: true
	},
	datatype: {
	    type: 'select',
	    help: "Select the data type/units for this Nugget.",
	    options: {'time_series': 'Time Series',
		      'json': 'JSON',
		      'text': 'Text',
		      'log': 'Log'},
	    reset_form: true
	},
	unit: {
	    type: 'select',
	    help: "Select the data type/units for this Nugget.",
	    get_options: function(nugget) {
		var opt_d = {};
		for (var category in glb.config.nugget.unit_cfg) {
		    opt_d['['+category+']'] = category;
		    var unit_cfg = glb.config.nugget.unit_cfg[category];
		    for (var key in unit_cfg) {
			var entry = unit_cfg[key];
			opt_d[key] = entry.label || key.capitalize();
		    }
		}
		return opt_d;
	    },
	    default: 'number',
	    condition: function(nugget) {return (nugget.datatype == "time_series")},
	},
	description: {
	    type: 'text',
	    help: "Write a human-readable description of this Nugget.",
	},
	// SNMP
	oid: {
	    type: 'input',
	    help: "Specify the OID to use in the SNMP query.",
	    placeholder: 'Example: 1.3.6.1.2.1.1.1'
	},
	query_type: {
	    type: "select",
	    options: ['get', 'walk', 'bulkwalk'],
	    default: 'get',
	    hide_default_indicator: true,
	    options_d: {
		get: [],
		walk: ['type_filter', 'oid_style', 'index_decoder'],
		bulkwalk: ['type_filter', 'oid_style', 'index_decoder', 'max_repititions'],
	    },
	    help: "Select the SNMP query type.",
	    reset_form: true
	},
	timeout: {
	    type: 'number',
	    min: 1,
	    get_placeholder: function(nugget) {
		return 'default: ' + glb.config.config.tool[nugget.type+'_timeout'] + ' (seconds)';
	    },
	    help: "Specify the query timeout (in seconds).",
	    advanced: "type",
	},
	retries: {
	    type: 'number',
	    min: 0,
	    get_placeholder: function(nugget){
		return 'default: ' + glb.config.config.tool.snmp_retries;
	    },
	    help: "Specify the number of query retries.",
	    advanced: "type",
	},
	max_repititions: {
	    type: 'number',
	    min: 1,
	    get_placeholder: function(nugget) {
		return 'default: ' + glb.config.config.tool.snmp_bulkwalk_reps;
	    },
	    help: "Specify 'max repititions' for each getbulk query.",
	    advanced: "type",
	},
	oid_style: {
	    type: 'select',
	    help: "Select a style for the oid keys.",
	    options: ['simplified', 'name', 'path'],
	    reset_form: true,
	},
	type_filter: {
	    type: 'select_multiple',
	    help: "Select which data types to include.",
	    options: ['Counter', 'Integer', 'String', 'Gauge', 'TimeTicks', 'IP Address'],
	},
	index_decoder: {
	    type: 'input',
	    help: "Give a pointer to Nugget entry which produces a dictionary which can<br>be used to convert object indexes (eg. object_name.14) to names.",
	    placeholder: "nugget_name"
	},
	// REST
	url: {
	    type: 'text',
	    help: "Specify which URL to use in the REST query."
	},
	http_method: {
	    type: "select",
	    options: ['GET', 'POST'],
	    default: 'GET',
	    hide_default_indicator: true,
	    options_d: {
		GET: [],
		POST: ['body'],
	    },
	    help: "Select the HTTP request method.",
	    reset_form: true
	},
	body: {
	    type: 'text',
	    help: "The data field for a HTTP POST",
	    tab_indent: true
	},
	// GRPC
	proto: {
	    type: 'text',
	    help: "Insert the protocol buffer definition (ie. the .proto file)",
	    reset: ['rpc'],
	},
	rpc: {
	    type: 'select',
	    get_options: function(nugget) {
		var opts = [];
		if (nugget.proto) {
		    var match_l = nugget.proto.matchAll(/\n\s*rpc\s+(\w+)/g);
		    for (let match of match_l) {
			opts.push(match[1])
		    }
		}
		return opts;
	    },
	    help: "Specify the rpc function call"
	},
	args: {
	    type: 'text',
	    help: 'The arguments for the rcp function call',
	},
	// Constant
	value: {
	    type: 'text',
	    help: "Give the value for this constant",
	},
	// Function
	code: {
	    type: 'text',
	    help: "The function body",
	    tab_indent: true,
	},
	arguments: {
	    type: 'text',
	    help: "The function arguments",
	},
	// Group
	members: {
	    type: 'list',
	    help: "Specify a list of group members (other Nugget names).",
	    placeholder: "{nugget_name_a}, {nugget_name_b}..."
	},
	aggregate: {
	    type: "select",
	    options: ['sum', 'dictionary'],
	    help: "Whether or not to aggregate all children into a new Nugget.",
	    reset_form: true
	},
	// Forumla
	formula: {
	    type: 'text',
	    help: "Specify a pythonic expession to combine multiple Nuggets.",
	    placeholder: "{nugget_name_a} / {nugget_name_b}",
	    tab_indent: true
	},
	index: {
	    type: 'text',
	    help: "If the formula uses Nuggets with dynamic indexes, we need to know the index list/dictionary.",
	    placeholder: "nugget_name"
	},
	dependencies: {
	    type: 'list',
	    help: "Typically the dependencies are discovered automatically by parsing the formula. Use this<br>"+
		"option to manually specify a list of dependencie Nuggets instead.",
	    placeholder: "{nugget_name_a}, {nugget_name_b}"
	},
	// File
	path: {
	    type: 'text',
	    help: 'Specify the file path',
	},
	comment_style: {
	    type: 'select',
	    options: ['#', '//', ';'],
	    help: "Specify the comment character in order to filter out comment lines"
	},
	// CLI
	command: {
	    type: 'text',
	    help: 'Give the CLI command to be executed.',
	    tab_indent: true,
	},
	lines: {
	    type: 'input',
	    help: 'Filter by line number...<br>'+
		'&nbsp;&nbsp;<b>"auto":</b> automatically guess which lines to include.<br>'+
		'&nbsp;&nbsp;&nbsp;<b>"all":</b> keep all lines.<br>'+
		'&nbsp;&nbsp;<b>manual:</b> manually specify which lines to keep (e.g. "1,3,5-7" or "4 - -2").',
	    placeholder: 'auto'
	},
	parser: {
	    type: "select",
	    help: 'Select a CLI parser...<br>'+
		'&nbsp;&nbsp;&nbsp;&nbsp;<b>regex:</b> use regular expressions to extract the data.<br>'+
		'&nbsp;&nbsp;<b>textfsm:</b> use a textFSM template to extract data.<br>'+
		'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>json:</b> parse the text as JSON.<br>'+
		'&nbsp;&nbsp;&nbsp;<b>keyval:</b> parse the text as a list of key/value pairs (common in config files).<br>'+
		'&nbsp;&nbsp;&nbsp;&nbsp;<b>table:</b> parse the text as an ascii-based table.',
	    options: {
		'[regex]': "Regex-Based",
		'regex': 'Regular Expression',
		'textfsm': "TextFSM",
		'[cli]': "CLI Output",
		'keyval': "Key/Value",
		'table': "ASCII table",
		'[cfg]': "Config Format",
		'apache': 'Apache',
		'csv': 'CSV',
		'ini': "INI",
		'json': "JSON",
		'yaml': 'YAML',
	    },
	    options_d: {
		regex: ['expression', 'findall', 'match_required'],
		table: ['delimiter', 'headers'],
		keyval: ['delimiter', 'as_list', 'comment_style',
			'group_start_regex', 'group_end_regex'],
		textfsm: ['template'],
		csv: ['headers_included', 'headers'],
	    },
	    nest_color: '#dec0c0;',
	    nest_header: function() {return pretty_name[nugget_browser.nugget.parser] + ' Parser Settings'},
	    reset_form: true
	},
	regex: {
	    expression: {
		type: 'input',
		help: 'Specify a regular expression to use.'
	    },
	    findall: {
		type: 'boolean',
		help: "Find all regex results (instead of just one)."
	    },
	    match_required: {
		type: 'boolean',
		help: "If a match is required, an error will occur when one<br>"+
		    "isn't found (and processing will stop)."
	    },
	},
	textfsm: {
	    template: {
		type: 'text',
		help: 'Specify a TextFSM template to use for parsing the text.'
	    },
	},
	apache: {
	},
	keyval: {
	    delimiter: {
		type: 'select',
		options: ['=', ':', 'space'],
		help: "Specify the delimiter between key and value",
		default: "=",
		hide_default_indicator: true,
	    },
	    as_list: {
		type: 'boolean',
		help: 'If keys are repeated (ie. in the case of a list of similar entries)'
	    },
	    comment_style: {
		type: 'select',
		options: ['#', '//', ';'],
		help: "Specify the comment character in order to filter out comment lines"
	    },
	    group_start_regex: {
		type: 'input',
		help: 'Specify a regular expression used to test if this is a group<br>'+
		    'start line (and extract the group name using a regex group)<br>'+
		    'INI style Example: ^\[(.*)\]$',
	    },
	    group_end_regex: {
		type: 'input',
		help: 'Specify a regular expression used to test if this is a group<br>'+
		    'end line (used together with group_start_regex)',
	    },
	},
	table: {
	    delimiter: {
		type: 'input',
		help: "A regular expression used to divide table columns"
	    },
	    headers: {
		type: 'list',
		help: "Manually specify the column headers (in case automatic parsing fails)"
	    },
	},
	csv: {
	    headers_included: {
		type: 'boolean',
		help: "Specify whether to interpret row 1 as headers",
	    },
	    headers: {
		type: 'list',
		help: 'Manually specify the column headers',
	    },
	},
	default_value: {
	    type: 'text',
	    help: "Define a default value to be used when collection fails.<br>"+
		"Otherwise, no data is collected.",
	},
	process: {
	    type: 'text',
	    help: "Modify the data (represented by {x}) with a pythonic expression.",
	    placeholder: "Example: {x} * 2",
	    tab_indent: true
	},
	post_process: {
	    type: 'text',
	    help: 'Modify the data (represented by {x}) with a pythonic expression.<br>'+
		'This is the final processing step. It occurs after splitting and incremental processing.',
	    placeholder: "Example: {x} * 2",
	    condition: function(nugget) {return nugget.split || nugget.incremental_process;},
	},
	incremental_process: {
	    type: 'select',
	    options: {'delta': 'Delta',
		      'counter_delta': 'Counter-to-delta',
		      'counter32_delta': 'Counter-to-delta (32-bit)',
		      'counter64_delta': 'Counter-to-delta (64-bit)',
		      'counter': 'Counter-to-rate',
		      'counter32': 'Counter-to-rate (32-bit)',
		      'counter64': 'Counter-to-rate (64-bit)',
		      'timestamped_entries': 'Timestamped Entries (ignore previously parsed)'},
	    help: "Incremental processing presets for certain sample types",
	    reset_form: true
	},
	// key_filter: {
	//     type: 'list',
	//     help: 'Specify which fields to include',
	// },

	split: {
	    type: 'boolean',
	    help: "Do you want to split this up into multiple Nuggets?",
	    reset_form: true
	},
	split_method: {
	    type: 'select',
	    help: "What method should be used for splitting?",
	    options: {'hierarchy': 'hierarchy-based', 'object': 'object-based'},
	    default: 'hierarchy',
	    reset_form: true,
	    condition: function(nugget) {return nugget.split},
	},
	split_format: {
	    type: 'input',
	    help: "Define the naming format to use when splitting (using the {index} and {nugget_name} variables)",
	    placeholder: "Default: {nugget_name}:{index}",
	    condition: function(nugget) {return nugget.split && (!nugget.split_method || nugget.split_method == "hierarchy")},
	},
    }
};

var pretty_name = {
    "cli": "CLI",
    "file": "File",
    "rest": "REST",
    "grpc": "GRPC",
    "snmp": "SNMP",
    "group": "Group",
    "constant": "Constant",
    "formula": "Formula",
    'function': "Function",
    "textfsm": "TextFSM",
    "table": "Table",
    "keyval": "Key/Value",
    "json": "JSON",
    "csv": "CSV",
    "ini": "INI",
    "apache": "Apache",
    "regex": "RegEx"
};

var option_sort_l = [
    'description',
    'datatype',
    'unit',
    'type',
    'command',
    // group
    'members',
    'aggregate',
    // snmp
    'oid',
    'query_type',
    // formula
    'formula',
    // rest
    'url',
    'http_method',
    'body',
    'new_root',
    'parser',
    'regex',
    'table',
    'textfsm',
    'keyval',
    'json',
    'expression',
    'findall',
    'match_required',
    'children',
    'process',
    'sample_type',
    'split',
    'split_method',
    'incremental_process',
    'post_process',
]

function getJSON(url) {
    var json = null;
    $.ajax({
        'async': false,
        'global': false,
        'url': url,
        'dataType': "json",
        'success': function (data) {
            json = data;
        }
    });
    return json;
}

/*
 * Functions for handling the websockets connection
 */

/* send a websockets query (for nugget testing) */
nugget_browser.send_query = function () {
    var params = {
	device_name: nugget_browser.device_name,
	nugget_name: nugget_browser.nugget_name,
	nugget_cfg: nugget_browser.nugget,
	nugget_cfg_full: nugget_browser.cfg_after,
    };
    nugget_browser.sock.send(JSON.stringify(params));
}

/* handle websockets response (for nugget testing) */
nugget_browser.sock_rx = function (e) {
    var self = nugget_browser;

    //$('#term_space').text($('#term_space').text() + (e.data));
    if (e.data == "done") {
	$('#nugget_browser #submit_btn').prop('disabled', false);
	return
    }

    $('#response').append("\n"+e.data);
    $('#response').scrollTop($('#response')[0].scrollHeight);
    $('.code:not(.json-document)').each(function() {
	try {
	    var text = $(this).text();
	    var line_count = text.split("\n").length;
	    var json_data = JSON.parse(text);
	    var collapse = (line_count > 20);
	    $(this).jsonViewer(json_data, {collapsed: collapse, withLinks: false});
	    // add the expand/collapse button
	    if (line_count > 1) {
		$(this).before('<div style="width: 100%; text-align: right; padding-top: 5px;">'+
			       '<div style="position: relative">'+
			       '<span class="expand_json">'+(collapse ? '+':'-')+'</span></div></div>');
	    }
	    // add the table button
	    if (table_viewer.is_tabular(json_data)) {
		$('#response').append('<div style="width: 100%; text-align: right; padding-top: 5px;">'+
				      '<div style="position: relative">'+
				      '<button class="std_button view_as_table" id="view_as_table_'
				      +self.cache.length+'">View as Table</button></div></div>');
	    }
	    self.cache.push(json_data);
	} catch {}
    });
}

/* close the websocket connection */
nugget_browser.sock_close = function (e) {
    // disable the test button until we reconnect
    $('#nugget_browser #submit_btn')
	.prop('disabled', true)
	.text("Not Connected");

    // Try to reconnect in 5 seconds
    setTimeout(function(){
	try {
	    nugget_browser.sock_open(e.target.url);
	} catch (err) {}
    }, 1000);
}

/* when a connection is opened, enable the test button */
nugget_browser.sock_onopen = function (e) {
    // enable the test button
    $('#nugget_browser #submit_btn')
	.prop('disabled', false)
	.text("Test");
}

/* initialize the websocket */
nugget_browser.sock_open = function (url) {
    nugget_browser.sock = new WebSocket(url);

    // set websocket handlers
    nugget_browser.sock.onmessage = nugget_browser.sock_rx;
    nugget_browser.sock.onclose = nugget_browser.sock_close;
    nugget_browser.sock.onopen = nugget_browser.sock_onopen;
}

nugget_browser.set_yaml = function () {
    var self = nugget_browser;

    if (Object.entries(self.nugget).length === 0) {
	self.yaml = '';
    } else {
	self.yaml = jsyaml.dump(self.nugget,
				{
				    indent:4,
				    sortKeys: function (a, b) {
					return option_sort_l.indexOf(a) - option_sort_l.indexOf(b);
				    }
				});
    }
}


nugget_browser.getDeviceList = function (){

    var url = utility.api_url("device_list");
    var params = {"static": true};

    $.getJSON(url, params)
	.done(function(device_l) {
	    var device_d = {};
	    for (var i=0; i < device_l.length; i++) {
		var device = device_l[i];
		if (device.snmp_supported || device.rest_supported ||
		    device.has_login_creds || device.type == "LocalHost") {
		    device_d[device_l[i].name] = device_l[i];
		}
	    }
	    nugget_browser.device_d = device_d;
	    nugget_browser.setBrowserForm();
	})
}
nugget_browser.resetFormEl = function (name, section = "") {
    var self = nugget_browser;
    $('#nugget_'+name).closest('tr').replaceWith(self.getFormEl(name, section = section));
}

nugget_browser.getFormEl = function (name, section = "") {
    var self = nugget_browser;
    var cfg;
    var prev_val = null;

    if (section) {
	cfg = self.option_cfg[section][name];
	try {
	    prev_val = nugget_browser.nugget[section][name];
	} catch {}
    } else {
	cfg = self.option_cfg[name];
	prev_val = nugget_browser.nugget[name];
    }

    // return if advanced and hidden
    if (prev_val == null && cfg.advanced && !self[cfg.advanced + "_advanced"]) {
	return "";
    }

    var type = cfg.type || cfg;
    if (cfg.get_default) {cfg.default = cfg.get_default(self.nugget);}
    if (cfg.get_placeholder) {cfg.placeholder = cfg.get_placeholder(self.nugget);}

    // don't show if the conditions aren't met
    if (!prev_val && cfg.condition && !cfg.condition(self.nugget))
	return '';

    var html = '<tr><td class="nugget_label">'+name+':'+
	'<span style="position: relative"><span class="tooltip">'+(cfg.help || '')+'</span></span>'+
	'</td><td section="'+section+'">';

    // Select box
    if (type == "select") {
	if (cfg.get_options) {cfg.options = cfg.get_options(self.nugget);}

	html += '<select id="nugget_'+name+'" class="nugget_param">';
	// add the null value?
	if (cfg.placeholder) {
	    html += '<option value=""><i>'+cfg.placeholder+'</i></option>';
	} else if (!cfg.default) {
	    html += '<option value=""></option>';
	}

	var cfg_options = cfg.options;

	// if it's given as a list, convert to dict
	var options;
	if (cfg_options.constructor != Object) {
	    options = {};
	    for (var i = 0; i < cfg_options.length; i++) {
		var x = cfg_options[i];
		options[x] = x;
	    }
	} else {
	    options = cfg_options;
	}

	//for (var i = 0; i < options.length; i++) {
	for (var x in options) {
	    var str = options[x];

	    if (x.indexOf('[') == 0) {
		html += '<optgroup label="'+str+'">"';
		continue;
	    }

	    html += '<option value="'+x+'"';
	    // is it selected?
	    if (x == prev_val || (prev_val == null && x == cfg.default)) {
		html += ' selected';
	    }
	    html += '>'+str;
	    // is it default?
	    if (x == cfg.default && ! cfg.hide_default_indicator) {
		html += ' (default)';
	    }
	    html += '</option>';
	}
	html += '</select>';
    }
    // Multi-Select box
    else if (type == "select_multiple") {
	html += '<select multiple id="nugget_'+name+'" class="nugget_param multiple">'+
	    '<option value=""></option>';
	for (var i = 0; i < cfg.options.length; i++) {
	    var x = cfg.options[i];
	    if (prev_val != null && prev_val.indexOf(x) >= 0) {
		html += '<option value="'+x+'" selected>'+x+'</option>';
	    } else {
		html += '<option value="'+x+'">'+x+'</option>';
	    }
	}
	html += '</select>';
    }
    // Checkbox
    else if (type == "boolean") {
	html += '<input type="checkbox" class="nugget_param" id="nugget_'+name+'"';
	if (prev_val == true) {
	    html += ' checked';
	}
	html += '>';

    }
    // Textarea
    else if (type == "text") {
	var tab_indent = cfg.tab_indent ? ' tab_indent' : '';
	html += '<textarea id="nugget_'+name+'" class="nugget_param'+tab_indent+'" rows="1" placeholder="'+
	    (cfg.placeholder || '')+'">';
	if (prev_val != null) {
	    html += prev_val;
	}
	html += '</textarea>';
    }
    // List
    else if (type == "list") {
	html += '<input id="nugget_'+name+'" class="nugget_param" placeholder="'+
	    (cfg.placeholder || '')+'"';
	if (prev_val != null) {
	    try {
		html += ' value="'+prev_val.join(', ')+'"';
	    } catch {
		html += ' value="'+prev_val+'"';
	    }
	}
	html += '></input>';
    }
    // Number
    else if (type == "number") {
	html += '<input type="number" id="nugget_'+name+'" class="nugget_param"';
	var current_value = (prev_val != null) ? prev_val : cfg.default;
	if (current_value) {
	    html += ' value="'+current_value+'"';
	}
	if (cfg.min) {
	    html += ' min='+cfg.min+'';
	}
	if (cfg.max) {
	    html += ' max='+cfg.max+'';
	}
	if (cfg.placeholder) {
	    html += ' placeholder="'+cfg.placeholder+'"';
	}
	html += '></input>';
    }
    // Other
    else {
	html += '<'+type+' id="nugget_'+name+'" class="nugget_param"';
	if (prev_val != null) {
	    html += ' value="'+prev_val+'"';
	}
	html += ' placeholder="'+(cfg.placeholder || '')+
	    '"></'+type+'>';
    }

    html += "</td></tr>";

    /* get additional options */
    if (cfg.options_d) {
	var current_value = (prev_val != null) ? prev_val : cfg.default;
	if (current_value && cfg.options_d[current_value]) {
	    if (cfg.nest_header) {
		// add the nest
		html += '<tr><td colspan=2><div class="nugget_browser_wrapper" style="background: '+cfg.nest_color+'">'+
		    '<table class="std_table nostripe nugget_browser">';
		// add the header text
		html += '<tr><th colspan=2">'+cfg.nest_header(self.nugget);
		// add the advanced checkbox
		var advanced_key = name+'_advanced';
		if (cfg.nest_advanced && cfg.nest_advanced(self.nugget)) {
		    html += '<div class="advanced_select_outer"><label class="advanced_select">Show Advanced '+
			'<input class="advanced_checkbox" id="'+advanced_key+'" type="checkbox"';
		    // remember state
		    if (self[advanced_key]) {
			html += ' checked';
		    }
		    html += '></input></label></div>';
		}
		html += '</th></tr>';
	    }
	    var opt_l = cfg.options_d[current_value] || [];
	    for (var i = 0; i < opt_l.length; i++) {
		if (name == "parser") {
		    html += self.getFormEl(opt_l[i], current_value);
		} else {
		    html += self.getFormEl(opt_l[i]);
		}
	    }
	    if (cfg.nest_header) {
		html += '</td></tr></table></div></td></tr>';
	    }
	}
    }
    
    return html
}
nugget_browser.setTestForm = function () {
    var self = nugget_browser;
    var dtype_path_d = glb.config.config.dtype_path_d;

    // filter the device list by device type
    var device_name_l = [];
    for (var key in self.device_d) {
	var device = self.device_d[key];
	if (device.type in dtype_path_d) {
	    var device_dtype_path = dtype_path_d[device.type];
	    if (device_dtype_path.includes(self.dtype)) {
		device_name_l.push(device.name);
	    }
	}
    }
    device_name_l.sort();

    // automatically set the test device
    if (!device_name_l.includes(self.device_name)) {
	self.device_name = device_name_l[0];
    }

    var html;

    // Device
    if (['cli','file','snmp','rest','grpc','formula','group'].indexOf(self.nugget.type) >= 0) {
	html = '<div class="nugget_browser_wrapper" style="background: #ddd; margin-top: 10px;">'+
	    '<table class="std_table nostripe nugget_browser">'+
	    '<tr><th colspan=2>Test on Device</th></tr>'+
	    '<tr><td>Device:</td>'+
	    '<td><select id="device_select">';
	// Device select list
	for (var i = 0; i < device_name_l.length; i++) {
	    var device_name = device_name_l[i];
	    var device = self.device_d[device_name];
	    // add the dropdown option
	    if (device.name == self.device_name) {
		html += '<option value='+device.name+' selected>'+device.name+'</option>';
	    } else {
		html += '<option value='+device.name+'>'+device.name+'</option>';
	    }
	}
	html += '</select></td></tr>'+
	    '<tr '+(self.device_name ? '':"hidden")+'>'+
	    '<td colspan=3 style="text-align: center;">'+
	    '<button class="std_button" style="min-width: 80px" id="submit_btn"';
	// check if the websocket is opened
	if (self.sock.readyState === WebSocket.CLOSED) {
	    html += "disabled>Not Connected";
	} else {
	    html += ">Test";
	}
	html += '</button></td></tr>'+
	    '</table>'+
	    '<div id="response"></div>';

	$('#device_select').html(html);
	$('#nugget_test').show();
    } else {
	$('#nugget_test').hide();
	$('#device_select').empty();
	$('#response').empty();
    }
}

/*
 * Nugget Manipulation Functions
 */
nugget_browser.MoveNugget = function(new_parent, copy) {
    var self = nugget_browser;

    // enable the save button
    config_browser.modified();

    var source = self.cfg_after[self.dtype];
    var destination = self.cfg_after[new_parent];

    // find the dest name
    var i = 1;
    var dest_name = self.nugget_name;
    while (true) {
	if (!(dest_name in destination)) {
	    break
	}
	dest_name = self.nugget_name + '(copy_'+i+')';
	i++;
    }

    if (copy) {
	// copy the nugget
	destination[dest_name] = utility.deep_copy(self.nugget);
	self.nugget = destination[dest_name];
	self.dtype = new_parent;
	self.nugget_name = dest_name;
    } else {
	// move the nugget
	destination[dest_name] = self.nugget;
	delete source[self.nugget_name];
	self.dtype = new_parent;
	self.nugget_name = dest_name;
    }
}
/*
 * Device Type Manipulation Functions
 */
nugget_browser.getDeviceTypeSelector_helper = function(entry, depth, filter) {
    var self = nugget_browser;
    var html = '';
    var entry_html;
    var child_html;
    var expanded = (filter || (!self.show_unused && self.dtype_used_l.length <= 10));
    var any_in_current_path = false;

    // sort the entries
    var keys = Object.keys(entry);
    keys.sort();
    // loop through the children
    for (var i = 0; i < keys.length; i++) {
	var x = keys[i];
	var in_current_path = (!filter && self.dtype && glb.config.config.dtype_path_d[self.dtype].contains(x));
	any_in_current_path = any_in_current_path || in_current_path;

	if (!filter &&
	    !self.show_unused &&
	    self.dtype_used_l && !self.dtype_used_l.contains(x) &&
	    !in_current_path) {
	    continue
	}

	entry_html = '<li>';
	child_html = '';

	if (Object.keys(entry[x]).length > 0) {
	    depth++;
	    child_html = self.getDeviceTypeSelector_helper(entry[x], depth, filter);
	    depth--;
	    if (child_html) {
		var icon = (in_current_path || expanded || depth < 1) ? '\u25BC':'\u25B6';
		entry_html = '<li class="nested"><div class="icon">'+icon+'</div>';
	    }
	}

	// highlight if this is the current selection
	var selected = (self.dtype == x) ? " selected": "";
	entry_html += '<span class="label'+selected+'">'+x+'</span></li>';

	if (!child_html && filter && x.toLowerCase().indexOf(filter) < 0) {
	    continue;
	} else {
	    html += entry_html + child_html;
	}
    }

    if (html) {
	// wrap the list
	if (depth == 0) {
	    html = '<ul class="root">'+html+'</ul>';
	} else if (any_in_current_path || expanded || depth < 2) {
	    html = '<ul>'+html+'</ul>';
	} else {
	    html = '<ul hidden>'+html+'</ul>';
	}
    }
    return html;
}

nugget_browser.setDtypeUsed = function () {
    var self = nugget_browser;
    var cfg = glb.config.config;

    var dtype_used_l = [];
    for (var i = 0; i < cfg.dtype_l.length; i++) {
	var dtype = cfg.dtype_l[i];
	if (!$.isEmptyObject(self.cfg_after[dtype])) {
	    var path = cfg.dtype_path_d[dtype];
	    for (var j = 0; j < path.length; j++) {
		var x = path[j];
		if (!dtype_used_l.contains(x)) {
		    dtype_used_l.push(x);
		}
	    }
	}
    }
    self.dtype_used_l = dtype_used_l;
}

nugget_browser.AddDeviceType = function (dtype, parent) {
    var self = nugget_browser;
    var dtype_l = glb.config.config.dtype_l;
    var dtype_d = glb.config.config.dtype_d;
    var dtype_path_d = glb.config.config.dtype_path_d;
    var device_type_cfg = jsyaml.load(glb.config.cfg_after.device_type) || {};

    // enable the save button
    config_browser.modified();

    // see if the name already exists
    if (dtype_l.contains(dtype)) {
	utility.alertPopup("This Device Type Already Exists!");
	return false;
    } else {

	// find the tree node
	var ptr = dtype_d;
	var path = dtype_path_d[parent];
	for (var i = 0; i < path.length; i++) {
	    var node = path[i];
	    ptr = ptr[node];
	}

	// insert the new type
	device_type_cfg[dtype] = {'parent': parent};
	glb.config.cfg_after.device_type = jsyaml.dump(device_type_cfg);
	dtype_l.push(dtype);
	ptr[dtype] = {};
	dtype_path_d[dtype] = dtype_path_d[parent].concat([dtype]);
	return true;
    }
};

nugget_browser.RemoveDeviceType = function () {
    var self = nugget_browser;
    var dtype_l = glb.config.config.dtype_l;
    var dtype_d = glb.config.config.dtype_d;
    var dtype_path_d = glb.config.config.dtype_path_d;
    // convert the config text to json
    var device_type_cfg = jsyaml.load(glb.config.cfg_after.device_type) || {};

    // enable the save button
    config_browser.modified();

    // find the tree node
    var ptr = dtype_d;
    var path = dtype_path_d[self.dtype];
    for (var i = 0; i < path.length - 1; i++) {
	var node = path[i];
	ptr = ptr[node];
    }

    // find all descendants
    var children = [];
    for (var x in dtype_path_d) {
	var path = dtype_path_d[x]
	if (path.contains(self.dtype)) {
	    children.push(x);
	}
    }

    // remove the type (and all children)
    for (var i = 0; i < children.length; i++) {
	var child = children[i];
	delete device_type_cfg[child];
	dtype_l.remove(child);
	delete dtype_path_d[child];
	delete self.cfg_after[child];
    }
    glb.config.cfg_after.device_type = jsyaml.dump(device_type_cfg);
    delete ptr[self.dtype]
    self.dtype = "Device";
};

nugget_browser.MoveDeviceType = function (new_parent, copy) {
    var self = nugget_browser;
    var dtype_l = glb.config.config.dtype_l;
    var dtype_d = glb.config.config.dtype_d;
    var dtype_path_d = glb.config.config.dtype_path_d;
    var device_type_cfg = jsyaml.load(glb.config.cfg_after.device_type) || {};

    // enable the save button
    config_browser.modified();

    // get the old parent
    var old_parent = device_type_cfg[self.dtype].parent;

    // find the old tree node
    var old_ptr = dtype_d;
    var path = dtype_path_d[old_parent];
    for (var i = 0; i < path.length; i++) {
	var node = path[i];
	old_ptr = old_ptr[node];
    }
    
    // find the new tree node
    var new_ptr = dtype_d;
    var path = dtype_path_d[new_parent];
    for (var i = 0; i < path.length; i++) {
	var node = path[i];
	new_ptr = new_ptr[node];
    }

    // move/copy the type
    if (copy) {
	// find the copy name
	var i = 1;
	while (true) {
	    var copy_name = self.dtype + '(copy_'+i+')';
	    if (!dtype_l.contains(copy_name)) {
		break
	    }
	    i++;
	}

	device_type_cfg[copy_name] = {'parent': new_parent};
	glb.config.cfg_after.device_type = jsyaml.dump(device_type_cfg);
	new_ptr[copy_name] = {};
	dtype_path_d[copy_name] = dtype_path_d[new_parent].concat([copy_name]);
	self.cfg_after[copy_name] = utility.deep_copy(self.cfg_after[self.dtype] || {});
	dtype_l.push(copy_name);
	self.dtype = copy_name;
    } else {
	device_type_cfg[self.dtype] = {'parent': new_parent};
	glb.config.cfg_after.device_type = jsyaml.dump(device_type_cfg);
	new_ptr[self.dtype] = old_ptr[self.dtype];
	delete old_ptr[self.dtype];
	dtype_path_d[self.dtype] = dtype_path_d[new_parent].concat([self.dtype]);
    }
};

nugget_browser.RenameDeviceType = function (old_name, new_name) {
    var self = nugget_browser;
    var dtype_l = glb.config.config.dtype_l;
    var dtype_d = glb.config.config.dtype_d;
    var dtype_path_d = glb.config.config.dtype_path_d;
    var device_type_cfg = jsyaml.load(glb.config.cfg_after.device_type) || {};

    // enable the save button
    config_browser.modified();

    // find the old tree node
    var ptr = dtype_d;
    var parent = device_type_cfg[old_name].parent;
    var path = dtype_path_d[parent];
    for (var i = 0; i < path.length; i++) {
	var node = path[i];
	ptr = ptr[node];
    }

    // rename the type
    device_type_cfg[new_name] = {'parent': parent};
    delete device_type_cfg[old_name];
    glb.config.cfg_after.device_type = jsyaml.dump(device_type_cfg);
    ptr[new_name] = ptr[old_name];
    delete ptr[old_name];
    dtype_path_d[new_name] = dtype_path_d[parent].concat([new_name]);
    delete dtype_path_d[old_name]
    dtype_l.push(new_name);
    dtype_l.remove(old_name);
    self.cfg_after[new_name] = self.cfg_after[old_name];
    delete self.cfg_after[old_name];
    self.dtype = new_name;
};

nugget_browser.UpdateDeviceTypeTree = function (cfg) {
    var self = nugget_browser;
    var dtype_l = glb.config.config.dtype_l;

    var todo = Object.keys(cfg).length;
    var changed = true;
    while (todo > 0 && changed) {
	changed = false;
	for (var dtype in cfg) {
	    var parent = cfg[dtype].parent;

	    // see if it can be added
            if (!dtype_l.contains(dtype) &&
		dtype_l.contains(parent)) {

		// add the type
		self.AddDeviceType(dtype, parent);

		// prepare for next iteration
		changed = true;
		todo--;
            }
	}
    }
}

nugget_browser.getDeviceTypeSelector = function() {
    var self = nugget_browser;
    var dtype_l = glb.config.config.dtype_l;
    var dtype_d = glb.config.config.dtype_d;
    self.setDtypeUsed();
    self.show_unused =  (self.dtype_used_l.length == 0);

    var html = '<div id="device_type">'+
	'<input id="device_type_input" autocomplete="off"></input>'+
	'<div style="position: relative; width: calc(100% - 2px)">'+
	'<div id="device_type_browser" hidden>'+
	'<label id="show_unused_label">Show Unused <input type="checkbox" id="show_unused_checkbox"'+
	(self.show_unused ? ' checked':'')+
	'></input></label>'+
	'<div id="device_type_dropdown">'+
	self.getDeviceTypeSelector_helper(dtype_d, 0)+
	'</div></div></div></div>';
    return html
}

nugget_browser.setBrowserForm_helper = function () {
    var self = nugget_browser;
    var html;

    // Device Type
    html = '<div class="nugget_browser_wrapper" style="background: #ddd">'+
	'<table class="std_table nostripe nugget_browser">'+
	'<tr><th colspan=7>Nugget Select</th></tr>'+
	'<tr><td>Device Type:</td>'+
	'<td><span id="dtype_select_wrapper">';
    html += self.getDeviceTypeSelector();
 
   var hide = "";
    if (glb.config.config.dtype_hard_l.contains(self.dtype)) {
	hide = " hidden";
    }
 
    html += '</span>'+
	'<input id="updated_dtype_name" placeholder="Enter New Device Type" hidden />'+
	'<div id="rename_dtype_error">This device type already exists!</div>'+
	'</td>'+
	'<td class="nugget_btn">'+
	'<span title="Add Device Type" id="add_dtype_btn">'+
	'<img src="'+utility.static_url('/img/plus.svg')+'"></span></td>'+
	'<td class="nugget_btn dtype_opt"'+hide+'><span title="Remove Device Type" id="rm_dtype_btn">'+
	'<img src="'+utility.static_url('/img/minus.svg')+'"></span></td>'+
	'<td class="nugget_btn dtype_opt"'+hide+'><span title="Rename Device Type" id="rename_dtype_btn">'+
	'<img src="'+utility.static_url('/img/rename.svg')+'"></span></td>'+
	'<td class="nugget_btn dtype_opt"'+hide+'><span title="Move/Copy Device Type" id="move_dtype_btn">'+
	'<img src="'+utility.static_url('/img/move.copy.svg')+'"></span></td>'+
	'</tr><tr id="nugget_select_row" hidden><td>Nugget Name:</td><td>'+
	'<span id="nugget_select_wrapper"><select id="nugget_select"></select></span>'+
	'<input id="new_nugget_name" placeholder="Enter New Nugget Name" hidden />'+
	'<div id="rename_nugget_error">This Nugget already exists!</div>'+
	'</td>'+
	'<td class="nugget_btn"><span title="Add Nugget\n(hold CTRL to duplicate)" id="add_nugget_btn">'+
	'<img src="'+utility.static_url('/img/plus.svg')+'"></span></td>'+
	'<td class="nugget_btn nug_opt" hidden><span title="Remove Nugget" id="rm_nugget_btn">'+
	'<img src="'+utility.static_url('/img/minus.svg')+'"></span></td>'+
	'<td class="nugget_btn nug_opt" hidden><span title="Rename Nugget" id="rename_nugget_btn">'+
	'<img src="'+utility.static_url('/img/rename.svg')+'"></span></td>'+
	'<td class="nugget_btn nug_opt" hidden><span title="Move/Copy Nugget" id="move_nugget_btn">'+
	'<img src="'+utility.static_url('/img/move.copy.svg')+'"></span></td>'+
	'</tr></table>';
    $('#browser').html(html);

    // initialize with remembered values
    if (self.dtype) {
	// set the dtype
	self.setDeviceType(self.dtype);
    } else {
	$('#nugget_browser #device_type_input').focus();
    }
}

nugget_browser.setDeviceType = function (dtype) {
    var self = nugget_browser;
    $('#nugget_browser #device_type_input').val(dtype);
    // initialize/show the nugget select
    self.setNuggetSelect();
    self.showNuggetSelect();
}

/*
 * Nugget Select Functions
 */
nugget_browser.showNuggetSelect = function () {
    $('#nugget_browser tr#nugget_select_row').show();
}

nugget_browser.hideNuggetSelect = function () {
    $('#nugget_browser tr#nugget_select_row').hide();
}

nugget_browser.setNuggetSelect = function (current) {
    var self = nugget_browser;
    current = current || self.nugget_name;
    var html = '<option value=""></option>';
    var nugget_name_d = self.cfg_after[self.dtype] || {};
    var nugget_name_l = Object.keys(nugget_name_d).sort();
    for (var i=0; i < nugget_name_l.length; i++) {
	var nugget_name = nugget_name_l[i];
	html += '<option value='+nugget_name;
	if (nugget_name == current) {
	    html += ' selected'
	}
	html += '>'+nugget_name+'</option>';
    }

    // initialize the nugget select box
    $('#nugget_browser #nugget_select')
	.html(html)
	.chosen({width: '100%',
		 placeholder_text_single: " ",
		 search_contains: true,
		 disable_search_threshold: 1,
		})
	.trigger('chosen:updated')
	.trigger('change')
}

nugget_browser.setBrowserForm = function () {
    var self = nugget_browser;
    if (self.standalone) {
	var url = utility.api_url("config_text");
	$.getJSON(url, function(cfg_d) {
	    glb.config.cfg_before = {};
	    glb.config.cfg_after = {};

	    // save the config
	    self.cfg_before = glb.config.cfg_before.nugget = cfg_d.nugget;
	    // copy the config
	    self.cfg_after = glb.config.cfg_after.nugget = utility.deep_copy(cfg_d.nugget);
	    // focus on nugget configs
	    self.setBrowserForm_helper();
	})
    } else {
	self.cfg_before = glb.config.cfg_before.nugget;
	self.cfg_after = glb.config.cfg_after.nugget;
	self.setBrowserForm_helper()
    }
}

nugget_browser.setForm = function() {
    var self = nugget_browser;

    var html;

    html = '<div class="nugget_browser_wrapper" style="background: #c0cee8; margin-top: 33px;">'+
	'<table id="nugget_cfg_form" class="std_table nostripe nugget_browser">'+
	'<tr><td style="padding: 0" colspan=2><div id="view_select_outer">';
    if (self.raw) {
	html += '<div id="view_select_visual" class="view_select">Visual</div>'+
	    '<div id="view_select_raw" class="view_select selected">Raw</div>';
    } else {
	html += '<div id="view_select_visual" class="view_select selected">Visual</div>'+
	    '<div id="view_select_raw" class="view_select">Raw</div>';
    }
    html += '</div></td></tr>';

    if (self.raw) {
	self.set_yaml();

	html += '<tr><th>Nugget Config</th></tr>';
	html += '<tr><td>'+
	    '<textarea id="nugget_cfg" class="tab_indent" spellcheck="false">'+
	    self.yaml+
	    '</textarea>'+
	    '</td></tr>';
    } else {
	// collection settings
	html += '<tr><th colspan=2>Nugget Settings</th></tr>';
	html += self.getFormEl("description");
	html += self.getFormEl("datatype");
	html += self.getFormEl("unit");

	html += '<tr><td colspan=2><div class="nugget_browser_wrapper" style="background: #c8bede">'+
	    '<table class="std_table nostripe nugget_browser">'+
	    '<tr><th colspan=2>Collection Settings</th></tr>';

	// type
	html += self.getFormEl("type");

	/* type options */
	if (self.nugget.type &&
	    !(self.nugget.type == "group" && !self.nugget.aggregate) &&
	    ['constant', 'function'].indexOf(self.nugget.type) < 0) {
	    html += self.getFormEl("process");
	    html += self.getFormEl("split");
	    html += self.getFormEl("split_method");
	    html += self.getFormEl("split_format");
	    html += self.getFormEl("incremental_process");
	    html += self.getFormEl("post_process");
	}
	html += '</table></div></td></tr>';
    }
    html += '</table></div>';

    $('#nugget_browser #form').html(html);

    /* enable autosizing */
    autosize($('textarea'));
    /* initialize chosen multiple select */
    $('#nugget_browser select.nugget_param.multiple').chosen(
	{width: "100%",
	 placeholder_text_multiple: " ",
	});
}

nugget_browser.init_standalone = function () {
    var self = nugget_browser;

    /* set the page title */
    $('#toolbar_center').html('<div id="span_header">Nugget Manager</div>');

    /* set the save button */
    var html = '<img title="Import" id="import_cfg_btn" class="ldm_icon" src="'+
	utility.static_url('/img/import.svg')+'">'+
	'<img title="Export" id="export_cfg_btn" class="ldm_icon" src="'+
	utility.static_url('/img/export.svg')+'">'+
	'<img title="Save" id="save_cfg_btn" class="ldm_icon disabled" src="'+
	utility.static_url('/img/save.svg')+'">';
    $('#toolbar_right').html(html);

    /* this is required for django CSRF handling */
    $.ajaxSetup({
        beforeSend: function(xhr, settings) {
            if (!(/^http:.*/.test(settings.url) || /^https:.*/.test(settings.url))) {
                // Only send the token to relative URLs i.e. locally.
                xhr.setRequestHeader("X-CSRFToken",
                                     $("input[name=csrfmiddlewaretoken]").val());
            }
        }
    });

    /* init global config */
    glb = {};
    glb.config = getJSON(utility.api_url("config"));
}

nugget_browser.init = function(el) {
    var self = nugget_browser;

    /* get the list of devices */
    self.getDeviceList();

    var html = ''+
	'<div id="nugget_browser">'+
	'<div id="browser"></div>'+
	'<div id="form"></div>'+
	'<div id="nugget_test">'+
	'<div id="device_select"></div>'+
	'</div></div>';

    $(el).html(html);
}

$(document).ready(function(){
    var self = nugget_browser;

    var path_l = location.pathname.split("/");
    self.standalone = (path_l.contains("nugget_manager"));

    if (self.standalone) {
	// get the last element (unless it's empty due to trailing /
	self.device_name = path_l.pop() || path_l.pop();
	self.init("#nugget_browser");
	self.init_standalone();
    }

    /* open the websocket */
    self.sock_open(self.sock_url);

    /*
     * Tab indention
     */
    $(document).on('keydown', '#nugget_browser .tab_indent', function (e) {
	switch(e.which) {
	case 9: // Tab
	    // set the default indent
	    document.execCommand('insertHTML', false, "    ");
	    e.preventDefault();
	    break
	default:
	    break;
	}
    });

    // convert yaml
    $(document).on('input', '#nugget_browser #nugget_cfg', function (e) {
	// the config has changed, enable save btn
	config_browser.modified();

	try {
	    var old_type = self.nugget.type;
	    self.nugget = self.cfg_after[self.dtype][self.nugget_name] = jsyaml.load($('#nugget_cfg').val()) || {};
	    if (self.nugget.type != old_type) {
		self.setTestForm();
	    }
	} catch {};
    });

    // view selected
    $(document).on('click', '#nugget_browser .view_select', function (e) {
	$('#nugget_browser .view_select').removeClass("selected");
	$(this).addClass("selected");

	self.raw = ($(this).html() == "Raw");

	self.setForm();
    });

    // 'advanced' checkbox
    $(document).on('change', '#nugget_browser .advanced_checkbox', function (e) {
	var id = $(this).attr('id');
	self[id] = $(this).prop("checked");
	self.setForm();
    });

    $(document).on('mousedown', '#nugget_browser #device_type_browser', function (e) {
	e.preventDefault();
    });

    // 'show unused' checkbox
    $(document).on('click', '#nugget_browser #show_unused_label', function (e) {
	$(this).find('input').trigger("change");
        e.preventDefault();
    });
    $(document).on('click change', '#nugget_browser #show_unused_checkbox', function (e) {
	if (e.type == "click") {
	    e.stopPropagation();
	} else {
	    // toggle the value
	    self.show_unused = !self.show_unused;
	    // set the check
	    $(this).prop("checked", self.show_unused);
	    // reset the dropdown
	    var html = self.getDeviceTypeSelector_helper(glb.config.config.dtype_d, 0);
	    $('#device_type_dropdown').html(html);
	}
    });

    /* device type expand/collapse */
    $(document).on('mousedown', '#nugget_browser li div.icon', function(e) {
	if ($(this).text() == '\u25BC') {
	    $(this).text('\u25B6');
	} else {
	    $(this).text('\u25BC');
	}
	$(this).parent().next('ul').toggle();
	e.preventDefault();
    });

    /* click on a device type */
    $(document).on('mousedown mouseup', '#nugget_browser #device_type_browser li span.label', function(e) {
	if (e.type == "mouseup") {
	    // highlight the selected option
	    $('#nugget_browser #device_type_browser li span.label').removeClass('selected');
	    $(this).addClass("selected");

	    // set the device type value
	    var dtype = $(this).text();
	    $('#nugget_browser #device_type_input')
		.val(dtype)
		.trigger('input', true);
	} else {
	    e.preventDefault();
	}
    });

    // hide device type browser when losing focus
    $(document).on('focusin focusout', '#nugget_browser #device_type_input', function (e) {
	$('#nugget_browser #device_type_browser').toggle(e.type == "focusin");
    });

    $(document).on('click', '#nugget_browser #device_type_input', function(e, give_focus) {
	// show the dropdown
	$(this).select();
	$('#nugget_browser #device_type_browser').show();
    });

    // adjust automatically with input
    $(document).on('input', '#nugget_browser #device_type_input', function(e, give_focus) {
	var self = nugget_browser;

	// assign the value
	self.dtype = $(this).val();
	var to_show = (glb.config.config.dtype_hard_l.indexOf(self.dtype) < 0);
	$('.nugget_btn.dtype_opt').toggle(to_show);

	if (!give_focus) {
	    var filter_str = self.dtype.toLowerCase();

	    // update the device type browser
	    $('#nugget_browser #device_type_browser ul').toggle((filter_str != ''));
	    var html = self.getDeviceTypeSelector_helper(glb.config.config.dtype_d, 0, filter_str);
	    $('#device_type_dropdown').html(html);
	    if (filter_str) {
		$('#nugget_browser #device_type_browser ul').show();
	    }
	}

	// clear the nugget and test forms
	self.nugget = {}
	$('#nugget_browser #form').empty();
	$('#nugget_browser #nugget_test').hide();

	// show/hide the nugget selectbox
	if (glb.config.config.dtype_l.indexOf(self.dtype) >= 0) {
	    // show the nugget select row
	    self.setNuggetSelect();
	    self.showNuggetSelect();
	    if (give_focus) {
		$('#nugget_browser #device_type_browser').hide();
		document.getSelection().removeAllRanges();
	    }
	} else {
	    // hide the nugget select row
	    self.hideNuggetSelect();
	};
    });

    /* nugget selector */
    $(document).on('change', '#nugget_browser select#nugget_select', function(e) {
	var self = nugget_browser;
	// set the current nugget name
	self.nugget_name = $(this).val()

	// modify the nugget config json
	if (self.nugget_name) {
	    self.nugget = self.cfg_after[self.dtype][self.nugget_name] || {};
	} else {
	    self.nugget = {};
	}

	// add/remove the nugget config browser
	if (self.nugget_name) {
	    $('td.nugget_btn.nug_opt').show();
	    $('#form').show();
	    self.setForm();
	} else {
	    $('td.nugget_btn.nug_opt').hide();
	    $('#rename_nugget_btn').parent().hide();
	    $('#form').hide();
	}

	// add/remove the nugget test form
	self.setTestForm();
    });

    // parameter
    $(document).on('input', '#nugget_browser .nugget_param', function (e) {
	// the config has changed, enable save btn
	config_browser.modified();

	var id = $(this).attr('id').replace(/nugget_/, '');
	var section = $(this).parent().attr("section");
	var node;
	var cfg;

	// check for section
	if (section) {
	    // add the section if it doesn't exist
	    if (!(section in self.nugget)) {
		self.nugget[section] = {}
	    }
	    node = self.nugget[section]
	    cfg = self.option_cfg[section][id];
	} else {
	    node = self.nugget
	    cfg = self.option_cfg[id];
	}
	var type = cfg.type || cfg;

	switch(type) {
	case "boolean":
	    val = $(this).prop("checked");
	    break;
	case "list":
	    val = $(this).val().split(',').map(x => x.trim()).filter(
		function(x){return x;}
		);
	    val = val.length ? val : null;
	    break;
	case "number":
	    val = parseInt($(this).val());
	    break;
	default:
	    val = $(this).val().trim();
	    if (!isNaN(val)) {
		val = parseInt(val);
	    }
	}

	// set the parameter
	if (val || val === 0) {
	    node[id] = val;
	} else {
	    delete node[id];
	}

	// clean up empty configs
	for (var key in self.nugget) {
	    var obj = self.nugget[key];
	    if (obj == null || (obj.constructor === Object &&
				Object.keys(obj).length === 0)) {
		delete self.nugget[key];
	    }
	}

	if (id == "type") {
	    self.setTestForm();
	}
	// update the form
	if (cfg.reset_form) {
	    self.setForm();
	    $("#"+$(this).attr('id')).focus();
	} else if (cfg.reset) {
	    // reset all options in the list
	    for (let i = 0; i < cfg.reset.length; i++) {
		var opt = cfg.reset[i];
		self.resetFormEl(opt);
	    }
	}
	if (cfg.on_input) {
	    cfg.on_input();
	}
    });

    // nugget label
    $(document).on('click', '#nugget_browser .nugget_label', function (e) {
	fancybox($(this).attr("title"));
    });

    // remove nugget
    $(document).on('click', '#nugget_browser #rm_nugget_btn', function (e) {
	// remove the nugget
	delete self.cfg_after[self.dtype][self.nugget_name];
	// remove the device type section if empty
	if (Object.entries(self.cfg_after[self.dtype]).length === 0) {
	    self.cfg_after[self.dtype] = null;
	}

	self.setNuggetSelect();


	// the config has changed, show the save button
	config_browser.modified();
    });

   // add new device type
    $(document).on('click', '#nugget_browser #add_dtype_btn', function (e) {
	var dtype_l = glb.config.config.dtype_l;
	dtype_l.sort();

	// build the popup html
	var html = "";
	html += '<div style="width: 400px">'+
	    '<table class="popup_table" style="margin:0">'+
	    '<tr><th class="label1">Add Device Type</th></tr>'+
	    '</table><table class="nugget_browser" style="margin-bottom: 5px">'+
	    '<tr><td>Name:</td><td><input id="new_dtype_name"></td></tr>'+
	    '<tr><td>Parent:</td><td><select id="new_dtype_parent">';

	for (var i = 0; i < dtype_l.length; i++) {
	    var dtype = dtype_l[i];
	    html += '<option value="'+dtype+'"';
	    if (self.dtype == dtype) {
		html += ' selected';
	    }
	    html += '>'+dtype+'</option>';
	}

	html += '</select>'+
	    '</td></tr></table>'+
	    '<button class="std_button" style="min-width: 80px;" id="submit_new_dtype_btn">Submit</button>'+
	    '</div>';

	fancybox(html);
	$('#new_dtype_name').focus();
    });

    $(document).on('click', '#submit_new_dtype_btn', function (e) {
	var dtype = $('#new_dtype_name').val();
	var parent = $('#new_dtype_parent').val();
	$.fancybox.close();
	if (self.AddDeviceType(dtype, parent)) {
	    self.dtype = dtype;
	    setView(glb.view);
	}
    })

    // move dtype
    $(document).on('click', '#move_dtype_btn', function (e) {
	var dtype_l = glb.config.config.dtype_l;
	var dtype_path_d = glb.config.config.dtype_path_d;
	var device_type_cfg = jsyaml.load(glb.config.cfg_after.device_type) || {};
	dtype_l.sort();

	// build the popup html
	var html = "";
	html += '<div style="width: 400px">'+
	    '<table class="popup_table" style="margin:0">'+
	    '<tr><th class="label1">Move/Copy Device Type</th></tr>'+
	    '</table><table class="nugget_browser" style="margin-bottom: 5px">'+
	    '<tr><td>Destination:</td><td><select id="new_dtype_parent">';

	self.current_parent = device_type_cfg[self.dtype].parent;

	for (var i = 0; i < dtype_l.length; i++) {
	    var dtype = dtype_l[i];
	    if (dtype == self.dtype ||
		dtype_path_d[dtype].contains(self.dtype))
		continue;

	    html += '<option value="'+dtype+'"';
	    if (self.current_parent == dtype) {
		html += ' selected';
	    }
	    html += '>'+dtype+'</option>';
	}

	html += '</select>'+
	    '</td></tr></table>'+
	    '<button class="std_button" style="min-width: 80px;" id="submit_move_dtype_btn" disabled>Move</button>'+
	    '<button class="std_button" style="min-width: 80px;" id="submit_copy_dtype_btn">Copy</button>'+
	    '</div>';

	fancybox(html);

    });
    $(document).on('input', 'select#new_dtype_parent', function (e) {
	$('button#submit_move_dtype_btn').prop('disabled', $(this).val() == self.current_parent);
    });

    $(document).on('click', '#submit_copy_dtype_btn, #submit_move_dtype_btn', function (e) {
	var id = $(this).attr('id');
	var parent = $('#new_dtype_parent').val();
	$.fancybox.close();
	self.MoveDeviceType(parent, (id == "submit_copy_dtype_btn"));
	setView(glb.view);
    })

    // remove dtype
    $(document).on('click', '#rm_dtype_btn', function (e) {
	utility.confirmPopup('Are you sure you want to delete this device type?',
			     function () {
				 self.RemoveDeviceType();
				 setView(glb.view);
			     });
    });

    // rename dtype
    $(document).on('click', '#nugget_browser #rename_dtype_btn', function (e) {
	// hide the nugget select
	$('#dtype_select_wrapper').hide();
	$('#updated_dtype_name')
	    .val(self.dtype)
	    .show()
	    .select();
    });
    $(document).on('focusout', '#nugget_browser #updated_dtype_name', function (e) {
	$(this)
	    .hide()
	    .val('');
	// show the nugget select
	$('#dtype_select_wrapper').show();
    });
    $(document).on('keydown', '#nugget_browser #updated_dtype_name', function (e) {
	switch(e.which) {
	case 13:// Enter
	    e.preventDefault();
	    var new_dtype_name = $(this).val();
	    // add the nugget
	    if (new_dtype_name) {
		self.RenameDeviceType(self.dtype, new_dtype_name);
		setView(glb.view);
	    }
	    $(this)
		.blur()
		.empty()
	    break
	default:
	    break;
	}
    });

    // add new nugget
    $(document).on('keydown keyup', function (e) {
	if (e.which == 17) { // CTRL
	    if (e.type == "keydown") {
		if (self.nugget_name) {
		    $('#nugget_browser #add_nugget_btn').css('cursor', 'copy');
		}
	    } else {
		$('#nugget_browser #add_nugget_btn').css('cursor', 'pointer');
	    }
	}
    });
    $(document).on('click contextmenu', '#nugget_browser #add_nugget_btn', function (e) {
	// should we duplicate the nugget?
	if (e.ctrlKey) {
	    e.preventDefault();
	    if (self.nugget_name) {
		self.duplicate = self.nugget_name;
	    }
	}

	// reset the forms
	$('#nugget_browser #form').hide();
	$('#nugget_browser #nugget_test').hide();
	self.nugget_name = '';

	// hide the nugget select
	$('#nugget_select_wrapper').hide();
	// clear the current nugget selection and trigger
	$('#nugget_select')
	    .val('')
	    .trigger("chosen:updated")
	    .trigger("change")

	// show the new name form
	$('#new_nugget_name')
	    .show()
	    .focus();

	if (self.duplicate) {
	    var nugget_d = self.cfg_after[self.dtype];
	    var i = 1;
	    while (true) {
		var attempt = self.duplicate + '(copy_'+i+')';
		if (!(attempt in nugget_d)) {
		    $('#new_nugget_name')
		    	.val(attempt)
			.select();
		    break;
		}
		i++;
	    }
	}
    });
    // rename nugget
    $(document).on('click', '#nugget_browser #rename_nugget_btn', function (e) {
	// hide the nugget select
	$('#nugget_select_wrapper').hide();
	$('#new_nugget_name')
	    .val(self.nugget_name)
	    .show()
	    .select();
    });
    $(document).on('focusout', '#nugget_browser #new_nugget_name', function (e) {
	$(this)
	    .hide()
	    .val('');
	// show the nugget select
	$('#nugget_select_wrapper').show();
    });
    $(document).on('keydown', '#nugget_browser #new_nugget_name', function (e) {
	switch(e.which) {
	case 13:// Enter
	    e.preventDefault();
	    var new_nugget_name = $(this).val();
	    // add the nugget
	    if (new_nugget_name) {
		// add the device section if not present
		if (!(self.cfg_after[self.dtype])) {
		    self.cfg_after[self.dtype] = {};
		}
		if (self.cfg_after[self.dtype][new_nugget_name]) {
		    $('#rename_nugget_error').show();
		    setTimeout(function () {
			$('#rename_nugget_error').hide();
		    }, 1000);
		    return;
		}
		if (self.nugget_name) {
		    // copy into new name
		    self.cfg_after[self.dtype][new_nugget_name] = self.cfg_after[self.dtype][self.nugget_name];
		    // remove old entry
		    delete self.cfg_after[self.dtype][self.nugget_name];
		} else if (self.duplicate) {
		    // copy into new name
		    self.cfg_after[self.dtype][new_nugget_name] = utility.deep_copy(
			self.cfg_after[self.dtype][self.duplicate]
		    );
		    self.duplicate = false;
		} else {
		    // create new empty nugget
		    self.cfg_after[self.dtype][new_nugget_name] = {};
		}
		self.setNuggetSelect(new_nugget_name);
		self.setDtypeUsed();

		// the config has changed, enable save btn
		config_browser.modified();
	    }
	    $(this)
		.blur()
		.empty()
	    break
	default:
	    break;
	}
    });
    // move nugget
    $(document).on('click', '#move_nugget_btn', function (e) {
	var dtype_l = glb.config.config.dtype_l;
	dtype_l.sort();

	// build the popup html
	var html = "";
	html += '<div style="width: 400px">'+
	    '<table class="popup_table" style="margin:0">'+
	    '<tr><th class="label1">Move/Copy Nugget</th></tr>'+
	    '</table><table class="nugget_browser" style="margin-bottom: 5px">'+
	    '<tr><td>Destination:</td><td><select id="new_nugget_parent">';

	for (var i = 0; i < dtype_l.length; i++) {
	    var dtype = dtype_l[i];

	    html += '<option value="'+dtype+'"';
	    if (dtype == self.dtype) {
		html += ' selected';
	    }
	    html += '>'+dtype+'</option>';
	}

	html += '</select>'+
	    '</td></tr></table>'+
	    '<button class="std_button" style="min-width: 80px;" id="submit_move_nugget_btn" disabled>Move</button>'+
	    '<button class="std_button" style="min-width: 80px;" id="submit_copy_nugget_btn">Copy</button>'+
	    '</div>';

	fancybox(html);

    });
    $(document).on('input', 'select#new_nugget_parent', function (e) {
	$('button#submit_move_nugget_btn').prop('disabled', $(this).val() == self.dtype);
    });
    $(document).on('click', '#submit_copy_nugget_btn, #submit_move_nugget_btn', function (e) {
	var id = $(this).attr('id');
	var parent = $('#new_nugget_parent').val();
	$.fancybox.close();
	self.MoveNugget(parent, (id == "submit_copy_nugget_btn"));
	setView(glb.view);
    })


    // test device select
    $(document).on('change', '#nugget_browser select#device_select', function (e) {
	self.device_name = $(this).val();
	$('#nugget_browser #response').empty();
	if (self.device_name) {
	    $('#nugget_browser #submit_btn').parent().parent().show();
	} else {
	    $('#nugget_browser #submit_btn').parent().parent().hide();
	}
    });

    // submit button
    $(document).on('click', '#nugget_browser #submit_btn', function(e) {
	$('#response').html("");
	$('#submit_btn').prop('disabled', true);
	self.cache = [];

	//var nugget_cfg = yaml_enc($('#nugget_cfg').val());
	if (self.device_name) {
	    self.send_query();
	}
    });

    // view as table
    $(document).on('click', '#nugget_browser .view_as_table', function(e) {
	var index = parseInt($(this).attr('id').split('_').last());
	fancybox('<div id="as_table"><div>', {
	    minWidth: 600
	});
	table_viewer.init_table('#as_table', self.cache[index]);
    });

    // expand all json
    $(document).on('dblclick', '#nugget_browser #response .code', function(e) {
        $(this).prev().find(".expand_json").click();
    });
    $(document).on('click', '#nugget_browser span.expand_json', function(e) {
	var blk = $(this).parent().parent().next();
	if ($(this).text() == '+') {
	    blk.find('a.json-toggle.collapsed').click();
	    $(this).text('-');
	} else {
	    blk.find('a.json-toggle:not(.collapsed)').click();
	    $(this).text('+');
	}
    });

    // tips popup
    $(document).off('click', '#tips_btn');
    $(document).on('click', '#tips_btn', function(e) {
	var html = '';
	html += '<table class="popup_table">'+
	    '<tr><th class="label1">Tips</th></tr>'+
	    '</table>'+
	    '<div style="text-align: left"><ul style="padding: 10px 30px; font-size: 14px;">'+
	    '<li>When creating a new nugget, hold CTRL to duplicate the current nugget</li>'+
	    '<li>When viewing JSON data (while testing a nugget), double click to expand a tree fully</li>'+
	    '</ul></div>';
	fancybox(html)
    });
});
