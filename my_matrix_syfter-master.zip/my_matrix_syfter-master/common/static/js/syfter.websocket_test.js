/*
 * Functions for handling the websockets connection
 */
var self = {
    sock_url: utility.ws_url('nugget_poll'),
}

/* send a websockets query (for nugget testing) */
self.send_query = function () {
    var msg = $('textarea#message').val();
    self.sock.send(msg);
}

/* handle websockets response (for nugget testing) */
self.sock_rx = function (e) {
    var json_data = JSON.parse(e.data);
    $('#response').jsonViewer(json_data, {collapsed: false, withLinks: false});
}

/* close the websocket connection */
self.sock_close = function (e) {
    $('#connect').removeClass("btn_green");

    // Try to reconnect in 5 seconds
    setTimeout(function(){
	try {
	    self.sock_open(e.target.url);
	} catch (err) {}
    }, 1000);
}

/* when a connection is opened, enable the test button */
self.sock_onopen = function (e) {
    console.log("Connected: " + self.sock_url);
    $('#connect').addClass("btn_green");
}

/* initialize the websocket */
self.sock_open = function (url) {
    self.sock = new WebSocket(url);

    // set websocket handlers
    self.sock.onmessage = self.sock_rx;
    self.sock.onclose = self.sock_close;
    self.sock.onopen = self.sock_onopen;
}

$(document).ready(function(){
    $(document).on("click", "button#connect", function() {
	var url = $('#websocket_url').val();
	self.sock_url = utility.ws_url(url);

	/* open the websocket */
	console.log("Connecting: " + self.sock_url);
	self.sock_open(self.sock_url);
    });

    $(document).on("click", "button#send", function() {
	$('#response').empty();
	self.send_query();
    });
});
