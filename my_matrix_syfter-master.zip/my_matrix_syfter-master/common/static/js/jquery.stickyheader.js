function stickyTable(table) {
    // Clone <thead>
    var $w = $(window),
    $t	   = table,
    $thead = $t.find('thead').clone();

    // Add class, remove margins, reset width and wrap table
    $t
	.addClass('sticky-enabled') // add table to 'sticky-enabled' class
	.wrap('<div class="sticky-wrap" />'); // wrap in a sticky-wrap div

    // put the move the overflow property to the wrapper
    if($t.hasClass('overflow-y'))
    {
	$t.removeClass('overflow-y').parent().addClass('overflow-y');
    }

    // Create new sticky table head (basic)
    // LEVY HACK (should add all classes manually)
    $t.after('<table class="sticky-thead table-header-rotated" />');

    // If <tbody> contains <th>, then we create sticky column and intersect (advanced)
    if($t.find('tbody th').length > 0) {
    	//$t.after('<table class="sticky-col table-header-rotated" /><table class="sticky-intersect" />');
	$t.after('<table class="sticky-col table-header-rotated" />');
    }

    // Create shorthand for things
    var $stickyHead  = $t.siblings('.sticky-thead'),
    $stickyCol   = $t.siblings('.sticky-col'),
    $stickyWrap  = $t.parent('.sticky-wrap');

    $stickyHead.append($thead);

    $t.find('tr').each(function(i) {
    	//var tr = $stickyCol.append("<tr>");
    	var $row = $('<tr></tr>');
    	$(this).find('th.row-header, th.padding').each(function() {
    	    $row.append($(this).clone());
    	});
    	$stickyCol.append($row);
    });

    // Set widths
    var setWidths = function () {
	$t
	    .find('thead th').each(function (i) {
		$stickyHead.find('th').eq(i).width($(this).width());
	    })
		.end()
	    .find('tr').each(function (i) {
		$stickyCol.find('tr').eq(i).height($(this).height());
	    });

	// Set width of sticky table head
	$stickyHead.width($t.width());

	// Set width of sticky table col
	//console.log($stickyHead.height());
    },
    repositionStickyHead = function () {
	// Return value of calculated allowance
	var allowance = calcAllowance();

	// Position sticky header based on viewport scrollTop
	if($w.scrollTop() > $t.offset().top && $w.scrollTop() < $t.offset().top + $t.outerHeight() - allowance) {
	    // When top of viewport is in the table itself
	    $stickyHead
		.css({
		    opacity: 1,
		    top: $w.scrollTop() - $t.offset().top + 48
		});
	} else {
	    // When top of viewport is above or below table
	    $stickyHead
		.css({
		    opacity: 0,
		    top: 0
		});
	}

    },
    repositionStickyCol = function () {
	if($w.scrollLeft() > $t.offset().left && $w.scrollLeft() < $t.offset().left + $t.outerWidth()) {
	    $stickyCol
		.css({
		    opacity: 1,
		    left: $w.scrollLeft() - $t.offset().left
		});
	} else {
	    // When left of wrapping parent is in view
	    $stickyCol
	    	.css({
		    opacity: 0,
		    left: 0
		});

	}
    },
    calcAllowance = function () {
	var a = 0;
	// Calculate allowance
	$t.find('tbody tr:lt(3)').each(function () {
	    a += $(this).height();
	});

	// Set fail safe limit (last three row might be too tall)
	// Set arbitrary limit at 0.25 of viewport height, or you can use an arbitrary pixel value
	if(a > $w.height()*0.25) {
	    a = $w.height()*0.25;
	}

	// Add the height of sticky header
	a += $stickyHead.height();
	return a;
    };

    setWidths();

    // $stickyWrap.scroll($.debounce(250, function() {
    // 	repositionStickyHead();
    // 	repositionStickyCol();
    // }));

    $w
	.resize($.debounce(250, function () {
	    setWidths();
	    repositionStickyHead();
	    repositionStickyCol();
	}))
	.scroll($.debounce(250, function() {
    	    repositionStickyHead();
    	    repositionStickyCol();
	}));
}

