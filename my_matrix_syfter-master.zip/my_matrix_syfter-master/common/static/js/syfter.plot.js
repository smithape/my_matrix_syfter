function getPlotHTML(has_parent, series_count) {
    height = Math.min(screen.height*0.5, 600);
    width = $('#content').width() - 60;

    var html_text = "<div id='popup'>";
    if (has_parent == true) {

	html_text += '<div align="left"><img src="'+static_root+'/img/back.svg" class="ldm_icon" id="plot_back"></div>';
    }
    html_text += "<div id='modal_graph' style='width:"+width+"; height:"+height+"; margin: 0 auto'></div>";
    //html_text += '<div align="right"><label><input type="checkbox" name="sd_toggle" data-chart="modal_graph"> Show Peaks</label></div>';
    html_text += '<div align="right" style="padding-top: 10px">resample by: <table id="resample_by" data-chart="modal_graph"><tr>'+
	'<td value="min">min</td>'+
	'<td value="avg" class="selected">avg</td>'+
	'<td value="max">max</td>';
    if (series_count > 1) {
	html_text += '<td value="all">all</td></tr></table></div>';
    } else {
	html_text += '</tr></table></div>';
    }

    html_text += '</div>';

    return html_text;
}

function showPlotModal(series_list, has_parent) {
    var html = getPlotHTML(has_parent, series_list.length);
    var renderTo = "modal_graph";
    // $("#popup").dialog({
    // 	modal: true,
    // 	height: "auto",
    // 	width: "auto",
    // });
    //var wind = window.open("", "plot", "width=1000, height=500");
    //wind.document.write(html);
    //$('#page_content').html(html);
    fancybox(html, {
        afterClose : function() {
    	    // delete the chart
    	    glb.chart_d[renderTo].destroy();
    	}
    });

    showPlot(null, series_list, renderTo);
}

function getUnit (nugget_name) {
    var unit = '';

    // find the unit of the series
    var nugget_root = nugget_name.split(":")[0];
    unit = glb.config.nugget.unit_d[nugget_root] || "number";

    return unit;
}

function addSeries(name, device_name, nugget_name, yAxis_idx, series_idx) {

    var series_l = [];
    var yAxis = yAxis_idx;
    var suffix = getUnit(nugget_name).unit;

    series = {
	device_name: device_name,
	nugget_name: nugget_name,
        name: name,
	yAxis: yAxis,
	type: 'spline',
	tooltip: {
	    valueSuffix: suffix
	},
	marker: {
            enabled: false
        }
    }
    series_l.push(series);

    series = {
        name: name + '.sd',
	yAxis: yAxis,
	type: 'areasplinerange',
	tooltip: {
	    valueSuffix: suffix
	},
	marker: {
            enabled: false
        },
	includeInCSVExport: false,
	linkedTo: ':previous',
	lineWidth: 0,
	color: Highcharts.getOptions().colors[series_idx],
	fillOpacity: 0.2,
	zIndex: 0
    }
    series_l.push(series);

    return series_l;
}

function getAxis (nugget_name, opposite) {
    var unit = getUnit(nugget_name);
    if (!unit)
	return
    var text = unit.axis_label;
    var min = unit.min;
    var max = unit.max;
    var ceiling = unit.ceiling;
    var label_suffix = unit.label_suffix;

    // initialize the axis
    axis = {
	title: {
	    text: text
	},
	gridLineWidth: 0,
	opposite: opposite,
	min: min,
	max: max,
	ceiling: ceiling
    };

    // custom axis labels
    if (label_suffix) {
	axis.labels = {
	    formatter: function() {
		return + this.value + label_suffix;
	    }
	}
    }

    return axis;
}

function getRangeSelector () {
    var span = getSpan();
    var delta_min = (span.max - span.min) / (60*1000); // in minutes
    var delta_hr = delta_min / 60;
    var delta_day = delta_hr / 24;
    var delta_week = delta_day / 7;

    var rangeSelector = {
	enabled: true,
        selected : 0, // all
        inputEnabled: false // it supports only days
    };

    var buttons = [{
        type: 'all',
        text: 'Reset'
    }];

    // 1m
    if (4 < delta_week) {
	buttons.push(
	    {
		type: 'month',
		count: 1,
		text: '1m'
	    }
	);
    }
    // 1w
    if (1 < delta_week) {
	buttons.push(
	    {
		type: 'week',
		count: 1,
		text: '1w'
	    }
	);
    }
    // 1d
    if (1 < delta_day) {
	buttons.push(
	    {
		type: 'day',
		count: 1,
		text: '1d'
	    }
	);
    }
    // 12h
    if (12 < delta_hr && delta_day <= 14) {
	buttons.push(
	    {
		type: 'hour',
		count: 12,
		text: '12h'
	    }
	);
    }
    // 4h
    if (4 < delta_hr && delta_day <= 7) {
	buttons.push(
	    {
		type: 'hour',
		count: 4,
		text: '4h'
	    }
	);
    }
    // 1h
    if (1 < delta_hr && delta_day <= 7) {
	buttons.push(
	    {
		type: 'hour',
		count: 1,
		text: '1h'
	    }
	);
    }
    // 30m
    if (30 < delta_min && delta_hr <= 12) {
	buttons.push(
	    {
		type: 'minute',
		count: 30,
		text: '30m'
	    }
	);
    }
    // 10m
    if (10 < delta_min && delta_hr <= 2) {
	buttons.push(
	    {
		type: 'minute',
		count: 10,
		text: '10m'
	    }
	);
    }

    rangeSelector.buttons = buttons;

    return rangeSelector;
}

function showPlot (plot_title, series_list, renderTo) {
    /* initialize the y axes */
    var yAxis_l = [];
    var series_l = [];
    var opposite = false;
    var chart;

    var axis;
    var yAxis_idx;
    var yAxis_already_present;

    for (var i = 0; i < series_list.length; i++) {
	name = series_list[i].name;
	device_name = series_list[i].device;
	nugget_name = series_list[i].nugget;

	axis = getAxis(nugget_name, opposite);
	if (!axis)
	    return

	yAxis_idx = yAxis_l.length;
	yAxis_already_present = false;
	$.each(yAxis_l, function (j, v) {
	    if (v.title.text == axis.title.text) {
		yAxis_idx = j;
		yAxis_already_present = true;
	    }
	});
	if (!yAxis_already_present) {
	    yAxis_l.push(axis);
	    opposite = !opposite;
	}
	s = addSeries(name, device_name, nugget_name, yAxis_idx, i);
	series_l = series_l.concat(s);
    }

    /* configure the range selector */
    var rangeSelector = getRangeSelector();

    Highcharts.setOptions({
        global: {
	    useUTC: false
        }
    });
    var options = {
	chart: {
            zoomType: 'x',
	    renderTo: renderTo,
	    alignTicks: false
	    //animation: false,
	    //plotBorderWidth: 1,
	    // resetZoomButton: {
	    //     theme: {
	    // 	//display: 'none',
	    //     }
	    // },
	},
	title: {
	    text: plot_title
	},
	navigator: {
	    adaptToUpdatedData: false,
	    enabled : true,
	    height: 20,
	    series: {
		includeInCSVExport: false,
		dataGrouping : {
		    enabled: false
		}
	    }
	},
	legend: {enabled: true},
	scrollbar: {enabled: false},
	rangeSelector : rangeSelector,
	plotOptions: {
	    areasplinerange: {
                states: {
		    hover: {enabled: false}
                }
	    },
	    spline: {
                states: {
		    hover: {
                        enabled: true,
			lineWidthPlus: 0,
			halo: {
			    size: 0
			}
		    }
                },
	    	events: {
	    	    show: function() {
			if (this.raw_data) {
	    		    var data = arrangeData(this.raw_data, this.chart.resample_by);
	    		    this.setData(data.series);
			    if (this.range_series && this.range_series.visible) {
				this.range_series.setData(data.range);
			    }

			}
	    	    }
	    	}
	    },
	    series: {
		animation: false,
		lineWidth: 1,
		marker: {
		    enabled: false,
		    radius: 0
		}
	    }
        },
        tooltip: {
	    animation: false,
	    crosshairs: true,
	    valueDecimals: 2,
	    useHTML: true,
            formatter: function() {

		// filter and sort the array
		var sorted = this.points
		    .filter(function (x) {
			return x.series.type == "spline";
		    })
		    .sort(function(a, b) {
			return ((a.y < b.y) ? -1 : ((a.y > b.y) ? 1 : 0));
		    }).reverse();


		var resample_by = this.points[0].series.chart.resample_by;
		var summarized = false;
		var units = false;
		for (var i = 0; i < sorted.length; i++) {
		    point = sorted[i].point;

		    /* use the raw data */
		    try {
			avg = point.series.raw_data[point.index][1];
			min = point.series.raw_data[point.index][2];
			max = point.series.raw_data[point.index][3];
			unit = point.series.options.tooltip.valueSuffix;
		    } catch (err) {
			break;
		    }

		    if (min != avg || max != avg)
			summarized = true;

		    if (unit)
			units = true;
		}


		// create the tooltip html
		// start with the date string
		var s = '<div class="highcharts_tt">' + getTimeString(moment(this.x), false) + '</div>';

		/* header */
		s += '<table class="highcharts_tt">';
		if (summarized) {
		    s += '<tr><th>Name</th><th>Min</th><th>Avg</th><th>Max</th>';
		} else {
		    s += '<tr><th>Name</th><th>Val</th>';
		}

		if (units)
		    s += '<th>Unit</th>';

		s += '</tr>';


		var point, unit, min, max, avg, suffix;
		for (var i = 0; i < sorted.length; i++) {
		    point = sorted[i].point;

		    /* the data units */
		    unit = point.series.options.tooltip.valueSuffix;

		    /* body */
                    s += '<tr><td class="name"><span style="font-weight: bold; color: '+ point.color +'">'+point.series.name+': </span></td>';
		    if (summarized) {
			/* use the raw data */
			avg = point.series.raw_data[point.index][1];
			min = point.series.raw_data[point.index][2];
			max = point.series.raw_data[point.index][3];

			switch (resample_by) {
			case 'min':
			    min = '<b>' + min + '</b>';
			    break;
			case 'avg':
			case 'all':
			    avg = '<b>' + avg + '</b>';
			    break;
			case 'max':
			    max = '<b>' + max + '</b>';
			    break;
			}

			s += '<td>' + min + '</td><td>' + avg + '</td><td>' + max + '</td>';
		    } else {
			s += '<td><b>' + point.y + '</b></td>';
		    }

		    /* unit */
		    if (unit)
			s += '<td>' + unit + '</td>';

		    s += '</tr>';
                }

		s += '</table>';

		return s;

		// // group by series (bring in the errorbar info)
		// var grouped = {};
		// for (var i = 0; i < this.points.length; i++) {
		//     var point =  this.points[i];
                //     if (point.series.type == 'areasplinerange') {
		// 	if (point.point.low != point.point.high) {
		// 	    grouped[point.series.linkedParent.name].max = point.point.high;
		// 	}
		//     } else {
		// 	grouped[point.series.name] = {
		// 	    color: point.series.color,
		// 	    name: point.series.name,
		// 	    val: point.y,
		// 	    suffix: point.series.options.tooltip.valueSuffix
		// 	};
		//     }
		// }

		// // convert to numeric array
		// var grouped_l = [];
		// for (var key in grouped) {
		//     grouped_l.push(grouped[key]);
		// }

		// // sort the array
		// var sorted = grouped_l.sort(function(a, b) {
		//     return ((a.val < b.val) ? -1 : ((a.val > b.val) ? 1 : 0));
		// }).reverse();

		// // create the tooltip html
		// for (var i = 0; i < sorted.length; i++) {
		//     var point = sorted[i];
                //     s += '<br><span style="font-weight: bold; color: '+ point.color +'">'+point.name+'</span>';
		//     s += ': <b>' + point.val + '</b>';
		//     s += point.suffix + ' ';

                //     if (point.max) {
		// 	// LEVY: for standard dev
                //         // diff = this.point.high - this.point.low;
                //         // s += '(\u03C3 = ' + diff.toFixed(2) + ')'
		// 	if (point.max != point.y) {
		// 	    s += '(peak = ' + point.max + ' ' + point.suffix +')';
		// 	}
		//     }
                // }

                // return s;
            },
            shared: true
        },
	xAxis: {
	    type: 'datetime',
	    ordinal: false,
	    //minRange: 3600 * 1000, // one minute
            events : {
                afterSetExtremes : afterSetExtremes
            }
	},
	yAxis: yAxis_l,
	series: series_l,
	credits: {
	    enabled: false
	}
    };

    chart = new Highcharts.StockChart(options);
    glb.chart_d[renderTo] = chart;

    // set the initial values
    chart.span_start = glb.span_start;
    chart.span_end = glb.span_end;
    chart.period = 0;
    chart.resample_by = glb.resample_by;
    setLegendHoverHandlers(chart);

    if (series_list.length > 1 && chart.resample_by != "all") {
	disableRanges(chart);
    }
    getPlotData(chart, "initial");

    /* start the statistics poller */
    var min_period = 30 * 1000;
    if (chart.span_end == "now") {
	chart.refresh = function(){
	    if ($('#'+renderTo).length) {
		//try {
		getPlotData(chart, "update");
		//} catch (err) { alert (err);}
		setTimeout(chart.refresh, Math.max(min_period, chart.period));
	    } else {
		try {
		    chart.destroy();
		} catch (err) {}
	    }
	}
    }
    setTimeout(chart.refresh, Math.max(min_period, chart.period));
}

function setLegendHoverHandlers (chart) {
    /* update the chart data */
    var i = 0;

    while (i < chart.series.length - 1) {
	(function(i) {
	    var series = chart.series[i];
	    series.range_series = chart.series[i+1];

	    $(series.legendItem.element).hover(
		function() { // in
		    if (series.visible && chart.series.length > 3 && chart.resample_by != "all") {
			/* show the range */
			var data = arrangeData(series.raw_data, chart.resample_by);
			series.range_series.setData(data.range, false);
			series.range_series.show();

			/* show plot bands */
			if (series.plot_bands) {
			    for (var i = 0; i < series.plot_bands.length; i++) {
				series.xAxis.addPlotBand(series.plot_bands[i]);
			    }
			}
		    }
		},
		function() {
		    if (chart.series.length > 3 && chart.resample_by != "all") {
			/* hide the range */
			series.range_series.hide();

			/* remove plot bands */
                        series.xAxis.removePlotBand('band');
		    }
		}
	    );
	})(i);
	i += 2;
    }
}

function updateRanges (chart, enable) {
    /* show/hide the series' */
    i = 1;
    while (i < chart.series.length) {
    	var series = chart.series[i];
    	if (series.type == 'areasplinerange') {
    	    if (enable && chart.series[i-1].visible) {
    		var data = arrangeData(chart.series[i-1].raw_data, chart.resample_by);
    		series.setData(data.range, false);
    		series.show();
    	    } else {
    		series.hide();
    	    }
    	}
    	i += 1;
    }
    chart.redraw();
}

function enableRanges(chart) {
    updateRanges(chart, true);
}

function disableRanges(chart) {
    updateRanges(chart, false);
}

function afterSetExtremes(e) {
    if (!e.trigger) {
	// do nothing if this wasn't caused by user interaction
	return;
    }

    // cancel the current outstanding timer
    var chart = e.target.chart;
    try {
	clearTimeout(chart.timer);
    } catch (err) {}

    chart.timer = setTimeout(function() {
	var e_delta = e.max - e.min;
	var period = getSamplePeriod(e.min, e.max);
	var chart_zoom_delta = chart.zoom_max - chart.zoom_min;
	var larger = Math.max(e_delta, chart_zoom_delta);
	var smaller = Math.min(e_delta, chart_zoom_delta);
	var ratio = (larger / smaller).toFixed(1);
	var nav_zoom_max = chart.xAxis[1].max;
	//var nav_data_max = chart.xAxis[1].dataMax;

	// reload the data if
	// (1) we changed the zoom range so the sample period is different
	// (2) we've moved the extremes past our current data limits
	// (3) we're at the end of the plot, and we have a dynamic plot
	if (ratio > 1.2 || period != chart.period ||
	    e.min < (chart.zoom_min - chart_zoom_delta) ||
	    e.max > (chart.zoom_max + chart_zoom_delta) ||
	    ((e.max > chart.prev_emax) &&
	     (e.max > (nav_zoom_max - chart.full_period)))
	   ) {
	    // if (ratio > 1.2) console.log("ratio");
	    // if (period != chart.period) alert("period: " + chart.period +'/'+period);
	    // if (e.min < (chart.zoom_min - chart_zoom_delta))
	    // 	console.log("exceded min");
	    // if (e.max > (chart.zoom_max + chart_zoom_delta))
	    // 	console.log("exceded max");
	    // if ((e.max > chart.prev_emax) &&
	    // 	(e.max > (nav_zoom_max - chart.full_period)))
	    // 	console.log("end bump");


	    chart.zoom_min = e.min;
	    chart.zoom_max = e.max;

	    getPlotData(chart, e.trigger);
	}
	chart.prev_emax = e.max;
    }, 250);
}

function getPlotBands (logs_l, span) {
    var bands = [];
    for (i = 0; i < logs_l.length; i++) {
	var log = logs_l[i];
	if (log.type != "nugget" || log.severity < 30) continue

	var band = {};
	/* id */
	band.id = "band";
	/* start time */
	band.from = log.timestamp;
	/* end time */
	try {
	    var j = i + 1;
	    /* find the next log with different severity */
	    while (logs_l[j].severity == log.severity) j++;
	    band.to = logs_l[j].timestamp;
	    i = j - 1;
	} catch (err) {
	    band.to = span.max;
	}
	/* severity color */
	switch (log.severity) {
	case 30:
	    //band.color = '#FEFEE5';
	    band.color = '#FEFEBF';
	    break
	case 40:
	    //band.color = '#FEE5E5';
	    band.color = '#FEBFBF';
	    break
	}
	/* text */
	//band.label = {text: log.message};
	bands.push(band);
    }
    return bands;
}

function getSamplePeriod (start, end) {
    // calculate the sample period
    var sample_count = 120;
    var delta = end - start; // in ms
    delta = Math.round(delta / 1000) // to sec
    period = delta / sample_count;
    period = Math.round(period / 30) * 30 // round to nearest 30
    return period * 1000;
}

// function seriesAddPts_bkp (series, data, raw_data) {
//     // find the last point in the series
//     var old_point = series.raw_data.last();

//     for (var i = 0; i < raw_data.length; i++) {
// 	var new_point = raw_data[i];

// 	if (new_point[0] == old_point[0]) {
// 	    if (new_point[1] != old_point[1]) {
// 		// update the last point in raw_data
// 		series.raw_data.last(new_point);

// 		// // LEVY: for some reason the point.update function is adding extra
// 		// // points...it's probably not a huge deal, but I'm not using it for now
// 		if (series.visible) {
// 		    // update the live data
// 		    var start = new Date().getTime();
// 		    series.data.last().update(data.series[i][1], false);
// 		    // series.data.last().remove();
// 		    // series.addPoint(data.series[i], false);
// 		    var time = new Date().getTime() - start;
// 		    console.log("remove/add: " + time);

// 		    // update the range series
// 		    if (series.range_series && series.range_series.visible) {
// 			series.range_series.data.last().update(data.range[i][1], false);
// 			//series.range_series.data.last().remove();
// 			//series.range_series.addPoint(data.range[i], false);
// 		    }
// 		}
// 	    }
// 	} else if (new_point[0] > old_point[0]) { // add new point
// 	    series.raw_data.push(new_point);
// 	    if (series.visible) {
// 	    	series.addPoint(data.series[i], false);
// 	    	if (series.range_series && series.range_series.visible) {
// 	    	    series.range_series.addPoint(data.range[i], false);
// 	    	}
// 	    }
// 	}
//     }
// }

// function seriesRemovePts_bkp (series, min) {
//     var raw_pt, pt;
//     /* figure out how many need to be removed */
//     for (var i = 0; i < series.raw_data.length; i++) {
//     	raw_pt = series.raw_data[i];
//     	if (raw_pt[0] >= min) {
//     	    break;
//     	}
//     }

//     /* remove the points */
//     var remove_count = i;
//     for (var i = 0; i < remove_count; i++) {

//     	/* update raw_data */
//     	series.raw_data.shift();
//     	// /* update data */
// 	try {
// 	    var start = new Date().getTime();
//     	    series.data[i].remove(false);
// 	    var time = new Date().getTime() - start;
// 	    console.log("remove: " + time);

// 	} catch (err) {
// 	    console.log(series.raw_data);
// 	    console.log(series);
// 	    console.log(i);
// 	}
//     	/* update range_series */
//     	if (series.range_series) {
//     	    series.range_series.data[i].remove(false);
//     	}
//     }

//     // for (var i = 0; i < series.data.length; i++) {
//     // 	var pt = series.data[i];
//     // 	if (pt) {
//     // 	    if (pt.x < min) {
//     // 		console.log(series.name);
//     // 		pt.remove(false);
//     // 		if (series.raw_data) {
//     // 	    	    series.raw_data.shift();
//     // 		}
//     // 	    } else {
//     // 		break;
//     // 	    }
//     // 	}
//     // }

//     // if (series.range_series && series.range_series.visible) {
//     // 	seriesRemovePts(series.range_series, min);
//     // }
// }

function seriesAddPts (series, raw_data) {
    // find the last point in the series
    var old_point = series.raw_data.last();

    for (var i = 0; i < raw_data.length; i++) {
	var new_point = raw_data[i];

	if (new_point[0] == old_point[0]) {
	    if (new_point[1] != old_point[1]) {
		// update the last point in raw_data
		series.raw_data.last(new_point);
	    }
	} else if (new_point[0] > old_point[0]) {
	    // add new point
	    series.raw_data.push(new_point);
	}
    }
}

function seriesRemovePts (series, min) {
    var raw_pt;
    /* figure out how many need to be removed */
    for (var i = 0; i < series.raw_data.length; i++) {
    	raw_pt = series.raw_data[i];
    	if (raw_pt[0] >= min) {
    	    break;
    	}
    }

    /* remove the points */
    var remove_count = i;
    for (var i = 0; i < remove_count; i++) {
    	/* update raw_data */
    	series.raw_data.shift();
    }
}

function arrangeData (data, resample_by) {
    var options = ["avg", "min", "max", "all"];
    var index = options.indexOf(resample_by) + 1;
    index = (index == 4) ? 1:index;
    var series_data = [];
    var range_data = [];
    var point;

    for (var i = 0; i < data.length; i++) {
	point = data[i];
	series_data.push([point[0], point[index]]);
	range_data.push([point[0], point[2], point[3]]);
    }

    return {
	series: series_data,
	range: range_data
    }
}

function rearrangeData(chart) {

    /* update the chart data */
    i = 0;
    var series;
    var data;
    while (i < chart.series.length - 1) {
	series = chart.series[i];
	if (series.type != 'areasplinerange') {
	    try {
		data = arrangeData(series.raw_data, chart.resample_by);
		series.setData(data.series, false);
		series.range_series.setData(data.range, false);
	    } catch (err) {}
	}
	i++;
    }
    chart.redraw();
}

function getPlotData (chart, trigger) {
    // t1 = new Date();
    if (!chart.xAxis) {
	// The chart no longer exists
	return;
    }

    var curr_zoom_min = chart.xAxis[0].min;
    var curr_zoom_max = chart.xAxis[0].max;
    var nav_zoom_max = chart.xAxis[1].max;
    var nav_series = chart.series[chart.series.length - 1];

    // if we're not at the end of the plot, don't update
    if (trigger == "update" && curr_zoom_max < (nav_zoom_max - chart.full_period)) {
	console.log("not at end");
	return;
    }

    // start with the theoretical chart span
    var span = getSpan(chart.span_start, chart.span_end);
    // the query min/max for the zoom (in contrast to the navigator needing the
    // full min/max)
    var zoom_query_min;
    var zoom_query_max;
    // if a zoom is specified, adjust
    if (chart.zoom_min && chart.zoom_max) {
	var zoom_delta = chart.zoom_max - chart.zoom_min;
	zoom_query_min = Math.max(chart.zoom_min - zoom_delta, span.min);
	if (curr_zoom_max > (nav_zoom_max - chart.full_period)) {
	    // if we're at the end of the plot, get the most recent data
	    zoom_query_max = span.max;
	} else {
	    // otherwise use the following algorithm
	    zoom_query_max = Math.min(chart.zoom_max + zoom_delta, span.max);
	}
    } else {
	zoom_query_min = chart.zoom_min = span.min;
	zoom_query_max = chart.zoom_max = span.max;
    }

    // period is based on our current "view" or "zoom"
    var full_period = getSamplePeriod(span.min, span.max);
    var period = getSamplePeriod(chart.zoom_min, chart.zoom_max);

    var i = 0;
    var last_i;
    // is the navigator series the same as series 0?
    var nav_is_0 = (span.min == zoom_query_min && span.max == zoom_query_max);
    if (nav_is_0) {
	last_i = chart.series.length - 1;
    } else {
	last_i = chart.series.length;
    }

    if (trigger != "update") chart.showLoading('Loading data from server...');
    var d_l = []; // initialize the json query list
    while (i < last_i) {
	(function(i) {
	    var url;
	    var device_name = chart.series[i].options.device_name;
	    var nugget_name = chart.series[i].options.nugget_name;
	    var query_min = zoom_query_min;
	    var query_max = zoom_query_max;
	    var query_period = period;
	    var old_period = chart.period;
	    var is_nav = (i == chart.series.length - 1);
	    var series = chart.series[i];

	    // check if it's the nagivator
	    if (is_nav) {
		query_period = full_period;
		old_period = chart.full_period;
		query_min = span.min;
		query_max = span.max;
	    }

	    // Full update, or just append?
	    if (trigger == "update" && query_period == old_period) {
		/*
		 * Partial update
		 */
		var min = span.min;
		if (series.raw_data) {
		    // since we're front-labelling the resample, this works.
		    // if we change to middle-labelling, we'll need to use the period
		    // to determine what min should be
		    min = series.raw_data.last()[0];
		}

		/* make the json query */
		url = utility.api_url("series",
				      [utility.name_enc(device_name),
				       utility.name_enc(nugget_name),
				       Math.floor(min/1000),
				       Math.floor(query_max/1000)]);
		var params = {period: query_period/1000};
		d_l.push($.getJSON(url, params)
			 .done(function(response, status) {
			     if (status == "nocontent")
				 return;

			     var raw_data = response.data;
			     var data_period = response.period * 1000;

			     /*
			       Remove old points
			     */
			     seriesRemovePts(series, query_min);

			     /* do we need to update the navigator series? */
			     if (nav_is_0 && i == 0) {
				 seriesRemovePts(nav_series, query_min);
			     }

			     /*
			       Add new points
			     */
			     if (raw_data) {
				 /* add points to the series */
				 seriesAddPts(series, raw_data);

				 /* do we need to update the navigator series? */
				 if (nav_is_0 && i == 0) {
				     seriesAddPts(nav_series, raw_data);
				 }
			     }

			     /*
			       apply the raw_data changes to the chart
			     */
			     if (series.visible) {
				 var data = arrangeData(series.raw_data, chart.resample_by);
				 series.setData(data.series, false);

				 if (series.range_series && series.range_series.visible) {
		    		     series.range_series.setData(data.range, false);
				 }
			     }

			     /* do we need to update the navigator series? */
			     if (nav_is_0 && i == 0) {
				 // first, pad with nulls
				 var nav_data = nav_series.raw_data.slice(0);
				 var timestamp = nav_data.last()[0] + data_period;
				 while (timestamp < span.max) {
				     nav_data.push([timestamp, null]);
				     timestamp += data_period;
				 }
		    		 nav_series.setData(nav_data, false);
			     }
			 })
			);
	    } else {
		/*
		 * Full update
		 */

		/* get the logs */
		url = utility.api_url("logs",
				      [Math.floor(query_min/1000),
				       Math.floor(query_max/1000)]);
		var params = {device: device_name, nugget: nugget_name};
		$.getJSON(url, params, function(data, status) {
		    if (status == "nocontent")
			return;

		    series.plot_bands = getPlotBands(data, span);
		    if (chart.series.length <= 3) {
			if (series.plot_bands) {
			    for (var i = 0; i < series.plot_bands.length; i++) {
				series.xAxis.addPlotBand(series.plot_bands[i]);
			    }
			}
		    }
		});

		/* make the json query */
		url = utility.api_url("series",
				      [utility.name_enc(device_name),
				       utility.name_enc(nugget_name),
				       Math.floor(query_min/1000),
				       Math.floor(query_max/1000)]);
		var params = {period: query_period/1000};
		d_l.push($.getJSON(url, params, function(response, status) {
		    if (status == "nocontent")
			return;

		    var raw_data = response.data;
		    var data_period = response.period * 1000;
		    var data = arrangeData(raw_data, chart.resample_by);

		    /* store the raw data */
		    series.raw_data = raw_data;

		    /* update a standard series */
		    if (!is_nav) {
			series.setData(data.series, false);
			series.range_series.setData(data.range, false);
		    }

		    /* pad the nav series */
		    if (is_nav || (nav_is_0 && i == 0)) {
			// copy the data
			var nav_data = raw_data.slice(0);
			// add filler points to beginning
			var timestamp = raw_data[0][0] - data_period;
			while (timestamp >= span.min) {
			    nav_data.unshift([timestamp, null]);
			    timestamp -= data_period;
			}

			// add filler points to end
			var timestamp = raw_data.last()[0] + data_period;
			while (timestamp < span.max) {
			    nav_data.push([timestamp, null]);
			    timestamp += data_period;
			}

			nav_series.raw_data = nav_data;
			nav_series.setData(nav_data.slice(0), false);
		    }
		}));
	    }
	})(i);
	i += 2;
    }

    $.when.apply($, d_l).always(function(){

	// t2 = new Date();
	// console.log("get nugget_data: " + (t2.getTime() - t1.getTime()));

	chart.redraw();
	if (trigger != "update") chart.hideLoading();

	// remember these values for later
	chart.period = period;
	chart.full_period = full_period;

	// adjust the navigator extremes
	chart.xAxis[1].setExtremes(chart.xAxis[1].dataMin, chart.xAxis[1].dataMax);

	// adjust zoom endpoints
	if (curr_zoom_min && curr_zoom_max) {
	    var zoom_min = curr_zoom_min;
	    var zoom_max = curr_zoom_max;

	    // if the zoom was at the end, advance it
	    if (trigger == "update" || curr_zoom_max >= (nav_zoom_max - chart.full_period)) {
		// the last datapoint of either navigator or data
		zoom_max = Math.max(chart.xAxis[0].dataMax, chart.xAxis[1].dataMax);
	    }

	    // Check if we need to update zoom_min
	    // update only when the chart span_start is dynamic
	    if ((trigger == "update" || trigger == "navigator") && chart.span_start < 0) {
		zoom_min += (zoom_max - curr_zoom_max);
	    }

	    // need to store the updated zoom extremes for later
	    chart.zoom_min = zoom_min;
	    chart.zoom_max = zoom_max;

	    // reset the extremes if required
	    if (zoom_min != curr_zoom_min || zoom_max != curr_zoom_max) {
		chart.xAxis[0].setExtremes(zoom_min, zoom_max);
	    }
	} else {
	    // initial chart load
	    chart.xAxis[0].setExtremes(chart.xAxis[1].min, chart.xAxis[1].max);
	}


	// t3 = new Date();
	// console.log("processing: " + (t3.getTime() - t2.getTime()));
    });
}

$(document).ready(function(){

    $(document).on('click', '#plot_back', function(e) {
	glb.back_fn();
	//showBarPlot(glb.parent_chart.nugget_name, glb.parent_chart.sort_by);
    });

    /* conditions/logs table */
    $(document).on('click', "table:not(#issues_tbl) span.nugget_popup", function() {
	var device_name = $(this).attr("device");
	var nugget_name = $(this).text();

	var series_l = [
	    {
		name: device_name + "/" + nugget_name,
		device: device_name,
		nugget: nugget_name
	    }
	]
	showPlotModal(series_l);
    });

    $(document).on('click', 'table#resample_by td', function(e) {
	$(this).closest('table').find('td').removeClass("selected");
	$(this).addClass('selected');

	var chart = glb.chart_d[$(this).closest("table").data('chart')];

	var prev = chart.resample_by;
	chart.resample_by = $(this).attr('value');

	if (chart.resample_by == "all" && prev != "all") {
	    enableRanges(chart);
	} else if (prev == "all" && chart.resample_by != "all") {
	    disableRanges(chart);
	}
	if (chart.resample_by != prev) {
	    rearrangeData(chart);
	}
    });

});
