utility = {};

function fancybox (html, options) {
    var defaults = {
	content     : html,
	fitToView   : true,
	autoSize    : true,
	minWidth    : 250,
	minHeight   : 20,
	openEffect  : 'none',
	closeEffect : 'none',
	closeBtn : false,
	helpers : {
	    overlay : {
		locked : false
	    }
	}
    }

    options = $.extend({}, defaults, options);

    $.fancybox(options);
}

utility.confirmPopup = function (msg, yes_callback, no_callback) {
    msg = msg || "Are you sure?";
    var ret;

    var html = '' +
	'<table class="popup_table borderless">'+
	'<tr><td colspan=2>'+msg+'</td></tr>'+
	'<tr>'+
	'<td style="padding-top: 5px">'+
	'<button id="confirm_no_btn" class="std_button" style="width: 100px">No</button>'+
	'<button id="confirm_yes_btn" class="std_button" style="width: 100px">Yes</button></td>'+
	'</tr></table>';

    fancybox(html, {
	afterShow: function() {
	    ret = false;
	    $('#confirm_no_btn, #confirm_yes_btn').on("click tap", function(e) {
		ret = (e.target.id == "confirm_yes_btn");
		$.fancybox.close()
	    });
	},
	afterClose: function() {
	    if (ret && yes_callback) {
		yes_callback.call(this);
	    } else if (!ret && no_callback) {
		no_callback.call(this)
	    }
	},
    });
}

utility.alertPopup = function (msg, callback) {
    var ret;
    var after_fn;

    var html = '' +
	'<table class="popup_table borderless">'+
	'<tr><td colspan=2>'+msg+'</td></tr>'+
	'<tr><td style="padding-top: 5px;">'+
	'<button id="popup_ok_btn" class="std_button" style="width: 100px">OK</button></td>'+
	'</tr></table>';

    if (callback) {
	after_fn = function() {
	    callback.call(this);
	}
    }

    fancybox(html, {
	afterShow: function() {
	    ret = false;
	    $('#popup_ok_btn').on("click tap", function(e) {
		$.fancybox.close()
	    });
	},
	afterClose: after_fn,
    });
}

String.prototype.capFirstLetter = function() {
    return this.charAt(0).toUpperCase() + this.slice(1);
}

String.prototype.startsWith = function (str)
{
    return this.indexOf(str) == 0;
}

String.prototype.capitalize = function() {
    return this.charAt(0).toUpperCase() + this.slice(1);
}

Array.prototype.last = function(val) {
    if (val) {
	this[this.length-1] = val;
    } else {
	return this[this.length-1];
    }
}

Array.prototype.remove = function(val) {
    var index = this.indexOf(val);
    if (index > -1) {
	this.splice(index, 1);
    }
    return this;
}

Array.prototype.contains = function(val) {
    return (this.indexOf(val) >= 0);
}

function remove_whitespace(str) {
    return str.replace(/ /g,'');
}

function get_regex (str) {
    var re;
    try {
	re = new RegExp(str, 'i');
    } catch (err) {
	re = new RegExp("\\" + str, 'i');
    }
    return re
}

function escapeHtml(unsafe) {
    return unsafe
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
	.replace(/'/g, "&#039;");
}

function selector_enc (str) {
    return str
	.replace(/([#;?%&,.+*~\':"!^$[\]()=>|\/@])/g,'\\$1');
}

utility.deep_copy = function (d) {
    return JSON.parse(JSON.stringify(d));
}

utility.name_enc = function (str) {
    return encodeURIComponent(
	str.replace(/\//g,'__'));
}

function yaml_enc (str) {
    /* condition the text */
    // space after colon
    str = str.replace(/(\n[^:]*):([^\s])/g, '$1: $2');
    // space after '-' for list
    str = str.replace(/(\n\s*)-([^\s])/g, '$1- $2');

    return str;
}

utility.api_url = function (url, path = []) {
    return [api_root, url].concat(path).join('/') + '/';
}

utility.static_url = function (str) {
    return static_root + str;
}

utility.ws_url = function(url) {
    var ws_proto = window.location.protocol == "https:" ? "wss" : "ws";
    return ws_proto + '://' + window.location.host + [root, 'ws', url].join('/') + '/';
}

utility.download_json_as_file = function(data, filename) {
    // format the data
    var blob = new Blob([JSON.stringify(data)], {type: "application/json"});

    // Create an invisible A element
    const a = document.createElement("a")
    a.style.display = "none";
    a.download = filename;
    a.href = window.URL.createObjectURL(blob);

    // add to the page
    document.body.appendChild(a);

    // Trigger the download by simulating click
    a.click();

    // Cleanup
    window.URL.revokeObjectURL(a.href);
    document.body.removeChild(a);
}

utility.range = function(start, end) {
    var size = end - start;
    return [...Array(size).keys()].map(i => i + start);
}
