function getJSON(url) {
    var json = null;
    $.ajax({
        'async': false,
        'global': false,
        'url': url,
        'dataType': "json",
        'success': function (data) {
            json = data;
        }
    });
    return json;
}

/* LEVY: not for the stadium wifi project...might be useful for LDM */
// function getTableHTML() {
//     var html_text = "";
//     html_text += "<input id='device_table_params' />"
//     html_text += "<table id='device_table'>";

//     for (var d in dict) {
// 	device = dict[d];
// 	html_text += "<tr>";
// 	html_text += "<td>"+device.__name__+"</td>";
// 	html_text += "<tr>";
//     }

//     html_text += "</table>";
//     return html_text;
// }

// function getTableContent(parameters) {
//     // remove whitespace and split on comma
//     var param_l = parameters.replace(/ /g,'').split(",");
//     var html_text = "";

//     metric_list = [];
//     for (var i in param_l) {
// 	if (param_l.hasOwnProperty(i) && param_l[i]) {
// 	    metric_list.push(param_l[i]);
// 	}
//     }
//     html_text += "<thead>";

//     html_text += "<th>name</th>";

//     for (var i in metric_list) {
//         html_text +='<th>'+metric_list[i]+'</th>';
//     }
//     html_text += "</thead>";

//     for (var d in dict) {
// 	device = dict[d];
// 	html_text += "<tr>";
// 	html_text += "<td>"+device.__name__+"</td>";
// 	for (var i in param_l) {
// 	    if (param_l.hasOwnProperty(i) && param_l[i]) {
// 		html_text += "<td>";
// 		parameter = param_l[i];
// 		if (device[parameter] !== undefined) {
// 		    html_text += device[parameter];
// 		}
// 		html_text += "</td>";
// 	    }
// 	}
// 	html_text += "<tr>";
//     }
//     return html_text;
// }

function setLeftbarHTML () {

    var txt = '';
    if (glb.config.group_l.length) {
	// show the group header
	var title;
	if (glb.group){
	    title = glb.group;
	} else {
	    title = "All Devices";
	}
	txt += '<span id="group_hdr" class="clickable">'+title+'</span>'+
	    '<span> | </span>';
    }
    // show the span header
    txt += '<span id="span_hdr" class="clickable">'+getSpanTitle(glb.span_d)+'</span>';

    txt = '<div id="title_header"></div>'+
	'<div id="toolbar_center_bubble">Time Span: '+
	txt+'</div>'+
	// help bubble
	'<div id="toolbar_help_bubble" hidden>'+
	'<img title="Tips" id="tips_btn" class="ldm_icon small" src="'+
	utility.static_url('/img/bulb.svg')+
	'"></div>';
    $('#toolbar_center').html(txt);

    var html = '';
    html += '<img id="leftbar_lbl" title="Menu" src="'+utility.static_url('/img/menu.svg')+'">'+
        '<div id="leftbar_content">'+
        '<ul id="leftbar_menu">'+
	'<div class="lbl" style="margin-bottom: 1px">Views</div>'+
	//'<li class="selected" id="home_btn">Summary</li>'+
	'<li id="menu_logs">Logs</li>';

    // don't show grid view if there's no data
    if (!$.isEmptyObject(glb.span_d.device_d)) {
	html += '<li id="menu_grid">Grid</li>';
    }

    html += '<li id="menu_devices">Devices</li>'+
	'<li id="menu_conditions">Conditions</li>';

    if (glb.config.user_is_admin) {
	html +=
	    '<div class="lbl" style="margin-bottom: 1px">Configs</div>'+
	    '<li id="menu_site">Site</li>'+
	    '<li id="menu_tool">Tool</li>'+
	    '<li id="menu_nugget">Nugget</li>'+
	    '<li id="menu_polling">Polling</li>';
    }
    html += '</ul></div>';

    $("#leftbar").html(html);

    if (glb.span_end == "now") {
	$("#report_btn").hide();
    }
}

function rightbarExpand () {
    $('#rightbar_lbl').hide();
    //$('#rightbar').animate({width:'175px'}, 200);
    $('#rightbar').css({width:'175px'});
    $('#rightbar_content').show();
}

function rightbarHide () {
    $('#rightbar_content').hide();
    if (glb.view != "home") {
	var enabled = false;
	for (var x in glb.filter) {
	    if (glb.filter[x]) {
		enabled = true;
		break;
	    }
	}
	if (enabled) {
	    $('#rightbar_lbl').attr('src', utility.static_url("/img/filter_g.svg"));
	} else {
	    $('#rightbar_lbl').attr('src', utility.static_url("/img/filter_w.svg"));
	}
	$('#rightbar_lbl').show(0);
    }
    //$('#rightbar').animate({width:'30px'}, 200);
    $('#rightbar').css({width:'30px'});
}

function setRightbarDeviceTypeFilter () {
    var html = '<option value=""></option>';

    for (var i = 0; i < glb.device_type_l.length; i++) {
	var dtype = glb.device_type_l[i];

	if (dtype == glb.filter.device_type) {
	    html += '<option value='+dtype+' selected>'+dtype+'</option>';
	} else {
	    html += '<option value='+dtype+'>'+dtype+'</option>';
	}
    }
    $('#filter_device_type').html(html);
}

function setRightbarHTML () {
    var html = '';
    html += '<img id="rightbar_lbl" src="'+utility.static_url('/img/filter_w.svg')+'">';

    html +=
        '<div id="rightbar_content">'+
	'<div id="glb_filter_toggle" class="lbl">'+
	//'<img style="width: 20px; opacity: 0.5; margin-right: 5px;" src="'+static_root+'/img/filter_w.svg">'+
	'Global Filters</div>'+
	/* device name */
        '<div>Device Name<br><input type="search" class="filter" id="filter_device"></div>'+
	/* device type */
        '<div>Device Type<br>'+
	'<select class="filter" id="filter_device_type">'+
	'</select></div>'+
	/* device severity */
	'<div>Device Severity<br><select class="filter" id="filter_device_sev">'+
	'<option value=0></option>';
    for (var id in glb.config.sev_map) {
	if (id > 20) {
	    html += '<option value='+id+'>'+glb.config.sev_map[id]+'</option>';
	}
    }
    html += '</select></div>'+
	/* device list */
        '<div>Nugget Name<br><input type="search" class="filter" id="filter_nugget"></div>';

    html += '<button class="std_button" id="clear_glb_filters_btn">Clear</button>';
    html += '</div>';

    $('#rightbar').html(html);
}

function setDeviceTypeList () {
    /* merge current and span device list */
    var device_d = $.extend({}, glb.device_d, glb.span_d.device_d);
    var device_type_count = {};
    for (var device in device_d) {
	var dtype = device_d[device].type;
	if (!(dtype in device_type_count)) {
	    device_type_count[dtype] = 0;
	}
	device_type_count[dtype]++;
    }

    glb.device_type_l = Object.keys(device_type_count).sort();
    setRightbarDeviceTypeFilter();

    var max_count = 0;
    var max_dtype = "";
    for (var dtype in device_type_count) {
	var count = device_type_count[dtype];
	if (count > max_count) {
	    max_count = count;
	    max_dtype = dtype;
	}
    }

    glb.max_device_type = max_dtype;
}

function loadReportContent(device_name_filter, metric_name_filter) {
    var device_d = glb.span_d.device_d;

    $('#page_content').html('<div class="center" style="text-align:center;" id="event_content"></div>');

    // clear the event_content div
    $('#event_content').html("");

    /* first we find the list of distinct Nuggets */
    var device_l = getFilteredDeviceList();
    var nugget_l = getFilteredNuggetList(device_l);

    var width = $('#content').width() - 20;

    var html_text = '<input id="mailto" type="text"><button class="std_button" id="send_report_btn">Send</button>';
    $('#event_content').append(html_text);

    /* add charts */
    for (var i=0; i < nugget_l.length; i++) {
	var nugget_name = nugget_l[i];
	var chart_id = "chart_"+nugget_name.replace('.','_');
	//var nugget_global_max = data[nugget_name]['max'];
	//var nugget_global_avg = data[nugget_name]['avg'];
	categories = [];
	avg_data = [];
	max_data = [];
	device_entries = [];
	// find devices that have this nugget
	for (var j = 0; j < device_l.length; j++) {
	    device_name = device_l[j];
	    nugget_d = device_d[device_name]['nugget_d'];
	    if (nugget_name in nugget_d)
	    {
		if (nugget_d[nugget_name] && 'avg' in nugget_d[nugget_name])
		{
		    device_entries.push(
			{
			    name: device_name,
			    avg: nugget_d[nugget_name]['avg'],
			    max: nugget_d[nugget_name]['max']
			}
		    );
		}
	    }
	}
	if (device_entries.length == 0) {
	    continue;
	}

	var chart_id = "chart_"+nugget_name.replace('.','_');
	//html_text = $('#event_content').html();

	nugget_name_pre = nugget_name.replace(/_[0-9\.]+GHz.*/, '');
	switch (nugget_name_pre)
	{
	case "cpuLoad":
	    html_text = "<div id='"+chart_id+"' style='clear:left;'></div>";
	    $('#event_content').append(html_text);
	    break;
	default:
	    html_text = "<div id='"+chart_id+"'></div>";
	    $('#event_content').append(html_text);
	}

	function sortByKey(array, key) {
	    return array.sort(function(a, b) {
		var x = b[key]; var y = a[key];
		return ((x < y) ? -1 : ((x > y) ? 1 : 0));
	    });
	}
	device_entries = sortByKey(device_entries, 'max');
	for (var j=0; j < Math.min(30, device_entries.length); j++)
	{
	    entry = device_entries[j];
	    categories.push(entry['name']);
	    avg_data.push(entry['avg']);
	    max_data.push(entry['max']);
	}

	// sum = 0;
	// for (var i in avg_data) {
	// 	sum += avg_data[i];
	// }
	// var average = (sum / avg_data.length).toFixed(2);
	yAxis = getAxis(nugget_name, false);
	//yAxis.max = nugget_global_max;
	//yAxis.endOnTick = false;
	//yAxis.minPadding = 5;
	//yAxis.max = Math.max(Math.max.apply(Math, avg_data), Math.max.apply(Math, max_data)) * 1.2;
	yAxis.max = null;
	var max_xAxis_range = 30;
	var scrollbar_enabled = false;
	if (avg_data.length > max_xAxis_range) {
	    scrollbar_enabled = true;
	}

	var options = {
	    chart: {
	    	type: 'column',
		//type: 'bar',
		renderTo: chart_id,
		//		    borderColor: '#EBBA95',
		borderWidth: 1,
		//		    plotBorderWidth: 1,
		//spacingLeft: 30,
		marginRight: 20,
		animation: false
	    },
	    legend : {
		//enabled: false
	    },
	    title: {
	    	text: nugget_name
	    },
	    subtitle: {
                //text: "Average = " + 10,//+ nugget_global_avg,
	    },
	    scrollbar: {
		enabled: scrollbar_enabled
	    },
	    xAxis: {
	    	categories: categories,
		max: Math.min(categories.length, max_xAxis_range) - 1,
		labels: {
		    enabled: true,
		    rotation: -90,
		    align: 'right'
		}
	    },
	    yAxis: yAxis,
	    plotOptions: {
		column: {
		    grouping: false,
		    threshold: yAxis.min
		},
                bar: {
	    	    dataLabels: {
			//align: 'left',
                        enabled: true,
			//			    overflow: false,
			verticalAlign: 'middle',
			y: -2
	    	    }
		},
		series: {
		    point: {
			events: {
			    click: function() {
				series_l = [{
				    name: this.category + "/" + this.series.chart.title.textStr,
				    device: this.category,
				    nugget: this.series.chart.title.textStr
				}];
				showPlotModal(series_l);
			    }
			}
		    }
		}
	    },
	    credits: {
	    	enabled: false
	    },
	    series: [
		{
		    name: "Maximum",
	    	    data: max_data
	    	},
		{
		    name: "Average",
	    	    data: avg_data
	    	}
	    ]
	};

	var chart = new Highcharts.Chart(options);
    }
    $('#grid_filter').show();
}

function dataTableHideEmptyColumns (table)
{
    console.log(table);
    var selector = table.selector;
    console.log(selector);
    var columnsToHide = [];

    $(selector).find('th').each(function(i) {
	console.log($(this).index());
        var columnIndex = $(this).index();
        var rows = $(this).parents('table').find('tr td:nth-child(' + (i + 1) + ')'); //Find all rows of each column
        var rowsLength = $(rows).length;
        var emptyRows = 0;

        rows.each(function(r) {
            if (this.innerHTML == '')
                emptyRows++;
        });

        if(emptyRows == rowsLength) {
            columnsToHide.push(columnIndex);  //If all rows in the colmun are empty, add index to array
        }
    });
    for(var i=0; i< columnsToHide.length; i++) {
        table.fnSetColumnVis( columnsToHide[i], false ); //Hide columns by index
    }
}

function loadDeviceTable () {
    clearLocalFilters();
    $('#rightbar_lbl').show();

    html_text =
	'<div style="margin-top:20px">'+
	'<table id="device_list" class="display compact cell-border std_table" cellspacing="0"'+
	'style="padding: 10px 0; width:95%;">'+
	'<thead>'+
	'<tr>'+
	'<th>Name</th>'+
	'<th>Type</th>'+
	'<th>IP Address</th>'+
	'<th>Upstream I/F</th>'+
	'<th>Groups</th>'+
	'<th>AP Group</th>'+
	'</tr>'+
	'</thead>'+
	'<tfoot>'+
	'<tr>'+
	'<th><input size="1" type="search"></th>'+
	//'<th><input size="1" type="search"></th>'+
	'<th><select id="lcl_filter_device_type">'+
	'<option value=""></option>';
    for (var i = 0; i < glb.device_type_l.length; i++) {
	var dtype = glb.device_type_l[i];
	html_text += '<option value="'+dtype+'$">'+dtype+'</option>';
    }
    html_text += '</select></th>'+
	'<th><input size="1" type="search"></th>'+
	'<th><input size="1" type="search"></th>'+
	'<th><input size="1" type="search"></th>'+
	'<th><input size="1" type="search"></th>'+
	'</tr>'+
	'</tfoot>'+
	'</table>'+
	'</div>';


    $('#page_content').html(html_text);

    // $('#device_list tfoot th').each(function() {
    // 	var title = $('#device_list thead th').eq($(this).index()).text();
    // 	$(this).html('<input type="text"/>');
    // });
    var height = window.innerHeight- 300;
    // the table rows are 23 pixels high
    var displayLength = Math.floor(height / 23);

    glb.table = $('#device_list').DataTable({
	//"data" : glb.device_l,
	// "ajax": {
	//     "url" : "api/device_list",
	//     "dataSrc": ""
	// },
	"search": {
	    "regex": true
	    //"smart": true
	},
	"aLengthMenu": [[25, 50, 100, -1], [25, 50, 100, "All"]],
	"iDisplayLength": displayLength,
	"columns" : [
	    {name: 'Device Name', "sClass": "nowrap"},
	    {name: 'Device Type', "data" : "type", "sClass": "nowrap"},
	    {name: 'IP Address'},
	    {name: 'Upstream I/F'},
	    {name: 'Groups'},
	    {name: 'AP Group'}
	],
	"columnDefs": [
	    {
		"name": "Device Name",
		"targets": [0],
		'type': 'html',
		"data": function (row, type, val, meta) {
		    if (type === 'display') {
			return '<span class="device_popup">'+row.name+'</span>';
		    } else {
			return row.name;
		    }
		}
	    },{
		"name": "IP Address",
		"targets": [2],
		'type': 'html',
		"data": function (row, type, val, meta) {
		    if (type === 'display') {
			return '<a href="http://'+row.ip_address+'" target="_blank">'+row.ip_address+'</a>';
		    }
		    return row.ip_address;
		}
	    },{
		"targets": [3],
		"type": 'natural',
		"data": function (row, type, val, meta) {
		    if (row.switch) {
			if (row.switch in glb.device_d) {
			    return '<span class="device_popup">'+row.switch + "</span> | " + row.switch_if;
			} else {
			    return row.switch + " | " + row.switch_if;
			}
		    } else {
			return '';
		    }
		}
	    },{
		"targets": [4],
		"data": function (row, type, val, meta) {
		    if (row.groups) {
			return row.groups.join(', ');
		    } else {
			return '';
		    }
		}
	    },{
		"targets": [5],
		"data": function (row, type, val, meta) {
		    if (row.ap_group) {
			return row.ap_group;
		    } else {
			return '';
		    }
		}
	    }
	]

    });

    lockLocalFilters();

    // Apply the search header handlers
    glb.table.columns().every( function () {
        var that = this;

	$('input, select', this.footer()).on( 'applyFilter input', function (e) {
	    var val = remove_whitespace(this.value).replace(/,/g, '|');

	    /* backup the local value */
	    if (e.type == "input") {
		var id = $(this).attr('id');
		if (id) {
		    id = id.replace(/lcl_filter_/g, '') + "_bkp";
		    lcl.filter[id] = val;
		}
	    }

	    that
                .search(val, true, false)
                .draw();
        });

	/* apply initial filter */
	$('input, select', this.footer()).trigger("applyFilter");

    } );

    glb.table.updateRows = function() {
	// init filters
	// apply the device filters
	var device_l = getFilteredDeviceList(true);
	var rows = glb.device_l.filter(function(x) {
	    return (device_l.indexOf(x.name) >= 0);
	});

	// initialize the data
	glb.table
	    .clear()
	    .rows.add(rows)
	    .columns.adjust()
	    .draw();
    }

    glb.table.updateRows();
}

function loadConditionTable () {
    clearLocalFilters();

    $('#rightbar_lbl').show();

    html_text =
	'<div style="margin-top:20px">'+
	'<table id="condition_table" class="display compact cell-border std_table" cellspacing="0"' +
	'style="padding: 10px 0; width:95%;">'+
	'<thead>'+
	'<tr>'+
	'<th>Timestamp (Duration)</th>'+
	'<th>Type</th>'+
	'<th>Severity</th>'+
	'<th>Device</th>'+
	'<th>Nugget</th>'+
	'<th>Message</th>'+
	'</tr>'+
	'</thead>'+
	'<tfoot>'+
	'<tr>'+
	'<th></th>'+
	'<th><select>'+
	'<option value=""></option>'+
	'<option value="system">system</option>'+
	'<option value="config">config</option>'+
	'<option value="device">device</option>'+
	'<option value="nugget">nugget</option>'+
	'</select></th>'+
	'<th><select id="lcl_filter_device_sev">'+
	'<option value=0></option>'+
	'<option value=30>warning</option>'+
	'<option value=40>error</option>'+
	'<option value=50>critical</option>'+
	'</select></th>'+
	'<th><input size="1" type="search"></th>'+
	'<th><input size="1" type="search"></th>'+
	'<th><input size="1" id="lcl_filter_message" type="search"></th>'+
	'</tr>'+
	'</tfoot>'+
	'</table>'+
	'</div>';


    $('#page_content').html(html_text);

    // var height = window.innerHeight - 300;
    // // the table rows are 23 pixels high
    // var displayLength = Math.floor(height / 23);
    var height = window.innerHeight- 300;
    // the table rows are 23 pixels high
    var displayLength = Math.floor(height / 23);

    var span = getSpan();
    //var url = "api/logs/"+Math.floor(span.min/1000)+"/"+Math.floor(span.max/1000);

    glb.table = $('#condition_table').DataTable({
	// "ajax": {
	//     "url" : url,
	//     "dataSrc": ""
	// },
	//"data": glb.logs,
	"aLengthMenu": [[25, 50, 100, -1], [25, 50, 100, "All"]],
	"iDisplayLength": displayLength,
	"order": [[0, "desc"]],
	"columns" : [
	    {name: 'Timestamp', "sClass": "nowrap"},
	    {name: 'Type', "data": "type"},
	    {name: 'Severity', "sClass": "nowrap"},
	    {name: 'Device Name', "sClass": "nowrap"},
	    {name: 'Nugget Name', "sClass": "nowrap"},
	    {name: 'Message', "data": "message", "sClass": "overflow"}
	    // {name: 'Device Type'},
	    // {name: 'Log Level'}
	],
	"columnDefs": [
	    {
		"name": "Timestamp",
	    	"targets": 0, // timestamp
		"data": function (source, type, val) {
		    if (type === 'display' || type === 'filter') {
			var t = moment(source.timestamp);
			return getTimeString(t, false) + ' (' + getTimeDiffString(t) + ')';
			//return moment(source.timestamp).format('YYYY-MM-DD HH:mm:ss');
		    }
		    return source.timestamp;
		}
	    },{
		"name": "Severity",
	    	"targets": 2,
		"data": function (source, type, val) {
		    if (type === 'display') {
			return glb.config.sev_map[source.severity];
		    }
		    return source.severity;
		}
	    },{
		"name": "Device Name",
		"targets": 3,
		'type': 'html',
		"data": function (row, type, val, meta) {
		    if (row.device in glb.device_d && type === 'display') {
			return '<span class="device_popup">'+row.device+'</span>';
		    } else {
			return row.device;
		    }
		}
	    },{
		'name': "Nugget Name",
		"targets": 4,
		"data": function (row, type, val, meta) {
		    if (row.nugget && row.device in glb.device_d && type === 'display') {
			return '<span device="'+row.device+'" class="nugget_popup">'+row.nugget+'</span>';
		    } else  if (row.nugget) {
			return row.nugget;
		    } else {
			return '';
		    }
		}
	    }
	],
	"rowCallback": function(row, data){
	    var sev = data.severity;
	    if (sev > 40) {
		$('td:eq(1)', row).addClass('crit');
	    } else if (sev > 30) {
		$('td:eq(1)', row).addClass('error');
	    } else if (sev > 20) {
		$('td:eq(1)', row).addClass('warning');
	    }
	}
    });


    // Apply the search header handlers
    glb.table.columns().every( function () {
        var that = this;

    	$('input, select', this.footer()).on( 'input', function () {
        //$( 'input', $('order_list thead tr:first th').on( 'keyup change', function () {
	    var val = this.value;
	    var id = $(this).attr('id');

	    if (id != "lcl_filter_message") {
		val = remove_whitespace(val).replace(/,/g, '|');
	    }

	    if (id == "lcl_filter_device_sev") {
		for (var i = parseInt(val); i < 50; i+=10) {
		    val += "|" + (i+10);
		}
	    }
            that
                .search(val, true, false)
                .draw();
        } );
    	$('input, select', this.footer()).trigger("input");
    } );

    glb.table.updateRows = function() {
	// init filters
	var rows;
	// apply the device filters
	if (glb.filter.device ||
	    glb.filter.device_type ||
	    glb.filter.device_sev) {
	    var device_l = getFilteredDeviceList(true);
	    rows = glb.condition_l.filter(function(x) {
		return (device_l.indexOf(x.device) >= 0);
	    });
	} else {
	    rows = glb.condition_l;
	}

	// initialize the data
	glb.table
	    .clear()
	    .rows.add(rows)
	    .columns.adjust()
	    .draw();
    }

    glb.table.updateRows();

}

function loadLogTable () {
    clearLocalFilters();

    $('#rightbar_lbl').show();

    html_text =
	'<div style="margin-top:20px">'+
	'<table id="log_table" class="display compact cell-border std_table" cellspacing="0"' +
	'style="padding: 10px 0; width:95%;">'+
	'<thead>'+
	'<tr>'+
	'<th>Timestamp</th>'+
	'<th>Type</th>'+
	'<th>Severity</th>'+
	'<th>Device</th>'+
	'<th>Nugget</th>'+
	'<th>Message</th>'+
	'</tr>'+
	'</thead>'+
	'<tfoot>'+
	'<tr>'+
	'<th></th>'+
	'<th><select>'+
	'<option value=""></option>'+
	'<option value="system">system</option>'+
	'<option value="config">config</option>'+
	'<option value="device">device</option>'+
	'<option value="nugget">nugget</option>'+
	'</select></th>'+
	//'<th><input size="1" type="search"></th>'+
	'<th><select id="lcl_filter_device_sev">'+
	'<option value=0></option>'+
	'<option value=30>warning</option>'+
	'<option value=40>error</option>'+
	'<option value=50>critical</option>'+
	'</select></th>'+
	'<th><input size="1" type="search"></th>'+
	'<th><input size="1" type="search"></th>'+
	'<th><input size="1" type="search"></th>'+
	'</tr>'+
	'</tfoot>'+
	'</table>'+
	'</div>';


    $('#page_content').html(html_text);

    // var height = window.innerHeight - 300;
    // // the table rows are 23 pixels high
    // var displayLength = Math.floor(height / 23);
    var height = window.innerHeight- 300;
    // the table rows are 23 pixels high
    var displayLength = Math.floor(height / 23);

    var span = getSpan();
    //var url = "api/logs/"+Math.floor(span.min/1000)+"/"+Math.floor(span.max/1000);

    glb.table = $('#log_table').DataTable({
	// "ajax": {
	//     "url" : url,
	//     "dataSrc": ""
	// },
	//"data": glb.logs,
	"aLengthMenu": [[25, 50, 100, -1], [25, 50, 100, "All"]],
	"iDisplayLength": displayLength,
	"order": [[0, "desc"]],
	"columns" : [
	    {name: 'Timestamp', "sClass": "nowrap"},
	    {name: 'Type', "data": "type"},
	    {name: 'Severity', "sClass": "nowrap"},
	    {name: 'Device Name', "sClass": "nowrap"},
	    {name: 'Nugget Name', "sClass": "nowrap"},
	    {name: 'Message', "data": "message", "sClass": "overflow"}
	],
	"columnDefs": [
	    {
	    	"targets": 0, // timestamp
		"data": function (source, type, val) {
		    if (type === 'display' || type === 'filter') {
			var t = moment(source.timestamp);
			return getTimeString(t, false);
			//return moment(source.timestamp).format('YYYY-MM-DD HH:mm:ss');
		    }
		    return source.timestamp;
		}
	    },{
	    	"targets": 2,
		"data": function (source, type, val) {
		    if (type === 'display') {
			return glb.config.sev_map[source.severity];
		    }
		    return source.severity;
		}
	    },{
		"name": "Device Name",
		"targets": 3,
		'type': 'html',
		"data": function (row, type, val, meta) {
		    if (row.device in glb.device_d && type === 'display') {
			return '<span class="device_popup">'+row.device+'</span>';
		    } else {
			return row.device;
		    }
		}
	    },{
		"name": "Nugget Name",
		"targets": 4,
		"data": function (row, type, val, meta) {
		    if (row.nugget && row.device in glb.device_d && type === 'display') {
			return '<span device="'+row.device+'" class="nugget_popup">'+row.nugget+'</span>';
		    } else {
			return row.nugget;
		    }
		}
	    }
	],
	"rowCallback": function(row, data){
	    var sev = data.severity;
	    if (sev > 40) {
		$('td:eq(2)', row).addClass('crit');
	    } else if (sev > 30) {
		$('td:eq(2)', row).addClass('error');
	    } else if (sev > 20) {
		$('td:eq(2)', row).addClass('warning');
	    }
	}
    });


    // Apply the search header handlers
    glb.table.columns().every( function () {
        var that = this;

    	$('input, select', this.footer()).on( 'input', function () {
        //$( 'input', $('order_list thead tr:first th').on( 'keyup change', function () {
	    var val = this.value;
	    var id = $(this).attr('id');

	    if (id != "lcl_filter_message") {
		val = remove_whitespace(val).replace(/,/g, '|');
	    }

	    if (id == "lcl_filter_device_sev") {
		for (var i = parseInt(val); i < 50; i+=10) {
		    val += "|" + (i+10);
		}
	    }
            that
                .search(val, true, false)
                .draw();
        } );
    	$('input, select', this.footer()).trigger("input");
    } );

    glb.table.updateRows = function() {
	// init filters
	var rows;
	// apply the device filters
	if (glb.filter.device ||
	    glb.filter.device_type ||
	    glb.filter.device_sev) {
	    var device_l = getFilteredDeviceList(true);
	    rows = glb.logs.filter(function(x) {
		return (device_l.indexOf(x.device) >= 0);
	    });
	} else {
	    rows = glb.logs;
	}

	// initialize the data
	glb.table
	    .clear()
	    .rows.add(rows)
	    .columns.adjust()
	    .draw();
    }

    glb.table.updateRows();

}

function loadDashboard () {
    $('#rightbar_lbl').hide(0);
    $('#page_content').html("");

    var html_text = '';

    html_text += '<div id="dashboard" class="center">';
    html_text += '<div>';
    html_text += '  <h1 style="font-size: x-large;" id="clientCount"></h1><hr>';
    html_text += '  <div style="display: inline-block; width:55%">';
    html_text += '    <div id="clientCount_plot"></div>';
    html_text += '<div align="right" style="padding-top: 10px">resample by: <table id="resample_by" data-chart="clientCount_plot"><tr>'+
	'<td value="min">min</td>'+
	'<td value="avg" class="selected">avg</td>'+
	'<td value="max">max</td>'+
	'<td value="all">all</td></tr></table></div>';
    html_text += '  </div>';
    html_text += '  <div style="display: inline-block; width:35%" id="clientCount_barplot"></div>';
    html_text += '</div>';
    html_text += '<div>';
    html_text += '  <h1 style="font-size:x-large;" id="throughput"></h1><hr>';
    html_text += '  <div style="display: inline-block; width:55%">';
    html_text += '    <div id="throughput_plot"></div>';
    html_text += '<div align="right" style="padding-top: 10px">resample by: <table id="resample_by" data-chart="throughput_plot"><tr>'+
	'<td value="min">min</td>'+
	'<td value="avg" class="selected">avg</td>'+
	'<td value="max">max</td>'+
	'<td value="all">all</td></tr></table></div>';

    html_text += '  </div>';
    html_text += '  <div style="display: inline-block; width:35%" id="throughput_barplot"></div>';
    html_text += '<hr>';
    html_text += '</div>';
    html_text += '</div>';
    $('#page_content').html(html_text);


    /*
     * Top Throughput
     */
    var yAxis = getAxis("ethThroughput", false);
    var options = {
	chart: {
	    type: 'bar',
	    renderTo: "throughput_barplot",
	    marginRight: 20,
	    animation: false
	},
	legend : {
	    enabled: false
	},
	title: {
	    text: "Top APs"
	},
	xAxis: {
	    categories: [],
	    labels: {
		enabled: true
		//rotation: -90,
		//align: 'right',
	    }
	},
	yAxis: yAxis,
	plotOptions: {
            bar: {
	    	dataLabels: {
                    enabled: true,
		    verticalAlign: 'middle',
		    y: -2,
		    formatter: function() {
			return this.y.toLocaleString();
		    }
	    	}
	    },
	    series: {
		cursor: 'pointer',
		point: {
		    events: {
			click: function() {
			    series_l = [
				{
				    name: this.category + "/" + "ethThroughput",
				    device: this.category,
				    nugget: "ethThroughput"
				},
				{
				    name: this.category + "/" + "ethThroughput_RX",
				    device: this.category,
				    nugget: "ethThroughput_RX"
				},
				{
				    name: this.category + "/" + "ethThroughput_TX",
				    device: this.category,
				    nugget: "ethThroughput_TX"
				}
			    ];
			    showPlotModal(series_l);
			}
		    }
		}
	    }
	},
        tooltip: {
	    enabled: false
        },
	credits: {
	    enabled: false
	},
	series: [
	    {
		name: "Values",
	    	data: []
	    }
	]
    };

    glb.chart_d['throughput_barplot'] = new Highcharts.Chart(options);

    /*
     * Top ClientCount
     */
    var yAxis = getAxis("clientCount", false);
    var options = {
	chart: {
	    type: 'bar',
	    renderTo: "clientCount_barplot",
	    marginRight: 20,
	    animation: false
	},
	legend : {
	    enabled: false
	},
	title: {
	    text: "Top APs"
	},
	xAxis: {
	    categories: [],
	    labels: {
		enabled: true
		// useHTML: true,
		// formatter: function() {
		//     return '<span class="device_popup nowrap clickable">'+this.value+'</span>';
		// }
		//rotation: -90,
		//align: 'right',
	    }
	},
	yAxis: yAxis,
	plotOptions: {
            bar: {
	    	dataLabels: {
                    enabled: true,
		    verticalAlign: 'middle',
		    y: -2
	    	}
	    },
	    series: {
		cursor: 'pointer',
		point: {
		    events: {
			click: function() {
			    series_l = [
				{
				    name: this.category + "/" + "clientCount_2.4GHz",
				    device: this.category,
				    nugget: "clientCount_2.4GHz"
				},
				{
				    name: this.category + "/" + "clientCount_5GHz",
				    device: this.category,
				    nugget: "clientCount_5GHz"
				}
			    ];
			    showPlotModal(series_l);
			}
		    }
		}
	    }
	},
        tooltip: {
            enabled: false
        },
	credits: {
	    enabled: false
	},
	series: [
	    {
		name: "Values",
	    	data: []
	    }
	]
    };

    glb.chart_d['clientCount_barplot'] = new Highcharts.Chart(options);
    // set the group prefix
    var prefix;
    if (glb.group) {
	prefix = glb.group;
    } else {
	prefix = "AP";
    }
    var group_device = "*"+prefix+"_Sum";

    series_l = [
    	{name: "Total", device: group_device, nugget: "clientCount"},
    	{name: "2.4GHz", device: group_device, nugget: "clientCount_2.4GHz"},
    	{name: "5GHz", device: group_device, nugget: "clientCount_5GHz"}
    ];
    showPlot("Attached Clients", series_l, "clientCount_plot");

    var tput_device = glb.config.nugget.global.throughput.device || group_device;
    var tput_nugget = glb.config.nugget.global.throughput.nugget;
    var tput_nugget_rx, tput_nugget_tx;
    if (tput_nugget in glb.config.nugget.unit_d) {
	tput_nugget_rx = tput_nugget + "_RX";
	tput_nugget_tx = tput_nugget + "_TX";
    } else {
        var name_l = tput_nugget.split(":");
	tput_nugget_rx = name_l[0] + "_RX:" + name_l[1];
	tput_nugget_tx = name_l[0] + "_TX:" + name_l[1];
    }

    series_l = [
	{name: "Total", device: tput_device, nugget: tput_nugget},
	{name: "RX", device: tput_device, nugget: tput_nugget_rx},
	{name: "TX", device: tput_device, nugget: tput_nugget_tx}
    ];

    showPlot("Network Throughput", series_l, "throughput_plot");


    /* start the statistics poller */
    function pollerStats(){
    	if (glb.view == "home") {
	    var url = utility.api_url("poller_stats");
    	    $.getJSON(url)
    		.done(function(stats_data, status) {
		    if (status == "nocontent")
			return;

    		    glb.poller_stats = stats_data;
    		    updateDashboard();
    		})
    		.always(function() {
    		    setTimeout(pollerStats,30000);
    		})
    	}
    }
    pollerStats();
}

function updateDashboard() {
    var text = "";

    var categories = [];
    var values = [];
    for (var i=0; i < glb.poller_stats['top_aps_tput'].length; i++) {
	categories.push(glb.poller_stats['top_aps_tput'][i]['name']);
	values.push(glb.poller_stats['top_aps_tput'][i]['val']);
    }
    glb.chart_d['throughput_barplot'].xAxis[0].setCategories(categories, false);
    glb.chart_d['throughput_barplot'].series[0].setData(values, false);
    glb.chart_d['throughput_barplot'].redraw();

    categories = [];
    values = [];
    for (var i=0; i < glb.poller_stats['top_aps_count'].length; i++) {
	categories.push(glb.poller_stats['top_aps_count'][i]['name']);
	values.push(glb.poller_stats['top_aps_count'][i]['val']);
    }
    glb.chart_d['clientCount_barplot'].xAxis[0].setCategories(categories, false);
    glb.chart_d['clientCount_barplot'].series[0].setData(values, false);
    glb.chart_d['clientCount_barplot'].redraw();

    /* clickable labels */
    $('.highcharts-xaxis-labels text').each(function(index, val) {
	var device_name = $(this).text();
	if (device_name in glb.device_d) {
	    var style = $(this).attr("style");
	    style += "cursor:pointer;";
	    $(this).attr("style", style);
	}
    });
}


function datetimeStrToSeconds(date_str) {
    var d = new Date(date_str);
    return d.getTime();
}

function datetimeSecondsToStr(date_sec) {
    var d = new Date(date_sec * 1000);
    return d.toLocaleTimeString();
}

function getSpan (span_start, span_end) {
    if (!span_start) span_start = glb.span_start;
    if (!span_end) span_end = glb.span_end;
    var min, max;

    min = span_start;
    max = span_end;

    if (max == "now") {
	max = new Date().getTime();
	if (span_start < 0) {
	    min = max + (span_start * 3600 * 1000); // to hours
	}
    }

    return {
	min: min,
	max: max
    }
}

function getEventTitle(event) {
    var start = moment(event.start_timestamp * 1000);
    var end = moment(event.end_timestamp * 1000);
    return (start.format('YYYY-MM-DD h:mm a')
    	    + " - " + end.format('h:mm a'));
}

function getTimeString (date, mil_time, seconds) {
    if (mil_time === undefined) mil_time = true;
    if (seconds === undefined) seconds = true;

    var ret = "";
    var now = moment();

    // is the day the same?
    if (now.diff(date, 'months', true) > 10) {
	ret += date.format('YYYY-MM-DD ');
    } else if (now.diff(date, "days") > 1) {
	if (now.diff(date, "days") > 6) {
	    ret += date.format('MMM DD ');
	} else {
	    ret += date.format('ddd ');
	}
    }

    if (mil_time) {
	if (seconds)
	    ret += date.format('HH:mm:ss');
	else
	    ret += date.format('HH:mm');
    } else {
	if (seconds)
	    ret += date.format('h:mm:ss A');
	else
	    ret += date.format('h:mm A');
    }
    return ret
}

function getTimeDiffString (a, b, decimals, plural) {
    if (b === undefined) b = moment();
    if (decimals === undefined) decimals = 1;
    if (plural === undefined) plural = true;

    var unit_l = ['years', 'months', 'weeks', 'days', 'hours', 'minutes']
    var unit_str_l = ['yr', 'mo', 'wk', 'day', 'hr', 'min']
    var d_str;
    for (var i = 0; i < unit_l.length; i++) {
	var unit = unit_l[i];
	var unit_str = unit_str_l[i];
	var d = Math.abs(b.diff(a, unit, true));
	d_str = d.toFixed(decimals) + " " + unit_str;
	if (d >= 1) {
	    if (d > 1 && plural) {
		d_str += 's';
	    }
	    return d_str
	}
    }
    return d_str
}

function getSpanTitle() {

    var ret = "";
    var now = moment();

    if (glb.span_start < 0) {
	ret += "last ";
	if (glb.span_start == -1) {
	    ret += "hour";
	} else {
	    ret += (-1*glb.span_start) + " hours";
	}
    } else {
	var start_d = moment(glb.span_start);
	// is the day the same?
	if (now.year() != start_d.year()) {
	    ret += start_d.format('YYYY-MM-DD ');
	} else if (now.dayOfYear() != start_d.dayOfYear()) {
	    ret += start_d.format('MMM DD ');
	} else {
	    ret += "Today: ";
	}
	ret += start_d.format('h:mma');
    }

    if (glb.span_start > 0) {
	ret += " &mdash; ";
	if (glb.span_end == "now") {
	    ret += "Now";
	} else {
	    var end_d = moment(glb.span_end);
	    if ((end_d.diff(start_d, 'days') > 0) &&  (now.diff(end_d, 'days') > 0)){
		ret += end_d.format('MMM DD h:mma');
	    } else {
		ret += end_d.format('h:mma');
	    }
	}
    }
    return ret;
}

function getSpanBrowserHTML() {
    var tab_width = 100;
    var html_text = ''+
	'<table class="popup_table">'+
	'<tr><th class="label1">Select a Time Span</th></tr>'+
	'<tr><td style="padding: 0">'+
	'<div id="event_tabs" class="tabs">'+
	'<ul>'+
	'<li><a href="#tabs-1" style="width:'+tab_width+'px">Custom Span</a></li>'+
	'<li><a href="#tabs-2" style="width:'+tab_width+'px">Recent</a></li>'+
	'</ul>'+
	'<div id="tabs-1">'+
	'  <div>Time Span: <input type="text" class="datetimepicker" id="start" placeholder="Start Time">'+
	'    <input type="text" class="datetimepicker" id="end" placeholder="End Time (blank=now)"></div><br>'+
	'    <div class="center" style="margin-top:10px;">'+
	'      <button class="std_button wide" id="span_load_btn">Load</button>'+
	'    </div>'+
	'</div>'+
	'<div id="tabs-2">'+
	'  <button class="std_button" style="padding:8px" id="recent_load_btn" value="-1">1 hour</button>'+
	'  <button class="std_button" style="padding:8px" id="recent_load_btn" value="-4">4 hours</button>'+
	'  <button class="std_button" style="padding:8px" id="recent_load_btn" value="-12">12 hours</button>'+
	'  <button class="std_button" style="padding:8px" id="recent_load_btn" value="-24">24 hours</button>'+
	'</div>'+
	'</td></tr></table>'

    return html_text;
}

function loadSpanBrowser () {
    var html = getSpanBrowserHTML();

    // open the fancybox
    fancybox(html, {
	minWidth    : 550,
    });

    $("#event_tabs").tabs();

    var startDateBox = $('.datetimepicker#start');
    var endDateBox = $('.datetimepicker#end');

    startDateBox.datetimepicker({
	//timeFormat: 'h:mmtt',
	//showMinute: false,
	maxDate: 0,
	defaultDate: 0,
	onClose: function() {
	    var date = $(this).datepicker('getDate');
	    endDateBox.datepicker('option', 'minDate', date);
	}
    });
    endDateBox.datetimepicker({
	//timeFormat: 'h:mmtt',
	//showMinute: false,
	maxDate: 0,
	defaultDate: 0,
	onClose: function() {
	    var date = $(this).datepicker('getDate');
	}
    });

    if (glb.span_start > 0) {
	startDateBox.datepicker('setDate', new Date(glb.span_start));
    }
    if (glb.span_end != "now") {
	endDateBox.datepicker('setDate', new Date(glb.span_end));
    }
}

function loadHelpPopup ()
{
    if (!glb.build_date) {
	glb.build_date = getJSON(utility.api_url("build_date"));
    }

    var date = moment(glb.build_date).format('YYYY-MM-DD');
    var html = '' +
	'<table class="popup_table">'+
	'<tr><th colspan=2 class="label1">Tool Info</th></tr>'+
	'<tr><th colspan=2 class="label2">General</th></tr>'+
	'<tr><th class="row-hdr">Author</th><td>Levi Mason<br>'+
	'<a href="mailto:levmason@cisco.com">levmason@cisco.com</a></td></tr>'+
	'<tr><th class="row-hdr">Build Date</th><td>'+date+'</td></tr>';

    if (glb.license_info) {
	html += '<tr><th colspan=2 class="label2">License</th></tr>'+
	    '<tr><th class="row-hdr">License Name</th><td>'+glb.license_info.license_name+'</td></tr>'+
	    '<tr><th class="row-hdr">License User</th><td>'+glb.license_info.license_user+'</td></tr>';
	    if (glb.license_info.exp_date) {
		html += '<tr><th class="row-hdr">Expiration Date</th><td>'+glb.license_info.exp_date+'</td></tr>';
	    }
    }

    html += '<tr><th colspan=2 class="label2">Help</th></tr>'+
	'<tr><td colspan=2 style="padding: 8px;"><a href="https://wiki.cisco.com/display/SYFTER/Syfter+Home" target="_blank">'+
	'<button class="std_button">Wiki</button></a></td></tr>';
	'</table>';
    //'<tr><th class="row-hdr">Build Date</th><td>'+date+'</td></tr>';
    fancybox(html);
}

function loadToolsPopup ()
{
    var html = '' +
	'<table class="popup_table">'+
	'<tr><th colspan=2 class="label1">Tools</th></tr>'+
	'<tr><td colspan=2 style="padding: 8px">'+
	'<div style="max-width: 150px; margin: auto;">';

    /* nugget manager */
    html += '<a href="nugget_manager" target="_blank">'+
	'<button class="std_button" style="width: 130px">Nugget Manager</button>'+
	'</a>';

    /* config tracking */
    html += '<a href="diff/cfg/tree/master/" target="_blank">'+
	'<button class="std_button" style="width: 130px">Config Tracker</button>'+
	'</a>';

    html += '</div></td></tr>';

    fancybox(html);
}

function loadGroupPopup ()
{
    var html = '' +
	'<table class="popup_table">'+
	'<tr><th colspan=2 class="label1">Select a Device Group</th></tr>'+
	'<tr><td><select id="group_select"><option value="">All Devices</option>';
    for (var i = 0; i < glb.config.group_l.length; i++) {
	var group = glb.config.group_l[i].name;
	if (group == glb.group) {
	    html += '<option value='+group+' selected>'+group+'</option>';
	} else {
	    html += '<option value='+group+'>'+group+'</option>';
	}
    }

    html += '</select><div style="padding-top: 10px"><button class="std_button" id="group_load_btn">Load</button>'+
	'</div></td></tr></table>';
    //'<tr><th class="row-hdr">Build Date</th><td>'+date+'</td></tr>';
    fancybox(html);
}

function blockElement (element, msg)
{
    if (msg == undefined)
	msg = null

    element.block({
	message: msg,
	css: {
            border: 'none',
            padding: '15px',
            backgroundColor: '#000',
            '-webkit-border-radius': '10px',
            '-moz-border-radius': '10px',
            opacity: .5,
            color: '#fff'
	},
	fadeIn: 0
    });
}

function blockUI ()
{
    $.blockUI({
	css: {
            border: 'none',
            padding: '15px',
            backgroundColor: '#000',
            '-webkit-border-radius': '10px',
            '-moz-border-radius': '10px',
            opacity: .5,
            color: '#fff'
	},
	fadeIn: 0
    });
}

function loadSpanData ()
{
    $.fancybox.close();

    var span = getSpan();
    var delta = span.max - span.min;

    if (delta) {
	var d_l = []; // initialize the deferred list
	blockUI();
	var url = utility.api_url("metric_presence",
				  [Math.floor(span.min/1000),
				   Math.floor(span.max/1000)]);
	var params = {};
	if (glb.group) {params['group'] = glb.group;}
	d_l.push($.getJSON(url, params)
		 .done(function(data) {
		     if (data) {
			 glb.span_d = data;
		     }
		     deviceListUpdate();
		     conditionsUpdate();
		     setLeftbarHTML();
		     setRightbarHTML();
		     setView();
		 })
		 .fail(function() {
		     console.log("no data");
		 })
		);

	/* load the logs */
	glb.logs = [];
	url = utility.api_url("logs",
			      [Math.floor(span.min/1000),
			       Math.floor(span.max/1000)]);
	var params = {};
	if (glb.group) {params['group'] = glb.group;}
	var d = $.getJSON(url, params)
	    .done(function(data, status) {
		if (status == "nocontent")
		    return;

		glb.logs = data;
		updateDeviceSeverity();
    		if (glb.view == "logs" && glb.table) {
		    glb.table.updateRows();
		}

	    })
	    .always(function() {
		if (glb.span_end == "now") {
		    setTimeout(updateLogs, cfg.poll_interval.logs);
		}
	    })
	if (glb.view == "logs") {
	    d_l.push(d);
	}

	$.when.apply($, d_l).always(function(){
	    $.unblockUI();
	    /* start the presence poller */
	    metricPresenceUpdate();

	    /* load the full nugget summaries */
	    if (glb.span_end != "now") {
		var url = utility.api_url("metric_summary",
					  [Math.floor(span.min/1000),
					   Math.floor(span.max/1000)]);
		var params = {};
		if (glb.group) {params['group'] = glb.group;}
		$.getJSON(url, params)
		    .done(function(data, status) {
			if (data) {
			    glb.span_d = data;
			}
		    })
	    }
	});

    }
}

function loadEventData (event)
{
    //var event_id = $('#event_select option:selected').val();
    $.fancybox.close();

    if (event) {
	// set globals
	glb.span_start = event['start_timestamp'];
	glb.span_end = event['end_timestamp'];

	var d_l = []; // initialize the deferred list
	blockUI();
	var url = utility.api_url("event", [event.id]);
	d_l.push($.getJSON(url, function(data) {
	    glb.span_d = data;
	    glb.group = data.group;
	    setDeviceTypeList();
	    setLeftbarHTML();
	    setRightbarHTML();
	    setView();
	}));

	/* load the logs */
	var span = getSpan();
	glb.logs = [];
	url = utility.api_url("logs",
			      [Math.floor(span.min/1000),
			       Math.floor(span.max/1000)]);
	var params = {};
	if (glb.group) {params['group'] = glb.group;}
	var d = $.getJSON(url, params)
	    .done(function(data, status) {
		if (status == "nocontent")
		    return;

		glb.logs = data;
		updateDeviceSeverity();
    		if (glb.view == "logs" && glb.table) {
		    glb.table.updateRows();
		}
	    })
	    .always(function() {
		if (glb.span_end == "now") {
		    setTimeout(updateLogs, cfg.poll_interval.logs);
		}
	    })
	if (glb.view == "logs") {
	    d_l.push(d);
	}

	$.when.apply($, d_l).always(function(){
	    $.unblockUI();
	});


    }
}

/* start the device list poller */
function updateLogs(){
    /* get the current span */
    var span = getSpan();

    /* remove old logs */
    for (var i=0; i < glb.logs.length; i++) {
	if (glb.logs[i].timestamp < span.min) {
	    glb.logs.shift();
	}
    }
    try {
	var last_timestamp = glb.logs[glb.logs.length - 1].timestamp;
	// need to round then add a second
	last_timestamp = (Math.floor(last_timestamp/1000) + 1) * 1000;
	span.min = Math.max(span.min, last_timestamp);
    } catch (err) {}

    var url = utility.api_url("logs",
			      [Math.floor(span.min/1000),
			       Math.floor(span.max/1000)]);
    var params = {};
    if (glb.group) {params['group'] = glb.group;}
    $.getJSON(url, params)
	.done(function(data, status) {
	    if (status == "nocontent")
		return;

	    glb.logs = glb.logs.concat(data);
	    updateDeviceSeverity();
    	    if (glb.view == "logs" && glb.table) {
		glb.table.updateRows();
	    }

	})
	.always(function() {
	    if (glb.span_end == "now") {
		setTimeout(updateLogs, cfg.poll_interval.logs);
	    }
	})
}

function updateDeviceSeverity() {
    var device_l = {};

    for (var i=0; i < glb.logs.length; i++) {
	var log = glb.logs[i];
	var sev = log.severity;
	var device = log.device;
	var nugget = log.nugget;

	if (log.type == "nugget") {
	    // see if we already have a device entry
	    if (device in device_l) {
		if (nugget in device_l[device]) {
		    sev = Math.max(sev, device_l[device][nugget]);
		}
	    } else {
		device_l[device] = {};
	    }

	    glb.device_sev[device] = sev;
	    device_l[device][nugget] = sev;
	}
    }

    glb.device_severity = device_l;

    if (glb.view == "grid") {
	updateGridColors();
    }
}

view_labels = {
    'grid': 'Grid View',
    'report': 'Report',
    'home': 'Summary',
    'devices': 'Device List',
    'conditions': 'Device Conditions',
    'logs': 'Logs',
    'nugget': 'Nugget Configuration',
    'polling': 'Polling Configuration',
    'site': 'Site Configuration',
    'tool': 'Tool Configuration',
    'device_type': 'Device Type Configuration',
}

function setView (view) {
    if (view == undefined)
	view = glb.view

    // highlight the menu item
    $('#leftbar ul > li').removeClass("selected");
    $('#menu_'+view).addClass('selected');
    $('#title_header').html(view_labels[view]);

    glb.view = view;

    // show/hide/position the time span
    $('#toolbar_center_bubble').css({bottom: (view == 'grid') ? '35px':'0px'});
    $('#toolbar_center_bubble').toggle(['logs','grid'].indexOf(view) >= 0);
    // show/hide the config buttons
    $('#toolbar_right_bubble').toggle(['site','polling','tool','device_type','nugget'].contains(view));
    // show/hide the grid filter bar
    if (view != "grid")	$('#filter_bar').empty();
    // show/hide the rightbar lbl
    $('#rightbar_lbl').toggle(['logs','grid','devices','conditions'].indexOf(view) >= 0);
    // show/hide the help bubble
    $('#toolbar_help_bubble').toggle(['nugget'].indexOf(view) >= 0);

    switch (view) {
    case "grid":
	loadGridHTML();
	break;
    case "report":
	loadReportContent();
	break;
    case "home":
	loadDashboard();
	break;
    case "devices":
	loadDeviceTable();
	break;
    case "conditions":
	loadConditionTable();
	break;
    case "logs":
	loadLogTable();
	break;
    case "nugget":
	nugget_browser.init("#page_content");
	break;
    default:
	showSimpleConfig(view);
    }
}
function showSimpleConfig(cfg_name) {

    var html ='<div id="config-browser">'+
	'<div id="'+cfg_name+'">'+
	'<textarea class="config" id="'+cfg_name+'_cfg_area" spellcheck="false" name="cfg_after">'+
	glb.config.cfg_after[cfg_name]+'</textarea>'+
	'</div></div>';
    $('#page_content').html(html);
}

function deviceListUpdate(){
    try {
	clearTimeout(glb.device_list_timer);
    } catch (err) {}

    var url = utility.api_url("device_list");
    var params = {"static": true};
    if (glb.group) {params['group'] = glb.group;}
    $.getJSON(url, params)
	.done(function(device_l) {
	    var device_d = {};
	    for (var i=0; i < device_l.length; i++) {
		var device_name = device_l[i].name;
		device_d[device_name] = device_l[i];
	    }
	    glb.device_l = device_l;
	    glb.device_d = device_d;
	    setDeviceTypeList();

    	    if (glb.view == "devices" && glb.table) {
		glb.table.updateRows();
	    }
	})
	.always(function() {
	    glb.device_list_timer = setTimeout(deviceListUpdate, cfg.poll_interval.device_list);
	})
}

function conditionsUpdate(){
    try {
	clearTimeout(glb.conditions_list_timer);
    } catch (err) {}

    var url = utility.api_url("conditions");
    var params = {};
    if (glb.group) {params['group'] = glb.group;}
    $.getJSON(url, params)
	.done(function(condition_l) {
	    glb.condition_l = condition_l;
    	    if (glb.view == "conditions" && glb.table) {
		glb.table.updateRows();
	    }
	})
	.always(function() {
	    glb.conditions_list_timer = setTimeout(conditionsUpdate, cfg.poll_interval.conditions);
	})
}

$(document).ready(function(){
    /* this is required for django CSRF handling */
    $.ajaxSetup({
        beforeSend: function(xhr, settings) {
            if (!(/^http:.*/.test(settings.url) || /^https:.*/.test(settings.url))) {
                // Only send the token to relative URLs i.e. locally.
                xhr.setRequestHeader("X-CSRFToken",
                                     $("input[name=csrfmiddlewaretoken]").val());
            }
        }
    });

    /* parse parameters */
    try {
	var param_d = {};
	var param_l = location.href.split("?")[1].split('&');

	// convert to dictionary
	for (var i = 0; i < param_l.length; i++) {
	    var param = param_l[i].split('=');
	    var name = param[0];
	    var value = param[1];
	    param_d[name] = value;
	}

	// check the parameters
	if (param_d.standalone) {
	    glb.view = param_d.standalone;
	    $('#toolbar_right_bubble').css({right: '0', top: '0'});
	    $('#wrapper').css({padding: "30px"});
	} else if (param_d.view) {
	    glb.view = param_d.view;
	}
    } catch {}

    /* initialize the config */
    // LEVY: Syncronous because we need it before generating the dashboard
    glb.config = getJSON(utility.api_url("config"));
    console.log(glb.config);

    glb.span_start = glb.config.span_start;
    glb.span_end = glb.config.span_end;

    /* get the build date */
    $.getJSON(utility.api_url("build_date"))
	.done(function(data) {
	    glb.build_date = data;
	})

    /* get the license info */
    $.getJSON(utility.api_url("license_info"))
	.done(function(data) {
	    glb.license_info = data;
	})

    /* initialize the interface */
    loadSpanData();

    // /* filterbar click */
    // $(document).on('click', '#filter_bar > label', function(e) {
    // 	$('#filter_bar > table').toggle(200);
    // 	$('#filter_bar > label').toggle();
    // });

    /* Leftbar Hover */
    $(document).on('mouseenter mouseleave', '#leftbar', $.debounce(100, function(e) {
	if (e.type == "mouseover") {
	    $('#leftbar_lbl').hide();
	    $('#leftbar_content').show();
	    $('#leftbar').css({width:'125px'});
	    //$('#leftbar').animate({width:'125px'}, 200);

	} else {
	    $('#leftbar_content').hide();
	    $('#leftbar_lbl').show();
	    $('#leftbar').css({width:'30px'});
	    //$('#leftbar').animate({width:'30px'}, 200);
	}
    }));

    /* Rightbar Hover */
    $(document).on('mouseenter mouseleave', '#rightbar', $.debounce(100, function(e) {
	if (['logs','grid','devices','conditions'].indexOf(glb.view) >= 0) {
	    if (e.type == "mouseover") {
		if ($(this).has(document.activeElement).length == 0) {
		    rightbarExpand();
		}
	    } else {
		if ($(this).has(document.activeElement).length == 0) {
		    rightbarHide();
		}
	    }
	}
    }));

    $(document).on('focusout', '#rightbar', $.debounce(100, function(e) {
	if ($(this).has(document.activeElement).length == 0) {
	    rightbarHide();
	}
    }));

    /* Toolbar Items */
    // $(document).on('click', '#print_btn', function(e) {
    // 	reportPopup();
    // 	return;
    // });

    $(document).on('click', '#event_btn', function(e) {
	loadEventBrowser();
    });

    $(document).on('click', '#help_btn', function(e) {
	loadHelpPopup();
    });

    $(document).on('click', '#tools_btn', function(e) {
	loadToolsPopup();
    });

    $(document).on('click', '#edit_cfg_btn', function(e) {
	window.open('nugget_manager');
    });

    $(document).on('click', '#group_hdr', function(e) {
	loadGroupPopup();
    });

    $(document).on('click', '#span_hdr', function(e) {
	loadSpanBrowser();
    });

    /* Menu Items */
    $(document).on('click', 'ul#leftbar_menu li', function(e) {
	var id = $(this).attr('id').split('_');
	id = id.slice(1).join('_');
	setView(id);
    });

    // Table Tab
    // $('#table_btn').click(function(e) {
    // 	var html = getTableHTML();
    // 	$('#page_content').html(html);
    // });
    // $(document).on('input', '#device_table_params', function() {
    // 	var html_text = getTableContent($(this).val());
    // 	$('#device_table').html(html_text);
    // });

    /* send_report */
    $(document).on('click', 'button#send_report_btn', function(e) {
	var span = getSpan();
	var delta = span.max - span.min;
	if (delta) {
	    url = utility.api_url("send_report",
				  [Math.floor(span.min/1000),
				   Math.floor(span.max/1000)]);
	    params = {data: JSON.stringify(glb.span_d),
		      to: $('#mailto').val()};
	    $.post(url, params);
	}
    });

    /* Load Event Data */
    $(document).on('click', 'button#span_load_btn', function(e) {
	glb.span_start = datetimeStrToSeconds($('.datetimepicker#start').val());
	glb.span_end = datetimeStrToSeconds($('.datetimepicker#end').val());
	if (isNaN(glb.span_end)) {
	    glb.span_end = "now";
	}

	loadSpanData();
    });

    $(document).on('click', 'button#group_load_btn', function(e) {
	glb.group = $('#group_select').val();
	loadSpanData();
    });

    $(document).on('click', 'button#recent_load_btn', function(e) {
	glb.span_end = "now";
	glb.span_start = $(this).val();
	loadSpanData();
    });
});

$.fn.redraw = function(){

    $(this).each(function(){

	var redraw = this.offsetHeight;

    });

};

var glb = {
    view: "logs",
    group: "",
    poller_status: "---",
    poller_stats: {},
    poller_query_done: true,
    chart_d: {},
    span_d: {
	device_d: {},
    },
    device_l: [],
    device_d: {},
    device_type_l: [],
    max_device_type: '',
    logs: [],
    device_severity: {},
    device_sev: {},
    span_start: -1,
    span_end: "now",
    filter_enabled: false,
    filter: {
	device: "",
	device_type: "",
	device_sev: "",
	nugget: ""
    },
    config: {},
    table: null,
    grid: {
	selected_device: [],
	selected_nugget: []
    },
    poller_status_timer: null,
    resample_by: "avg",
    back_function: null
};

var lcl = {
    filter: {
	device: "",
	device_type: "",
	device_sev: 0,
	nugget: ""
    }
};

var cfg = {
    poll_interval: {
	logs: 30000, // 30sec
	conditions: 30000, // 30sec
	device_list: 60000, // 1min
	metric_presence: 60000 // 1min
    }
};
