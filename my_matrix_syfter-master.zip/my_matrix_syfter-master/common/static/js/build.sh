rm syfter.min.js

# check for -q argument
QUICK=false
for arg in "$@"
do
    if [ "$arg" == "-q" ]
    then
	QUICK=true
    fi
done

if $QUICK; then
    cat \
	export-csv.js \
	jquery.blockUI.js \
	jquery.stickyheader.js \
	jquery-ui-timepicker-addon.js \
	jquery.json-viewer.js \
	syfter.utility.js \
	syfter.js \
	syfter.column.js \
	syfter.table.js \
	syfter.config_editor.js \
	syfter.device_popup.js \
	syfter.event_browser.js \
	syfter.filter.js \
	syfter.grid.js \
	syfter.nugget_manager.js \
	syfter.plot.js \
	syfter.poller_status.js \
	natural.js \
	autosize.min.js \
	jquery.ba-throttle-debounce.min.js \
	js-yaml.min.js \
	moment.min.js \
	>> syfter.min.js
else
    ./compressjs.sh \
	export-csv.js \
	jquery.blockUI.js \
	jquery.stickyheader.js \
	jquery-ui-timepicker-addon.js \
	jquery.json-viewer.js \
	syfter.utility.js \
	syfter.js \
	syfter.column.js \
	syfter.table.js \
	syfter.config_editor.js \
	syfter.device_popup.js \
	syfter.event_browser.js \
	syfter.filter.js \
	syfter.grid.js \
	syfter.nugget_manager.js \
	syfter.plot.js \
	syfter.poller_status.js \
	natural.js \
	syfter.min.js
    cat \
	autosize.min.js \
	jquery.ba-throttle-debounce.min.js \
	js-yaml.min.js \
	moment.min.js \
	>> syfter.min.js
fi
