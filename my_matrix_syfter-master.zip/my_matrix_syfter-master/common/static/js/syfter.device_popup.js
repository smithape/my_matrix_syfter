function loadDevicePopup (device_name, prev_popup_html, callback) {
    var url = utility.api_url("device_status", [device_name]);
    $.getJSON(url)
	.done(function(dev_status) {
	    var html = '';
	    var dev = glb.device_d[device_name];
	    if (!dev) return;

	    // html += '<div style="background-color:#424242;">'+
	    // 	'<h1 style="color:#ccc;">Device Info</h1>'+
	    // 	'</div>';

	    html += '<table id="device_popup_tbl" class="popup_table" device_name='+device_name+'>'+
		//'<tr><th colspan=2 class="label1">'+dev.name+'</th></tr>'+
		'<tr><th colspan=2 class="label1">Device Info</th></tr>'+
		//'<tr><td colspan=2 style="font-size:14px">'+dev.name+'</td></tr>'+
		'<tr><th colspan=2 class="label2">Attributes</th></tr>'+
		'</thead>';

	    /* name */
	    if (dev.name) {
	    	html += '<tr><th class="row-hdr">Name</th><td>'+dev.name+'</td></tr>';
	    }

	    /* type */
	    if (dev.type) {
		html += '<tr><th class="row-hdr">Type</th><td>'+dev.type+'</td></tr>';
	    }

	    /* model */
	    if (dev.model) {
		html += '<tr><th class="row-hdr">Model</th><td>'+dev.model+'</td></tr>';
	    }

	    /* IP Address */
	    if (dev.ip_address) {
		html += '<tr><th class="row-hdr">IP Address</th><td><a href="ssh://'+
		    dev.ip_address+'">'+dev.ip_address+'</a></td></tr>';
	    }

	    /* MAC Address */
	    if (dev.mac_address) {
		html += '<tr><th class="row-hdr">Mac Address</th><td>'+dev.mac_address+'</td></tr>';
	    }

	    /* upstream i/f */
	    if (dev.switch) {
		html += '<tr><th class="row-hdr">Upstream I/F</th><td>'+
		    dev.switch + " | " + dev.switch_if+'</td></tr>';
	    }

	    /* ap group */
	    if (dev.ap_group) {
		html += '<tr><th class="row-hdr">AP Group</th><td>'+
		    dev.ap_group+'</td></tr>';
	    }

	    /*
	     * Nugget status
	     */
	    if (!$.isEmptyObject(dev_status)) {
		function getValCell(entry_name, entry) {
		    var cls = '';
		    if (entry.sev > 30) {
			cls = "error";
		    } else if (entry.sev > 20) {
			cls = 'warning';
		    }

		    var html = '';
		    if (cls) {
			html += '<td class="'+cls+'">';
		    } else {
			html += '<td>';
		    }

		    if (entry.val != null) {
			var unit = getUnit(entry_name).unit || '';
			html += entry.val +''+unit+'</td>';
		    } else {
			html += '-</td>';
		    }

		    return html;
		}

		html += '<tr><th colspan=2 class="label2">Current Status</th></tr>';

		for (var entry_name in dev_status) {
		    var entry = dev_status[entry_name];

		    html += '<tr class="clickable hover plot" nugget_name="'+entry_name+'">'+
			'<th class="row-hdr">'+entry_name+'</th>';

		    if (entry.children) {
			html += '<td class="embedder"><table class="embedded"><tr>';
			/* set the header */
			var width = (100.0 / Object.keys(entry.children).length);
			for (var child in entry.children) {
			    html += '<th style="background:rgba(0, 0, 0, 0.1); width:'+width+'%;">'+child+'</th>';
			}
			html += '</tr><tr>';
			/* the values */
			for (var child in entry.children) {
			    var child_entry = entry.children[child];
			    html += getValCell(entry_name+'_'+child, child_entry);
			}
			html += '</tr></table></td>';
		    } else {
			html += getValCell(entry_name, entry)
		    }
		}
	    }

	    /*
	     * actions
	     */
	    html += '<tr><th colspan=2 class="label2">Actions</th></tr>'+
		'<tr><td colspan=2 style="padding: 8px">'+
		'<div style="max-width: 150px; margin: auto;">';

	    /* test ping */
	    html += '<button id="test_ping_btn" test="ping" value="'+dev.name+
		'" class="std_button" style="width: 130px">Test Ping</button>';
	    /* test snmp */
	    if (dev.snmp_supported) {
		html += '<button id="test_snmp_btn" test="snmp" value="'+dev.name+
		    '" class="std_button" style="width: 130px">Test SNMP</button>';
	    }
	    html += '</div></td></tr>';

	    /*
	     * tools
	     */
	    if (glb.config.user_is_admin && (dev.has_login_creds || dev.track_config) || dev.snmp_supported) {
		html += '<tr><th colspan=2 class="label2">Tools</th></tr>'+
		    '<tr><td colspan=2 style="padding: 8px">'+
		    '<div style="max-width: 150px; margin: auto;">';

		/* web term */
		if (glb.config.user_is_admin && dev.has_login_creds) {
		    html += '<a href="term/'+dev.name+'" target="_blank">'+
			'<button class="std_button" style="width: 130px">Web Terminal</button>'+
			'</a>';
		}
		/* config tracking */
		if (glb.config.user_is_admin && dev.track_config) {
		    html += '<a href="diff/cfg/tree/master/'+dev.name+'.cfg/" target="_blank">'+
			'<button class="std_button" style="width: 130px">Config Tracker</button>'+
			'</a>';
		}
		html += '</div></td></tr>';
	    }


	    html += '</table>';

	    // spawn the popup
	    if (prev_popup_html) {
		fancybox(html, {
		    afterClose: function() {
			fancybox(prev_popup_html);
			if (callback) {
			    callback.apply(this);
			}
			return false;
		    }
		});
	    } else {
		fancybox(html);
	    }
	})
}

$(document).ready(function(){

    /* conditions/logs table */
    $(document).on('click', "table:not(#issues_tbl) span.device_popup", function() {
	var device_name = $(this).text();
	loadDevicePopup(device_name);
    });

    /* poller status popup */
    $(document).on('click', "table#issues_tbl span.device_popup", function() {
    	var device_name = $(this).text();
	var html = $('div.fancybox-inner').html();
	loadDevicePopup(device_name, html, updatePollerStatus);
    });

    /* highcharts axis */
    $(document).on('click', '.highcharts-xaxis-labels text', function () {
	var device_name = $(this).text();

	if (device_name in glb.device_d) {
	    loadDevicePopup(device_name);
	}
    });

    $(document).on('click', 'table#device_popup_tbl tr.plot', function () {
	var device_name = $('table#device_popup_tbl').attr('device_name');
	var nugget_name = $(this).attr('nugget_name');
	var series_l = [];
	var nugget_l = [nugget_name];

	/* add the children */
	$(this).find('table.embedded th').each(function() {
	    var child_suffix = $(this).text();
	    var child_name = nugget_name + '_' + child_suffix;
	    nugget_l.push(child_name);
	});

	for (var i = 0; i < nugget_l.length; i++) {
	    nugget_name = nugget_l[i];
	    if (nugget_name in glb.config.nugget.unit_d) {
		series_l.push(
		    {
			name: device_name + "/" + nugget_name,
			device: device_name,
			nugget: nugget_name
		    }
		);
	    }
	}

	glb.back_fn = function () {
	    loadDevicePopup(device_name);
	}

	showPlotModal(series_l, true);
    });

    /* test snmp */
    $(document).on('click', '#test_snmp_btn, #test_ping_btn', function () {
	var device_name = $(this).val();
	var test = $(this).attr('test');
	var _this = $(this);
	var text_before = _this.text();

	blockElement(_this);
	var url = utility.api_url("test", [test, device_name]);
	$.getJSON(url)
	    .done(function(json) {
		var cls;
		var text;
		if (json.result) {
		    text = "Pass";
		    cls = "btn_green";
		} else {
		    text = "Fail";
		    cls = "btn_red";
		}

		_this.text(text);
		_this.addClass(cls)

		setTimeout(function () {
		    _this.removeClass(cls, 500, function () {
			_this.text(text_before);
		    });
		}, 1000);
	    })
	    .always(function() {
		_this.unblock();
	    });
    });
});
