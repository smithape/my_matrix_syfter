function lockLocalFilters () {
    var val, disable;

    /* device type */
    val = glb.filter.device_type;
    disable = val?true:false;
    val = val || lcl.filter.device_type_bkp;
    lcl.filter.device_type = val;

    $('#lcl_filter_device_type')
	.val(val)
	.prop("disabled", disable)
	.trigger("applyFilter");

    /* device sev */
    val = glb.filter.device_sev;
    disable = val?true:false;
    val = val || lcl.filter.device_sev_bkp || 0;
    lcl.filter.device_sev = val;

    $('#lcl_filter_device_sev')
	.val(val)
	.prop("disabled", disable)
	.trigger("applyFilter");
}

function clearGlobalFilters () {
    /* clear the values */
    glb.filter = {
	device: "",
	device_type: "",
	device_sev: 0,
	nugget: ""
    }
    /* clear the ui */
    for (key in glb.filter) {
	var id = "#filter_" + key;
	$(id).val(glb.filter[key]);
    }

    /* update the local filters */
    lockLocalFilters();

    /* update the view */
    if (glb.view == "grid") {
	/* grid view */
	loadGrid();
    } else {
	/* table views */
	glb.table.updateRows();
    }
}

function clearLocalFilters () {
    lcl.filter = {
	device: "",
	device_type: "",
	device_sev: 0,
	nugget: ""
    }
}

function applyFilter_handler () {
    var id = $(this).attr('id').replace(/filter_/, '');
    var val = remove_whitespace($(this).val()).replace(/,/g, '|');
    var col_name;
    var tbl_filter;

    switch (id) {
    case "device":
	glb.filter.device = val;
	col_name = "Device Name";
	break;
    case "lcl_device":
	lcl.filter.device = val;
	col_name = "Device Name";
	break;
    case "device_type":
	/* set global and local */
	glb.filter.device_type = val;
	lockLocalFilters();
	tbl_filter = lcl.filter.device_type;
	col_name = "Device Type";
	break;
    case "lcl_device_type":
	lcl.filter.device_type_bkp = val;
	lcl.filter.device_type = val;
	col_name = "Device Type";
	break;
    case "device_sev":
	if (val) {
	    val = parseInt(val);
	} else {
	    val = 0;
	}
	glb.filter.device_sev = val;
	lockLocalFilters();
	break;
    case "lcl_device_sev":
	if (val) {
	    val = parseInt(val);
	} else {
	    val = 0;
	}
	lcl.filter.device_sev_bkp = val;
	lcl.filter.device_sev = val;
	break;
    case "nugget":
	glb.filter.nugget = val;
	col_name = "Nugget Name";
	break;
    case "lcl_nugget":
	lcl.filter.nugget = val;
	col_name = "Nugget Name";
	break;
    }


    if (glb.view == "grid") {
	/* grid view */
	loadGrid();
    } else {
	/* table views */
	if (id.startsWith("device")) {
	    glb.table.updateRows();
	    /* table filters */
	    if (tbl_filter) {
		glb.table
		    .column(col_name+":name")
		    .search(tbl_filter, true, false)
		    .draw();
	    }

	} else {
	    /* table filters */
	    glb.table
		.column(col_name+":name")
		.search(val, true, false)
		.draw();
	}
    }
}

function applyGlobalFilters(device_d, device_l) {
    /* nothing to do? */
    if (!glb.filter.device &&
	!glb.filter.device_type &&
	!glb.filter.device_sev) {
	return device_l;
    }
    var name_re = get_regex(glb.filter.device);
    var type_re = get_regex(glb.filter.device_type);

    device_l = device_l.filter(function (x) {
	var device_sev = (x in glb.device_sev) ? glb.device_sev[x]: 0;

    	return (name_re.test(x) &&
		type_re.test(device_d[x].type) &&
		device_sev >= glb.filter.device_sev
	       );
    });
    return device_l;
}

function applyLocalFilters(device_d, device_l) {
    /* nothing to do? */
    if (!lcl.filter.device &&
	!lcl.filter.device_type &&
	!lcl.filter.device_sev) {
	return device_l;
    }

    var name_re = get_regex(lcl.filter.device);
    var type_re = get_regex(lcl.filter.device_type);

    device_l = device_l.filter(function (x) {
	var device_sev = (x in glb.device_sev) ? glb.device_sev[x]: 0;

    	return (name_re.test(x) &&
		type_re.test(device_d[x].type) &&
		device_sev >= lcl.filter.device_sev
	       );
    });
    return device_l;
}

function getFilteredDeviceList(current) {
    var device_d;

    /* start with the complete list of devices */
    if (current) {
	/* merge current and span device list */
	device_d = $.extend({}, glb.device_d, glb.span_d.device_d);
    } else {
	device_d = glb.span_d.device_d;
    }

    var device_l = Object.keys(device_d).sort();
    /* apply the global filters first */
    device_l = applyGlobalFilters(device_d, device_l);
    /* apply the local filters */
    if (glb.view == "grid") {
	device_l = applyLocalFilters(device_d, device_l);
    }

    return device_l;
}

function getFilteredNuggetList(device_l) {
    var device_d = glb.span_d['device_d'];
    var device_l_orig = Object.keys(device_d);
    if (!device_l) device_l = getFilteredDeviceList();

    var nugget_l;
    if (device_l.length == device_l_orig.length) {
	/* the nugget list is unaffected by device filters */
	nugget_l = glb.span_d['nugget_l'];
    } else {
	/* filter based on device/nugget availability */
	nugget_l = [];
	for (var i=0; i < device_l.length; i++) {
	    var device_name = device_l[i];
	    var nugget_d = device_d[device_name]['nugget_d'];
	    for(var nugget_name in nugget_d) {
		if (nugget_l.indexOf(nugget_name) < 0) {
                    nugget_l.push(nugget_name);
		}
	    }
	}
    }

    if (!nugget_l) return;

    nugget_l.sort();

    /* apply global filters */
    var name_re = get_regex(glb.filter.nugget);
    nugget_l = nugget_l.filter(function (x) {
    	return name_re.test(x);
    });

    /* apply local filters */
    var name_re = get_regex(lcl.filter.nugget);
    nugget_l = nugget_l.filter(function (x) {
    	return name_re.test(x);
    });

    return nugget_l
}

$(document).ready(function(){
    /*
     * Filter Bar
     */
    $(document).on('input', 'input.filter', $.debounce(500, applyFilter_handler));
    $(document).on('input', 'select.filter', applyFilter_handler);

    $(document).on('click', '#clear_glb_filters_btn', function () {
	clearGlobalFilters();
    });
});
