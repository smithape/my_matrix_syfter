// This is currently deprecated, though it might be added back in the future

function loadClientTable () {

    html_text =
	'<div style="margin-top:20px">'+
	'<table id="client_list" class="display compact cell-border std_table" cellspacing="0"'+
	'style="padding: 10px 0; width:95%;">'+
	'<thead>'+
	'<tr>'+
	'<th>Mac Address</th>'+
	'<th>IP Address</th>'+
	'<th>Group</th>'+
	'</tr>'+
	'</thead>'+
	'<tfoot>'+
	'<tr>'+
	'<th><input size="1" type="search"></th>'+
	'<th><input size="1" type="search"></th>'+
	'<th><input size="1" type="search"></th>'+
	'<option value=""></option>';
	'</tr>'+
	'</tfoot>'+
	'</table>'+
	'</div>';


    $('#page_content').html(html_text);

    // $('#device_list tfoot th').each(function() {
    // 	var title = $('#device_list thead th').eq($(this).index()).text();
    // 	$(this).html('<input type="text"/>');
    // });
    var height = window.innerHeight- 300;
    // the table rows are 23 pixels high
    var displayLength = Math.floor(height / 23);

    glb.table = $('#client_list').DataTable({
	"data" : glb.client_l,
	"ajax": {
	    "url" : utility.api_url("client_list"),
	    "dataSrc": ""
	},
	"search": {
	    "regex": true
	    //"smart": true
	},
	"aLengthMenu": [[25, 50, 100, -1], [25, 50, 100, "All"]],
	"iDisplayLength": displayLength,
	"columns" : [
	    {name: 'Mac Address', "data": "mac_address", "sClass": "nowrap"},
	    {name: 'IP Address', "data": "ip_address", "sClass": "nowrap"},
	    {name: 'Group', "data" : "group", "sClass": "nowrap"},
	],

    });


    // Apply the search header handlers
    glb.table.columns().every( function () {
        var that = this;

	$('input, select', this.footer()).on( 'applyFilter input', function (e) {
	    var val = remove_whitespace(this.value).replace(/,/g, '|');

	    /* backup the local value */
	    if (e.type == "input") {
		var id = $(this).attr('id');
		if (id) {
		    id = id.replace(/lcl_filter_/g, '') + "_bkp";
		    lcl.filter[id] = val;
		}
	    }

	    that
                .search(val, true, false)
                .draw();
        });

	/* apply initial filter */
	$('input, select', this.footer()).trigger("applyFilter");

    } );

    // glb.table.updateRows = function() {
    // 	// init filters
    // 	// apply the device filters
    // 	var device_l = getFilteredDeviceList(true);
    // 	var rows = glb.device_l.filter(function(x) {
    // 	    return (device_l.indexOf(x.name) >= 0);
    // 	});

    // 	// initialize the data
    // 	glb.table
    // 	    .clear()
    // 	    .rows.add(rows)
    // 	    .columns.adjust()
    // 	    .draw();
    // }

    // glb.table.updateRows();
}

