var table_viewer = {
    table_data: null,
}

table_viewer.is_tabular = function(data) {
    var self = table_viewer;
    try {
	return (Array.isArray(data) && data[0].constructor == Object);
    } catch {
	return false;
    }
}

table_viewer.parse_headers = function () {
    self = table_viewer;

    // find the headers
    var header_l = [];
    for (var i = 0; i < self.table_data.length; i++) {
	var entry = self.table_data[i];
	for (var key in entry) {
	    if (header_l.indexOf(key) < 0) {
		header_l.push(key);
	    }
	}
    }
    return header_l;
}

table_viewer.get_table_html = function () {
    self = table_viewer;

    var html = '<div style="padding: 20px">'+
	'<table id="syfter_table" class="display compact cell-border std_table"'+
	'cellspacing="0">'+
	'<thead>'+
	'<tr>';

    for (var i = 0; i < self.header_l.length; i++) {
	var header = self.header_l[i];
	html += '<th>'+header+'</th>';
    }
    html += '</tr></thead></table></div>';

    return html;
}

table_viewer.init_table = function (destination, table_data) {
    self = table_viewer;
    self.table_data = table_data;

    // initialize the data
    if (self.table_data.headers) {
	self.header_l = self.table_data.headers;
	self.data = self.table_data.data;
    } else {
	self.header_l = self.parse_headers();
	self.data = self.table_data;
    }

    // insert the html
    var html = self.get_table_html();

    $(destination).html(html);

    // init the datatables
    var cols = [];
    for (var i = 0; i < self.header_l.length; i++) {
	var header = self.header_l[i];
	var col = {
	    name: header,
	    data: header,
	    defaultContent: "",
	    sClass: "nowrap"
	};
	if (['timestamp', 'time', 'ts'].indexOf(header.toLowerCase()) >= 0) {
	    col.render = function(timestamp) {
		// make sure it's epoch
		if (isNaN(timestamp)) return timestamp;

		// convert secs to ms
		if (timestamp < 315532800000) {
		    timestamp = timestamp * 1000;
		}
		var t = moment(timestamp);
		return getTimeString(t, false);
	    }

	}
	cols.push(col);
    }

    var height = window.innerHeight- 300;
    // the table rows are 23 pixels high
    var displayLength = Math.floor(height / 23);

    self.table = $('#syfter_table').DataTable({
	data: self.data,
	columns: cols,
	iDisplayLength: displayLength,
	scrollX: true
    });
}

$(document).ready(function(){
    self = table_viewer;
//    self.init_table('#nugget_browser');
});
