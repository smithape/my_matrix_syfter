function getReportHTML () {
    var html = '';
    html += ''+
	'<div id="report">'+
	'<table class="popup_table" style="border-collapse: collapse;">'+
	'<tr><td>test</td><td>test2</td></tr>'+
	'<tr><td>test</td><td>test2</td></tr>'+
	'</table>'+
	'</div>'+
	'<iframe width="80%" style="width: 80%" id="test"></iframe>';

    return html;
}

function reportPopup () {

    var html = getReportHTML()

    $.fancybox({
    	content     : html,
    	fitToView   : true,
    	autoSize    : true,
    	minWidth    : 800,
    	minHeight   : 800,
    	openEffect  : 'none',
    	closeEffect : 'none',
    	closeBtn : true,
    	helpers : {
    	    overlay : {
    		locked : false,
     		css : {
    		    background : 'none'
    		}
    	    }
    	}
    });

    html2canvas ($('#report'), {
	onrendered: function(canvas) {
	    var imgData = canvas.toDataURL('image/png');
	    //var pdf = new jsPDF('p', 'mm', 'a4');
	    var pdf = new jsPDF();
	    //pdf.addImage(imgData, 'PNG', 10, 10, 100, 250);
	    pdf.addImage(imgData, 'PNG', 10, 10);
	    pdf.save('web.pdf');
	}
    });
    // var pdf = new jsPDF('p', 'pt', 'a4');
    // var options = {
    // 	pagesplit: false
    // };
    // pdf.addHTML($('#page_content')[0], options, function() {
    // 	//var string = pdf.output('datauristring');
    // 	//$('#test').attr('src', string);
    // 	pdf.save('web.pdf');
    // });
    // pdf.fromHTML(html, 45, 15);
    // var string = pdf.output('datauristring');
    // $('#test').attr('src', string);

    //pdf.save("web.pdf");
}