function getBarPlotHTML() {
    var height = Math.min(screen.height*0.5, 600);
    var width = $('#content').width() - 60;

    var html_text =
	'<div align="right">'+
	'Sort By <select name="column_sort">'+
	'<option value="avg">Average</option>'+
	'<option value="max">Maximum</option>'+
	'</select>'+
	'</div>'+
	"<div id='graph' style='width:"+width+"; height:"+height+"; margin: 0 auto'></div>";

    return html_text;
}

function showBarPlot(nugget_name, sort_by) {

    var max_xAxis_range = 30;
    var cols_max = 30;
    var chart;

    /*
     * Initialize the modal
     */
    var html = getBarPlotHTML();
    fancybox(html, {
        beforeClose : function() {
	    // delete the chart
	    chart.destroy();
	},
    });

    /*
     * set the initial state of the sort radio button
     */
    if (sort_by != undefined) {
	$("select[name=column_sort]").val(sort_by);
    }

    var yAxis = getAxis(nugget_name, false);
    yAxis.max = null;
    // var scrollbar_enabled = false;
    // if (data.avg.length > max_xAxis_range) {
    // 	scrollbar_enabled = true;
    // }

    var options = {
	chart: {
	    type: 'column',
	    renderTo: "graph",
	    marginRight: 20,
	    animation: true
	},
	legend : {
	    //enabled: false
	},
	title: {
	    text: nugget_name
	},
	subtitle: {
	    text: "Showing top "+cols_max+" devices"
            //text: "Average = " + 10,//+ nugget_global_avg,
	},
	// scrollbar: {
	//     enabled: scrollbar_enabled
	// },
	xAxis: {
	    //categories: data.categories,
	    //max: Math.min(data.categories.length, max_xAxis_range) - 1,
	    labels: {
		enabled: true,
		rotation: -90,
		align: 'right'
	    }
	},
	yAxis: yAxis,
	plotOptions: {
            bar: {
	    	dataLabels: {
		    //align: 'left',
                    enabled: true,
		    //			    overflow: false,
		    verticalAlign: 'middle',
		    y: -2
	    	}
	    },
	    column: {
		animation: true,
		grouping: false,
		threshold: yAxis.min
            },
	    series: {
		cursor: 'pointer',
		point: {
		    events: {
			click: function() {
			    series_l = [{
				name: this.category + "/" + this.series.chart.title.textStr,
				device: this.category,
				nugget: this.series.chart.title.textStr
			    }];
			    var sort_by = $("select[name=column_sort] option:selected").val();
			    glb.back_fn = function () {
			    	showBarPlot(nugget_name, sort_by);
			    }
			    showPlotModal(series_l, true);
			}
		    }
		}
	    }
	},
        tooltip: {
            formatter: function() {
                var s = "";
                $.each(this.points, function(i, point) {
                    s += '<span style="font-weight: bold; color: '+ point.series.color +'">';
		    s += point.series.name+'</span>: <b>'+point.y.toLocaleString()+'</b> <br>';
		    //s += point.series.options.tooltip.valueSuffix+'</br>';
                });
                return s;
            },
            shared: true
        },
	credits: {
	    enabled: false
	},
	series: [
	    {
		name: "Average",
	    	//data: data.avg,
		zIndex: 2
	    },
	    {
		name: "Maximum",
	    	//data: data.max,
		zIndex: 1
	    }
	]
    };

    /* initialize the chart */
    chart = new Highcharts.Chart(options);
    chart.nugget_name = nugget_name;
    chart.cols_max = cols_max;

    getBarPlotData(chart)

    // var data = getBarPlotData(nugget_name, cols_max);

    // function updateChart(data) {
    // 	chart.series[0].setData(data.avg, false);
    // 	chart.series[1].setData(data.max, false);
    // 	chart.xAxis[0].setCategories(data.categories, false);
    // 	chart.redraw();
    // };
    // updateChart(data);

    /*
     * Column Chart Sort
     */
    $("select[name=column_sort]").change(function() {
	getBarPlotData(chart);
	// var data = getBarPlotData(nugget_name, cols_max);
	// updateChart(data);
    });
}

function getBarPlotData (chart) {

    function crunch_data (chart) {
	var sort_by = $("select[name=column_sort] option:selected").val();
	var categories = [];
	var avg_data = [];
	var max_data = [];
	var device_entries = [];

	for (var device_name in chart.data) {
	    var device_vals = chart.data[device_name];

	    device_entries.push(
		{
		    name: device_name,
		    avg: device_vals['avg'],
		    max: device_vals['max']
		}
	    );
	}


	if (device_entries.length == 0) {
	    return;
	}

	function sortByKey(array, key) {
	    return array.sort(function(a, b) {
		var x = b[key]; var y = a[key];
		return ((x < y) ? -1 : ((x > y) ? 1 : 0));
	    });
	}

	device_entries = sortByKey(device_entries, sort_by);

	for (i = 0; i < Math.min(chart.cols_max, device_entries.length); i++)
	{
	    entry = device_entries[i];
	    categories.push(entry['name']);
	    avg_data.push(entry['avg']);
	    max_data.push(entry['max']);
	}

    	chart.series[0].setData(avg_data, false);
    	chart.series[1].setData(max_data, false);
    	chart.xAxis[0].setCategories(categories, false);
    	chart.redraw();

	/* clickable labels */
	$('.highcharts-xaxis-labels text').each(function(index, val) {
	    var device_name = $(this).text();
	    if (device_name in glb.device_d) {
		var style = $(this).attr("style");
		style += "cursor:pointer;";
		$(this).attr("style", style);
	    }
	});
	// return {
	//     categories: categories,
	//     max: max_data,
	//     avg: avg_data
	// }
    }

    if (chart.data) {
	crunch_data(chart);
    } else if (glb.span_end == "now" || glb.span_d.state == "partial") {
	var span = getSpan(glb.span_start, glb.span_end);
	var url = utility.api_url("top_devices", [chart.nugget_name,
						  Math.floor(span.min/1000),
						  Math.floor(span.max/1000)]);
	var params = {group: glb.group};
	if (chart.cols_max) params.n = chart.cols_max;
	if (lcl.filter.device_type) params.device_type = lcl.filter.device_type;
	if (lcl.filter.device) params.filter = lcl.filter.device;
	else if (glb.filter.device) params.filter = glb.filter.device;
	$.getJSON(url, params, function(json) {
	    //chart.data = json.data;
	    chart.data = json;
	    crunch_data(chart);
	});
    } else {
	var data = {};
	var device_l = getFilteredDeviceList();
	for (var i = 0; i < device_l.length; i++) {
	    var device_name = device_l[i];
	    if (device_name.startsWith("*")) continue
	    var nugget_d = glb.span_d.device_d[device_name]['nugget_d'];
	    if (chart.nugget_name in nugget_d && 'avg' in nugget_d[chart.nugget_name])
	    {
		data[device_name] = nugget_d[chart.nugget_name];
	    }
	}
	chart.data = data;
	crunch_data(chart);
    }
}
