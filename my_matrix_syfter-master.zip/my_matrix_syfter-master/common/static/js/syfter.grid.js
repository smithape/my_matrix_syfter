function getTextWidth(text, el_class) {
    element = $("<span class='" + el_class + "'>" + text + "</span>");
    $('body').append(element);
    var width = element.width();
    element.remove();
    return width;
}

function setFilterBarHTML () {
    var html_text = '<table>';

    /* device name */
    html_text += '<td>Device Name<input type="search" class="filter" id="lcl_filter_device"></td>';

    /* device type */
    html_text += '<td>Device Type<select class="filter" id="lcl_filter_device_type">'+
	'<option value=""></option>';
    for (var i = 0; i < glb.device_type_l.length; i++) {
	var dtype = glb.device_type_l[i];

	if (dtype == lcl.filter.device_type) {
	    html_text += '<option value='+dtype+' selected>'+dtype+'</option>';
	} else {
	    html_text += '<option value='+dtype+'>'+dtype+'</option>';
	}
    }
    html_text += '</select>';

    /* device severity */
    html_text += '<td>Device Severity<select class="filter" id="lcl_filter_device_sev">'+
	'<option value=0></option>';
    for (var id in glb.config.sev_map) {
	if (id > 20) {
	    html_text += '<option value='+id+'>'+glb.config.sev_map[id]+'</option>';
	}
    }
    html_text += '</select></td>';

    /* nugget name */
    html_text += '<td>Nugget Name<input type="search" class="filter" id="lcl_filter_nugget"></td>'+
	'</tr><tr><td></td>'+
	'</td>'+
	'</tr>'+
	'</table>';

    $('#filter_bar').html(html_text);
}

function loadGridHTML () {

    $('#rightbar_lbl').show();
    clearLocalFilters();
    setFilterBarHTML();
    lockLocalFilters();
    $('#filter_bar').show();

    var html_text = "";

    html_text += '<div class="center" style="text-align:center;" id="event_content"></div>';
    html_text += '<div style="height: 50px;"></div>';

    html_text += '<table class="grid_controls" id="grid_footer">';
    html_text += '<tr>';
    html_text += '<td>';
    html_text += '<button class="std_button" id="clear_checkboxes_btn">Clear Selection</button>';
    html_text += '</td>';
    html_text += '<td class="center">';
    html_text += '<button class="std_button center" id="plot_btn">Plot</button>';
    html_text += '</td>';
    html_text += '<td></td></tr></table>';

    $('#page_content').html(html_text);

    loadGrid();
}

function loadGrid () {
    var device_d = glb.span_d['device_d'];
    // clear the event_content div
    $('#event_content').html("");

    /* first we find the list of distinct Nuggets */
    var device_l = getFilteredDeviceList();
    var nugget_l = getFilteredNuggetList(device_l);

    var html_text = ""
    html_text += "<table class='table-header-rotated'>";
    html_text += "<thead>";
    // add the header row
    html_text += '<tr><th colspan="2"></th>';
    var max_width = 75; //LEVY: not sure about hardcoding, maybe I should
    var limit = 50;
    if (nugget_l.length > limit) {
	$('#event_content').html("Too many nuggets! ("+nugget_l.length+")");
	return;
    }
    //t_start = new Date();
    for (var i = 0; i < nugget_l.length; i++) {
	var nugget_name = nugget_l[i];
	//LEVY: calculating takes time
    	var width = getTextWidth(nugget_name, "");
    	max_width = Math.max(max_width, width);
	html_text += '<th class="col-header"><div><span>'+nugget_name;
	/* do we add the column-plot option? */
	if (nugget_name.split(':')[0] in glb.config.nugget.unit_d && glb.config.nugget.unit_d[nugget_name] != "setting") {
	    html_text += '<div style="position:relative;display:inline;">'+
		'<img src="'+static_root+'/img/bar.svg" height="15px" width="15px" class="bar_btn" id="'+nugget_name+'">'+
		'</div>';
	}
	html_text += '</span></div></th>';
    }

    //t_end = new Date();
    //console.log("header_height took: " + (t_end.getTime() - t_start.getTime()));

    html_text +='<th style="min-width: ' + max_width + 'px"></th>';
    html_text += '</tr>';

    html_text += "</thead>";

    html_text += "<tbody>";
    /* top checkboxes */
    html_text += '<tr ><th colspan="2"></th>';
    for (var i = 0; i < nugget_l.length; i++) {
        html_text +='<td class="header_checkbox"><label><input type="checkbox" class="agg_checkbox" value="'+nugget_l[i]+'"></label></td>\n';
    }
    html_text += '</tr>';

    //t_start = new Date();

    var limit = 100; // maximum number of rows to show
    var k = 0;
    for (var i = 0; i < device_l.length; i++) {
	if (k >= limit) break;
	var device_name = device_l[i];
        var nugget_d = device_d[device_name]['nugget_d'];
	var row_empty = true;
	device_row = '<tr>';
	if (device_name in glb.device_d) {
	    device_row += '<th class="row-header"><span class="device_popup">'+device_name+'</span></th>';
	} else {
	    device_row += '<th class="row-header"><nobr>'+device_name+'</nobr></th>';
	}
	/* side checkbox */
	device_row +='<td class="header_checkbox"><label><input type="checkbox" class="agg_checkbox" name="'+device_name+'"></label></td>\n';
	for (var j = 0; j < nugget_l.length; j++) {
	    nugget = nugget_l[j];
	    if (nugget in nugget_d) {
		/* add the cell */
                device_row += '<td><label><input type="checkbox" class="std_checkbox" value="'+nugget+'" name="'+device_name+'"></label></td>\n';
		row_empty = false;
	    } else {
                device_row += "<td></td>\n";
	    }
        }
        device_row += '</tr>\n';

	if (!row_empty) {
	    html_text += device_row;
	    k++;
	}
    }

    //t_end = new Date();
    //console.log("tbody: " + (t_end.getTime() - t_start.getTime()));

    html_text += "</tbody>";
    html_text += "</table>";
    html_text += "</div>";



    //var t_start = new Date();
    $('#event_content').html(html_text);
    //var t_end = new Date();

    //console.log("time for dom: " + (t_end.getTime() - t_start.getTime()));
    $('.bar_btn').each(function () {
	$(this).parents('span').addClass("clickable");
    });


    $('.col-header').css({
        'height': max_width + 'px'
    });

    $('.col-header > div').css({
        'left': max_width/2 + 'px'
    });

    updateGridColors();
    //var t_start = new Date();
    stickyTable($('table.table-header-rotated'))
    //var t_end = new Date();

    //console.log("time for sticky headers: " + (t_end.getTime() - t_start.getTime()));
}

/*
 * Initialize Handlers etc
 */
$(document).ready(function(){

    // column plot header button
    $(document).on('click', '.col-header span.clickable', function(e) {
	var nugget_name = $(this).text();
	showBarPlot(nugget_name);
    });

    $(document).on('mouseenter mouseleave', '.col-header span', function(e) {
	// escape all special characters that don't work in selectors
	var nugget_name = $(this).text()

	var btn = $(".bar_btn#"+selector_enc(nugget_name));
	if (e.type == "mouseenter") {
	    btn.css({opacity:1.0});
	} else {
	    btn.css({opacity:0});
	}
    });

    /*
     * checkboxes
     */
    $(document).on('click', 'button#clear_checkboxes_btn', function(e) {
	$('input:checkbox').prop('checked', false);
    });

    $(document).on('click', 'input:checkbox.agg_checkbox', function(e) {
	if (this.name) {
	    $('input:checkbox.std_checkbox[name="'+this.name+'"]').prop('checked', this.checked);
	} else {
	    $('input:checkbox.std_checkbox[value="'+this.value+'"]').prop('checked', this.checked);
	}
    });

    $(document).on('change', 'input:checkbox.std_checkbox', function(e) {
	var row = $('input:checkbox.std_checkbox[name="'+this.name+'"]');
	var row_hdr = $('input:checkbox.agg_checkbox[name="'+this.name+'"]');
	var col = $('input:checkbox.std_checkbox[value="'+this.value+'"]');
	var col_hdr = $('input:checkbox.agg_checkbox[value="'+this.value+'"]');

	/* row handling */
	if (row_hdr.prop('checked')) {
	    if (row.filter(':checked').length != row.length) {
		row_hdr.prop('indeterminate', true);
	    } else {
		row_hdr.prop('indeterminate', false);
	    }
	}

	/* col handling */
	if (col_hdr.prop('checked')) {
	    if (col.filter(':checked').length != col.length) {
		col_hdr.prop('indeterminate',true);
	    } else {
		col_hdr.prop('indeterminate', false);
	    }
	}
    });

    /*
     * Plot btn
     */
    $(document).on('click', 'button#plot_btn', function(e) {
	var series_l = [];
	$('input:checkbox.std_checkbox:checked').each(function (i, box) {
	    series_l.push (
		{
		    name: box.name + "/" + box.value,
		    device: box.name,
		    nugget: box.value
		}
	    );
	});
	showPlotModal(series_l);
    });

});

function updateGridColors() {
    // first remove all classes
    $('input:checkbox.std_checkbox[name="'+device+'"][value="'+nugget+'"]')
	.closest('td')
	.removeClass();

    var device_d = glb.device_severity;

    for (var device in device_d) {
	for (var nugget in device_d[device]) {
	    var sev = device_d[device][nugget];
	    $('input:checkbox.std_checkbox[name="'+device+'"][value="'+nugget+'"]')
		.closest('td')
		.addClass(glb.config.sev_map[sev]);
	}
    }
}

function metricPresenceUpdate() {
    try {
	clearTimeout(glb.metric_presence_timer);
    } catch (err) {}

    if (glb.span_end == "now") {
	var url = utility.api_url("metric_presence");
	var params = {};
	if (glb.group) {params['group'] = glb.group;}
	$.getJSON(url, params)
	    .done(function(device_d) {
		for (var device_name in device_d) {
		    if (!(device_name in glb.span_d.device_d)) {
			glb.span_d.device_d[device_name] = {
			    'type': device_d[device_name].type,
			    'nugget_d': {},
			}
		    }
		    var nugget_l = device_d[device_name].nugget_l;
		    for (var i = 0; i < nugget_l.length; i++) {
			var nugget_name = nugget_l[i];
			if (!(nugget_name in glb.span_d.device_d[device_name]['nugget_d'])) {
			    glb.span_d.device_d[device_name]['nugget_d'][nugget_name] = {};
			}
		    }
		}

    		if (glb.view == "grid") {
		    loadGrid();
		}
	    })
	    .always(function() {
		glb.metric_presence_timer = setTimeout(metricPresenceUpdate,
						       cfg.poll_interval.metric_presence);
	    })
    }
}

