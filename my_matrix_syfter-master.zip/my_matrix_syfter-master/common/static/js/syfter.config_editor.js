var config_browser = {}

config_browser.modified = function () {
    $('#save_cfg_btn')
	.removeClass('disabled')
	.addClass('selected');
}

config_browser.loadImportPopup = function () {
    var html = `
	<table class="popup_table" >
	<tr><th class="label1">Import Configs</th></tr>
	<tr><th class="label2">Config File</th></tr>
	<td style="padding: 10px"><input type="file" id="file_import" hidden/>
	<label id="file_import_label" class="std_button" for="file_import">Choose a file...</label>
	</td></tr>
	<tr><th id="import_name" class="label2" hidden>Config Sections</th></tr>
	<tr hidden><td id="import_details" style="padding: 10px 0 10px 80px; text-align: left;" colspan=2></td></tr>
	</table>
	</div>
	<div style="padding-top:10px">
	<button id="import_save_btn" class="std_button wide" hidden>Import</button>
	</div>`;

    fancybox(html, {
	maxWidth: 400,
    });

    function show_details (cfg_name, cfg_d) {
	//$('#import_name').html("Importing: " + cfg_name);
	$('#file_import_label').text(cfg_name);
	var html = '';
	if ("polling" in cfg_d)
	    html += '<label><input type="checkbox" name="polling_config" checked> Polling Config</label><br>';
	if ("site" in cfg_d)
	    html += '<label><input type="checkbox" name="site_config" checked> Site Config</label><br>';
	if ("tool" in cfg_d)
	    html += '<label><input type="checkbox" name="tool_config" checked> Tool Config</label><br>';
	if ("nugget" in cfg_d || "device_type" in cfg_d)
	    html += '<label><input type="checkbox" name="nugget_config" checked> Nugget Config</label>';

	$('#import_details').html(html);
	$('#import_name').show();
	$('#import_details').parent().show();
	$('#import_save_btn').show();
    }

    $(document).on('change', '#file_import', function(e) {
	var file = e.target.files[0];
	var reader = new FileReader();
	reader.onload = function(e) {
	    var cfg_d = JSON.parse(e.target.result);
	    glb.config.config_import = cfg_d;
	    show_details(file.name.split('.')[0], cfg_d);
	}
	reader.readAsText(file);
    });
}

config_browser.loadExportPopup = function () {
    var html = `
	    <table class="popup_table">
	    <tr><th class="label1">Export Configs</th></tr>
	    <tr><th class="label2">Config Name</th></tr>
	    <tr><td>
	    <input style="text-align: center" name="filename">
	    </td></tr>
	    <tr><th class="label2">Config Sections</th></tr>
	    <tr><td style="text-align: left; padding: 10px 0 10px 50px;">
	    <label><input type="checkbox" name="polling_config" checked> Polling Config</label><br>
	    <label><input type="checkbox" name="site_config" checked> Site Config</label><br>
	    <label><input type="checkbox" name="tool_config" checked> Tool Config</label><br>
	    <label><input type="checkbox" name="nugget_config" checked> Nugget Config</label></td></tr>
	    </table>
	    </div><div style="padding-top:10px">
	    <button id="export_save_btn" class="std_button wide">Export</button></div>`;

    fancybox(html, {
	minWidth: 200
    });
}

$(document).ready(function(){
    var self = config_browser;

    /* warning when leaving with unsaved */
    window.onbeforeunload = function (e) {
	return $('#save_cfg_btn').hasClass("selected") || undefined;
    };

    /* save config */
    $(document).on('click', '#save_cfg_btn', function () {
	if (!$(this).hasClass("selected"))
	    return;

	var config_l = [];
	// get standard configs
	for (var cfg_name in glb.config.cfg_after) {
	    if (cfg_name != "nugget") {
		config_l.push(cfg_name);
	    }
	}

	// get nugget configs
	for (var dtype in glb.config.cfg_after.nugget) {
	    if (glb.config.cfg_before.nugget[dtype] || glb.config.cfg_after.nugget[dtype]) {
		config_l.push('nugget/'+dtype);
	    }
	}

	// submit each config
	config_d = {}
	for (var i = 0; i < config_l.length; i++) {
	    var cfg_name = config_l[i];
	    // if it's a nugget config
	    if (cfg_name.startsWith('nugget/')) {
		var [tmp, dtype] = cfg_name.split('/');
		// initialize to empty strings
		var cfg_before = "";
		var cfg_after = "";
		// if not empty, convert to yaml
		if (glb.config.cfg_before.nugget[dtype]) {
		    cfg_before = jsyaml.dump(glb.config.cfg_before.nugget[dtype],
					     {sortKeys: true});
		}
		if (glb.config.cfg_after.nugget[dtype]) {
		    cfg_after = jsyaml.dump(glb.config.cfg_after.nugget[dtype],
					    {sortKeys: true});
		}
		config_d[cfg_name] = {
		    cfg_before: cfg_before,
		    cfg_after: cfg_after
		}
	    } else {
		config_d[cfg_name] = {
		    cfg_before: glb.config.cfg_before[cfg_name],
		    cfg_after: glb.config.cfg_after[cfg_name]
		}
	    }
	}

	// disable the save btn
	$(this)
	    .removeClass('selected')
	    .addClass('disabled');

	var params = {data: JSON.stringify(config_d)};
	$.post(utility.api_url("config_save"), params)
	    .fail(function(response, status) {
		alert(response.responseText);
	    })
	    .done(function(response, status) {
		// copy the after config into the before
		glb.config.cfg_before = JSON.parse(JSON.stringify(glb.config.cfg_after));
	    })
    });

    /* export config */
    $(document).on('click', '#export_cfg_btn', function () {
	self.loadExportPopup();
    });
    $(document).on('click', '#export_save_btn', function () {
	//var url = utility.api_url("export_config");
	var options = {
	    polling: $('input:checkbox[name="polling_config"]').prop('checked'),
	    site: $('input:checkbox[name="site_config"]').prop('checked'),
	    tool: $('input:checkbox[name="tool_config"]').prop('checked'),
	    nugget: $('input:checkbox[name="nugget_config"]').prop('checked'),
	    device_type: $('input:checkbox[name="nugget_config"]').prop('checked')
	};
	var name = $('input[name="filename"]').val() || "mdf";
	name += ".conf";

	var cfg = {};
	for (var key in options) {
	    if (options[key]) {
		cfg[key] = glb.config.cfg_after[key];
	    }
	 }

	utility.download_json_as_file(cfg, name);
	$.fancybox.close()
    });

    $(document).on('click', '#import_save_btn', function() {
	var options = {
	    polling: $('input:checkbox[name="polling_config"]').prop('checked'),
	    site: $('input:checkbox[name="site_config"]').prop('checked'),
	    tool: $('input:checkbox[name="tool_config"]').prop('checked'),
	    nugget: $('input:checkbox[name="nugget_config"]').prop('checked'),
	    device_type: $('input:checkbox[name="nugget_config"]').prop('checked')
	};

	for (var key in options) {
	    if (options[key]) {
		var cfg = glb.config.config_import[key];
		if (key == "nugget") {
		    // merge with existing
		    for (var device_type in cfg) {
			// add missing device types
			if (!glb.config.cfg_after.nugget[device_type]) {
			    glb.config.cfg_after.nugget[device_type] = {};
			}
			for (var nugget_name in glb.config.config_import.nugget[device_type]) {
			    glb.config.cfg_after.nugget[device_type][nugget_name] = glb.config.config_import.nugget[device_type][nugget_name];
			}
		    }
		} else if (key == "device_type") {
		    var device_type_cfg = jsyaml.load(yaml_enc(cfg));
		    nugget_browser.UpdateDeviceTypeTree(device_type_cfg);
		} else {
		    if (key == "site") {
			// remove obfuscated passwords
			cfg = cfg.replace(/\*\*(\d+)\*\*/g,'');
		    }
		    glb.config.cfg_after[key] = cfg;
		}
	    }
	 }

	$.fancybox.close();
	// reload the current page (if config)
	if (['nugget', 'site','tool','polling'].contains(glb.view)) {
	    setView(glb.view);
	}

	// enable the save button
	self.modified();
    });

    $(document).on('click', '#import_cfg_btn', function() {
	self.loadImportPopup();
    });

    $(document).on('input', 'textarea.config', function (e) {
	self.modified();

	var id = $(this).attr('id').replace("_cfg_area", "");
	glb.config.cfg_after[id] = yaml_enc($(this).val());
    });

    var indent_re = /^(\s+)/;
    $(document).on('keydown', 'textarea.config', function (e) {
	switch(e.which) {
	case 9: // Tab
	    // set the default indent
	    var indent = "    ";

	    // find the cursor/selection location
	    var start = this.selectionStart;
	    var end = this.selectionEnd;

	    // current text
	    var text = $(this).val();

	    // find current indentation
	    var tmp_str = text.substring(0, start)
	    var tmp_str = tmp_str.substring(0, tmp_str.lastIndexOf("\n"));
	    var last_line = tmp_str.split('\n').last();
	    var match = indent_re.exec(last_line);
	    if (match) {
		indent = match[1];
	    }

	    $(this).val(text.substring(0, start)
			+ indent
			+ text.substring(end));
	    this.selectionStart = this.selectionEnd = start + indent.length;

	    e.preventDefault();
	default:
	    break;
	}
    });
});
