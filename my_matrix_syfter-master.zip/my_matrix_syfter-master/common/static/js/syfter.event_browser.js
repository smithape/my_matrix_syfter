function getEventBrowserHTML(event_list) {
    var tab_width = 100;
    var html_text = ''+
	// header
	'<table class="popup_table">'+
	'<tr><th class="label1">Event Browser</th></tr>'+
	'<tr><td style="padding-top: 10px">'+
	// datatable
	'<table id="event_list" class="display compact cell-border std_table" cellspacing="0"'+
	'style="padding: 10px 0;">'+
	'<thead>'+
	'<tr>'+
	'<th>Start Time</th>'+
	'<th>Group</th>'+
	'<th>Name</th>'+
	'</tr>'+
	'</thead>'+
	'<tfoot>'+
	'<tr>'+
	'<th><input size="1" type="search"></th>'+
	'<th><input size="1" type="search"></th>'+
	'<th><input size="1" type="search"></th>'+
	'</tr>'+
	'</tfoot>'+
	'</table>'+
	'</td></tr></table>'+
	// buttons
	'<div class="center" style="margin:10px 0 0 0;">'+
	'<div style="float:left; position:absolute;">';
    if (glb.span_end != "now") {
	html_text += '<button class="std_button wide" id="event_save_btn">Add</button>';
    }
    html_text += '<button class="std_button wide" id="event_delete_btn">Delete</button></div>'+
	'<div style="margin:0 auto;"><button class="std_button wide" id="event_load_btn">Load</button></div>'+
	'</div>';
    return html_text;
}

function loadEventBrowser()
{
    var event_d = {} // initialize to empty
    var url = utility.api_url("event");
    $.getJSON(url, function(json, status) {
	var event_l = json.event_l;
	// save as dict
	for (var i=0; i < event_l.length; i++) {
	    event_d[event_l[i]['id']] = event_l[i];
	}

	var html = getEventBrowserHTML();

	// open the fancybox
	fancybox(html, {
	    minWidth    : 650,
	});

	var height = window.innerHeight - 320;
	// the table rows are 23 pixels high
	var displayLength = Math.floor(height / 23);

	//
	// the event table
	var table = $('#event_list').DataTable({
	    "data" : event_l,
	    "search": {
		"regex": true
		//"smart": true
	    },
	    "dom": "tipr",
	    "order": [[0, "desc"]],
	    //"filter" : false,
	    //"paginate": true,
	    "pagingType": "simple",
	    "iDisplayLength": displayLength,
	    "columns" : [
		{name: 'Timestamp', "sClass": "nowrap dt-body-justify clickable"},
		{name: 'Group', "data": "group", "sClass": "nowrap clickable"},
		{name: 'Name', "sClass": "nowrap"},
		{name: 'ID', "data": "id"}
	    ],
	    "columnDefs": [
		{
		    "name": "Timestamp",
	    	    "targets": 0, // timestamp
		    "data": function (row, type, val) {
			if (type === 'display' || type === 'filter') {
			    var t = moment(row.start_timestamp);
			    return getTimeString(t, false, false);
			}
			return row.start_timestamp;
		    }
		},{
		    "targets": 2,
		    "data": function (row, type, val) {
			if (type === 'display') {
			    var display_name = row.name || "";
			    return '<div class="event_name" event_id="'+row.id+'" contenteditable>'+display_name+'</div>';
			} else {
			    return row.name;
			}
		    }
		},{
		    "targets": 3,
		    "visible": false,
		    "searchable": false
		}
	    ]

	});
	// Apply the search header handlers
	table.columns().every( function () {
            var that = this;
	    var footer = this.footer();
	    if (footer) {
		$('input, select', footer).on( 'input', function (e) {
		    //var val = remove_whitespace(this.value).replace(/,/g, '|');
		    var val = this.value;
		    that
			.search(val, true, false)
			.draw();
		});
	    }
	} );

	// select the first option
	$("#event_list tbody tr:first").addClass('selected');

	/*
	 * Add event handlers
	 */
	// row selection
	$("#event_list tbody").on('click', 'tr', function(e) {
	    var event_id = $(this).attr('event_id')
	    table.$('tr.selected').removeClass('selected');
	    $(this).addClass('selected');
	});
	// load event
	$("button#event_load_btn").on('click', function(e) {
	    var event_id = table.row('.selected').data().id;
	    var event = event_d[event_id]
	    loadEventData(event);
	});
	// delete event
	$("button#event_delete_btn").on('click', function(e) {
	    var event_id = table.row('.selected').data().id;
	    if (event_id) {
		var url = utility.api_url("event/delete", [event_id])
		$.post(url, function() {
		    table.row('.selected').remove().draw(false);
		});
	    }
	});
	// save event
	$("button#event_save_btn").on('click', function(e) {
	    var span = getSpan();
	    var delta = span.max - span.min;

	    if (delta) {
		blockElement($('#event_tabs'));
		params = {data: JSON.stringify(glb.span_d)};
		var url = utility.api_url("event/save")
		$.post(url, params)
		    .done(function(event) {
			if (event.created) {
			    console.log(event);
			    table
				.row.add(event)
				.columns.adjust()
				.draw();
			}
		    })
		    .always(function() {
			$('#event_tabs').unblock();
		    });
	    }
	});
	// save name
	$('div.event_name').on('blur', function(e) {
	    var event_id = $(this).attr('event_id');
	    var new_name = $(this).text();
	    // save to DB
	    var url = utility.api_url("event/name", [event_id])
	    params = {name: new_name};
	    $.post(url, params)
		.fail(function() {
		    alert("error");
		})
	});
	$('div.event_name').on('keydown', function(e) {
	    switch (e.which) {
	    case 13: // Enter
		$(this).blur();
		e.preventDefault();
		break;
	    }
	});
    });
}
