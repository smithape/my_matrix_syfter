function send_command (command) {
    // var url = "/levi-collector/api/term/" + glb.device_name;
    var params = {
	command: command,
	device: glb.device_name
    };

    console.log(params);
    glb.sock.send(JSON.stringify(params));
}

function sock_rx (e) {
    //$('#term_space').text($('#term_space').text() + (e.data));
    $('#term_space').append(e.data);
    $('#term_space').scrollTop($('#term_space')[0].scrollHeight);
}

function sock_close (e) {
    // Try to reconnect in 5 seconds
    setTimeout(function(){
	try {
	    sock_open(e.target.url);
	} catch (err) {}
    }, 1000);
}
function sock_opn (e) {
    if (glb.onopen) {
	glb.onopen();
    }
    send_command('\r\r');
}

function sock_open (url) {
    glb.sock = new WebSocket(url);

    // set websocket handlers
    glb.sock.onmessage = sock_rx;
    glb.sock.onclose = sock_close;
    glb.sock.onopen = sock_opn;
}

$(document).ready(function(){
    /* open the websocket */
    sock_open(glb.sock_url);

    var path_l = location.pathname.split("/");
    // get the last element (unless it's empty due to trailing /
    glb.device_name = path_l.pop() || path_l.pop();
    // change the base template
    $('#page_content').css("padding", 0);
    $('#content').css("padding-bottom", 0);
    $('#wrapper').css("padding-bottom", 0);
    // set the header to show the device name
    $('#toolbar_center').html('<div id="span_header">'+glb.device_name+'</div>');
    // focus on the input
    $('#term_input').focus();

    /* this is required for django CSRF handling */
    $.ajaxSetup({
        beforeSend: function(xhr, settings) {
            if (!(/^http:.*/.test(settings.url) || /^https:.*/.test(settings.url))) {
                // Only send the token to relative URLs i.e. locally.
                xhr.setRequestHeader("X-CSRFToken",
                                     $("input[name=csrfmiddlewaretoken]").val());
            }
        }
    });

    $(document).on('keydown', '#term_input', function(e) {
	switch(e.which) {
	case 9: // Tab
	    e.preventDefault();
	    break
	}
    });

    $(document).on('keyup', '#term_input', function(e) {
	var command = $('#term_input').val();

	/* send the command */
	switch(e.which) {
	case 13: // Enter
	    command += '\r';
	    $('#term_input').val('');
	    send_command(command);
	    break
	case 191: // ?
	    if (e.shiftKey) {
		$('#term_input').val(command.slice(0,-1));
		send_command(command);
	    }
	    break
	default:
	    break;
	}

	//send_command(String.fromCharCode(e.which));

	/* clean the prompt */

	// if(e.which == 13) {
	//     send_command($('#term_prompt').val());
	//     $('#term_prompt').val('');
	// }
    });

    $(document).on('click', '#term', function(e) {
	$('#term_input').focus();
    });
});

var glb = {
    device_name: "",
    sock: null,
    sock_url: utility.ws_url('term')
}
