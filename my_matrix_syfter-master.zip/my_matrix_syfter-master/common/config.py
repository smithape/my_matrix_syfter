"""
File: config.py
Class: config

The config class is meant to handle the overall configuration and variables
shared between the different modules. One of its primary functions is to house
he yaml config object.
"""


import sys, os, time, inspect, re, traceback
from collections import OrderedDict
from threading import Lock
import base64
import copy

from django.db import OperationalError, ProgrammingError
from django.conf import settings
from cryptography.fernet import Fernet, InvalidToken
import yaml
import json
try:
    from yaml import CLoader as Loader, CDumper as Dumper
except ImportError:
    from yaml import Loader, Dumper

from . import linux
from .models import Config as Config_db
from . import logger as log
from . import utility
from . import DB

from device import Item as Item_module
from device.Item import Item
from device.Device import Device
from device.CiscoAPIC import CiscoAPIC
from device.CiscoISE import CiscoISE
from device.CiscoUCS import CiscoUCS
from device.CiscoNCS import CiscoNCS
from device.CiscoDNAC import CiscoDNAC
from device.CvimMon import CvimMon
from device.CiscoDevice import CiscoDevice
from device.CiscoASA import CiscoASA
from device.CiscoIOS import CiscoIOS
from device.CiscoSwitch import CiscoSwitch
from device.CiscoWLC import CiscoWLC
from device.CiscoMSE import CiscoMSE, CiscoCMX, CiscoCMXCloud
from device.CiscoDHCP import CiscoDHCP
from device.CiscoAP import CiscoAP, CiscoAPv1, CiscoAPv2
from device.Linux import *
from device.OpenStack_UCS import OpenStack_UCS
from device.OpenStack import OpenStack
from device.Kubernetes import *
from device.OpenStack_v18 import *
from device.OpenStack_v19 import *
from device.LocalHost import LocalHost
from device.CiscoNFVI import CiscoNFVI
from device.CiscoIDF import CiscoIDF

from nugget import Nugget as ngt
from nugget.NuggetCli import *
from nugget.NuggetRest import *
from nugget.NuggetSnmp import *
from nugget.NuggetGrpc import *
from nugget.NuggetFormula import *
from nugget.NuggetGroup import *
from nugget.NuggetFunction import *

tool_name = "syfter"

# Polling Config Options
global_throughput = "*AP_Sum/ethThroughput"
cli_poll_filter = ""

# Globals
distro = linux.distro()
release = linux.release()
config = {}
group_d = {}
device_d = {}
device_d_lock = Lock()
device_by_ip_d = {}
poller = None
log_q = None
timezone = None
crypto = None
nugget_var_re = re.compile(r'(?<!\\){([\w\:\-]+)}') #re.compile(r'(?<!\\){([^}]+[^\\])}')
proj_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
log_dir = "/var/log/cisco/"
storage_dir = "/storage"
device_type_l = []
device_type_hard_l = []
device_type_d = {}
device_type_path_d = {}
reserved_sections = ["global", "groups", "defaults", "localhost"]


# Root Config Options
root_cfg_opts = {
    'mask_passwords': False,
    'license_required': False,
    'license_server': None,
    'license_hold_days': 7,
    'proxy_server': None,
    'query_debug': False,
    'proxy_username': None,
    'proxy_password': None,
    'full_proxy': None
}

# Site Config Options
site_cfg_opts = {
    'site_name': '',
    'company': '',
    'timezone': '',
    'root_poll_period': 30,# used only for the temp dashboard
    'admin_email': None,
    'event_email': None,
    'nightly_email': None,
}

#
# Tool Config Options
tool_cfg_opts = {
    'admin_email': None,
    'event_email': None,
    'nightly_email': None,
    'localhost_ifname': 'eth0',
    'suppress_logs': [],
    'ssh_options': '-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o ControlMaster=auto -o ControlPath=/tmp/.%r@%h:%p',
    'connect_method': "ssh",
    'event_detection': False,
    'event_detection_period': 60,
    'baseline_lookback': 259200,
    'baseline_period': 86400,
    'hourly_agg_lookback': 24,
    'default_span_start': -1,
    'default_span_end': 'now',
    'watchdog_timer': 300,
    # GRPC
    'grpc_build_dir': '%s/grpc/' % proj_dir,
    # REST
    'rest_timeout': 30,
    # SNMP
    'snmp_timeout': 1,
    'snmp_retries': 3,
    'snmp_bulkwalk_reps': 10,
    'snmp_timeout_hold_time': 300,
    # SNMP trap
    'snmptrap_port': 162,
    'snmptrap_community': 'public',
    'snmptrap_db': '',
    'keepalive_period': 60,
    'cli_timeout': 10,
    'cli_connect_timeout': 10,
    'cli_keepalive_period': 300,
    'days_to_keep_data': 0,
    'days_to_keep_events': -1,
    'maintenance_hour': 4,
    'mem_usage_threshold': 90,
    'disk_usage_threshold': 80,
    'disk_usage_error': 90,
    'scan_period': 3600,
    'ap_monitor_period': 600,
    'client_monitor_period': 1200,
    'client_monitor_vc': True,
    'client_monitor_location': True,
    'client_monitor_presence': True,
    'client_hold_hrs': 30,
    'ap_hold_time': 1800,
    'poller_stats_update_period': 60,
    'poller_server_port': 8080,
    'termserver_hold_time': 3600,
    'termserver_port': 8081,
    'db_server_port': 8082,
    'power_cycle_downtime': 5,
    'series_decode_period': 10,
    'data_precision': 2,
    'data_buffer_duration': 300,
    'data_buffer_min_size': 8,
    'db_insert_period': 30,
    'scan_scope': "global",
    'poll_bulk': False,
    'poll_stagger': True,
    'poll_stagger_interval': 1,
    'poll_stagger_span': 0,
    'pexpect_use_epoll': False,
    'pexpect_login_timeout': 30,
    'aggregate_ap_groups': False,
    # SFTP
    'sftp_username': 'sftpuser',
    'config_tracker_dir': '%s/cfg/' % storage_dir, # hardcoded in install scripts
    # DB
    'datastore': None,
    'metric_db': 'local',
    'log_db': 'local',
    'syslog_db': '',
    # File System
    'filesystem_path': '%s/filesystem_dump' % storage_dir,
    'filesystem_flush_period': 300,
    'filesystem_config_update_period': 3600,
    # JSON stream
    'json_url': None,
    'json_username': '',
    'json_password': '',
    'json_push_timeout': 10,
    'json_max_bytes': 1000000,
    'json_dump_dir': '%s/json_dump/' % storage_dir,
    'json_dump_hold_days': 5,
    # Redis stream
    'redis_port': 6379,
    'redis_host': 'localhost',
    'redis_username': None,
    'redis_password': None,
    'redis_push_timeout': 10,
    'redis_dump_dir': '%s/redis_dump/' % storage_dir,
    'redis_config_update_period': 3600,
    'redis_dump_hold_days': 5,
    # splunk
    'splunk_index': 'main',
    'splunk_username': None,
    'splunk_password': None,
    'splunk_max_bytes': 1000000,
    'splunk_protocol': 'https',
    'splunk_push_timeout': 10,
    'splunk_ec_port': 8088,
    'splunk_client_port': 8089,
    'splunk_ip_address': None,
    'splunk_token': None,
    'splunk_site_name': '',
    'splunk_site_lat': '',
    'splunk_site_lon': '',
    'splunk_source': '',
    'splunk_dump_dir': '%s/splunk_dump/' % storage_dir,
    'splunk_dump_hold_days': 5,
    # elasticsearch
    'es_host': None,
    # netflow
    'netflow_enabled': False,
    'nfacctd_enabled': False,
    'netflow_port': 2055,
    'netflow_period': 600,
    'netflow_dir': '%s/netflow' % storage_dir,
    'netflow_config_dir': '%s/netflow/nfacctd' % proj_dir,
    #scan idf neighbors every 24 hours
    'idf_neighbor_scan_period': 86400,
    'idf_monitor_period': 600
}

def init_config ():
    global \
        global_throughput, \
        cli_poll_filter, \
        timezone

    # set the local timezone
    timezone = utility.get_system_timezone()

    init_crypto()

    # OS-specific settings
    if distro == "ubuntu" or (distro == "debian" and release > 8):
        tool_cfg_opts['pexpect_use_epoll'] = True

    #
    # read in the config
    try:
        read_config()
    except (OperationalError, ProgrammingError):
        pass

    #
    # init root globals
    for key, value in root_cfg_opts.items():
        globals()[key] = get_root(key, default=value)

    # if we set proxy in root globals, set the environment vars
    if full_proxy:
        # set proxy authentication
        os.environ["http_proxy"] = "http://%s" % full_proxy
        os.environ["https_proxy"] = "https://%s" % full_proxy

    #
    # init tool globals
    # first, flatten the tool config
    try:
        tool_cfg_flat = {}
        tool_cfg = config['tool']
        for key, value in tool_cfg.items():
            if isinstance(value, dict):
                for key1, value1 in tool_cfg[key].items():
                    tool_cfg_flat[key+'_'+key1] = value1
            else:
                tool_cfg_flat[key] = value
    except KeyError: pass

    # next, assign the globals
    for key, value in tool_cfg_opts.items():
        try:
            globals()[key] = tool_cfg_flat[key]
        except KeyError:
            globals()[key] = value

    #
    # init site globals
    # LEVY: complicated so values can go in either config place
    for key, value in site_cfg_opts.items():
        try:
            # remember other setting value
            other_value = ""
            if key in globals():
                other_value = globals()[key]
            # get new  setting value
            globals()[key] = get_global(key, default=value)
            # if null, use the other one
            if globals()[key] == "" and other_value != "":
                globals()[key] = other_value
        except KeyError: pass

    # other site globals
    suppress_logs = re.sub(r'\s', '', get_global("suppress_logs")).split(',')

    # set polling config options
    tmp = get_poll_global('throughput', default=global_throughput)
    try: # validate before assigning
        device, nugget = tmp.split('/', 1)
        global_throughput = tmp
    except: pass

    cli_poll_filter = re.sub(r'\s', '', get_poll_global("cli_poll_filter")).lower().split(',')

    # initialize the device type list
    set_device_type_dictionary()

    # initialize the Nugget config
    ngt.init_config()

    # initialize devices
    try:
        set_device_dictionary()
    except Exception as e:
        print("ERROR TRYING TO BUILD TREE")
        print(traceback.format_exc())

    # initialize the device groups
    init_groups()

def get_key_uuid ():
    uuid = utility.get_system_uuid().replace('-', '').encode()
    key = base64.urlsafe_b64encode(uuid)
    return key

def get_key_uuid2 ():
    import hashlib

    uuid = utility.get_system_uuid().replace('-', '').encode()
    key = hashlib.pbkdf2_hmac('sha256', b'syfter', uuid, 100000, dklen=32)
    return key

def get_key_file ():
    # set the config encryption key
    filepath = '%s/.%s.conf' % (proj_dir, utility.get_system_uuid())
    try:
        with open (filepath, 'rb') as f:
            key = f.read()
    except FileNotFoundError as e:
        key = Fernet.generate_key()
        with open (filepath, 'wb') as f:
            f.write(key)

    return key

def init_crypto ():
    global crypto

    key = get_key_file()
    crypto = Fernet(key)

def clear_config ():
    Config_db.objects.all().delete()

def get_polling_cfg (section, option=None):
    """ retrieve the global polling config for a particular device type """
    if section in config['polling']:
        if option:
            if option in config['polling'][section]:
                return config['polling'][section][option]
            else:
                return None
        else:
            return config['polling'][section]
    else:
        return {}

def get_polling_cfg_names (device_type):
    """
    Expand group Nuggets to show the full polling configuration
    """

    polling_cfg = []
    for nugget_name in get_polling_cfg(device_type).keys():
        try:
            nugget = ngt.nugget_config[device_type][nugget_name]
        except KeyError:
            continue

        polling_cfg.append(nugget_name)

        # parse out children entries
        if "children" in nugget:
            for child in nugget['children']:
                child_name = "%s_%s" % (nugget_name, child)
                polling_cfg.append(child_name)

    return polling_cfg

def get_polling_interval_d ():
    d = {}
    for dtype,x in config['polling'].items():
        for nugget_name,y in x.items():
            try:
                nugget = ngt.nugget_config[dtype][nugget_name]
            except KeyError:
                # only take valid Nuggets
                continue

            # add the type
            if dtype not in d:
                d[dtype] = {}

            try:
                interval = int(y)
            except ValueError:
                try:
                    interval = int(y['schedule'])
                except ValueError: continue

            d[dtype][nugget_name] = interval

            # add children nuggets
            if "children" in nugget:
                for child in nugget['children']:
                    child_name = "%s_%s" % (nugget_name, child)
                    d[dtype][child_name] = interval

        # add formula variables
        if dtype in d:
            for nugget_name, interval in list(d[dtype].items()):
                nugget = ngt.nugget_config[dtype][nugget_name]
                if nugget['type'] == "formula":
                    for nugget_var in re.findall(r'{([^}]+)}', nugget["formula"]):
                        if nugget_var not in d[dtype]:
                            d[dtype][nugget_var] = interval

    return d

def init_nugget (*args, **kwargs):
    """ initialize a nugget object """

    # break out the arguments
    device, nugget_name, schedule = args
    # find the nugget config argument
    nugget_cfg = kwargs.get('nugget_cfg') or device.nugget_cfg[nugget_name]
    # duplicate, don't share config dictionary
    nugget_cfg = kwargs['nugget_cfg'] = copy.deepcopy(nugget_cfg)
    # find the nugget class
    _type = nugget_cfg.get('type').capitalize()
    try:
        function = globals()["Nugget%s" % _type]
    except KeyError:
        function = Nugget

    return function(*args, **kwargs)

def get_config_yaml (config_name):
    try:
        text = get_config_text(config_name)
        value = yaml.full_load(text) or {}
        if isinstance(value, str):
            value = {}
    except:
        value = {}

    return value

def get_config_text (config_name):
    config_obj = get_config_obj(config_name)

    if config_obj:
        try:
            text = crypto.decrypt(config_obj.text.encode()).decode()
            return text
        except InvalidToken:
            return config_obj.text
    else:
        return ""

def save_config_text (config_name, text):
    config_obj = get_config_obj(config_name)

    if config_obj:
        config_obj.text = crypto.encrypt(text.encode()).decode()
        config_obj.save()

def get_config_obj (config_name, text=False):
    config_obj, created = Config_db.objects.get_or_create(name=config_name)
    return config_obj

def get_config_obj_all ():
    return Config_db.objects.all()

def init_groups ():
    from device.DeviceGroup import DeviceGroup
    global group_d

    try:
        # Hack: which config to use?
        config_name = 'site'
        if 'groups' in config['polling']:
            config_name = 'polling'

        groups_config = config[config_name]['groups']
    except (ValueError, TypeError):
        log.error("Invalid groups config", "system")
        return
    except KeyError:
        return
    except Exception:
        log.error("Problem reading groups config", "system")
        return

    for group_name, group_cfg in groups_config.items():
        # default values
        db_index = ''
        aggregate = True
        event_detection = False
        filters = {}
        device_type = ''
        agg_ap_groups = False

        if isinstance(group_cfg, str):
            # short-hand groups
            aggregate = True
            filters = {'name': group_cfg}
        else:
            # full syntax
            if 'splunk_index' in group_cfg:
                db_index = group_cfg['splunk_index']
            if 'db_index' in group_cfg:
                db_index = group_cfg['db_index']
            if 'aggregate' in group_cfg:
                aggregate = group_cfg['aggregate']
            if 'event_detection' in group_cfg:
                event_detection = group_cfg['event_detection']
            if 'device_match' in group_cfg:
                filters = group_cfg['device_match']
                if isinstance(filters, str):
                    filters = {'name': filters}
            if 'device_type' in group_cfg:
                device_type = group_cfg['device_type']
            if 'aggregate_ap_groups' in group_cfg:
                agg_ap_groups = group_cfg['aggregate_ap_groups']

        group_d[group_name] = DeviceGroup(group_name, device_type, aggregate, event_detection,
                                          db_index, filters, aggregate_ap_groups=agg_ap_groups)

    # add the ap_group groups
    if aggregate_ap_groups:
        ap_group_s = set()
        for wlc in devices(type="CiscoWLC").values():
            ap_group_s |= wlc.ap_group_s

        try:
            ap_group_s.remove("default")
        except KeyError: pass

        for ap_group in ap_group_s:
            if ap_group in group_d:
                grp_name = '%s(APG)' % ap_group
            else:
                grp_name = ap_group

            group_d[grp_name] = DeviceGroup(grp_name, "CiscoAP", True, False, '',
                                            {'ap_group': ap_group})


def read_config ():
    """
    Read the configuration.
    """
    global config

    # initialize the root config
    config['root'] = settings.CONFIG

    config_names = ['tool', 'polling', 'site']
    for name in config_names:
        # initialize the tool config
        config[name] = get_config_yaml(name)

def set_device_dictionary ():
    """
    the device dictionary consists of ONLY device objects (no generic items)
    """
    global device_d
    device_d = OrderedDict()

    # load the config
    config['site'] = get_config_yaml('site')

    # Create a dictionary of (all) items
    for section in config['site']:
        if section in reserved_sections:
            continue
        device = init_device_object(section)
        if isinstance(device, Device):
            # add to global dictionaries
            device_d[device.name] = device
            if device.ip_address:
                device_by_ip_d[device.ip_address] = device

    # store in redis
    DB.redis.set('device_d_cfg', json.dumps({x.name:x.get_device_d(full=True) for x in device_d.values()}).encode())

def set_device_type_dictionary ():
    global \
        device_type_l, \
        device_type_hard_l, \
        device_type_d, \
        device_type_path_d

    # load the config
    config['device_type'] = get_config_yaml('device_type')

    x = Item("root")
    device_type_hard_l = x.descendant_l
    type_l = x.descendant_l.copy()
    type_d = x.descendant_d
    path_d = x.descendant_path_d
    # don't overwrite hardcoded types?
    device_type_cfg = {x:y for x,y in config['device_type'].items()
                       if x not in path_d}

    # Add the configured types
    todo = len(device_type_cfg)
    while todo:
        prev = todo
        for type_name, type_entry in device_type_cfg.items():
            if type_name in path_d: continue

            # find the configured parent node
            parent = type_entry['parent']

            # see if the parent node is already in the dictionary
            try:
                parent_path = path_d[parent]
            except KeyError:
                continue

            # find the parent in the path_d
            d = type_d
            for x in parent_path[:-1]:
                d = d[x]

            # add into the type dictionary
            d[parent][type_name] = {}
            # add into the type list
            type_l.append(type_name)
            # add path into the path_d
            path_d[type_name] = path_d[parent] + [type_name]

            # decrement the todo count
            todo -= 1

        # check for infinite loops
        if prev == todo: break

    # assign the global variables
    device_type_l = type_l
    device_type_d = type_d
    device_type_path_d = path_d

def get_device (device_name, reset=False):
    # reload static config
    if reset:
        set_device_type_dictionary()
        set_device_dictionary()

    # init device
    if device_name in device_d:
        device = device_d[device_name]
    else:
        # get devices from redis
        redis_device_d = json.loads(DB.redis.get("device_d_full").decode())
        # get the device json
        device_json = redis_device_d[device_name]
        device = init_device_object(device_name, device_json['class'])
        # set device attributes by using the device_json key/value pairs
        for key in device_json:
            setattr(device, key, device_json[key])
        # remember for next time
        device_d[device_name] = device

    return device

def init_device_object (device_name, device_type=None):
    """ Initialize a device object. """

    if not device_type:
        if (device_name not in config['site']):
            log.error("%s is not in the config" % device_name, "system")
        elif 'type' in config['site'][device_name]:
            device_type = config['site'][device_name]['type']
        else: # default to "Other"
            device_type = "Other"

    device_types = {
        'CiscoRouter' : CiscoIOS,
        'CiscoTermserver' : CiscoIOS,
        'Other' : Device,
    }

    # Use the device type to find the class to use
    class_type = device_type
    while True:
        if class_type in config['device_type']:
            class_type = config['device_type'][class_type]['parent']
            continue
        elif class_type in device_types:
            function = device_types[class_type]
        elif class_type in globals():
            function = globals()[class_type]
        else:
            # if the device type is unrecognized, use Device
            function = Device
        break

    device = function(device_name, device_type)
    device.configured = True

    if isinstance(device, Device):
        device.init_config()
        # if the name is an IP
        if utility.is_valid_ip_address(device.name):
            if not device.ip_address:
                device.ip_address = device.name

    return device

def get (section, option, size=1, default="", config_file='site'):
    """
    retrieve a config option from the config file

    Parts are separated by the colon ':'.

    Args:
      option: the option to retrieve
      size: the expected number of parts to this option
      default: the default value (for size=1)
    """

    # initialize the return list
    val_list = []
    for i in range(size):
        val_list.append(default)

    try:
        string = config[config_file][section][option]
        if size > 1:
            # remove whitespace
            string = re.sub(r'\s', '', string)
            # split into parts
            val_list = string.split('/', size-1)
        else:
            val_list[0] = string
    except (TypeError, KeyError): pass

    if size > 1:
        return val_list
    else:
        return val_list[0]

def devices (dtype = None, filter = None):
    if dtype or filter:
        if not isinstance(dtype, list):
            dtype = [dtype]
        return {x:y for x,y in device_d.items()
                if y.type in dtype and
                (not filter or re.search(filter, y.name))
        }
    else:
        return device_d

def set_cfg (section, option, value):
    """set a config option in the config file"""

    config['site'][section][option] = value

def get_global (option, size=1, default=""):
    """get a config option from the global section"""

    return get("global", option, size=size, default=default)

def get_poll_global (option, size=1, default=""):
    return get("global", option, size=size, default=default,
               config_file="polling")

def get_root (option, default=""):
    ret = default
    try:
        ret = config['root'][option]
    except KeyError: pass

    return ret

def set_global (option, value):
    """set a config option in the config file"""

    set_cfg("global", option, value)

def remove_config_option(section, option):
    """remove a config option from the config file"""

    del config['site'][section][option]
    yaml.dump(config['site'], Dumper=Dumper)

def get_logfile (name):
    return '/var/log/cisco/%s.log' % name

def get_pidfile (name):
    return '/run/%s_%s.pid' % (tool_name, name)

def get_sockfile (name):
    return '%s/run/%s.sock' % (proj_dir, name)
