"""
File: PeriodicThread.py
Class: PeriodicThread.py
Parent: object

The PeriodicThread class is used to spawn a thread and run a function
periodically at a specified interval.
"""

import sys, os, time, sched
from threading import Timer, Lock

from . import logger as log

class PeriodicThread(object):
    def __init__ (self, name, interval, action, args=(), daemon=False, quiet=False):
        self.name = name # thread name
        self.interval = interval # The period interval
        self.action = action # function ptr
        self.args = args # function arguments
        self.thread = None # keep track of the thread so we can cancel it
        self.run_lock = Lock() # so periods don't overlap
        self.lock = Lock()
        self.stopping = False
        self.daemon = daemon
        self.quiet = quiet
        self.iterations = 0
        self.missed_iterations = 0
        self.max_timer = 0 # time the periodic function

    def start (self, start_time=None):
        """ Start the periodic thread """

        if not start_time:
            start_time = time.time()

        # schedule the first call
        delay = start_time - time.time()
        self.thread = Timer(delay, self.periodic, [start_time])
        self.thread.name = self.name
        self.thread.daemon = self.daemon
        self.thread.start()

    def stop (self):
        """ Stop the periodic thread """

        with self.lock:
            # set the stopping flag
            self.stopping = True

            # cancel the next iteration
            try:
                self.thread.cancel()
            except AttributeError: pass

        # wait till the current iteration completes
        if not self.daemon:
            with self.run_lock: pass

    def periodic(self, curr_call):
        """
        This is the function that's run periodically. It schedules the next
        occurence and then runs the desired action function.
        """

        #
        # schedule next iteration
        with self.lock:
            if self.stopping: return

            # Do some math to prevent time drift in the period
            next_call = curr_call + self.interval;
            delay = next_call - time.time()
            # schedule the next period thread
            self.thread = Timer(delay, self.periodic, [next_call])
            self.thread.name = self.name
            self.thread.daemon = self.daemon
            self.thread.start()

        #
        # Abort?
        with self.lock:
            if self.stopping: return

        #
        # run the function
        if self.run_lock.acquire(False):
            try:
                start_time = time.time()
                self.action(*self.args)
                self.max_timer = max(self.max_timer, time.time() - start_time)
            except Exception as e:
                log.exception("Action failed for PeriodicThread: %s" % self.name, "system")
            finally:
                self.run_lock.release()
        else:
            self.missed_iterations += 1
            if not self.quiet:
                log.warning("PeriodicThread missed an iteration (%s)" % self.name, "system")


        self.iterations += 1

# LEVY: I'm not using this one for now. This was an approach where I used
# processes instead of threads. I believe it uses more resources and I also
# had trouble stopping all of the processes (scheduled events had to finish
# before I could kill)
# class PeriodicThreadSched(object):
#     def __init__ (self, interval, action, args=()):
#         self.interval = interval
#         self.action = action
#         self.args = args
#         self.scheduler = None
#         self.task = None
#         self.thread = None

#     def start (self):
#         self.thread = Thread(target=self.periodic_start)
#         self.thread.start()

#     def stop (self):
#         print(self.args[0].name)
#         self.scheduler.cancel(self.task)

#     def periodic_start(self):
#         self.scheduler = sched.scheduler(time.time, time.sleep)
#         self.periodic()
#         self.scheduler.run()

#     def periodic(self, curr_call=time.time()): # this won't work
#         print(self.args[0].name)
#         next_call = curr_call + self.interval;
#         delay = next_call - time.time()
#         self.task = self.scheduler.enter(delay, 1, self.periodic, [next_call])

#         self.action(*self.args)

#     def join (self):
#         self.thread.join()
