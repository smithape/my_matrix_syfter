import traceback
import time
import queue
import multiprocessing
import subprocess
from threading import Thread, Lock
import json
import re
import datetime, struct
from django.db import connection

from pkg.snmp import snmp
from twisted.internet import reactor

from . import utility
from . import config as cfg
from . import logger as log
from . import DB

style_map = {
    'name': 's',
    'path': 'f'
}
def process (data_d, start_oid = None, style = None, index_map = None, filter_l = None):

    # apply the type filter
    if filter_l:
        data_d = {x:y['value'] for x,y in data_d.items() if y['type'] in filter_l}
    else:
        data_d = {x:y['value'] for x,y in data_d.items()}

    if not data_d:
        return {}

    # apply the oid style
    if style in ["name", "path"]:
        oid_l = list(data_d.keys())
        command = 'snmptranslate -O%s -M /%s/cfg/mibs/ %s' % (style_map[style], cfg.proj_dir, ' '.join(oid_l))
        response_l = subprocess.check_output(command, shell=True, stdin=subprocess.PIPE).decode().split()

        data_d = {re.sub('\.0$', '', name):data_d[oid] for oid, name in zip(oid_l, response_l)}

        # replace index with names
        if style == "name" and index_map:
            new_data_d = {}
            for key, val in data_d.items():
                try:
                    name, index = key.split('.', 1)
                    key = '%s:%s' % (name, index_map[index])
                except (ValueError, KeyError): pass

                # assign the new value
                new_data_d[key] = val

            data_d = new_data_d
    elif style == "simplified":
        data_d = {re.sub('\.0$', '', x[len(start_oid)+1:]):y for x,y in data_d.items()}


    return data_d

secLevelMap = { 'noAuthNoPriv':1, 'authNoPriv':2, 'authPriv':3 }

def format_oid (oid):
    # add period to beginning
    if oid[0] != '.':
        oid = '.' + oid

    return oid

class SNMPEngine():
    def __init__(self):
        self.device_d = {}
        self.session_d = {}
        self.input_q = multiprocessing.Queue()
        self.output_q = multiprocessing.Queue()
        self.response_d = {}
        self.store_t = Thread(name="SNMPEngine_store", target=self.store)
        self.stopping = multiprocessing.Value('b', 0)

    def start (self):
        """ start the engine """
        # close the django connection
        connection.close()

        # the process to consume the input queue and schedule snmp queries
        multiprocessing.Process(target=self.poll).start()

        # consume the output queue and put it into the dict
        self.store_t.start()

    def stop (self):
        self.stopping.value = 1
        self.input_q.close()
        self.output_q.close()

    def poll (self):
        # start the reactor in another thread
        Thread(target=reactor.run, kwargs={'installSignalHandlers': 0}).start()
        # initialize the redis interface
        self.redis = DB.init_redis()

        while not self.stopping.value:
            try:
                q_name, device_name, opt, fn_name = self.input_q.get(timeout=1)

                fn = getattr(self, fn_name)
                # since we're in a separate thread, we need to use callFromThread
                # to make sure this runs in the main reactor loop
                reactor.callFromThread(fn, q_name, device_name, opt)
            except queue.Empty: pass
            except:
                log.debug(traceback.format_exc())
                break

        # stop the reactor
        reactor.callFromThread(reactor.stop)

    # def poll_start (self):
    #     # starting the polling thread
    #     reactor.callInThread(self.poll_thread)
    #     # run the reactor
    #     reactor.run()

    # def poll_thread (self):
    #     while not self.stopping.value:
    #         try:
    #             q_name, device_name, opt, fn_name = self.input_q.get(timeout=1)

    #             fn = getattr(self, fn_name)
    #             # since we're in a separate thread, we need to use callFromThread
    #             # to make sure this runs in the main reactor loop
    #             reactor.callFromThread(fn, q_name, device_name, opt)
    #         except queue.Empty: pass
    #         except:
    #             log.debug(traceback.format_exc())
    #             break

    #     # stop the reactor
    #     reactor.callFromThread(reactor.stop)

    def add (self, q_name, device, opt, fn_name="get"):
        #log.debug("add: %s/%s\n%s" % (q_name, fn_name, opt))

        if q_name not in self.response_d:
            self.response_d[q_name] = queue.Queue()

        self.input_q.put([q_name, device.name, opt, fn_name])

    def read (self, q_name, timeout=None):
        try:
            return self.response_d[q_name].get(timeout=timeout)
        except queue.Empty:
            raise SNMPEngineTimeout()

    def store (self):
        while not self.stopping.value:
            try:
                q_name, timestamp, response = self.output_q.get(timeout=1)
                self.response_d[q_name].put((timestamp, response))
            except queue.Empty: pass
            except IOError: break
            except Exception as e:
                log.debug(traceback.format_exc())
                break

    def new_session (self, params, timeout, retries):
        # get the required snmp options
        timeout = timeout * 1000000

        address = params['address']
        version = params["version"]

        if version == 3:
            username = params["username"]
            seclevel = secLevelMap[params["seclevel"]]
            authproto = authpass = ""
            privproto = privpass = ""

            if seclevel > 1:
                authproto = params["authproto"]
                authpass = params["authpass"]
                if seclevel > 2:
                    privproto = params["privproto"]
                    privpass = params["privpass"]

            session = snmp.Session(ip=address.encode(),
                                   version=version,
                                   retries=retries,
                                   timeout=timeout,
                                   sec_name=username.encode(),
                                   sec_level=seclevel.encode(),
                                   auth_proto=authproto.encode(),
                                   auth_pass=authpass.encode(),
                                   priv_proto=privproto.encode(),
                                   priv_pass=privpass.encode())
        else:
            community = params["community"]
            session = snmp.Session(ip=address.encode(),
                                   version=version,
                                   retries=retries,
                                   timeout=timeout,
                                   community=community.encode())

        return session

    def get_session (self, device_name, timeout, retries):
        key = "%s/%s/%s" % (device_name, timeout, retries)
        try:
            # see if we already have a session
            session = self.session_d[key]
        except KeyError:
            # session doesn't exist, set a new one
            try:
                device = self.device_d[device_name]
            except KeyError as e:
                # re-read the device_d from redis
                self.device_d = json.loads(self.redis.get("device_d_full").decode())
                # reload static config
                self.device_d.update(json.loads(self.redis.get("device_d_cfg").decode()))
                device = self.device_d[device_name]

            # set the new session
            session = self.new_session(device['snmp_params'], timeout, retries)
            # save the session for next time
            self.session_d[key] = session

        return session

    def decode_response (self, response):
        # decode the strings
        for oid,(value, type) in response.items():
            if isinstance(value, bytes):
                try:
                    # try as a string
                    value = value.decode()
                except:
                    try:
                        # try as a date and time struct
                        tmp = struct.unpack('>HBBBBBBcBB', value)
                        time_str = b"%d-%02d-%02d %02d:%02d:%d.%d00000 %s%02d%02d" % tmp
                        time_dt = datetime.datetime.strptime(time_str.decode(), "%Y-%m-%d %H:%M:%S.%f %z")
                        # use epoch
                        value = utility.datetime_to_epoch(time_dt)
                        type = "TimeTicks"
                    except Exception as e:
                        value = value.hex().upper()

            # set the entry
            response[oid] = {
                'value': value,
                'type': type
            }

    def get_errback (self, q_name, timestamp, err):
        self.output_q.put((q_name, timestamp, {'Error': err.value}))

    def get_callback (self, q_name, timestamp, oid_l, response):
        # decode the snmp data
        self.decode_response(response)

        # send the response
        self.output_q.put((q_name, timestamp, response))

    def walk (self, q_name, device_name, opt, last_oid = None, response={}):
        start_oid = opt['oid']
        #log.debug("walk: %s, %s" % (opt, last_oid or start_oid))

        # retrieve the snmp session
        session = self.get_session(device_name, opt['timeout'], opt['retries'])

        # set the timestamp
        timestamp = int(time.time())

        # make the query
        oid = last_oid or start_oid
        d = session.getnext([oid.encode()])

        # set the callbacks
        d.addCallback(lambda x: self.walk_callback(q_name, device_name,
                                                   opt, timestamp, response, x))
        d.addErrback(lambda x: self.get_errback(q_name, timestamp, x))
        return d

    def bulkwalk (self, q_name, device_name, opt, last_oid = None, response={}):
        start_oid = opt['oid']
        #log.debug("bulkwalk: %s, %s" % (opt, last_oid or start_oid))

        # retrieve the snmp session
        session = self.get_session(device_name, opt['timeout'], opt['retries'])

        # set the timestamp
        timestamp = int(time.time())

        # make the query
        oid = last_oid or start_oid
        d = session.getbulk([oid.encode()], opt['max_repititions'], 0)

        # set the callbacks
        d.addCallback(lambda x: self.walk_callback(q_name, device_name,
                                                   opt, timestamp, response, x))
        d.addErrback(lambda x: self.get_errback(q_name, timestamp, x))
        return d

    def walk_callback (self, q_name, device_name, opt, timestamp, full_response, response):
        #log.debug("walk_callback: %s" % response)
        start_oid = opt['oid']

        # see if we got to the end of the view (and remove this entry)
        endofmibview = response.pop("ENDOFMIBVIEW", False)

        # sort the response by oid
        keys = sorted(response, key=lambda x: list(map(int, x[1:].split('.'))))

        # remember the last oid
        last_oid = keys[-1]

        # add the new data to the full response
        full_response.update(response)

        # send next query or finalize
        if endofmibview or not last_oid.startswith(start_oid+"."):
            # remove all extra data
            full_response = {x:y for x,y in full_response.items() if x.startswith(start_oid+'.')}
            # decode the snmp data
            self.decode_response(full_response)

            # send the response
            self.output_q.put((q_name, timestamp, full_response or {'Error': "No such instance exists"}))
        else:
            # send the next query
            walk_function = getattr(self, opt['query_type'])
            walk_function(q_name, device_name, opt, last_oid, full_response)

    def get (self, q_name, device_name, opt):
        oid_l = opt['oid_l']
        #log.debug("get: %s" % (opt))

        # retrieve the snmp session
        session = self.get_session(device_name, opt['timeout'], opt['retries'])

        # set the timestamp
        timestamp = int(time.time())

        # make the query
        d = session.get(oid_l)

        # set the callbacks
        d.addCallback(lambda x: self.get_callback(q_name, timestamp, oid_l, x))
        d.addErrback(lambda x: self.get_errback(q_name, timestamp, x))
        return d


class SNMPEngineTimeout(Exception):
    """ Very simple class definition to define our own exception type"""

    def __init__(self, value = None):
        self.value = value
    def __str__(self):
        return self.value
