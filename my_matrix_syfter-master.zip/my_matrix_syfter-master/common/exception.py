class LDMError(Exception):
    """ Very simple class definition to define our own exception type"""

    def __init__(self, value = None):
        self.value = value
    def __str__(self):
        return self.value

class ConfigError(Exception):
    """ Very simple class definition to define our own exception type"""

    def __init__(self, value = None):
        self.value = value
    def __str__(self):
        return self.value

class NuggetNotSupported(Exception):
    """ Very simple class definition to define our own exception type"""

    def __init__(self, value = None):
        self.value = value
    def __str__(self):
        return self.value
