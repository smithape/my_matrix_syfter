from twisted.internet import reactor, defer, error
from pysnmp.entity import engine, config
from pysnmp.entity.rfc3413.twisted import cmdgen
from pysnmp.carrier.twisted import dispatch
from pysnmp.carrier.twisted.dgram import udp

class SNMPEngine2():
    def __init__(self):
        self.input_q = multiprocessing.Queue()
        #self.input_q = defer.DeferredQueue()
        #self.output_q = multiprocessing.Queue()
        self.response_d = {}
        self.pool = []
        self.poll_t = Thread(name="SNMPEngine_poll", target=self.poll)
        self.signal = multiprocessing.Value('b', 0)
        # initialize the twisted snmpEngine
        self.snmpEngine = engine.SnmpEngine()
        self.timeout = 1000000
        self.retries = 2
        self.total = 0
        self.dropped = 0

    def start (self):
        self.set_config()

        for device_name in cfg.devices().keys():
            self.response_d[device_name] = {}

        self.poll_t.start()
        # for i in xrange(multiprocessing.cpu_count()):
        #     t = Thread(name="SNMPEngine_poll", target=self.poll)
        #     t.start()

        # proc = Process(target=reactor.run, kwargs={'installSignalHandlers':0})
        # proc.daemon = True
        # proc.start()

        t = Thread(target=reactor.run, kwargs={'installSignalHandlers':0})
        t.start()

    def stop (self):
        self.signal.value = 1
        reactor.stop()

    def set_config (self, timeout=None, retries=None):
        self.snmpEngine.registerTransportDispatcher(dispatch.TwistedDispatcher())

        #
        # Setup transport endpoint and bind it with security settings yielding
        # a target name
        #

        # UDP/IPv4
        config.addSocketTransport(
            self.snmpEngine,
            udp.domainName,
            udp.UdpTwistedTransport().openClientMode()
            )

        community_l = []
        for device in cfg.devices().values():
            try:
                ip_address = device.get("ip_address", required=True)
                community = device.get("snmp_community", required=True)
            except utility.ConfigError:
                continue

            if community not in community_l:
                # SecurityName <-> CommunityName mapping
                config.addV1System(self.snmpEngine, "%s_area" % community, community)

                # Specify security settings per SecurityName (SNMPv1 - 0, SNMPv2c - 1)
                config.addTargetParams(self.snmpEngine,
                                       "%s_creds" % community,
                                       "%s_area" % community,
                                       'noAuthNoPriv', 1)

                community_l.append(community)

            if not timeout: timeout = self.timeout / 10000
            if not retries: retries = self.retries

            config.addTargetAddr(
                self.snmpEngine,
                device.name,
                udp.domainName,
                (ip_address, 161),
                "%s_creds" % community,
                timeout=timeout,  # in 1/100 sec
                retryCount=retries
                )

    def add (self, device_name, oid, qtype="get"):
        self.input_q.put([device_name, oid, qtype])

    def check (self, device, oid):
        return oid in self.response_d[device.name]

    def consume (self, device, oid):
        return self.response_d[device.name].pop(oid, False)

    def poll (self):
        queued = 0
        while not self.signal.value:
            try:
                device_name, oid, qtype = self.input_q.get(timeout=1)
                timestamp = int(time.time())
                args = [device_name, oid, timestamp]
                reactor.callFromThread(self.get, *args)
                queued += 1
                #reactor.callLater(0, self.get, *args)
                #self.get(*args)
            except Queue.Empty:
                if queued:
                    #print "queued: %s" % queued
                    queued = 0
                if self.total and self.dropped:
                    print "dropped %s/%s" % (self.dropped, self.total)
                    self.total = 0
                    self.dropped = 0

            except:
                break
                #print traceback.format_exc()

    def get (self, device_name, oid_l, timestamp):
        oid_l = [(x, None) for x in oid_l]

        # Prepare request to be sent yielding Twisted deferred object
        df = cmdgen.GetCommandGenerator().sendReq(
            self.snmpEngine,
            device_name,
#            device_name.replace(".", "_"),
            oid_l
            )

        timestamp_2 = int(time.time())
        # if timestamp != timestamp_2:
        #     print timestamp_2 - timestamp

        # Register error/response receiver function at deferred
        df.addCallback(self.get_callback, device_name=device_name, oid_l=oid_l, timestamp_1=timestamp_2)
        df.addErrback(self.get_errback)
        #df.setTimeout(3)
        #reactor.wakeUp()

    def get_errback (self):
        print "whoops"

    def get_callback (self, cb_ctx, device_name, oid_l, timestamp_1):
        timestamp = int(time.time())
        self.total += 1

        (errorIndication, errorStatus, errorIndex, varBinds) = cb_ctx
        if errorIndication:
            for oid in oid_l:
                self.response_d[device_name][oid[0]] = (timestamp, None)
            self.dropped += 1
            #print (errorIndication._ErrorIndication__value)
            #print(errorIndication)
        elif errorStatus:
            print('%s at %s' % (
                    errorStatus.prettyPrint(),
                    errorIndex and varBinds[int(errorIndex)-1][0] or '?'
                )
            )
        else:
            for oid, val in varBinds:
                self.response_d[device_name]['.'+oid.prettyPrint()] = (timestamp, val._value)

def get_callback (cb_ctx):
    (errorIndication, errorStatus, errorIndex, varBinds) = cb_ctx
    if errorIndication:
        print(errorIndication)
    elif errorStatus:
        print('%s at %s' % (
                errorStatus.prettyPrint(),
                errorIndex and varBinds[int(errorIndex)-1][0] or '?'
            )
        )
    else:
        for oid, val in varBinds:
            print('levy: %s = %s' % (oid.prettyPrint(), val.prettyPrint()))

    #    reactor.stop()

def get2 (device, oid_l, timeout=None, retries=None):

    # Create SNMP engine instance
    snmpEngine = engine.SnmpEngine()

    # Instantiate and register Twisted dispatcher at SNMP engine
    snmpEngine.registerTransportDispatcher(dispatch.TwistedDispatcher())

    #
    # SNMPv2c setup
    #

    if not timeout: timeout = cfg.snmp_timeout / 1000
    if not retries: retries = cfg.snmp_retries
    ip_address = device.get("ip_address", required=True)
    community = device.get("snmp_community", required=True)

    # SecurityName <-> CommunityName mapping
    config.addV1System(snmpEngine, 'my-area', community)

    # Specify security settings per SecurityName (SNMPv1 - 0, SNMPv2c - 1)
    config.addTargetParams(snmpEngine, 'my-creds', 'my-area', 'noAuthNoPriv', 1)

    #
    # Setup transport endpoint and bind it with security settings yielding
    # a target name
    #

    # UDP/IPv4
    config.addSocketTransport(
        snmpEngine,
        udp.domainName,
        udp.UdpTwistedTransport().openClientMode()
    )
    config.addTargetAddr(
        snmpEngine, device.name,
        udp.domainName, (ip_address, 161),
        'my-creds',
        timeout=timeout,  # in 1/100 sec
        retryCount=retries
    )

    oid_l = [(x, None) for x in oid_l]

    # Prepare request to be sent yielding Twisted deferred object
    df = cmdgen.GetCommandGenerator().sendReq(
        snmpEngine,
        device.name,
        oid_l
    )

    # Register error/response receiver function at deferred
    df.addCallback(get_callback)
    reactor.run()
