from __future__ import division
import multiprocessing
from multiprocessing.pool import ThreadPool
import time
from collections import OrderedDict
from datetime import datetime, timedelta
import cPickle as pickle
import calendar
import re
import traceback
import json

from django.db import connection, IntegrityError
from django.utils import timezone
from django.conf import settings
from django.db.models import Q
from django.core.exceptions import ObjectDoesNotExist
import numpy as np
import pandas as pd
import psutil

import KPI
from pkg.ext import misc
from models import \
    Device as Device_db, \
    KPI as KPI_db, \
    Sample as Sample_db, \
    SampleGrpHourly as SampleGrpHourly_db, \
    SampleGrpHourly2 as SampleGrpHourly2_db, \
    SampleHourly as SampleHourly_db, \
    Log as Log_db, \
    Event as Event_db, \
    State as State_db

import config as cfg
import logger as log
import utility
import Splunk, ElasticSearch

# Globals
cpu_count = None
pool = None
device_by_name = {}
device_by_id = {}
kpi_by_name = {}
kpi_by_id = {}
db_dir = ""

def init ():
    global device_by_name, \
        device_by_id, \
        kpi_by_name, \
        kpi_by_id, \
        cpu_count, \
        pool, \
        db_dir

    # initialize the device cache
    device_l = Device_db.objects.all()
    for d in device_l:
        device_by_name[d.name] = d
        device_by_id[d.id] = d

    # add KPI object to the DB
    for category in KPI.kpi_config:
        for kpi_name in KPI.kpi_config[category]:
            KPI_db.objects.get_or_create(name=kpi_name)

    # initialize the KPI cache
    kpi_l = KPI_db.objects.all()
    for k in kpi_l:
        kpi_by_name[k.name] = k
        kpi_by_id[k.id] = k

    # initialize the thread pool
    cpu_count = multiprocessing.cpu_count()
    pool = ThreadPool(processes=cpu_count)

    # find the DB directory
    db_dir = get_db_dir()

    Splunk.init()
    ElasticSearch.init()

def get_db_dir ():
    # find the DB directory
    cursor = connection.cursor()
    cursor.execute("SELECT setting FROM pg_settings WHERE name = 'data_directory';")
    db_dir, = cursor.fetchone()

    return db_dir

def hourly_agg ():
    # find the hour start/end
    now = int(time.time())
    end = utility.epoch_to_hour(now)
    start = end - 3600 * cfg.hourly_agg_lookback

    while start < end:
        if not SampleGrpHourly_db.objects.filter(timestamp=utility.epoch_to_datetime(start)).exists():
            hourly_agg_helper(start)
        start += 3600

def hourly_agg_helper (start):
    end = start + 3600

    # We only want to lookat numeric data
    # kpi_d = KPI.getKpiByFlag("Numeric")
    # kpi_id_l = []
    # for kpi_name in kpi_d:
    #     kpi_id_l.append(get_kpi(name=kpi_name))

    query_start_time = time.time()

    # LEVY: store all for now, until logging is there, this will
    # help with quick_load
    #qs = Sample_db.objects.filter(kpi__in=kpi_id_l)
    qs = Sample_db.objects
    columns = ['device','kpi','timestamp', 'value']
    values = query(qs, start, end, columns, series=True)

    if not values:
        return

    process_start_time = time.time()

    # values must be in timestamp order
    values = sorted(values, key=lambda x: x[2])

    #
    # Loop through and compile all of the raw data
    data_d = {}
    for device_id, kpi_id, timestamp, value in values:
        try:
            data_d[device_id][kpi_id].append((timestamp, value))
        except KeyError:
            try:
                data_d[device_id][kpi_id] = [(timestamp, value)]
            except KeyError:
                data_d[device_id] = {kpi_id : [(timestamp, value)]}

    sample_l = []
    sample_grp_l = []
    sample_grp2_l = []
    for device_id, device_d in data_d.items():
        for kpi_id, data in device_d.items():

            # find summary values
            try:
                _min, _max, _avg = crunchSeries(data, start, end)
            except TypeError: continue

            # prepare the samples
            timestamp_dt = utility.epoch_to_datetime(start)
            id = int(str(start) + ("%04d" % kpi_id) + ("%04d" % device_id))

            # the aggregation sample
            s = SampleHourly_db(id=id,
                                timestamp=timestamp_dt,
                                device_id=device_id,
                                kpi_id=kpi_id,
                                avg=_avg,
                                min=_min,
                                max=_max,
                            )
            sample_l.append(s)

            # the group sample
            json_data = json.dumps([(utility.datetime_to_epoch(timestamp), value) for timestamp, value in data])
            s = SampleGrpHourly_db(id=id,
                                   timestamp=timestamp_dt,
                                   device_id=device_id,
                                   kpi_id=kpi_id,
                                   data=json_data,
                               )
            sample_grp_l.append(s)

            # the group2 sample
            timestamp_l, value_l = zip(*data)
            s = SampleGrpHourly2_db(id=id,
                                    timestamp=timestamp_dt,
                                    device_id=device_id,
                                    kpi_id=kpi_id,
                                    timestamp_l=timestamp_l,
                                    value_l=value_l,
            )
            sample_grp2_l.append(s)

    write_start_time = time.time()

    # aggregation samples
    try:
        SampleHourly_db.objects.bulk_create(sample_l)
    except IntegrityError as e: pass

    # group samples
    try:
        SampleGrpHourly_db.objects.bulk_create(sample_grp_l)
        SampleGrpHourly2_db.objects.bulk_create(sample_grp2_l)
    except IntegrityError as e: pass

    end_time = time.time()
    log.debug("hourly_agg query/process/write/total: %s/%s/%s/%s" %
              (round(process_start_time - query_start_time, 2),
               round(write_start_time - process_start_time, 2),
               round(end_time - write_start_time, 2),
               round(end_time - query_start_time, 2)))

def reindex_table (table_name, cursor=None):
    """
    Performs a concurrent reindex on the table
    """

    log.info("Reindexing table: %s" % table_name, "system")

    # init the cursor
    if not cursor:
        cursor = connection.cursor()

    # find all indexes for the table
    cursor.execute("SELECT indexname FROM pg_indexes where tablename = '%s';" % table_name)
    index_l = [x for x, in cursor.fetchall()]

    junk_index_l = [x for x in index_l if x.endswith('_')]
    index_l = [x for x in index_l if not x.endswith('_')]

    # remove leftover tmp indexes leftover from unfinished reindexes
    for index_name in junk_index_l:
        if index_name.endswith('_'):
            # drop the junk index
            log.warning("Removing junk index: %s" % index_name, "system")
            cursor.execute("DROP INDEX %s;" % index_name)

    for index_name in index_l:
        # extract the columns from the index name
        cols = re.sub(r'^%s_' % table_name, '', index_name)
        cols = re.sub(r'_idx$', '', cols)
        if cols == "pkey": # it's the primary key
            # create a duplicate index
            cursor.execute("CREATE UNIQUE INDEX CONCURRENTLY %s_ ON %s (id);"
                                 % (index_name, table_name))
            # reassign the primary key to the new table (old is removed)
            cursor.execute("ALTER TABLE %s DROP CONSTRAINT %s, ADD CONSTRAINT %s PRIMARY KEY USING INDEX %s_;"
                           % (table_name, index_name, index_name, index_name))
        else:
            cols = re.findall(r'([a-z]+(?:_id)?)', cols)
            # create a duplicate index
            cursor.execute("CREATE INDEX CONCURRENTLY %s_ ON %s (%s);"
                           % (index_name, table_name, ', '.join(cols)))
            # drop the original table
            cursor.execute("DROP INDEX %s;" % index_name)
            # rename the new table
            cursor.execute("ALTER INDEX %s_ RENAME TO %s;" % (index_name, index_name))

def drop_partitions ():
    """ drop all time-based partitions """

    # create the DB connection
    cursor = connection.cursor()

    table_l, part_d = get_tables()

    for name in part_d.keys():
        cursor.execute("DROP TABLE %s;" % name)

def drop_tables ():
    """ drop all matrix tables """

    # create the DB connection
    cursor = connection.cursor()

    table_l, part_d = get_tables()

    for name in table_l:
        cursor.execute("DROP TABLE %s CASCADE;" % name)

def partitions_in_span (start, end, part_d=None):
    """ find the partitions that contain data pertinent to a timespan """

    if not part_d:
        table_l, part_d = get_tables()

    # included if...
    # (1) start or end is in the partition span
    # (2) start-end encompasses the whole partition
    return {x:y for x,y in part_d.items()
            if y['start'] <= start <= y['end']
            or y['start'] <= end <= y['end']
            or start < y['start'] and end > y['end']}

def get_tables ():
    """
    return two lists:
        (1) standard matrix tables
        (2) matrix partitions
    """

    # get list of tables in the DB
    full_table_l = connection.introspection.table_names()
    # select only matrix tables
    full_table_l = [x for x in full_table_l if x.startswith("mtx_")]

    #
    # get the list of partitions
    table_l = []
    part_d = {}
    partition_re = r'^(\w+)_y(\d+)([d|w])(\d+)$'
    for table_name in full_table_l:
        match = re.search(partition_re, table_name)
        if not match:
            # it's a regular table
            table_l.append(table_name)
        else:
            # it's a partition
            # Extract values from partition name
            parent = match.group(1)
            year = int(match.group(2))
            type = match.group(3)

            partition = {
                'name' : table_name,
                'parent' : parent,
                'type' : type,
                }

            # find partition start/end times
            if type == 'w':
                week = int(match.group(4)) - 1
                partition['start'] = calendar.timegm(
                    time.strptime("%s/%s/1" % (year, week + 1), "%Y/%W/%w"))
                partition['end'] = calendar.timegm(
                    time.strptime("%s/%s/1" % (year, week + 2), "%Y/%W/%w"))
            elif type == 'd':
                day = int(match.group(4))
                partition['start'] = calendar.timegm(
                    time.strptime("%s/%s" % (year, day), "%Y/%j"))
                partition['end'] = calendar.timegm(
                    time.strptime("%s/%s" % (year, day + 1), "%Y/%j"))

            part_d[table_name] = partition

    # sort the list of partitions by end time
    part_d = OrderedDict(sorted(part_d.items(), key=lambda p: p[1]['end']))

    return table_l, part_d

def get_partition_state():
    state_d = {}

    # load the partition state
    try:
        s = State_db.objects.get(name="partition")
        state_d = pickle.loads(str(s.value)) or {}
    except State_db.DoesNotExist: pass

    return state_d

def save_partition_state (state_d):

    db_row = {
        'timestamp': timezone.now(),
        'value': pickle.dumps(state_d)
        }

    s, created = State_db.objects.update_or_create(name="partition", defaults=db_row)

def partition_maintenance ():
    """
    Perform a number of partition maintenance operations

    1) reindex recently completed partitions
    2) drop (if no event) or archive (if event) old partitions
        Archival:
            1) delete non-event data
            2) perform a full_vacuum
    3) drop old partitions if we're short on disk space
    """

    log.debug("Partition Maintenance")

    # partitions use UTC time
    now = int(time.time())
    day_start = utility.epoch_to_day(now)
    time_cutoff = day_start - (cfg.days_to_keep_data)*86400

    # define the list of archivable tables, and the associated model classes
    tables_to_archive = {
        "mtx_sample" : Sample_db,
        "mtx_log" : Log_db
        }

    # create the DB connection
    cursor = connection.cursor()

    # retrieve the list of partitions
    table_l, part_d = get_tables()

    # load the partition state
    reindexed = []
    archived = []
    state_d = get_partition_state()
    if state_d:
        if 'reindexed' in state_d:
            reindexed = [x for x in state_d['reindexed'] if x in part_d]
        if 'archived' in state_d:
            archived = [x for x in state_d['archived'] if x in part_d]

    #
    # archive partitions
    try:
        for name, p in part_d.items():
            try:
                # determine whether the partition is for a table we archive
                if p['parent'] in tables_to_archive:
                    p['to_archive'] = True
                    p['model_class'] = tables_to_archive[p['parent']]
                else:
                    p['to_archive'] = False

                # Is it an old partition?
                if (p['end'] <= time_cutoff):
                    # See if an event lies in the partition
                    qs = Event_db.objects.filter(Q(start_timestamp__range=(p['start'], p['end'])) |
                                                 Q(end_timestamp__range=(p['start'], p['end'])))
                    p['contains_event'] = qs.exists()

                    #
                    # take action
                    if p['contains_event'] and p['to_archive']:
                        if name not in archived:
                            #
                            # Archive (trim and compress) the partition
                            log.debug("Archiving partition: %s" % name)
                            events = qs.values_list("start_timestamp", "end_timestamp")
                            p['events'] = sorted(events, key=lambda x: x[0])
                            trim_partition(p)
                            try:
                                # remove the partition from parent
                                cursor.execute("ALTER TABLE %s NO INHERIT %s;" % (name, p['parent']))
                            except: pass
                            try:
                                # vacuum the partition
                                cursor.execute("VACUUM FULL ANALYZE %s;" % name)
                            except Exception as e:
                                log.exception("Partition vacuum failed: %s\n%s" % (name, e), "system")
                                continue
                            finally:
                                # reattach the partition to the parent
                                cursor.execute("ALTER TABLE %s INHERIT %s;" % (name, p['parent']))

                            # mark the partition as archived
                            archived.append(name)
                    else:
                        #
                        # Drop the partition
                        log.debug("Dropping partition: %s" % name)
                        cursor.execute("DROP TABLE %s;" % name)
                #
                # Reindex the partition
                elif name not in reindexed and now > p['end']:
                    try:
                        reindex_table(name, cursor=cursor)
                    except Exception as e:
                        log.exception("Partition reindex failed: %s\n%s" % (name, e), "system")
                        continue

                    # mark the partition as reindexed
                    reindexed.append(name)

            except Exception as e:
                log.exception("Partition maintenance failed: %s\n%s" % (name, e), "system")

    finally:
        # save the parititon state
        state_d['reindexed'] = reindexed
        state_d['archived'] = archived
        save_partition_state(state_d)

    #
    # Next remove old partitions if we need disk space
    # LEVY TODO: Also delete associated events?
    for name in part_d.keys():
        if psutil.disk_usage(db_dir).percent > cfg.disk_usage_threshold:
            log.warning("Disk Space Low: Dropping partition: %s" % name, "system")
            cursor.execute("DROP TABLE %s;" % name)
        else:
            break

def trim_partition (partition):
    """
    Remove rows that are not part of an event
    """
    # some tables must be trimmed in hourly segments
    hourly_trim = partition['parent'] in ['mtx_sample']

    # get all the event time spans and create time spans for the in-between
    spans_to_delete = []
    span_start = partition['start']
    for event_start, event_end in partition['events']:
        if hourly_trim:
            event_start = utility.epoch_to_hour(event_start)
            event_end = utility.epoch_to_hour(event_end, next=True) + 1

        span_end = event_start

        if span_start < span_end:
            spans_to_delete.append((span_start, span_end))

        span_start = event_end

    if span_start < partition['end']:
        spans_to_delete.append((span_start, partition['end']))

    for start, end in spans_to_delete:
        #log.debug("delete range: %s  -  %s" % (start, end))
        partition['model_class'].objects.filter(
            timestamp__range=(
                utility.epoch_to_datetime(start),
                utility.epoch_to_datetime(end)
                )
            ).delete()


def get_disk_usage ():
    """ Get table/index database usage numbers """

    # create the DB connection
    cursor = connection.cursor()

    # find the reported DB size (including dead rows)
    cursor.execute("SELECT pg_database_size('%s');" %
                   settings.DATABASES['default']['NAME'])
    db_size, = cursor.fetchone()

    # get list of tables in the DB
    tables = connection.introspection.table_names()
    # start assuming nothing is dead
    total_table_space = 0
    total_index_space = 0
    for table in tables:
        # find the space used for the table
        cursor.execute("SELECT pg_table_size('%s');" % table)
        table_space, = cursor.fetchone()
        # find the space used for the index
        cursor.execute("SELECT pg_indexes_size('%s');" % table)
        index_space, = cursor.fetchone()
        # Add to the totals
        total_table_space += table_space
        total_index_space += index_space

    return (db_size, total_table_space, total_index_space)

def add_device (device):
    global device_by_name
    global device_by_id

    d, created = Device_db.objects.get_or_create(name=device.name)
    # set/update the values
    d.type = device.type
    if device.ip_address:
        d.ip_address = device.ip_address
    d.save()

    # put into the mapping dicts
    device_by_name[d.name] = d
    device_by_id[d.id] = d

    # remember the DB entry
    device.db_entry = d

    return d

def get_device (name = "", id = ""):
    if name:
        try:
            return device_by_name[name]
        except KeyError:
            d, created = Device_db.objects.get_or_create(name=name)
            device_by_name[d.name] = d
            device_by_id[d.id] = d
            return d
    elif id:
        try:
            return device_by_id[id]
        except KeyError:
            d = Device_db.objects.get(pk=id)
            device_by_name[d.name] = d
            device_by_id[d.id] = d
            return d

    # if name and name in device_by_name:
    #     return device_by_name[name]
    # elif id and id in device_by_id:
    #     return device_by_id[id]
    # else:
    #     # Load from the DB
    #     pass

def get_kpi (name = "", id = ""):
    if name:
        try:
            return kpi_by_name[name]
        except KeyError:
            d, created = KPI_db.objects.get_or_create(name=name)
            kpi_by_name[d.name] = d
            kpi_by_id[d.id] = d
            return d
    elif id:
        try:
            return kpi_by_id[id]
        except KeyError:
            d = KPI_db.objects.get(pk=id)
            kpi_by_name[d.name] = d
            kpi_by_id[d.id] = d
            return d

def query_helper_list (query_set, distinct, *columns):
    if distinct:
        ret = list(query_set.values_list(*columns).distinct())
    else:
        ret = list(query_set.values_list(*columns))

    connection.close()
    return ret

def query_helper_dict (query_set, distinct, *columns):
    if distinct:
        ret = list(query_set.values(*columns).distinct())
    else:
        ret = list(query_set.values(*columns))

    connection.close()
    return ret

def crunchSeries_spans (values, spans):
    avg_sum = 0
    delta_sum = 0
    min_l = []
    max_l = []

    for start, end in spans:
        try:
            _min, _max, _avg = crunchSeries(values, start, end)
        except TypeError: continue

        # number of seconds in the span
        delta = end - start

        # process span results
        avg_sum += _avg * delta
        delta_sum += delta
        min_l.append(_min)
        max_l.append(_max)

    # calculate total results
    try:
        _avg = avg_sum / delta_sum
        _min = min(min_l)
        _max = max(max_l)
    except ZeroDivisionError:
        return None

    return (_min, _max, _avg)

def crunchSeries (values, start, end):
    start_dt = utility.epoch_to_datetime(start)
    end_dt = utility.epoch_to_datetime(end)

    # add null to the end of the span (just in case we're tracing the end point
    # and it doesn't show up in the DB)
    values = values + [[end_dt, None]]

    # calculate average
    prev_timestamp = utility.epoch_to_datetime(0)
    prev_value = None
    avg_sum = 0
    delta_sum = 0
    values_in_span = set()
    for timestamp, value in values:
        if timestamp > start_dt and prev_timestamp < end_dt:
            if prev_timestamp < start_dt:
                prev_timestamp = start_dt

            if timestamp > end_dt:
                timestamp = end_dt

            if prev_value is not None:
                delta = (timestamp - prev_timestamp).total_seconds()
                avg_sum += prev_value * delta
                delta_sum += delta
                values_in_span.add(prev_value)

        prev_timestamp = timestamp
        prev_value = value

    try:
        _avg = avg_sum / delta_sum
    except ZeroDivisionError:
        return None

    # calculate min/max
    _min = min(values_in_span)
    _max = max(values_in_span)

    return (_min, _max, _avg)

def decodeSeries (values, start, end, period=None):
    if not period:
        period = cfg.series_decode_period

    # split into lists
    timestamp_l, value_l = zip(*values)

    # create a dataframe from the queryset
    ds = pd.Series(value_l, index=timestamp_l)
    #ds.sort(inplace=True)
    ds.fillna(-np.inf, inplace=True)

    ds = ds.resample('%ss' % period, how='last', fill_method="ffill")
    ds.replace(-np.inf, np.nan, inplace=True)

    # trim down to original timespan
    start_dt = utility.epoch_to_datetime(start)
    end_dt = utility.epoch_to_datetime(end)
    if timestamp_l[0] < start_dt or timestamp_l[-1] > end_dt:
        ds = ds[(ds.index >= start_dt) & (ds.index <= end_dt)]
        #ds = ds[start_dt:end_dt] #LEVY: this method is empirically slower


    # for timestamp, value in values:
    #     #print timestamp.strftime("%H:%M:%S"), value
    #     if timestamp >= start_dt and timestamp <= end_dt:
    #         print timestamp.strftime("%H:%M:%S"), value

    return ds

def get_leftover_spans (start, end, hourstamps):
    if not hourstamps:
        return [[start, end]]

    # convert hourstamps to epoch
    hourstamps = [utility.datetime_to_epoch(x) for x in hourstamps]
    hourstamps.sort()
    first_hourstamp = hourstamps[0]
    last_hourstamp = hourstamps[len(hourstamps) - 1]

    # find the spans to check in the raw sample table
    # we know we need spans before and after the hourstamps
    spans = []
    if start < (first_hourstamp - 1):
        spans.append([start, first_hourstamp])
    if end > (last_hourstamp + 3600):
        spans.append([last_hourstamp + 3600, end])

    # see if an hour is missing
    x = first_hourstamp
    while (x < last_hourstamp and x < end):
        if x not in hourstamps:
            spans.append([x, x+3600])
        x += 3600

    return spans

def query_series (device_name, kpi_name, start_time, end_time):
    # find the device/kpi DB objects
    device = get_device(name=device_name)
    kpi = get_kpi(name=kpi_name)

    if True:
        # use grouping
        query_set = device.samplegrphourly_set.filter(kpi=kpi)
        hourstamps, values = query_grp(query_set, start_time, end_time)
        spans = get_leftover_spans(start_time, end_time, hourstamps)
        if spans:
            print spans
            query_set = device.sample_set.filter(kpi=kpi)
            columns = ['timestamp','value']
            values += query_spans(query_set, spans, columns, series=True)

        values.sort(key=lambda x: x[0])
    else:
        query_set = device.sample_set.filter(kpi=kpi)
        columns = ['timestamp','value']
        values = query(query_set, start_time, end_time, columns, series=True)

    return values

def query_grp (query_set, start, end):
    start = utility.epoch_to_hour(start)
    end = utility.epoch_to_hour(end)

    qs = query_set.filter(
        timestamp__range=(
            utility.epoch_to_datetime(start),
            utility.epoch_to_datetime(end))
        )

    values = []
    hourstamps = []
    if True:
        data = query_helper_list(qs, False, *['timestamp', 'data'])

        for hourstamp, json_data in data:
            if json_data:
                hourstamps.append(hourstamp)
                values += json.loads(json_data)

        # convert to datetime
        t1 = time.time() * 1000
        values = [(utility.epoch_to_datetime(x),y) for x,y in values]
        t2 = time.time() * 1000
        log.debug(t2-t1)
    else:
        t1 = time.time() * 1000
        data = query_helper_list(qs, False, *['timestamp', 'timestamp_l', 'value_l'])
        log.debug(time.time() * 1000 - t1)
        for hourstamp, timestamp_l, value_l in data:
            hourstamps.append(hourstamp)
            values += zip(timestamp_l, value_l)

    return hourstamps, values

def query (query_set, start, end, columns, series=False, distinct=False, asdict=False):
    return query_spans(query_set, [[start, end]],
                       columns, series=series, distinct=distinct, asdict=asdict)

def query_spans (query_set, spans, columns, series=False, distinct=False, asdict=False):

    values = []
    ret = []

    for span in spans:
        [start, end] = span
        if series:
            start = utility.epoch_to_hour(start)
            end = utility.epoch_to_hour(end, next=True)

        qs = query_set.filter(
            timestamp__range=(
                utility.epoch_to_datetime(start),
                utility.epoch_to_datetime(end))
            )
        args = [qs, distinct] + columns

        if asdict:
            result = pool.apply_async(query_helper_dict, args)
        else:
            result = pool.apply_async(query_helper_list, args)

        ret.append(result)

    for r in ret:
        values += r.get()

    if distinct:
        return set(values)
    else:
        return values

def threadedQuery(query_set, start, end, columns, series=False, distinct=False, asdict=False):
    return threadedQuery_spans(query_set, [[start, end]],
                               columns, series=series, distinct=distinct, asdict=asdict)

def threadedQuery_spans (query_set, spans, columns, series=False, distinct=False, asdict=False):

    values = []
    ret = []

    bkt_count = cpu_count // len(spans) or 1
    total_bkt_count = bkt_count * len(spans)

    for span in spans:
        [start, end] = span
        if series:
            start = utility.epoch_to_hour(start)
            end = utility.epoch_to_hour(end, next=True)

        # set the initial values
        bkt_size = (end - start) // bkt_count
        bkt_start = start
        bkt_end = bkt_start + bkt_size
        for i in xrange(bkt_count):
            if (i == bkt_count-1):
                bkt_end = end
            query_set_segment = query_set.filter(
                timestamp__range=(
                    utility.epoch_to_datetime(bkt_start),
                    utility.epoch_to_datetime(bkt_end-1))
                )
            args = [query_set_segment, distinct] + columns
            if asdict:
                result = pool.apply_async(query_helper_dict, args)
            else:
                result = pool.apply_async(query_helper_list, args)
            ret.append(result)

            bkt_start += bkt_size
            bkt_end += bkt_size

    for i in xrange(total_bkt_count):
        values += ret[i].get()

    if distinct:
        return set(values)
    else:
        return values

def query_series_hourly (device_name, kpi_name, start_time, end_time):
    # find the device/kpi DB objects
    device = get_device(name=device_name)
    kpi = get_kpi(name=kpi_name)

    query_set = device.samplehourly_set.filter(kpi=kpi)
    columns = ['timestamp','avg','min','max']
    values = query_hourly(query_set, start_time, end_time, columns)

    return values

def query_hourly (query_set, start, end, columns, distinct=False):
    end = utility.epoch_to_hour(end)

    qs = query_set.filter(
        timestamp__range=(
            utility.epoch_to_datetime(start),
            utility.epoch_to_datetime(end-1))
        )

    values = query_helper_list(qs, distinct, *columns)

    if distinct:
        return set(values)
    else:
        return values

def create_sample_postgres (timestamp, device_name, kpi_name, value):
    """ create a postgres sample """

    # find the device/kpi DB objects
    kpi = get_kpi(name=kpi_name)
    device = get_device(name=device_name)

    # convert timestamp to datetime
    timestamp_dt = utility.epoch_to_datetime(timestamp)

    # set the ID
    # id = timestamp | kpi_id | device_id (4 digits allocated kpi/device ids)
    id = int(str(timestamp) + ("%04d" % kpi.id) + ("%04d" % device.id))

    # create the sample
    r = Sample_db(id=id,
                  timestamp=timestamp_dt,
                  device=device,
                  kpi=kpi,
                  value=value)

    return r

def create_sample (timestamp, device_name, kpi_name, value):
    return (timestamp, device_name, kpi_name, value)

def series_terminate (timestamp, startup=False):
    sample_l = []

    # combine devices and vdevices
    device_d = cfg.device_d.copy()
    device_d.update(cfg.poller.vdevice_d)

    # loop through real devices
    for device_name, device in device_d.items():
        for kpi_name, entry in device.kpi_d.items():
            if entry.store and (startup or entry.last_value is not None):

                # add null
                r = create_sample(timestamp,
                                  device_name,
                                  kpi_name,
                                  None)
                sample_l.append(r)

    return sample_l

def series_data_hourly (device_name, kpi_name, start_time, end_time, resample_period):
    ret = {}

    query_start_time = time.time() * 1000

    # query the DB
    values = query_series_hourly(device_name, kpi_name, start_time, end_time)

    # empty buffer
    if not values:
        return None

    df_start_time = time.time() * 1000

    # split into lists
    timestamp_l, avg_l, min_l, max_l = zip(*values)

    # put data into dataframe
    df = pd.DataFrame(zip(avg_l, min_l, max_l), index=timestamp_l, columns=['avg', 'min', 'max'])

    #
    # calculate summary values
    ret['min'] = round(df['min'].min(), 2)
    ret['max'] = round(df['max'].max(), 2)
    ret['avg'] = round(df['avg'].mean(), 2)
    ret['start'] = start_time * 1000
    ret['end'] = end_time * 1000
    ret['count'] = len(df.index)
    ret['period'] = max(resample_period, cfg.series_decode_period)
    ret['resample_period'] = resample_period

    resample_start_time = time.time() * 1000
    try:
        df_final = df.resample('%ss' % resample_period, how={'avg': np.mean, 'min': np.min, 'max': np.max})[df.columns]

        # place the timestamp back into a column
        df_final = df_final.reset_index()

        # name the columns
        df_final.columns = ['timestamp', 'avg', 'min', 'max']
    except Exception, e:
        return False

    # empty buffer
    if df_final is None or df_final.empty:
        return None

    # convert the dataframe to a json string
    data_json = df_final.to_json(orient='values', double_precision=2)

    # Create the JSON object to return. We need to do some string manipulation here.
    ret_json = json.dumps(ret)[:-1] # remove the closing brace of the JSON string
    ret_json += ', "data": %s}' % data_json # add in the data JSON we created above

    end_time = time.time() * 1000
    log.debug ("query/df/resample/total: %s/%s/%s/%s" %
               (int(df_start_time - query_start_time),
                int(resample_start_time - df_start_time),
                int(end_time - resample_start_time),
                int(end_time - query_start_time)))

    return ret_json
