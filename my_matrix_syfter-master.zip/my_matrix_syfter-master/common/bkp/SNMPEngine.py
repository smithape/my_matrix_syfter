import traceback
import time
import Queue
import multiprocessing
from multiprocessing import Process
from multiprocessing.pool import ThreadPool
from threading import Thread, Lock
import netsnmp

from PeriodicThread import PeriodicThread
import utility
import config as cfg
import logger as log

class SNMPEngine():
    def __init__(self):
        self.input_q = multiprocessing.Queue()
        self.output_q = multiprocessing.Queue()
        self.response_d = {}
        self.response_d_lock = Lock()
        self.store_t = Thread(name="SNMPEngine_store", target=self.store)
        self.stopping = multiprocessing.Value('b', 0)
        self.semaphore = multiprocessing.Semaphore(256)
        self.timeout = 2
        self.retries = 3
        self.timeout_blk = 3
        self.retries_blk = 2
        self.maxreps = 1024

    def start (self):
        # LEVY: for if we need more than one process
        # proc_count = int(multiprocessing.cpu_count() * 3/4)
        # for i in xrange(proc_count):
        #     proc = Process(target=self.poll)
        #     proc.start()

        # the process to spawn snmpget threads
        Process(target=self.poll).start()

        self.store_t.start()

    def stop (self):
        self.stopping.value = 1
        self.input_q.close()
        self.output_q.close()

    def poll (self):
        while not self.stopping.value:
            try:
                device_name, params, oid, fn_name = self.input_q.get(timeout=1)

                args = [device_name, params, oid]
                if fn_name == "get":
                    fn = self.get
                elif fn_name == "bulkwalk":
                    fn = self.bulkwalk

                Thread(target=fn, args=args).start()
            except Queue.Empty: pass
            except:
                log.debug(traceback.format_exc())
                break

    def add (self, device, oid, fn_name="get"):
        # get the snmp info
        try:
            params = device.snmp_params
        except AttributeError:
            params = device.set_snmp_params()

        self.input_q.put([device.name, params, oid, fn_name])

    def read (self, device, oid, timeout=None, bulk=False):
        if not timeout:
            if bulk:
                timeout = self.timeout_blk * (self.retries_blk + 1)
            else:
                timeout = self.timeout * (self.retries + 1) + 1

        sleep_time = 1
        i_max = int(timeout / sleep_time)
        for i in xrange(i_max):
            try:
                if oid in self.response_d[device.name]:
                    with self.response_d_lock:
                        return self.response_d[device.name].pop(oid, None)
            except KeyError: pass

            # take a break
            time.sleep(sleep_time)

        raise SNMPEngineTimeout()

    def store (self):
        while not self.stopping.value:
            try:
                device_name, tag, timestamp, value = self.output_q.get(timeout=1)
                # was a bulkwalk timeout detected?
                if tag is None: # I signal bulkwalk timeout with a null oid tag
                    try:
                        device = cfg.device_d[device_name]
                        device.snmp_timeout_detected = timestamp
                    except KeyError: pass
                else:
                    with self.response_d_lock:
                        try:
                            self.response_d[device_name][tag] = (timestamp, value)
                        except KeyError:
                            self.response_d[device_name] = {}
                            self.response_d[device_name][tag] = (timestamp, value)
            except Queue.Empty: pass
            except IOError: break

    def get_session (self, params, timeout=None, retries=None):

        # timeout/retries
        if timeout: timeout = timeout * 1000000
        else: timeout = cfg.snmp_timeout * 1000000
        if not retries: retries = cfg.snmp_retries

        # get the required snmp options
        ip_address = params['ip_address']
        version = params["version"]

        if version == 3:
            username = params["username"]
            seclevel = params["seclevel"]

            if seclevel == "authPriv" or seclevel == "auth":
                authproto = params["authproto"]
                authpass = params["authpass"]
            if seclevel == "authPriv" or seclevel == "priv":
                privproto = params["privproto"]
                privpass = params["privpass"]

            session = netsnmp.Session(DestHost=ip_address,
                                      Version=version,
                                      SecName=username,
                                      SecLevel=seclevel,
                                      AuthProto=authproto,
                                      AuthPass=authpass,
                                      PrivProto=privproto,
                                      PrivPass=privpass,
                                      Timeout=timeout,
                                      Retries=retries,
                                      UseNumeric=True)
        else:
            community = params["community"]
            session = netsnmp.Session(DestHost=ip_address,
                                      Version=version,
                                      Community=community,
                                      Timeout=timeout,
                                      Retries=retries,
                                      UseNumeric=True)

        return session


    def get (self, device_name, snmp_params, oid_l):
        session = self.get_session(snmp_params, timeout=self.timeout, retries=self.retries)

        # put our oid_l into varbind format
        varbind_list = []
        for oid in oid_l:
            varbind_list.append(netsnmp.Varbind(oid))

        # create a varlist object
        var_list = netsnmp.VarList(*varbind_list)

        response_l = []
        #with self.semaphore:
        timestamp = int(time.time())
        response_l = session.get(var_list)

        # did we time out?
        timed_out = (session.ErrorInd == -24)

        # prepare the response list.
        for oid, val in zip(oid_l, response_l):
            if timed_out:
                val = False
            else:
                val = parseVal(val)

            try:
                self.output_q.put([device_name, oid, timestamp, val])

            except IOError: break

    def bulkwalk (self, device_name, snmp_params, oid):
        session = self.get_session(snmp_params, timeout=self.timeout_blk, retries=self.retries_blk)

        oid_l = []
        prev_start_oid = None
        start_oid = oid
        while start_oid and start_oid != prev_start_oid and start_oid.startswith(oid):
            prev_start_oid = start_oid
            varbind = netsnmp.Varbind(start_oid)
            var_list = netsnmp.VarList(varbind)

            # send the request
            with self.semaphore:
                timestamp = int(time.time())
                session.getbulk(0, self.maxreps, var_list)

            # did we timeout?
            if session.ErrorInd == -24:
                # using oid=None here communicates a bulkwalk timeout
                log.debug("bulkwalk timeout: %s" % device_name)
                self.output_q.put([device_name, None, timestamp, None])
                return

            # prepare the response list.
            for x in var_list:
                if x.tag:
                    if x.tag.startswith(oid):
                        # find the full numeric oid
                        if x.iid:
                            x.oid = x.tag + "." + x.iid
                        else:
                            x.oid = x.tag

                        # advance the start_oid
                        start_oid = x.oid

                        # parse the value
                        val = parseVal(x.val, x.type)

                        if x.oid in oid_l:
                            log.debug("dups")
                        oid_l.append(x.oid)
                        # add to output list
                        self.output_q.put([device_name, x.oid, timestamp, val])

                    else:
                        start_oid = None
                        break
                else:
                    log.debug("Stupid null tag :(")
                    break

def parseVal (sample, type=None):
    if type:
        if (type == "INTEGER" or
            type == "COUNTER" or
            type == "GAUGE"):
            sample = int(sample)
    else:
        try: # try INT
            sample = int(sample)
        except (ValueError, TypeError):
            try: # try FLOAT
                sample = float(sample)
            except (ValueError, TypeError):
                if not sample:
                    sample = None

    return sample

def get (device, oid_l, timeout=None, retries=None):

    # set the snmp session
    session = device.get_snmp_session(timeout=timeout, retries=retries)

    # put our oid_l into varbind format
    varbind_list = []
    for oid in oid_l:
        varbind_list.append(netsnmp.Varbind(oid))

    # create a varlist object
    var_list = netsnmp.VarList(*varbind_list)

    session.get(var_list)

    # timeout
    if session.ErrorInd == -24:
        device.snmp_timeout_detected = time.time()
        return None

    # prepare the response list.
    res_l = []
    empty = True
    for x in var_list:
        if x.val:
            empty = False
        res_l.append(parseVal(x.val, x.type))

    # if everything is None
    if empty:
        return []

    return res_l

def walk (device, oid, timeout=None, retries=None):
    """
    execute an snmp walk request to device starting with the input OID
    """

    # set the snmp session
    session = device.get_snmp_session(timeout=timeout, retries=retries)

    # put our oid into varbind format
    varbind_list = []
    varbind_list.append(netsnmp.Varbind(oid))

    # create a varlist object
    var_list = netsnmp.VarList(*varbind_list)

    # perform walk
    session.walk(var_list)

    # prepare the response list.
    for x in var_list:
        # find the full numeric oid
        if x.iid:
            x.oid = x.tag + "." + x.iid
        else:
            x.oid = x.tag

        # the __setattr__ function will always cast to 'str'
        # otherwise, this would be: x.val = ...
        x.__dict__["val"] = parseVal(x.val, x.type)

        # if not x.oid:
        #     log.error("snmp walk returned null tag!", "system")

    return var_list


def bulkwalk (device, oid, timeout=None, retries=None, max_repeat=1024):

    # set the snmp session
    session = device.get_snmp_session(timeout=timeout, retries=retries)

    var_list_full = []
    oid_l = []
    prev_start_oid = None
    start_oid = oid
    while start_oid and start_oid != prev_start_oid and start_oid.startswith(oid):
        prev_start_oid = start_oid
        varbind = netsnmp.Varbind(start_oid)
        var_list = netsnmp.VarList(varbind)

        # send the request
        session.getbulk(0, max_repeat, var_list)

        # timeout
        if session.ErrorInd == -24:
            device.snmp_timeout_detected = time.time()

        # prepare the response list.
        for x in var_list:
            if x.tag:
                if x.tag.startswith(oid):
                    # find the full numeric oid
                    if x.iid:
                        x.oid = x.tag + "." + x.iid
                    else:
                        x.oid = x.tag

                    start_oid = x.oid

                    # the __setattr__ function will always cast to 'str'
                    # otherwise, this would be: x.val = ...
                    x.__dict__["val"] = parseVal(x.val, x.type)

                    # add to output list
                    if x.oid in oid_l:
                        log.debug("dups")
                    oid_l.append(x.oid)
                    var_list_full.append(x)
                else:
                    start_oid = None
                    break
            else:
                break

    if start_oid != oid:
        return var_list_full
    else:
        return []

class SNMPEngineTimeout(Exception):
    """ Very simple class definition to define our own exception type"""

    def __init__(self, value = None):
        self.value = value
    def __str__(self):
        return self.value
