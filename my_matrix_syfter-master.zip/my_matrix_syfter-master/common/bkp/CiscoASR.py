from __future__ import division
import requests, json
import re
import time
import copy

from Device import Device
from RackDevice import RackDevice
from PeriodicThread import PeriodicThread
import DB
import KPI
import config as cfg

def time_function(f):
    def wrap(*args):
        time1 = time.time()
        ret = f(*args)
        time2 = time.time()
        delta = (time2-time1)*1000.0
        print '%s function took %0.3f ms' % (f.func_name, delta)
        return ret
    return wrap

def snmp_card_id (oid):
    re_str = r"([0-9]+)\.[0-9]+$"
    match = re.search(re_str, oid)
    return int(match.group(1))

class CiscoASRCard (Device):
    def __init__(self, device_name):
        super(CiscoASRCard, self).__init__(device_name)

        self.oid_map.update(KPI.getOIDMap("CiscoASR"))
        self.kpi_cfg.update(KPI.getKPIConfig("CiscoASR"))

        self.idx_count = 0

class CiscoASR (RackDevice):
    def __init__(self, device_name):
        super(CiscoASR, self).__init__(device_name)

        self.oid_map.update(KPI.getOIDMap("CiscoASR"))
        self.kpi_cfg.update(KPI.getKPIConfig("CiscoASR"))

        self.cards = {}

        self.device_d = {}

    def poller_init (self):
        self.scan_cards()

    def add_card (self, card_id, dtype):
        if card_id not in self.cards:
            card_name = "%s.%02d" % (self.name, card_id)
            device = CiscoASRCard(card_name)
            device.type = dtype
            self.cards[card_id] = device
            self.device_d[device.name] = device

    def scan_cards (self):
        #
        # find the io_cards
        oid = self.kpi_cfg['ethThroughput_RX']['oid']
        snmp_response = self.snmp_bulkwalk(oid)

        for var in snmp_response:
            card_id = snmp_card_id(var.oid)
            if card_id != 24:
                self.add_card(card_id, "CiscoASRCard_IO")
                self.cards[card_id].idx_count += 1

        #
        # find the app_cards
        oid = self.kpi_cfg['memUsage']['oid']
        snmp_response = self.snmp_bulkwalk(oid)

        for var in snmp_response:
            card_id = snmp_card_id(var.oid)
            self.add_card(card_id, "CiscoASRCard_APP")
            self.cards[card_id].idx_count += 1

        #
        # add cards to the DB
        for card_id, device in self.device_d.items():
            # add to the DB
            d = DB.add_device(device)
            device.db_entry = d

    def start_polling_thread (self, init_session=True):

        # initialize the term session
        if init_session and self.polling_cfg_includes_type('cli'):
            self.set_session()

        # Initialize the polling config
        self.init_polling_config()

        if not self.kpi_d:
            return

        # Start polling thread
        self.poll_thread = PeriodicThread(name=self.name,
                                          interval=self.poll_interval,
                                          action=self.poll,
                                          quiet=True)

        self.poll_thread.start()

    #@time_function
    def poll (self):
        """This is the function called every poll period"""

        timestamp = int(time.time())

        # Skip if the device is down
        if self.down:
            if self.is_up():
                self.down = False
                log.info("Device up", "device", device=self)
                self.remove_code('down')
                self.snmp_timeout_detected = 0
            else:
                return

        # initialize the lists
        cli_kpi_d = {}
        snmp_kpi_d = {}
        snmpwalk_kpi_d = {}
        rest_kpi_d = {}
        keepalive = False

        # look through the device's KPI entry list
        for kpi_name, kpi_entry in self.kpi_d.items():
            if not kpi_entry.poll: continue
            # find the entries that are due to poll
            if kpi_entry.counter <= 0:
                kpi_entry.counter = kpi_entry.interval;
                # split into cli/snmp
                if kpi_entry.type == "cli":
                    cli_kpi_d[kpi_name] = kpi_entry
                elif kpi_entry.type == "snmp":
                    snmp_kpi_d[kpi_name] = kpi_entry
                elif kpi_entry.type == "snmpwalk":
                    snmpwalk_kpi_d[kpi_name] = kpi_entry
                elif kpi_entry.type == "rest":
                    rest_kpi_d[kpi_name] = kpi_entry
                elif kpi_entry.type == 'keepalive':
                    keepalive = True

            kpi_entry.counter -= self.poll_interval


        # the response dict
        response_d = {}

        #
        # Send Keepalive
        if keepalive and not (cli_kpi_d or snmp_kpi_d):
            if not self.is_up():
                self.down = True

        #
        # snmp query
        if snmp_kpi_d and not self.down:
            cfg.poller.poll_snmp_queue(self, snmp_kpi_d)

        #
        # snmpwalk query
        if snmpwalk_kpi_d and not self.down:
            response_d.update(self.poll_snmpwalk(snmpwalk_kpi_d, timestamp))

        #
        # snmp read
        if snmp_kpi_d and not self.down:
            response_d[self.name] = cfg.poller.poll_snmp_read(self, self, snmp_kpi_d)

        # Check whether the device was flagged as down
        if self.down:
            log.error("Device down", "device", device=self)
            # if the device went down, sluggish snmp is irrelevent
            self.snmp_sluggish = False
            self.remove_code('snmp_down')

            # add the error code
            self.add_code('down')

            self.down_since = time.time()
            return

        for device_name, response_l in response_d.items():
            if device_name == self.name:
                device = self
            else:
                device = self.device_d[device_name]

            response_l = cfg.poller.process_poll_response(device, response_l)
            response_d[device_name] = response_l
            cfg.poller.store_poll_response(device, response_l)

        #
        # bubble up
        response_l = self.bubble_up(response_d, timestamp)
        cfg.poller.store_poll_response(self, response_l)

    def poll_snmpwalk (self, kpi_d, timestamp):

        response_d = {}
        for kpi_name, kpi_entry in kpi_d.items():
            for oid in kpi_entry.oid:
                r = self.snmp_walk(oid)
                for var in r:
                    response = int(var.val)
                    card_id = snmp_card_id(var.oid)
                    if card_id in self.cards:
                        device_name = "%s.%02d" % (self.name, card_id)
                        if self.cards[card_id].idx_count > 1:
                            idx = int(var.oid.split('.')[-1])
                            kpi_name_final = "%s.%d" % (kpi_name, idx)
                        else:
                            kpi_name_final = kpi_name

                        if device_name not in response_d:
                            response_d[device_name] = []

                        response_d[device_name].append([kpi_name_final, response, timestamp])

        return response_d

    def bubble_up (self, response_d, timestamp):
        sums = {}
        for device_name, response_l in response_d.items():
            if device_name is self.name: continue
            for kpi_name, timestamp, sample, value in response_l:
                if not value: continue
                device = self.device_d[device_name]
                kpi_root = kpi_name.split(".")[0]
                kpi_entry = device.kpi_cfg[kpi_root]
                if 'bubble_up' in kpi_entry:
                    if kpi_root not in sums:
                        sums[kpi_root] = 0

                    if kpi_entry['bubble_up'] == "sum":
                        sums[kpi_root] += value

        # convert to list
        response_l = []
        for kpi_name, val in sums.items():
            response_l.append([kpi_name, timestamp, None, val])

        return response_l

    def init_polling_config (self):
        """ DESCRIBE """

        # call the parent function
        super(CiscoASR, self).init_polling_config()

        # configure polling config for card devices
        for device_name, device in self.device_d.items():
            # copy the kpi_d to the card device
            for kpi_name, kpi_entry in self.kpi_d.items():
                new_kpi_entry = KPI.kpiEntry(device, kpi_name, None,
                                             kpi_cfg = kpi_entry.kpi_cfg,
                                             store = kpi_entry.store,
                                             poll = False)
                new_kpi_entry.init_thresholds(kpi_entry.threshold_cfg)
                device.kpi_d[kpi_name] = new_kpi_entry

            # add index KPIs
            for kpi_name, kpi_entry in device.kpi_d.items():
                kpi_indexed = kpi_entry.kpi_cfg['indexed']
                if kpi_indexed:
                    # add the indexes
                    for i in xrange(device.idx_count):
                        kpi_name_child = "%s.%d" % (kpi_name, i)
                        new_kpi_entry = KPI.kpiEntry(device, kpi_name_child, None,
                                                     kpi_cfg = kpi_entry.kpi_cfg,
                                                     store = kpi_entry.store,
                                                     poll = False)
                        new_kpi_entry.init_thresholds(kpi_entry.threshold_cfg)
                        device.kpi_d[kpi_name_child] = new_kpi_entry
