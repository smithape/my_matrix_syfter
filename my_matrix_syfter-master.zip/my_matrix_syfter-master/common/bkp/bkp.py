"""
Alternet processing from hourly_agg
"""
    # create a dataframe from the queryset
    df = pd.DataFrame(values, columns=columns)
    df.fillna(-np.inf, inplace=True)

    # set timestamp as index
    df.set_index('timestamp', inplace=True)

    # group by device/kpi
    group = df.groupby(['device', 'kpi'])

    # calculate min/max
    min_l = group.min()['value']
    max_l = group.max()['value']

    # need to resample/decode in order to find average
    df = group.resample('%ss' % cfg.series_decode_period, how=np.max, fill_method="ffill")
    df.replace(-np.inf, np.nan, inplace=True)

    avg_l = df.mean(level=[0,1])['value']

    #start_t = time.time()
    sample_l = []
    for (device_id, kpi_id), junk in group:
        device_id = int(device_id)
        kpi_id = int(kpi_id)

        # prepare the sample
        id = int(str(start) + ("%04d" % kpi_id) + ("%04d" % device_id))
        timestamp_dt = utility.epoch_to_datetime(start)
        min = min_l[device_id][kpi_id]
        avg = avg_l[device_id][kpi_id]
        max = max_l[device_id][kpi_id]

        # if device.name == "AP-I-1B-EFF9-OPS":
        #     print "%s\t%s" % (kpi.name, round(avg, 2))

        s = SampleHourly_db(id=id,
                            timestamp=timestamp_dt,
                            device_id=device_id,
                            kpi_id=kpi_id,
                            avg=avg,
                            min=min,
                            max=max,
                            )
        sample_l.append(s)

#print "x took: %s" % (time.time() - start_t)

"""
Previous hourly_agg
"""
def hourly_agg_bkp ():
    # find the hour start/end
    current_time = int(time.time())
    end = utility.epoch_to_hour(current_time)
    start = end - 3600

    # We only want to lookat numeric data
    kpi_d = KPI.getKpiByFlag("Numeric")
    kpi_id_l = []
    for kpi_name in kpi_d:
        kpi_id_l.append(get_kpi(name=kpi_name))

    query_start_time = time.time()

    # LEVY: store all for now, until logging is there, this will
    # help with quick_load
    #qs = Sample_db.objects.filter(kpi__in=kpi_id_l)
    qs = Sample_db.objects
    columns = ['device','kpi','value']
    values = query(qs, start, end, columns, series=True)

    if not values:
        return

    process_start_time = time.time()

    # create a dataframe from the queryset
    df = pd.DataFrame(values, columns=columns)

    # find unique device/kpi groups
    group = df.groupby(['device', 'kpi'])

    # Pandas is giving me negative variance values and causing std to fail,
    # so I need to disable this warning (and do the fillna below)
    #bkp = np.seterr(invalid='ignore')
    # calculate aggregations for each grouping
    #count_l = group.count()['value']
    avg_l = group.mean()['value']
    min_l = group.min()['value']
    max_l = group.max()['value']
    #std_l = group.std()['value'].fillna(0)
    #np.seterr(**bkp)

    sample_l = []
    for (device_id, kpi_id), junk in group:
        # lookup the device/kpi objects from the ID
        device = get_device(id=device_id)
        kpi = get_kpi(id=kpi_id)

        # prepare the sample
        timestamp_dt = utility.epoch_to_datetime(start)
        id = int(str(start) + ("%04d" % kpi.id) + ("%04d" % device.id))
        s = SampleHourly_db(id=id,
                            timestamp=timestamp_dt,
                            device = device,
                            kpi = kpi,
                            #count = count_l[device_id][kpi_id],
                            avg = avg_l[device_id][kpi_id],
                            min = min_l[device_id][kpi_id],
                            max = max_l[device_id][kpi_id],
                            #std = std_l[device_id][kpi_id]
                            )
        sample_l.append(s)

    write_start_time = time.time()

    try:
        SampleHourly_db.objects.bulk_create(sample_l)
    except IntegrityError as e: pass
    end_time = time.time()
    log.debug("hourly_agg query/process/write/total: %s/%s/%s/%s" %
              (round(process_start_time - query_start_time, 2),
               round(write_start_time - process_start_time, 2),
               round(end_time - write_start_time, 2),
               round(end_time - query_start_time, 2)))


"""
alternet processing for top_devices_span
"""
    df_tmp = pd.DataFrame(values_raw, columns=columns)
    df_tmp.fillna(-np.inf, inplace=True)

    # set timestamp as index
    df_tmp.set_index('timestamp', inplace=True)

    # group rows by device
    group = df_tmp.groupby(['device'])

    # decode the data
    df_tmp = group.resample('%ss' % cfg.series_decode_period, how=np.max, fill_method="ffill")
    #df_tmp.sort(inplace=True)
    df_tmp.replace(-np.inf, np.nan, inplace=True)

    # trim down to original timespan
    start_dt = utility.epoch_to_datetime(start)
    end_dt = utility.epoch_to_datetime(end)
    df_tmp = df_tmp[(df_tmp.index.get_level_values(1) >= start_dt) &
                    (df_tmp.index.get_level_values(1) <= end_dt)]

    # crunch the numbers
    df_raw = df_tmp.max(level=0)
    df_raw.columns = ['max']
    df_raw['avg'] = df_tmp.mean(level=0)



"""
previous full_load function
"""
    def full_load_bkp (self, start, end):
        values_hourly = None
        values_raw = None

        # initialize the event dictionary
        event = {}
        event['start_timestamp'] = start
        event['end_timestamp'] = end
        event['device_d'] = {}
        event['state'] = None

        # a quick load will give us ALL KPIs (even those that don't have numeric
        # min/max/avg
        event = self.quick_load(start, end)
        if not event:
            return None

        query_start_time = int(time.time() * 1000)

        # read the kpi_config to determine the list of KPIs to read
        kpi_d = KPI.getKpiByFlag("Numeric")
        kpi_id_l = []
        for kpi_name in kpi_d:
            kpi_id_l.append(DB.get_kpi(name=kpi_name))

        # initialize the queryset
        qs = SampleHourly_db.objects.filter(kpi__in=kpi_id_l)

        # query the hourly table
        try:
            #columns = ['device', 'kpi', 'count', 'avg', 'max']
            columns = ['device', 'kpi', 'avg', 'max']
            values_hourly = DB.query_hourly(qs, start, end, columns)
            df_hourly = pd.DataFrame(values_hourly, columns=columns)
        except ValueError: pass

        # find the hours that are present in the hourly table
        columns = ['timestamp']
        hourstamps = DB.query_hourly(qs, start, end, columns, distinct=True)
        spans = self.get_query_spans(start, end, hourstamps)

        process_start_time = int(time.time() * 1000)

        if spans:
            # query the raw sample table
            try:
                qs = Sample_db.objects.filter(kpi__in=kpi_id_l)
                columns = ['device','kpi','value']
                values_raw = DB.query_spans(qs, spans, columns)
                process_start_time = int(time.time() * 1000)
                df_tmp = pd.DataFrame(values_raw, columns=columns)
                # find unique device/kpi groups
                group = df_tmp.groupby(['device', 'kpi'])

                df_raw = group.max()
                df_raw.columns = ['max']
                df_raw['avg'] = group.mean()
            except ValueError: pass

        # prepare the dataframes
        if values_hourly:
            df = df_hourly

            if values_raw:
                # append the raw data
                df = df.append(df_raw.reset_index())

            group = df.groupby(['device', 'kpi'])

            df = group.sum()['avg'].to_frame()
            df.columns = ['avg']
            df['max'] = group.max()['max']

        elif values_raw:
            df = df_raw
        else:
            return None

        for (device_id, kpi_id), row in df.iterrows():
            # lookup the device/kpi objects from the ID
            device = DB.get_device(id=device_id)
            kpi = DB.get_kpi(id=kpi_id)

            # skip global devices
            if device.name.startswith("*"):
                continue

            # get the right dict
            d = event['device_d'][device.name]['kpi_d'][kpi.name]

            d['avg'] = round(row['avg'], 2)
            d['max'] = round(row['max'], 2)


        end_time = int(time.time() * 1000)

        log.debug ("/query/process/total: %s/%s/%s" %
                          (process_start_time - query_start_time,
                           end_time - process_start_time,
                           end_time - query_start_time))

        # # LEVY: test the new hourly aggregation
        # event_old = self.full_load_old(start, end)
        # mismatch = 0
        # total = 0
        # for device_name in event['devices']:
        #     for kpi_name in event['devices'][device_name]['kpi_d']:
        #         a = event['devices'][device_name]['kpi_d'][kpi_name]
        #         b = event_old['devices'][device_name]['kpi_d'][kpi_name]
        #         total += 1
        #         if 'avg' in a:
        #             if (a['count'] != b['count']):
        #                 mismatch += 1
        #                 print ("%s/%s: %s/%s" % (device_name, kpi_name,
        #                                          a['count'], b['count'],
        #                                          ))
        #             elif (a['max'] != b['max']):
        #                 mismatch += 1
        #                 print ("%s/%s: %s/%s" % (device_name, kpi_name,
        #                                          a['max'], b['max'],
        #                                          ))
        #             elif (a['avg'] != b['avg']):
        #                 mismatch += 1
        #                 print ("%s/%s: %s/%s" % (device_name, kpi_name,
        #                                          a['avg'], b['avg'],
        #                                          ))

        # if mismatch > 0:
        #     print "didn't match: %s/%s" % (mismatch, total)
        # else:
        #     print "they match"

        event['state'] = "full"
        return event


"""
full_load alternate processing
"""

            df_tmp = pd.DataFrame(values_raw, columns=columns)
            df_tmp.fillna(-np.inf, inplace=True)

            # set timestamp as index
            df_tmp.set_index('timestamp', inplace=True)

            # group by device/kpi
            group = df_tmp.groupby(['device', 'kpi'])

            # need to resample/decode in order to find average
            start_t = time.time()
            df_tmp = group.resample('%ss' % cfg.series_decode_period, how=np.max, fill_method="ffill")
            print "x took: %s" % (time.time() - start_t)
            df_tmp.replace(-np.inf, np.nan, inplace=True)

            # trim down to original timespan
            start_dt = utility.epoch_to_datetime(start)
            end_dt = utility.epoch_to_datetime(end)
            df_tmp = df_tmp[(df_tmp.index.get_level_values(2) >= start_dt) &
                            (df_tmp.index.get_level_values(2) <= end_dt)]


            # crunch the numbers
            df_raw = df_tmp.max(level=[0,1])
            df_raw.columns = ['max']
            df_raw['avg'] = df_tmp.mean(level=[0,1])



"""
how to preserve twisted file handlers into a daemon
"""
    #from twisted.internet import reactor

    # find FDs to preserve into the daemon
    files_preserve = []
    # the logging file
    files_preserve.append(logger.fh.stream)

    # # Twisted FDs (this was hard; don't delete!)
    # for x, y in reactor._selectables.items():
    #     files_preserve += [y.i, y.o]
    # files_preserve.append(reactor._poller.fileno())

