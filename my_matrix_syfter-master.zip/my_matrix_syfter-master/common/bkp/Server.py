"""
This file has been deprecated. Below I have included the function used in
matrix.py to utilize this module.
=============
def start_server ():
    from twisted.web.server import Site
    from twisted.internet import reactor
    from twisted.web.static import File

    # set the root page ("/") for the server
    root = Server.Root()
    # add the 'home' page
    root.putChild('home', Server.Main())
    root.putChild('json', Server.getJSON())
    root.putChild('test', Server.test())
    root.putChild('device_data', Server.DeviceData())
    root.putChild('device_config', Server.DeviceConfig())
    root.putChild('list', Server.List())
    root.putChild('system_info', Server.systemInfo())
    root.putChild('help', File(utility.resource_path('html/help.html')))
    root.putChild('showinterfaces', Server.ShowInterfaces())
    root.putChild('showports', Server.ShowPorts())
    root.putChild('editconfig', Server.EditConfig())
    # add a the scripts/css dirs to the server
    root.putChild('scripts', File(utility.resource_path('scripts')))
    root.putChild('css', File(utility.resource_path('css')))
    root.putChild('img', File(utility.resource_path('img')))
    root.putChild('docs', File(utility.resource_path('docs')))
    factory = Site(root)
    # set the server port
    reactor.listenTCP(args.port, factory)
    # start the server
    reactor.run()
"""

"""
File: Server.py
Classes:
  Root: This is the root resource for the LDM web interface
  Home: This is the home resource for the LDM web interface
  ShowInterfaces: This resource supports the Show I/Fs button of
                  LDM web interface
  ShowPorts: This resource supports the Show Ports button of the LDM
             web interface

  FileServer: This is NOT used as part of the ldm web interface.
              This class is used for copying file from IOS devices.
              It is a custom http server that handles PUT requests.

This module contains support for all of the twisted servers. Twisted can be
pretty confusing...I recommend reading documentation about 'twisted web'
on the internet.

Most importantly, this is where all of the web-interface code lives.
"""
from __future__ import division
import sys, os, time, socket
from collections import OrderedDict
from itertools import islice
from datetime import datetime
import json
from tempfile import TemporaryFile
from xml.sax.saxutils import quoteattr, unescape
import multiprocessing
import commands

import jinja2
import psutil
from twisted.web.server import Site
from twisted.internet import reactor
from twisted.application import service
from twisted.web.static import File

from twisted.internet import defer
from twisted.internet import threads
from twisted.web.server import Site
from twisted.web.resource import Resource
from twisted.web.resource import NoResource
#from twisted.web.static import File
from twisted.web.util import redirectTo
from twisted.web.server import NOT_DONE_YET
import numpy as np

from KPI import parseDataSample
from Event import Event
import config as cfg
import logger
import DB
import utility

def action_button (device_name, action, button_text):
    """macro supplying HTML code for action buttons"""

    return (
        "<button align='center' class='std_button wide' id='fancy' href='#%s_%s'>" % (action, device_name)
        + "%s" % button_text
        + "</button><br>"
        )

def show_iframe_button (device_name, href, button_text):
    """macro supplying HTML code for action buttons that spawn an iframe"""

    return (
        "<button align='center' class='std_button wide fancybox.ajax' id='fancy'"
        + "href='%s?device_name=%s'>" % (href, device_name)
        + "%s" % button_text
        + "</button><br>"
        )

def power_form (device_name):
    """HTML code for the power (on/off/cycle) form"""
    action = "power"
    button_text = "Power"

    ret = "<div class='hidden fancy_form' id='%s_%s'>" % (action, device_name)
    ret += confirm_form(device_name, "poweron", "On")
    ret += confirm_form(device_name, "poweroff", "Off")
    ret += confirm_form(device_name, "powercycle", "Cycle")
    ret += "</div>"
    ret += action_button(device_name, action, button_text)

    return ret

def reserve_form (device_name):
    """HTML code for the reservation form"""
    action = "reserve"
    button_text = "Reserve"
    return (
        "<div class='hidden'>"
        + "<form class='fancy_form' id='%s_%s' autocomplete='off'>" % (action, device_name)
        + "<input type='hidden' name='device_name' value=%s>" % quoteattr(device_name)
        + "<input type='hidden' name='action' value=%s>" % quoteattr(action)
        + "<table>"
        + "<tr>"
        + "<td class='key'>Username: </td><td><input type='text' name='username' autofocus /></td>"
        + "</tr><tr>"
        + "<td class='key'>Reserve for: </td><td><input type='number' min='1' value='1' name='reserve_for'></td>"
        + "<td><select class='std_button' name='time_unit'>"
        + "<option value='604800'>weeks</option>"
        + "<option value='86400' selected='true'>days</option>"
        + "<option value='3600'>hours</option>"
        + "<option value='60'>minutes</option>"
        + "</select></td>"
        + "</tr></table>"
        + "<br>"
        + "<button class='std_button wide' value='Yes'>Reserve</button>"
        + "<button class='std_button wide' value='No'>Cancel</button>"
        + "</form>\n"
        + "</div>"
        + action_button(device_name, action, button_text)
        )

def confirm_form (device_name, action, text, message=""):
    """HTML code for yes/no prompt forms"""

    ret = (
        "<div class='hidden'>"
        + "<form class='fancy_form' id='%s_%s' name='input'>" % (action, device_name)
        + "<input type='hidden' name='device_name' value=%s>" % quoteattr(device_name)
        + "<input type='hidden' name='action' value=%s>" % quoteattr(action)
        )

    if message:
        ret += (
            "%s<br><br>" % message
            )

    ret += (
        "Are you sure?<br>"
        + "<button class='std_button wide' value='Yes'>Yes</button>"
        + "<button class='std_button wide' value='No'>No</button>"
        + "</form>\n"
        + "</div>"
        + action_button(device_name, action, text)
        )

    return ret


def link_button (device_name, type, text, link):
    """HTML code for buttons that point to URLS"""
    return (
        "<button class='std_button wide' id='%s' " % type
        + "value=%s " % quoteattr(device_name)
        + "onClick=\"location.href='%s'\">" % link
        + "%s" % text
        + "</button><br>"
        )

def time_function(f):
    def wrap(*args):
        time1 = time.time()
        ret = f(*args)
        time2 = time.time()
        logger.log.debug('%s function took %0.3f ms'
                         % (f.func_name, (time2-time1)*1000.0))
        return ret
    return wrap

def device_parse (root, path=''):
    """
    This will parse a device and compile dictionaries that will be passed
    into the jinja2 template.

    This is a recursive function that parses the device tree.

    Args:
        root: where to start parsing the tree
    """
    device_l = []

    for device in root.children:
        if device.filtered:
            continue

        device_d = {}

        # These two dictionaries hold the information for the 'Details" and "Actions"
        # frames in the GUI
        details = OrderedDict()
        actions = OrderedDict()

        # if this device has children, recurse
        if device.children:
            device_d['children'] = device_parse(device, path + "/" + device.name)

        device_d['name'] = device.name
        device_d['path'] = path + "/" + device.name
        device_d['type'] = device.get('type')
        (owner,
         reserved_until,
         ownership_origin,
         partially_owned) = device.get_ownership()

        string = ""
        if owner:
            string = owner
            if reserved_until:
                string += " (%s)" % utility.time_remaining_string(reserved_until)
            if not device.name == ownership_origin: # ownership is inhereted
                string += "<span tt='owned via %s' class='tooltip'>*</span>" % ownership_origin
        elif partially_owned:
            string = "<span tt='partially owned' class='tooltip'>~~</span>"

        device_d['owner'] = string

        # these line exists to set proper ording of action buttons
        actions['Connect'] = ""
        actions['ClearLine'] = ""
        actions['Power'] = ""
        actions['ShowInterfaces'] = ""
        actions['ShowPorts'] = ""
        actions['Reserve'] = ""
        actions['UnReserve'] = ""


        # description
        details['Description'] = device.get('description')

        # ip_address
        ip_address = device.get('ip_address')
        details['IP Address'] = ip_address

        # debug_ip_address
        details['Debug IP Address'] = device.get('debug_ip_address')

        # console
        [ts_hostname, ts_port] = device.get("console", size=2)
        if (ts_hostname and ts_port):
            link = "telnet://"+ts_hostname+":"+ts_port
            details['Console'] = "<a href=\"%s\">%s:%s</a><br>" % (link, ts_hostname, ts_port)
            actions['ClearLine'] = confirm_form(device.name, "clearline", "Clear Line")

        # Add the "connect" button
        connect_method = device.get('connect_method')
        if connect_method == "console" and ts_hostname and ts_port:
            link = "telnet://"+ts_hostname+":"+ts_port
            actions['Connect'] = link_button(device.name, "connect", "Connect", link)
        elif connect_method == "telnet" and ip_address:
            link = "telnet://"+ip_address
            actions['Connect'] = link_button(device.name, "connect", "Connect", link)
        elif connect_method == "ssh" and ip_address:
            link = "ssh://"+ip_address
            actions['Connect'] = link_button(device.name, "connect", "Connect", link)


        # aux
        [aux_hostname, aux_line] = device.get("aux", size=2)
        if (aux_hostname and aux_line):
            details['Aux'] = "%s:%s<br>" % (aux_hostname, aux_line)

        # power
        output = ""
        i = 0
        while (True):
            [hostname, outlet] = device.get("rpc%s" % i, size=2)
            if hostname and outlet:
                output += "<a href=\"http://%s\">%s</a>:%s<br>" % (hostname, hostname, outlet)
                i += 1
            else:
                break
        details['Power'] = output

        # power cycle button
        if i > 0 and not device.is_locked() and device.has_rpc_support():
            actions['Power'] = power_form(device.name)
        #actions['PowerCycle'] = confirm_form(device.name, "powercycle", "Power Cycle")
        # actions['PowerOff'] = confirm_form(device.name, "poweroff", "Power Off")
        # actions['PowerOn'] = confirm_form(device.name, "poweron", "Power On")

        # username/password
        username = device.get('username')
        password = device.get('password')
        if username or password:
            details['Username/Password'] = "%s/%s" % (username, password)

        # reserved_until
        if reserved_until:
            time_left = utility.time_remaining_string(reserved_until)
            string = utility.convert_time_str_to_tz(reserved_until)
            string += " (%s)" % time_left
            details['Reserved Until'] = string
            if device.name == ownership_origin:
                actions['UnReserve'] = confirm_form(device.name, "unreserve", "Cancel Reservation",
                                                    "You should only cancel your own reservations!")
        elif not owner and not partially_owned:
            actions['Reserve'] = reserve_form(device.name)

        # location
        lab = device.get("lab")
        rack = device.get("rack")
        if lab or rack:
            details['Location'] = "%s %s" % (lab, rack)

        # model_number
        details['Model Number'] = device.get('model_number')

        # asset_tag_number
        details['Asset Tag Number'] = device.get('asset_tag_number')

        # serial_number
        details['Serial Number'] = device.get('serial_number')

        # other
        details['Other'] = device.get('other').replace("\n", "<br>")

        # leftover action buttons
        if device.get("type") == "CiscoTermserver":
            actions['ShowPorts'] = show_iframe_button(device.name, "showports", "Show Ports")
        if hasattr(device, "has_connections_defined") and device.has_connections_defined():
            actions['ShowInterfaces'] = show_iframe_button(device.name, "showinterfaces", "Show I/Fs")

        # add show interfaces button
        device_d['details'] = details
        if len(''.join(actions.values())):
            device_d['actions'] = actions
        device_l += [device_d]

    return device_l

class Root(Resource):
    """This is the root resource for the LDM web interface"""
    isLeaf = False

    def render_GET(self, request):
        return redirectTo("home", request)

    def getChild(self, path, request):
        if path:
            return NoResource()
        else:
            return self

class Main(Resource):
    """This is the home resource for the LDM web interface"""
    isLeaf = True

    def __init__(self):
        Resource.__init__(self)

    def request_finish (self, value, request):
        request.finish()

    def deferred_err (self, err, request):
        err.trap(Exception)
        request.write(err.getErrorMessage())
        request.finish()

    def deferred_cancel (self, err, deferred):
        deferred.cancel()

    def render_POST(self, request):
        parser = cfg.refresh_parser()
        d = None
        # LEVY DEBUG
        #for key, val in request.args.items():
        #    print "%s = %s" % (key, val)

        if 'action' in request.args and 'device_name' in request.args:
            action = request.args['action'][0]
            device_name = request.args['device_name'][0]

            device = cfg.device_tree[device_name]

            #
            # Power Operations
            if (action == "poweron" or
                action == "poweroff" or
                action == "powercycle"):

                # strip off the 'power' from the command (eg. 'poweron'-->'on')
                action = action.replace("power", "")
                d = threads.deferToThread(device.power_ctrl, action)
            #
            # Clear Line
            elif action == "clearline":
                d = threads.deferToThread(device.clear_my_line)

            #
            # Reserve
            elif action == "reserve":
                username = request.args['username'][0]
                reserve_for = request.args['reserve_for'][0]
                time_unit = request.args['time_unit'][0]

                # how long to reserve?
                if not username:
                    return ("You must specify a username!")

                if reserve_for:
                    reserve_for_secs = int(reserve_for) * int(time_unit)
                else:
                    return "You must specify a time duration!"

                # check for an existing owner
                (owner,
                 reserved_until,
                 ownership_origin,
                 partially_owned) = device.get_ownership()
                if owner and reserved_until:
                    return ("This device is reserved by %s!" % owner)
                elif owner:
                    return ("This device is owned by %s!" % owner)
                elif partially_owned:
                    return ("This device is partially owned!")

                # make the reservation
                d = threads.deferToThread(device.reserve, username, reserve_for_secs)

            #
            # Unreserve
            elif action == "unreserve":
                d = threads.deferToThread(device.unreserve)

            #
            # Edit
            if action == "edit":
                d = threads.deferToThread(self.edit_config_block, request, device)

        elif "action" in request.args:
            action = request.args['action'][0]
            if action == "edit":
                d = threads.deferToThread(self.edit_config_file, request)

        # Wrap up the request
        if d:
            d.addCallback(self.request_finish, request)
            d.addErrback(self.deferred_err, request)
            request.notifyFinish().addErrback(self.deferred_cancel, d)
            return NOT_DONE_YET
        else:
            return "success"

    def render_GET(self, request):
        parser = cfg.refresh_parser()
        template_dict = {}

        templateLoader = jinja2.FileSystemLoader("/")
        templateEnv = jinja2.Environment (loader=templateLoader,
                                          trim_blocks = True,
                                          )
        template = templateEnv.get_template(utility.resource_path("html/template_main.html"))

        # Check for filters
        filters = []
        # filter_string = form.getfirst('filter')
        if 'filter' in request.args:
            filter_string = request.args['filter'][0]
            if filter_string:
                template_dict['filter_string'] = filter_string
                filters += filter_string.split(',')

        # Get the path
        path = ""
        if 'path' in request.args:
            path = request.args['path'][0]
            if path:
                template_dict['path'] = path

        # from the path, find the name of the root device
        root_name = os.path.basename(path)

        # validate the path and set the path header
        path_hdr = ""
        if path:
            path_nodes = path.split("/")
            partial_path = ""
            for name in path_nodes:
                if not name:
                    continue
                if not name in cfg.device_tree:
                    path = ""
                    path_hdr = ""
                    root_name = ""
                    break
                partial_path += "/" + name
                if name != root_name:
                    path_hdr += "<a href='home?path=%s'>%s</a>/" % (partial_path, name)
                else:

                    path_hdr += name + "/"

        template_dict['path'] = path
        template_dict['path_hdr'] = path_hdr


        template_dict['testbed_name'] = cfg.get_global('testbed_name')
        template_dict['config_errors'] = cfg.get_global('config_errors')

        return str(template.render(template_dict))

    def edit_config_file(self, request):
        """Apply changes to the config file"""

        cfg_before = request.args['cfg_before'][0].replace("\r", "")

        cfg_after = request.args['cfg_after'][0].replace("\r", "")

        # get the current state of the cfg file (it could have changed since we
        # opened it)
        with open(cfg.config_file, 'r') as f:
            cfg_now = f.read()

        # patch the current config file
        patched_string = utility.three_way_merge(cfg_before,
                                                 cfg_after,
                                                 cfg_now)

        # write patched config file
        with open(cfg.config_file, 'wb') as f:
            f.write(patched_string)

    def edit_config_block(self, request, device):
        """Apply change to a config file device block"""

        cfg_before = request.args['cfg_before'][0].replace("\r", "")
        cfg_after = request.args['cfg_after'][0].replace("\r", "")

        # retrieve the current state of the config block
        parser = cfg.refresh_parser()
        cfg_now = utility.get_parser_section_contents(parser, device.name)

        # Apply the patch to the current state
        patched_string = utility.three_way_merge(cfg_before, cfg_after, cfg_now)

        # write the patched version of the block into a tmp file
        tmp_f = TemporaryFile()
        tmp_f.write("[%s]\n" % device.name)
        tmp_f.write(patched_string)

        # clear the section in the real parser
        for option in parser.options(device.name):
            parser.remove_option(device.name, option)

        # read in the tmp file with the real parser
        tmp_f.seek(0)
        parser.readfp(tmp_f)

        # write the real parser back to the persistent config file
        with open(cfg.config_file, 'wb') as f:
            parser.write(f)

class ShowInterfaces(Resource):
    """This resource supports the Show I/Fs button of the web interface"""
    isLeaf = True

    def __init__(self):
        Resource.__init__(self)

    def render_GET(self, request):

        if 'device_name' in request.args:
            device_name = request.args['device_name'][0]
            device = cfg.device_tree[device_name]
            output = "<html><body><pre style='padding:15px; text-align:left; font-size:14px'>"
            output += device.show_interfaces()
            output += "</pre></body></html>"
            return output

        return "failure"

class ShowPorts(Resource):
    """This resource supports the Show Ports button of the web interface"""
    isLeaf = True

    def __init__(self):
        Resource.__init__(self)

    def render_GET(self, request):

        if 'device_name' in request.args:
            device_name = request.args['device_name'][0]
            device = cfg.device_tree[device_name]
            output = "<html><body><pre style='padding:15px; text-align:left; font-size:14px'>"
            output += device.show_ports()
            output += "</pre></body></html>"
            return output

        return "failure"

class EditConfig(Resource):
    """This resource supports the form for editing the config file"""
    isLeaf = True

    def __init__(self):
        Resource.__init__(self)

    def render_GET (self, request):
        # LEVY DEBUG
        #for key, val in request.args.items():
        #    print "%s = %s" % (key, val)
        if 'device_name' in request.args:
            device_name = request.args['device_name'][0]
            if device_name:
                device = cfg.device_tree[device_name]
                return self.config_block(device)
        else:
            return self.config_file()

    def config_file (self):
        """Return a html form for editing the config file"""

        f = open(cfg.config_file, 'r')
        # read the file
        file_text = f.read()

        output = "<script type='text/javascript' src='scripts/ldm.fancybox.js'></script>\n"
        output += ("<form class='fancy_form'>\n"
                   + "<input type='hidden' name='action' value='edit'>\n"
                   + "<input type='hidden' name='cfg_before' value=%s>\n" % quoteattr(file_text)
                   + "<textarea name='cfg_after' rows='50' cols='80'>\n"
                   + "%s" % file_text
                   + "</textarea><br>"
                   + "<button class='std_button wide' value='Yes'>Save</button>"
                   + "<button class='std_button wide' value='No'>Cancel</button>"
                   + "</form>"
                   )
        return output

    def config_block (self, device):
        """Return a html form for editing device config block"""

        # copy the config section to a tmp parser
        file_text = utility.get_parser_section_contents(cfg.parser, device.name)

        output = "<script type='text/javascript' src='scripts/ldm.fancybox.js'></script>\n"
        output += "<h2 align='left'>[%s]</h2>" % device.name
        output += ("<form class='fancy_form'>\n"
                   + "<input type='hidden' name='action' value='edit'>\n"
                   + "<input type='hidden' name='device_name' value=%s>\n" % quoteattr(device.name)
                   + "<input type='hidden' name='cfg_before' value=%s>\n" % quoteattr(file_text)
                   + "<textarea name='cfg_after' rows='50' cols='80'>\n"
                   + "%s" % file_text
                   + "</textarea><br>"
                   + "<button class='std_button wide' value='Yes'>Save</button>"
                   + "<button class='std_button wide' value='No'>Cancel</button>"
                   + "</form>"
                   )
        return output

def device_parse2 (root, path=''):
    """
    This will parse a device and compile dictionaries that will be passed
    into the jinja2 template.

    This is a recursive function that parses the device tree.

    Args:
        root: where to start parsing the tree
    """
    device_tree_d = {}

    for device in root.children:
        if device.filtered:
            continue

        device_d = {}

        # These two dictionaries hold the information for the 'Details" and "Actions"
        # frames in the GUI
        details = OrderedDict()
        actions = OrderedDict()

        # if this device has children, recurse
        if device.children:
            device_d['children'] = device_parse(device, path + "/" + device.name)

        device_d['name'] = device.name
        i = 0
        metrics = []
        while (True):
            [oid, interval] = device.get("poll_snmp%s" % i, size=2)
            if oid:
                metrics += [oid]
                oid = { "name":oid, "interval":interval }
                device_d["poll_snmp%s" % i] = oid
            else:
                break
            i += 1

        device_d['metrics'] = metrics
        device_tree_d[device.name] = device_d

    return device_tree_d


class DeviceData(Resource):
    """This is the resource for the device data tree (json format)"""
    isLeaf = True

    def __init__(self):
        Resource.__init__(self)

    def render_GET(self, request):
        # set the root device
        root = cfg.device_tree[""]

        # recursively parse the device tree
        device_tree_d = device_parse2(root)
        return json.dumps(device_tree_d)

class DeviceConfig(Resource):
    """This is the resource for the device data tree (json format)"""
    isLeaf = True

    def __init__(self):
        Resource.__init__(self)

    def render_GET(self, request):
        return json.dumps(cfg.parser._sections)


class systemInfo(Resource):
    isLeaf = True

    def __init__(self):
        Resource.__init__(self)

    def render_GET(self, request):
        GB = 1073741824.0

        cpu_count = multiprocessing.cpu_count()
        cpu_tuple = os.getloadavg()
        cpu_load = "1m=%.2f | 5m=%.2f | 15m=%.2f" % (
            (cpu_tuple[0] / cpu_count),
            (cpu_tuple[1] / cpu_count),
            (cpu_tuple[2] / cpu_count)
            )
        mem_tuple = psutil.virtual_memory()
        mem_load = "total=%.1fG | used=%.1fG | free=%.1fG | usage=%.1f%%" % (
            mem_tuple.total / GB,
            (mem_tuple.total - mem_tuple.available) / GB,
            mem_tuple.available / GB,
            mem_tuple.percent
            )
        disk_tuple = psutil.disk_usage(DB.db_dir)
        disk_usage = "total=%.1fG | used=%.1fG | free=%.1fG | usage=%.1f%%" % (
            disk_tuple.total / GB,
            disk_tuple.used / GB,
            disk_tuple.free / GB,
            disk_tuple.percent
            )
        db_tuple = DB.get_usage(scan=False)
        table_tuple = DB.get_table_space()
        lapsed = (time.time() - db_tuple[2]) / 3600
        db_usage = ("total=%.1fG | used=%.1fG | free=%.1fG | usage=%.1f%% (%.1f hours ago)" % (
                db_tuple[0] / GB,
                (db_tuple[0] - db_tuple[1]) / GB,
                db_tuple[1] / GB,
                ((db_tuple[0] - db_tuple[1]) / (db_tuple[0])) * 100,
                lapsed)
                    + "<br>table_space=%.1fG | index_space=%.1fG" % (
                table_tuple[0] / GB,
                table_tuple[1] / GB
                ))

        html_text = ('<style>'
                     '#system_info td {'
                     'white-space:nowrap;'
                     '}'
                     '#system_info td.col1 {'
                     'padding-right:20px;'
                     'border-bottom:dotted 1px;'
                     '}'
                     '</style>')

        html_text += '<div style="background-color:#424242;">'
        html_text += '<h1 style="color:#ccc;">Server Status</h1>'
        html_text += '</div>'

        html_text += '<table id="system_info">'
        html_text += '<tr><td class="col1">CPU Cores</td><td>%d</td></tr>' % cpu_count
        html_text += '<tr><td class="col1">CPU Load Avg</td><td>%s</td></tr>' % cpu_load
        html_text += '<tr><td class="col1">Memory</td><td>%s</td></tr>' % mem_load
        html_text += '<tr><td class="col1">Disk</td><td>%s</td></tr>' % disk_usage
        html_text += '<tr><td class="col1">DB</td><td>%s</td></tr>' % db_usage
        html_text += '</table>'
        return html_text

class test (Resource):
    isLeaf = True
    def __init__(self):
        Resource.__init__(self)

    def render_GET(self, request):
        event_mgr = Event()
        event_mgr.test()
        return

class getJSON (Resource):
    isLeaf = True

    def __init__(self):
        Resource.__init__(self)
        self.event_mgr = Event()
        # initialize the db cache
        DB.init()
        #print DB.get_usage(scan=True)

    def render_GET(self, request):
        query = ""
        if "query" in request.args:
            query = request.args['query'][0]

        if query == "full_load" or query == "save_load":
            if "start" in request.args and "end" in request.args:
                start = int(request.args['start'][0])
                end = int(request.args['end'][0])
                event = self.event_mgr.full_load(start, end)
                if query == "save_load":
                    self.event_mgr.saveEvent(event)
                return json.dumps(event)
        elif query == "quick_load":
            if "start" in request.args and "end" in request.args:
                start = int(request.args['start'][0])
                end = int(request.args['end'][0])
                event = self.event_mgr.quick_load(start, end)
                return json.dumps(event)
        elif query == "event_load":
            if "event_id" in request.args:
                event_id = int(request.args['event_id'][0])
                event = self.event_mgr.getEventByID(event_id)
                return json.dumps(event)
        elif query == "event_delete":
            if "event_id" in request.args:
                event_id = int(request.args['event_id'][0])
                self.event_mgr.deleteEvent(event_id)
                return json.dumps({})
        elif query == "event_list":
            return self.event_mgr.getEventList();
        elif query == "kpi_data":
            return self.kpi_data(request)
        elif query == "poll_status":
            return self.poll_status(request)
        else:
            return {}

    @time_function
    def render_POST(self, request):
        code = 0
        query = ""

        if "query" in request.args:
            query = request.args['query'][0]

        if query == "poller_start":
            (code, result) = commands.getstatusoutput('ldm poller start')
        elif query == "poller_stop":
            (code, result) = commands.getstatusoutput('ldm poller stop')
        elif query == "poller_restart":
            (code, result) = commands.getstatusoutput('ldm poller restart')

        if code:
            return "failure"
        else:
            return "success"

    def poll_status (self, request):
        host, port = "localhost", 8080
        response = ""

        # Create a socket (SOCK_STREAM means a TCP socket)
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

        try:
            # Connect to server and send data
            sock.connect((host, port))
            sock.sendall("status")

            # Receive data from the server and shut down

            response = ""
            while True:
                data = sock.recv(2048)
                if not data: break
                response += data;
            #print response
        except socket.error:
            pass
        finally:
            sock.close()

        return response

    def kpi_data (self, request):
        data_raw = []
        data_summary = []
        span_start = zoom_start = 0
        span_end = zoom_end = time.time()

        # LEVY TODO: check for wlc_name?
        if 'kpi_name' in request.args and 'device_name' in request.args:
            device_name = request.args['device_name'][0]
            kpi_name = request.args['kpi_name'][0]

            if device_name and kpi_name:
                if 'start' in request.args:
                    span_start = int(request.args['start'][0])
                if 'end' in request.args:
                    span_end = int(request.args['end'][0])

                if 'zoom_start' in request.args:
                    zoom_start = int(request.args['zoom_start'][0])
                if 'zoom_end' in request.args:
                    zoom_end = int(request.args['zoom_end'][0])

                start = max(span_start, zoom_start)
                end = min(span_end, zoom_end)
                delta = end - start

                sstart = max(start - delta, span_start)
                eend = min(end + delta, span_end)

                query_start_time = time.time() * 1000
                # find the min and max data in the input range

                d = DB.get_device(name=device_name)
                k = DB.get_kpi(name=kpi_name)

                if True: # multi-threaded
                    query_set = d.sample_set.filter(kpi=k)
                    columns = ['timestamp',
                               'int_value',
                               'bigint_value',
                               'smallint_value',
                               'str_value',
                               ]
                    values = DB.threadedQuery(query_set, sstart, eend, columns)
                else:
                    record_l = d.sample_set.filter(kpi=k,
                                                   timestamp__range=(sstart, eend))
                    values = list(record_l.values_list('timestamp',
                                                       'int_value',
                                                       'bigint_value',
                                                       'smallint_value',
                                                       'str_value'))

                copy_start_time = time.time() * 1000

                for timestamp, int_value, smallint_value, bigint_value, str_value in values:
                    if smallint_value != None:
                        data_raw.append([timestamp, smallint_value])
                    elif int_value != None:
                        data_raw.append([timestamp, int_value])
                    elif bigint_value != None:
                        data_raw.append([timestamp, bigint_value])
                    else: # it's a complex string value
                        record_l = parseDataSample(kpi_name, str_value)

                        if record_l:
                            data_raw.append([timestamp] + record_l)

                if not data_raw:
                    print "no data"
                    return json.dumps(data_raw)

                # Update the range now that we know what data is available
                data_start = data_raw[0][0]
                data_end = data_raw[len(data_raw)-1][0]
                start = max(start, data_start)
                end = min(end, data_end)
                delta = end - start

                bkt_start_time = time.time() * 1000

                # set the bucket size
                num_bkts = 100
                bkt_size = delta / num_bkts
                if not bkt_size:
                    bkt_size = 1

                bkt_l = {}

                for i in xrange(len(data_raw)):
                    timestamp = data_raw[i][0]
                    bkt_i = (timestamp // bkt_size) * bkt_size + bkt_size / 2
                    if bkt_i not in bkt_l:
                        bkt_l[bkt_i] = []
                        for val in data_raw[i][1:]:
                            bkt_l[bkt_i].append([])
                    for j, v in enumerate(data_raw[i][1:]):
                        bkt_l[bkt_i][j].append(v)

                process_start_time = time.time() * 1000
                for key, bkt in bkt_l.items():
                    timestamp = int(key) * 1000
                    point = [timestamp]
                    if len(bkt) == 1:
                        nums = np.array(bkt)
                        mean = nums.mean(dtype=int)
                        std = mean + nums.std()
                        point += [mean, std]
                    else:
                        for p in bkt:
                            nums = np.array(p)
                            mean = nums.mean(dtype=int)
                            point += [mean]
                    data_summary.append(point)

                end_time = time.time() * 1000
                logger.log.debug ("query/copy/buckets/process/total: %s/%s/%s/%s/%s" %
                                  (int(copy_start_time - query_start_time),
                                   int(bkt_start_time - copy_start_time),
                                   int(process_start_time - bkt_start_time),
                                   int(end_time - process_start_time),
                                   int(end_time - query_start_time)))

                data_summary = sorted(data_summary, key=lambda point: point[0])

                return json.dumps(data_summary)

class List(Resource):
    """This is the analytics resource for the LDM web interface"""
    isLeaf = True

    def __init__(self):
        Resource.__init__(self)

    def render_GET(self, request):
        parser = cfg.refresh_parser()
        template_dict = {}

        templateLoader = jinja2.FileSystemLoader("/")
        templateEnv = jinja2.Environment (loader=templateLoader,
                                          trim_blocks = True,
                                          )
        template = templateEnv.get_template(utility.resource_path("html/list_content.html"))

        # Check for filters
        filters = []
        # filter_string = form.getfirst('filter')
        if 'filter' in request.args:
            filter_string = request.args['filter'][0]
            if filter_string:
                filters += filter_string.split(',')

        # Get the path
        path = ""
        if 'path' in request.args:
            path = request.args['path'][0]

        # from the path, find the name of the root device
        root_name = os.path.basename(path)

        # set the root device
        root = cfg.device_tree[root_name]

        if filters:
            cfg.filter_device_tree(root, filters)

        # recursively parse the device tree
        devices_l = device_parse(root, path)

        template_dict['testbed_name'] = cfg.get_global('testbed_name')
        template_dict['config_errors'] = cfg.get_global('config_errors')
        template_dict['devices'] = devices_l


        return str(template.render(template_dict))

#
# This class is NOT part of the LDM web interface.
# it is used for the 'ldm copy' command
#
class FileServer(Resource):
    """Wait for a put request and write its content to a file"""

    isLeaf = True

    def __init__(self, dirname):
        self.dirname = dirname
        Resource.__init__(self)

    def render_PUT(self, request):
        #levy DEBUG
        #for key, val in request.args.items():
        #    print "%s = %s" % (key, val)

        # TODO: can you pass a number into read and
        # just read a bit at a time?
        data = request.content.read() #getvalue()
        filepath = self.dirname + request.uri

        try:
            f = open(filepath, 'w')
            f.write(data)
        except IOError, e:
            print e
            return

        return "success"
