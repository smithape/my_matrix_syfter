from io import StringIO
import json as _json
import yaml as _yaml
import csv as _csv
import re
import io
import configparser
import apacheconfig

try:
    from textfsm import TextFSM
    import erl_terms
except: pass

from . import logger as log
from . import utility

def to_num (x):
    # try to convert string to number
    if not isinstance(x, (int, float)):
        try: # try INT
            x = int(x)
        except:
            try: # try FLOAT
                x = float(x)
            except: pass

    return x

key_val_re = re.compile(r'([\w ]+) *[:|=] *((?:[\S].+)?)')
def keyval (text, delimiter="=", as_list=False,
            comment_style=None, group_start_regex=None, group_end_regex=None):
    data_l = []
    key_l = []
    entry = pointer = {}
    if delimiter == "space":
        delimiter = " "

    for line in text.splitlines():
        if comment_style:
            line = re.sub(r'%s.*' % comment_style, "", line)
        #match = re.search(key_val_re, line)
        if group_start_regex:
            match = re.match(group_start_regex, line)
            if match:
                group_name = match.group(1).strip()
                pointer = entry[group_name] = {}
                continue
            elif group_end_regex:
                match = re.match(group_end_regex, line)
                if match:
                    pointer = entry
                    continue

        match = line.split(delimiter, 1)
        if len(match) > 1:
            key, value = [x.strip().strip('"') for x in match]
            if as_list:
                try:
                    if key_l.index(key) == 0:
                        # store the entry
                        data_l.append(entry)
                        # reset the entry
                        entry = pointer = {}
                except ValueError:
                    key_l.append(key)
            pointer[key] = value

    # store the final entry
    data_l.append(entry)

    if as_list:
        return data_l
    else:
        return data_l[0]

def table (text, delimiter=None, headers=[], wordwrap_key=None, key_regex=None):
    """
    convert a fixed-width ascii (terminal) table into a python list

    @param text: The input text
    #param delimiter: Optional delimiter used to separate table columns
    @param wordwrap_key: When a key is specified, that header MUST always be present in
                         a table row. This is used to identify when word-wrap is occuring
                         within cells.
    @param headers: A list of the table headers used to help in parsing the columns.

    @return: table entries as list or dict
    """

    # remove hr lines
    text2 = ''
    for line in text.splitlines():
        if not re.match(hr_re, line):
            text2 += line + '\n'

    if delimiter:
        data_l = delimited_table(text2,
                                 delimiter)

    else:
        data_l = aligned_table(text2,
                               wordwrap_key=wordwrap_key,
                               key_regex=key_regex,
                               headers=headers)

    return data_l

hr_re = re.compile(r'^[^\w]*$')
def aligned_table (text, wordwrap_key=None, key_regex=None, headers=[]):
    # parse the header
    header = text.splitlines()[0]
    header_l = parse_header(header, headers=headers)

    # modify key for case-insensitive
    if wordwrap_key:
        match = False
        for header, length in header_l:
            if wordwrap_key.lower() == header.lower():
                wordwrap_key = header
                match = True
                break

        if not match:
            raise KeyError("Key ('%s') not found in table!" % wordwrap_key)

    # parse the row data
    row_l = []
    for line in text.splitlines()[1:]:
        row = {}
        i = 0
        for header, length in header_l:
            # if length is 0, parse the rest of the line
            if length:
                val = line[i:(i+length)]
            else:
                val = line[i:]

            row[header] = to_num(val.strip(' \t|'))
            i += length

        # word wrap? check the key
        if wordwrap_key:
            key_complete = True
            if key_regex:
                try:
                    key_complete = re.match(key_regex, row_l[-1][wordwrap_key])
                except IndexError as e: pass

            if not row[wordwrap_key] or not key_complete:
                # this is an word-wrapped cell, append to previous row
                for x,y in row.items():
                    row_l[-1][x] += row[x]
                continue
            else:
                # this is a new key, start new row
                row_l.append(row)
        else:
            # standard add new row element
            row_l.append(row)

    return row_l


def delimited_table (text, delimiter):
    # parse the header
    header = text.splitlines()[0]
    try:
        header_l = [x.strip() for x in re.split(delimiter, header.strip())]
    except:
        delimiter = "\\" + delimiter
        header_l = [x.strip() for x in re.split(delimiter, header.strip())]

    # parse the row data
    row_l = []
    for line in text.splitlines()[1:]:
        row_l.append({x:to_num(y.strip()) for x,y in zip(header_l, re.split(delimiter, line.strip())) if x})

    return row_l


header_re = re.compile(r'(\|*\s*((?:[^\|\s]+ ?)+)\s*\|*)') # | delimited
#header_re = re.compile(r'((?:\S+ ?)+)[\s]+') # whitespace delimited
header_re_str = r'(\|*[\s]*((?:%s)+)\s*\|*)' # used for when headers are specified
def parse_header (header, headers=[]):
    if headers:
        tmp_header_re = re.compile(header_re_str % '|'.join(headers), flags=re.IGNORECASE)
    else:
        tmp_header_re = header_re

    # use the regex to find all the headers and column width
    cols = re.findall(tmp_header_re, header)

    # find column widths
    header_l = [(header.strip(), len(match)) for match, header in cols]

    # no need to limit the last column, set it's length to 0
    header_l[-1] = (header_l[-1][0], 0)

    return header_l

def json (text):
    """
    basically just json.load(), but ensures the string is decoded first
    """

    try:
        data = _json.loads(text)
    except TypeError:
        data = _json.loads(text.decode())

    return data

def yaml (text):
    """
    basically just json.load(), but ensures the string is decoded first
    """

    try:
        data = _yaml.full_load(text)
    except TypeError:
        data = _yaml.full_load(text.decode())

    return data

def apache (text):
    options = {
        'useapacheinclude': False,
    }
    with apacheconfig.make_loader(**options) as loader:
        data = loader.loads(text)

    return data

def ini (text):
    """
    basically just json.load(), but ensures the string is decoded first
    """
    # Add the default section?
    if not text.lstrip().startswith("[DEFAULT]"):
         text = "[DEFAULT]\n" + text

    parser = configparser.ConfigParser(allow_no_value=True, strict=False)

    try:
        parser.read_string(text)
    except TypeError:
        parser.read_string(text.decode())
    data = dict(parser._sections).copy()
    data['DEFAULT'] = dict(parser._defaults)
    data = {x.strip():y for x,y in data.items() if y != {}}

    return data

def csv (text, headers_included = False, headers = []):
    """Parse CSV format"""

    f = StringIO(text)
    reader = _csv.reader(f, escapechar="\\", skipinitialspace=True)
    row_l = [x for x in reader]

    if headers_included:
        headers = row_l[0]
        row_l = row_l[1:]
    
    if headers:
        return [dict(zip(headers, row)) for row in row_l]
    else:        
        return row_l

def erl_terms (text):
    """
    placeholder
    """

    return erl_terms.decode(text)

template = """Value PID (\d+)
Value USER (\S+)
Value PRI (\S+)
Value ni (\S+)
Value VIRT (\d+)
Value RES (\d+)
Value SHR (\d+)
Value STATE (\S+)
Value CPU ([\d\.]+)
Value MEM ([\d\.]+)
Value TIME (\S+)
Value index (\S+(\s\S+)+|\S+)

Start
  ^ *${PID} *${USER} *${PRI} *${ni} *${VIRT} *${RES} *${SHR} *${STATE} *${CPU} *${MEM} *${TIME} *${index} -> Record
"""
def textfsm (text, fsm=None, template=template):
    if not fsm:
        # remove extra whitespace
        template = template.strip()

        # read the textfsm template (as a file)
        fsm = TextFSM(io.StringIO(template))

    # parse the text
    table = fsm.ParseText(text)

    #return table

    # # apply the line filter
    # if top and top < (len(table) - 1):
    #     table = table[0:top]

    data_l = []
    for row in table:
        data_d = {}
        for key, val in zip(fsm.header, row):
            data_d[key] = to_num(val)

        data_l.append(data_d)

    return data_l

def regex (text, expression, findall = False, match_required = True):
    match_l = None
    if findall:
        match_l = re.findall(expression, text)
    else:
        try:
            match_l = list(re.search(expression, text).groups())
        except AttributeError: pass

    if match_l:
        # convert to numbers
        match_l = [to_num(x) for x in match_l]

        if isinstance(match_l, list) and len(match_l) == 1:
            # if only one result, no need for list
            data = match_l[0]
        else:
            data = match_l
        return data
    elif not match_required:
        return text
    else:
        raise Exception("No regex match :-(")

def timestamps (data):
    """ attempt to convert timestamps to epoch """
    if isinstance(data, list):
        for x in data:
            timestamps(x)
    elif isinstance(data, dict):
        for x,y in data.items():
            if x.lower() in ['time', 'timestamp', 'ts']:
                data[x] = utility.datetime_to_epoch(utility.parse_time(data[x]))

    return data
