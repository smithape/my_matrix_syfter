import os
import time
from datetime import datetime
import queue
import json
import psutil

from .PeriodicThread import PeriodicThread
from . import DB
from . import logger as log
from . import utility
from . import config as cfg

class FileSystem (DB.DBObject):
    def __init__ (self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.send_buffer = queue.Queue()
        self.up = True
        self.status = "ok"

        # initialize the data directory
        if not os.path.exists(cfg.filesystem_path):
            os.makedirs(cfg.filesystem_path, 0o755)

        now = int(time.time())
        self.tstamp_d = {
            'flush': now,
            'send_config': 0,
            }

    def start (self):
        # Start the monitor thread
        self.monitor_t = PeriodicThread(name="filesystem_db/monitor",
                                        interval=10,
                                        action=self.monitor,
                                        daemon=True)
        self.monitor_t.start(time.time())

    def stop (self):
        # stop the monitor thread
        if self.monitor_t:
            self.monitor_t.stop()

    def monitor (self):
        now = int(time.time())

        # flush the send buffer
        if now - self.tstamp_d['flush'] >= cfg.filesystem_flush_period:
            self.flush()
            self.tstamp_d['flush'] = now

        # send the configs
        if now - self.tstamp_d['send_config'] >= cfg.filesystem_config_update_period:
            self.send_config()
            self.tstamp_d['send_config'] = now

    def bulk_insert (self, sample_l):
        for timestamp, device_name, nugget_name, value in sample_l:
            e = self.create_sample(timestamp, device_name, nugget_name, value)
            self.send_buffer.put(e)

    def nugget_cfg (self, data):
        """ handle incoming nugget configs """
        # send full (updated) config
        self.send_config()

    def create_sample (self, timestamp, device_name, nugget_name, value):
        sample = {
            'timestamp': timestamp,
            'device': device_name,
            'nugget': nugget_name,
            'value': value
        }

        return sample

    def flush (self):
        buffer_l = list(self.send_buffer.queue)

        if buffer_l:
            data = list(self.send_buffer.queue)
            self.send_buffer.queue.clear()
            self.send_data(data)

    def send_data (self, data):
        if data:
            if not isinstance(data, str):
                data = json.dumps(data)
                #data = json.dumps(data, indent=4)

            # find the filepath
            filepath_root = filepath = "%s/%s" % (cfg.filesystem_path, int(time.time() * 1000))

            # make sure the filepath is unique
            i = 0
            while os.path.exists(filepath):
                filepath = "%s.%s" % (filepath_root, i)
                i += 1

            # write the dump
            with open (filepath, "w") as f:
                f.write(data)

    def send_config (self):
        config = {
            'company': cfg.company,
            'timezone': cfg.timezone,
            'nugget': DB.db.nugget_cfg_d,
            'device': DB.db.device_d
        }

        # find the filepath
        filepath = "%s/config" % cfg.filesystem_path

        # write the dump
        with open (filepath, "w") as f:
            f.write(json.dumps(config))

    def maintenance (self):
        """
        This function is run by the monitor service during the nightly maintenance hour
        """

        now = int(time.time())

        for filename in sorted(os.listdir(cfg.filesystem_path)):
            if filename == 'config': continue

            timestamp = int(filename.split('.')[0]) // 1000

            if timestamp < (now - cfg.days_to_keep_data * 86400):
                log.debug("Removing old dump %s" % filename)
                filepath = os.path.join(cfg.filesystem_path, filename)
                os.remove(filepath)
            elif psutil.disk_usage(cfg.filesystem_path).percent > cfg.disk_usage_threshold:
                log.warning("Disk space low, removing old dump %s" % filename, "system")
                filepath = os.path.join(cfg.filesystem_path, filename)
                os.remove(filepath)
            else: break
