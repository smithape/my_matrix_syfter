import os, sys
import time
from threading import Thread
import asyncore, socket, asynchat
import requests, json
import traceback
from queue import Queue
from twisted.internet import reactor, threads, protocol as p
from django.db import connection, IntegrityError
import numpy as np
import pandas as pd
import redis as redis_py

from .PeriodicThread import PeriodicThread
from . import config as cfg
from . import logger as log
from . import utility
from . import linux
from device.Device import Device

# interface to redis
def init_redis ():
    if linux.distro() == "docker":
        redis_host = 'redis'
    else:
        redis_host = 'localhost'
    return redis_py.StrictRedis(host=redis_host)

redis = init_redis()

# the default database manager
db = None
def init ():
    return DBManager(set_global=True)

class DbDaemon ():
    def __init__(self):
        self.stdin_path = '/dev/null'
        self.stdout_path = '/dev/tty'
        self.stderr_path = '/dev/tty'
        self.pidfile_path =  cfg.get_pidfile('db')
        self.pidfile_timeout = 1
        self.interrupt = False
        self.server_t = Thread(target=reactor.run, kwargs={'installSignalHandlers': 0})

    def run(self):
        init()
        reactor.listenTCP(cfg.db_server_port, DBServer())
        try:
            self.server_t.start()
            db.start()
            while not self.interrupt:
                time.sleep(1)
        except Exception as e:
            log.debug(traceback.format_exc())
        finally:
            try:
                db.stop()
                reactor.callFromThread(reactor.stop)
            except:
                log.debug("exception in DB server shutdown")
                log.debug(traceback.format_exc())

    def terminate(self, signal_number, stack_frame):
        self.interrupt = True

class DBServer (p.Factory):
    def buildProtocol(self, addr):
        return RequestHandler()

class RequestHandler (p.Protocol):
    delimiter = b'\n'

    def __init__(self):
        self.ibuffer = bytearray()

    def dataReceived(self, data):
        # add new data to the buffer
        self.ibuffer.extend(data)
        # delimiter marks the end of the message
        if data[-1] == self.delimiter[-1]:
            try:
                # parse the message into json
                request = json.loads(self.ibuffer.decode())
                # process the request
                self.process_request(request)
            except Excpetion as e:
                log.error("Invalid Request (cannot parse)", "system")
            finally:
                # clear the buffer
                self.ibuffer = bytearray()

    def process_request (self, request):
        # extract the query type
        query = request['name'].lower()
        # find the query handler
        fn = getattr(self, query)

        try:
            response = fn(request['options'])
        except KeyError as e:
            response = fn()

        if response:
            self.respond(response)

    def respond (self, response):
        if not isinstance(response, str):
            response = json.dumps(response)

        response = response.encode() + self.delimiter
        self.transport.write(response)
        self.transport.loseConnection()

    def write_rate (self):
        # get the current value
        ret = db.write_rate
        # reset to 0
        db.write_rate = 0

        return json.dumps(ret)

    def series_data (self, opt):
        start = opt['start']
        end = opt['end']
        device_name = opt['device']
        nugget_name = opt['nugget']
        resample_period = opt['resample_period']

        d = threads.deferToThread(db.series_data, start, end,
                                  device_name, nugget_name, resample_period)
        d.addCallback(self.respond)
        #return db.series_data(start, end, device_name, nugget_name, resample_period)

    def series_summary (self, opt):
        start = opt['start']
        end = opt['end']
        device_name = opt['device']
        nugget_name = opt['nugget']

        d = threads.deferToThread(db.series_summary, start, end,
                                  device_name, nugget_name)
        d.addCallback(self.respond)

    def metric_presence (self, opt):
        start = opt['start']
        end = opt['end']
        group = opt['group']

        d = threads.deferToThread(db.query_metric_presence, start, end, group)
        d.addCallback(self.respond)

    def metric_summary (self, opt):
        start = opt['start']
        end = opt['end']
        group = opt['group']

        d = threads.deferToThread(db.query_metric_summary, start, end, group)
        d.addCallback(self.respond)

    def top_devices (self, opt):
        start = opt['start']
        end = opt['end']
        resample_period = opt['resample_period']
        device_type_l = opt['device_type_l']
        device_filter = opt['device_filter']
        device_group = opt['device_group']
        nugget_name = opt['nugget']
        n = opt['n']

        d = threads.deferToThread(db.top_devices, start, end, device_type_l, nugget_name,
                                  device_filter=device_filter, device_group=device_group,
                                  n=n, resample_period=resample_period)
        d.addCallback(self.respond)

    def bulk_insert (self, opt):
        sample_l = opt['sample_l']
        reactor.callInThread(db.bulk_insert, sample_l)
        return json.dumps(True)

    def log_insert (self, opt):
        log_data = opt['log_data']
        reactor.callInThread(db.log_insert, log_data)
        return json.dumps(True)

    def diff_insert (self, opt):
        log_data = opt['diff_data']
        reactor.callInThread(db.diff_insert, log_data)
        return json.dumps(True)

    def nf_insert (self, opt):
        timestamp = opt['timestamp']
        field = opt['field']
        data_l = opt['data']
        reactor.callInThread(db.nf_insert, field, timestamp, data_l)
        return json.dumps(True)

    def syslog_insert (self, opt):
        reactor.callInThread(db.syslog_insert, opt)
        return json.dumps(True)

    def snmptrap_insert (self, opt):
        snmptrap_data = opt['trap_data']
        reactor.callInThread(db.snmptrap_insert, snmptrap_data)
        return json.dumps(True)

    def client_report (self, opt):
        timestamp = opt['timestamp']
        client_l = opt['client_l']
        reactor.callInThread(db.client_report_insert, timestamp, client_l)
        return json.dumps(True)

    def send_report (self, opt):
        reactor.callInThread(db.send_report, opt)
        return json.dumps(True)

    def nugget_cfg (self, opt):
        reactor.callInThread(db.nugget_cfg, opt)
        return json.dumps(True)

class DBManager (object):

    def __init__ (self, set_global=False):
        if set_global:
            global db
            db = self

        self.log_q = Queue()
        self.pool = None
        self.main_db = None
        self.db_d = {}
        self.db_l = []
        self.db_status_d = {}
        self.metric_db_l = []
        self.log_db_l = []
        self.syslog_db_l = []
        self.snmptrap_db_l = []
        self.write_rate = 0
        self.device_list_t = None

        self.init_db()

        self.metric_db = self.metric_db_l[0]
        self.log_db = self.log_db_l[0]
        self.nugget_cfg_d = {}
        # needed to find db_index
        self.device_d = {}
        self.device_ip_d = {}

        # initialize the main DB directory
        self.dir = self.main_db.dir

        now = int(time.time())
        self.tstamp_d = {
            'start': now,
            'get_device_list': 0,
            'update_db_status': 0,
        }

    def init_db (self):
        from .PostgreSQL import PostgreSQL
        from .JSONStream import JSONStream
        from .RedisStream import RedisStream
        from .FileSystemDB import FileSystem
        from .Splunk import Splunk
        from .ElasticSearch import ElasticSearch

        object_map = {
            'local': PostgreSQL,
            'postgresql': PostgreSQL,
            'postgres': PostgreSQL,
            'splunk': Splunk,
            'redis': RedisStream,
            'json': JSONStream,
            'json_db': JSONStream,
            'elasticsearch': ElasticSearch,
            'filesystem': FileSystem
        }

        main_db_str_l = ['local']
        metric_db_str_l = []
        log_db_str_l = []
        syslog_db_str_l = []
        snmptrap_db_str_l = []

        if cfg.datastore:
            metric_db_str_l = [x for x in cfg.datastore.lower().replace(' ', '').split(',')
                               if x in object_map]
        elif cfg.metric_db:
            metric_db_str_l = [x for x in cfg.metric_db.lower().replace(' ', '').split(',')
                               if x in object_map]
        if cfg.log_db:
            log_db_str_l = [x for x in cfg.log_db.lower().replace(' ', '').split(',')
                            if x in object_map]
        if cfg.syslog_db:
            syslog_db_str_l = [x for x in cfg.syslog_db.lower().replace(' ', '').split(',')
                               if x in object_map]
        if cfg.snmptrap_db:
            snmptrap_db_str_l = [x for x in cfg.snmptrap_db.lower().replace(' ', '').split(',')
                                 if x in object_map]

        db_str_l = set(main_db_str_l + metric_db_str_l + log_db_str_l + syslog_db_str_l + snmptrap_db_str_l)

        # init the the db objects
        for db_str in db_str_l:
            try:
                function = object_map[db_str]
            except KeyError: continue

            db = function()
            self.db_d[db_str] = db

        # the complete list of DBs
        self.db_l = list(self.db_d.values())
        # set the main DB
        self.main_db = self.db_d[main_db_str_l[0]]
        # set the metric DB list
        for db_str in metric_db_str_l:
            self.metric_db_l.append(self.db_d[db_str])
        # set the log DB list
        for db_str in log_db_str_l:
            self.log_db_l.append(self.db_d[db_str])
        # set the syslog DB list
        for db_str in syslog_db_str_l:
            self.syslog_db_l.append(self.db_d[db_str])
        # set the snmptrap DB list
        for db_str in snmptrap_db_str_l:
            self.snmptrap_db_l.append(self.db_d[db_str])

    def monitor (self):
        now = int(time.time())

        # update device list
        if now - self.tstamp_d['get_device_list'] >= 60:
            self.get_device_list()
            self.tstamp_d['get_device_list'] = now

        # update device list
        if now - self.tstamp_d['update_db_status'] >= 10:
            self.update_db_status()
            self.tstamp_d['update_db_status'] = now

        health = {}
        health['uptime_seconds'] = now - self.tstamp_d['start']
        redis.set('%s.db.health' % cfg.tool_name, json.dumps(health).encode(), ex=(self.monitor_t.interval * 2))

    def update_db_status (self):
        store = False
        for db_name, db_obj in self.db_d.items():
            status = db_obj.status
            if status != self.db_status_d.get(db_name):
                store = True
            self.db_status_d[db_name] = status

        if store:
            redis.set("%s.db_status" % cfg.tool_name, json.dumps(self.db_status_d).encode())

    def get_device_list (self):
        try:
            # read from redis
            self.device_d.update(json.loads(redis.get("device_d").decode()))
            self.device_d.update(json.loads(redis.get("vdevice_d").decode()))

            for device in self.device_d.values():
                self.device_ip_d[device['ip_address']] = device
        except (TypeError, AttributeError):
            pass

    def get_nugget_cfg (self):
        try:
            # read from redis
            self.nugget_cfg_d = json.loads(redis.get("nugget_cfg_d").decode())
        except (TypeError, AttributeError):
            pass

    def add_to_device_list (self, host):
        d = Device(host)
        d.ip_address = host
        d.set_groups()
        self.device_d[host] = self.device_ip_d[host] = d.get_device_d()
        return host

    def start (self):
        # disable system proxies
        try:
            del os.environ['http_proxy']
            del os.environ['https_proxy']
        except KeyError: pass

        # start the monitor thread
        # Poll the poller device list
        self.monitor_t = PeriodicThread(name="DB/monitor",
                                        interval=10,
                                        action=self.monitor,
                                        daemon=True)
        self.monitor_t.start()

        # get the nugget_cfg_d
        self.get_nugget_cfg()

        # start the log consumer
        log.start()

        # start databases
        for db in self.db_l:
            if hasattr(db, 'start'):
                Thread(target=db.start).start()

    def stop (self):
        # stop the device list update thread
        if self.device_list_t:
            self.device_list_t.stop()

        for db in self.db_l:
            if hasattr(db, 'stop'):
                Thread(target=db.stop).start()

################################################################################
# Write Functions
################################################################################

    def nugget_cfg (self, data):
        # update our cached version
        self.nugget_cfg_d.update(data)

        # send to output modules
        for db in self.metric_db_l:
            if hasattr(db, 'nugget_cfg'):
                return db.nugget_cfg(data)

    def send_report (self, report_d):
        for db in self.metric_db_l:
            if hasattr(db, 'send_report'):
                return db.send_report(report_d)

    def client_report_insert (self, timestamp, client_l):
        for db in self.metric_db_l:
            if hasattr(db, 'client_report_insert'):
                return db.client_report_insert(timestamp, client_l)

    def log_insert (self, log_data):
        if log.log_type_name[log_data[4]] == "system":
            self.main_db.log_insert(log_data)
        else:
            for db in self.log_db_l:
                db.log_insert(log_data)

    def diff_insert (self, data):
        for db in self.log_db_l:
            if hasattr(db, 'diff_insert'):
                db.diff_insert(data)

    def nf_insert (self, field, timestamp, data_l):
        for db in self.log_db_l:
            if hasattr(db, 'nf_insert'):
                db.nf_insert(field, timestamp, data_l)

    def syslog_insert (self, log_data):
        for db in self.syslog_db_l:
            if hasattr(db, 'syslog_insert'):
                db.syslog_insert(log_data)

    def snmptrap_insert (self, snmptrap_data):
        for db in self.snmptrap_db_l:
            if hasattr(db, 'snmptrap_insert'):
                db.snmptrap_insert(snmptrap_data)

    def bulk_insert (self, sample_l):
        """
        bulk insert a list of samples
        sample format: (timestamp, device_name, nugget_name, value)
        """

        start_t = time.time()
        for db in self.metric_db_l:
            db.bulk_insert(sample_l)

        # take stats
        delta = time.time() - start_t
        self.write_rate = (len(sample_l))/ delta

################################################################################
# Read Functions
################################################################################
    def query_logs (self, start, end, fields, type=None, sev=None, sev_gte=None,
                    group=None, device_name=None, nugget_name=None):
        return self.log_db.query_logs(start, end, fields, type=type, sev=sev, sev_gte=sev_gte,
                                      group=group, device_name=device_name, nugget_name=nugget_name)

    def query_metric (self, start, end, filter_d):
        return self.metric_db.query_metric(start, end, filter_d)

    def query_series (self, start, end, device_name, nugget_name):
        return self.metric_db.query_series(start, end, device_name, nugget_name)

    def query_metric_presence (self, start, end, group=None):
        for db in self.metric_db_l:
            if hasattr(db, 'query_metric_presence'):
                return db.query_metric_presence(start, end, group)

    def query_metric_summary (self, start, end, group):
        return self.metric_db.query_metric_summary(start, end, group)

    def top_devices (self, start, end, device_type_l, nugget_name,
                     device_filter=None, device_group=None, n=0, resample_period=0):
        return self.metric_db.top_devices(start, end, device_type_l, nugget_name,
                                           device_filter, device_group, n, resample_period)

    def series_data (self, start, end, device_name, nugget_name, resample_period):
        try:
            return self.metric_db.series_data(start, end, device_name, nugget_name, resample_period)
        except AttributeError as e:
            log.error("Backend does not support retrieval of series data: %s" % self.metric_db, "system")

    def series_summary (self, start, end, device_name, nugget_name):
        try:
            return self.metric_db.series_summary(device_name, nugget_name, start, end)
        except AttributeError:
            log.error("Backend does not support summary of series data: %s" % self.metric_db, "system")

################################################################################
# Maintenence Functions
################################################################################

    def hourly_agg (self):
        for db in self.metric_db_l:
            if hasattr(db, 'hourly_agg'):
                Thread(target=db.hourly_agg).start()

    def maintenance (self):
        log.debug("DB Maintenance")
        for db in self.db_l:
            if hasattr(db, 'maintenance'):
                Thread(target=db.maintenance).start()

################################################################################
# Misc Functions
################################################################################
    def backup (self, span_l, event_l):
        try:
            self.metric_db.backup(span_l, event_l)
        except AttributeError:
            log.error("Backend does not support backup: %s" % self.metric_db, "system")

    def restore (self, filepath, jobs):
        try:
            return self.metric_db.restore(filepath, jobs)
        except AttributeError:
            log.error("Backend does not support restore: %s" % self.metric_db, "system")

    def clear_logs (self):
        if hasattr(db, 'clear_logs'):
            self.metric_db.clear_logs()

    def clear_data (self):
        if hasattr(db, 'clear_data'):
            self.metric_db.clear_data()

    def clear_db (self):
        if hasattr(db, 'clear_db'):
            self.metric_db.clear_db()

    def add_device (self, device):
        return self.main_db.add_device(device)

    def get_device (self, name = "", id = ""):
        return self.main_db.get_device(name=name, id=id)

    def get_nugget (self, name = "", id = ""):
        return self.main_db.get_nugget(name=name, id=id)

    def get_disk_usage (self):
        return self.main_db.get_disk_usage()

class DBObject (object):
    def __init__ (self):
        self.status = None

    def __repr__(self):
        return type(self).__name__

    def series_data (self, start, end, device_name, nugget_name, resample_period):
        """ return a [resampled] time-series """
        # hourly time
        if resample_period >= 3600 and hasattr(self, 'query_series_hr'):
            return self.series_data_hr(start, end, device_name, nugget_name, resample_period)
        else:
            return self.series_data_raw(start, end, device_name, nugget_name, resample_period)

    def series_data_raw (self, start, end, device_name, nugget_name, resample_period):
        """ return a full-resolution series """
        ret = {}
        # query_start_time = time.time() * 1000

        # see if we can get the data from the ram buffer
        values = []
        trace = None
        now = time.time()
        if start > (now - cfg.data_buffer_duration):
            values = get_series_buffer(device_name, nugget_name)
        elif end > utility.epoch_to_hour(now):
            trace = get_series_trace(device_name, nugget_name)

        # otherwise, we'll have to go to the DB
        if not values:
            values = self.query_series(start, end, device_name, nugget_name)

        # add the ram-loaded trace point
        if trace:
            values.append(trace)

        # empty buffer
        if not values: return None

        # decode the series into a DF
        # df_start_time = time.time() * 1000
        df = decodeSeries(values, start, end).to_frame()

        # empty dataframe
        if df.empty: return None

        # process_start_time = time.time() * 1000

        #
        # calculate summary values
        ret['min'] = round(df[0].min(), 2)
        ret['max'] = round(df[0].max(), 2)
        ret['avg'] = round(df[0].mean(), 2)
        ret['start'] = start * 1000
        ret['end'] = end * 1000
        ret['count'] = len(df.index)
        ret['period'] = max(resample_period, cfg.series_decode_period)
        ret['resample_period'] = resample_period

        #
        # resample based on resample_period
        df_final = None
        if resample_period > cfg.series_decode_period:
            # first, get the mean
            try:
                #df_final = df.resample('%ss' % resample_period, how=[np.mean, np.min, np.max])
                df_final = df.resample('%ss' % resample_period).agg([np.mean, np.min, np.max])
                # place the timestamp back into a column
                df_final = df_final.reset_index()
                df_final.columns = ['timestamp', 'avg', 'min', 'max']
            except Exception as e:
                return False
        else:
            # use the original df...no resampling
            df_final = df.reset_index()
            # Levy: this is dumb
            df_final['min'] = df_final[0]
            df_final['max'] = df_final[0]
            df_final.columns = ['timestamp', 'avg', 'min', 'max']

        # empty buffer
        if df_final is None or df_final.empty:
            return None

        # convert the dataframe to a json string
        data_json = df_final.to_json(orient='values', double_precision=2)

        # Create the JSON object to return. We need to do some string manipulation here.
        ret_json = json.dumps(ret)[:-1] # remove the closing brace of the JSON string
        ret_json += ', "data": %s}' % data_json # add in the data JSON we created above

        # end_time = time.time() * 1000

        # if cfg.query_debug:
        #     log.debug ("Series Data: query/df/process/total: %s/%s/%s/%s [%s]" %
        #                (int(df_start_time - query_start_time),
        #                 int(process_start_time - df_start_time),
        #                 int(end_time - process_start_time),
        #                 int(end_time - query_start_time), self
        #             ))

        return ret_json

    def series_data_hr (self, start, end, device_name, nugget_name, resample_period):
        """ return series data from the hourly table when resample_period is large """

        ret = {}

        # query_start_time = time.time() * 1000

        # query the DB
        values = self.query_series_hr(start, end, device_name, nugget_name)

        # empty buffer
        if not values:
            return None

        # df_start_time = time.time() * 1000

        # split into lists
        timestamp_l, avg_l, min_l, max_l = list(zip(*values))

        # put data into dataframe
        df = pd.DataFrame(list(zip(avg_l, min_l, max_l)), index=timestamp_l, columns=['avg', 'min', 'max'])

        #
        # calculate summary values
        ret['min'] = round(df['min'].min(), 2)
        ret['max'] = round(df['max'].max(), 2)
        ret['avg'] = round(df['avg'].mean(), 2)
        ret['start'] = start * 1000
        ret['end'] = end * 1000
        ret['count'] = len(df.index)
        ret['period'] = max(resample_period, cfg.series_decode_period)
        ret['resample_period'] = resample_period

        # resample_start_time = time.time() * 1000
        try:
            #df_final = df.resample('%ss' % resample_period, how={'avg': np.mean, 'min': np.min, 'max': np.max})[df.columns]
            df_final = df.resample('%ss' % resample_period).agg({'avg': np.mean, 'min': np.min, 'max': np.max})[df.columns]

            # place the timestamp back into a column
            df_final = df_final.reset_index()

            # name the columns
            df_final.columns = ['timestamp', 'avg', 'min', 'max']
        except Exception as e:
            return False

        # empty buffer
        if df_final is None or df_final.empty:
            return None

        # convert the dataframe to a json string
        data_json = df_final.to_json(orient='values', double_precision=2)

        # Create the JSON object to return. We need to do some string manipulation here.
        ret_json = json.dumps(ret)[:-1] # remove the closing brace of the JSON string
        ret_json += ', "data": %s}' % data_json # add in the data JSON we created above

        # end_time = time.time() * 1000
        # if cfg.query_debug:
        #     log.debug("Series Data HR: query/df/resample/total: %s/%s/%s/%s" %
        #               (int(df_start_time - query_start_time),
        #                int(resample_start_time - df_start_time),
        #                int(end_time - resample_start_time),
        #                int(end_time - query_start_time)))

        return ret_json

    def series_summary (self, device_name, nugget_name, start, end):
        """ return min/max/avg for a specific series """

        query_start_time = time.time() * 1000

        # see if we can get the data from the ram buffer
        values = None
        trace = None
        now = time.time()
        if start > (now - cfg.data_buffer_duration):
            values = get_series_buffer(device_name, nugget_name)
        elif end > utility.epoch_to_hour(now):
            trace = get_series_trace(device_name, nugget_name)

        # otherwise, we'll have to go to the DB
        if not values:
            values = self.query_series(start, end, device_name, nugget_name)

        # add the ram-loaded trace point
        if trace:
            values.append(trace)

        # empty buffer
        if not values:
            return None

        values = sorted(values, key=lambda x: x[0])
        return crunchSeries(values, start, end)

# Maybe these should move elsewhere?
###################################################
def crunchSeries_spans (values, spans):
    avg_sum = 0
    delta_sum = 0
    min_l = []
    max_l = []

    for start, end in spans:
        try:
            _min, _max, _avg = crunchSeries(values, start, end)
        except TypeError: continue

        # number of seconds in the span
        delta = end - start

        # process span results
        avg_sum += _avg * delta
        delta_sum += delta
        min_l.append(_min)
        max_l.append(_max)

    # calculate total results
    try:
        _avg = avg_sum / delta_sum
        _min = min(min_l)
        _max = max(max_l)
    except ZeroDivisionError:
        return None

    return (_min, _max, _avg)

def crunchSeries (values, start, end):
    # # levy: delete this after fixing
    # prev_timestamp = 0
    # for timestamp, value in values:
    #     if timestamp < prev_timestamp:
    #         print("out of order! (%s, %s)" % (prev_timestamp, timestamp))
    #     prev_timestamp = timestamp

    # add null to the end of the span (just in case we're tracing the end point
    # and it doesn't show up in the DB)
    values = values + [[end, None]]

    # calculate average
    prev_timestamp = 0
    prev_value = None
    avg_sum = 0
    delta_sum = 0
    values_in_span = set()
    for timestamp, value in values:
        if timestamp > start and prev_timestamp < end:
            if prev_timestamp < start:
                prev_timestamp = start

            if timestamp > end:
                timestamp = end

            if prev_value is not None:
                delta = (timestamp - prev_timestamp)
                avg_sum += prev_value * delta
                delta_sum += delta
                values_in_span.add(prev_value)

        prev_timestamp = timestamp
        prev_value = value

    try:
        _avg = avg_sum / delta_sum
    except ZeroDivisionError:
        return None

    # calculate min/max
    _min = min(values_in_span)
    _max = max(values_in_span)

    return (_min, _max, _avg)

def crunchSeries_spans2 (values, spans):
    avg_sum = 0
    delta_sum = 0
    min_l = []
    max_l = []

    for start, end in spans:
        try:
            _min, _max, _avg = crunchSeries2(values, start, end)
        except TypeError: continue

        # number of seconds in the span
        delta = end - start

        # process span results
        avg_sum += _avg * delta
        delta_sum += delta
        min_l.append(_min)
        max_l.append(_max)

    # calculate total results
    try:
        _avg = avg_sum / delta_sum
        _min = min(min_l)
        _max = max(max_l)
    except ZeroDivisionError:
        return None

    return (_min, _max, _avg)

def crunchSeries2 (values, start, end):
    start = utility.epoch_to_datetime(start)
    end = utility.epoch_to_datetime(end)

    # add null to the end of the span (just in case we're tracing the end point
    # and it doesn't show up in the DB)
    values = values + [[end, None]]

    # calculate average
    prev_timestamp = utility.epoch_to_datetime(0)
    prev_value = None
    avg_sum = 0
    delta_sum = 0
    values_in_span = set()
    for timestamp, value in values:
        if timestamp > start and prev_timestamp < end:
            if prev_timestamp < start:
                prev_timestamp = start

            if timestamp > end:
                timestamp = end

            if prev_value is not None:
                delta = (timestamp - prev_timestamp).total_seconds()
                avg_sum += prev_value * delta
                delta_sum += delta
                values_in_span.add(prev_value)

        prev_timestamp = timestamp
        prev_value = value

    try:
        _avg = avg_sum / delta_sum
    except ZeroDivisionError:
        return None

    # calculate min/max
    _min = min(values_in_span)
    _max = max(values_in_span)

    return (_min, _max, _avg)

def decodeSeries (values, start, end, period=None):
    now = int(time.time())
    if not period:
        period = cfg.series_decode_period

    # extend the values to the end
    last_timestamp = values[-1][0]
    if last_timestamp < end:
        if utility.epoch_to_hour(end) < utility.epoch_to_hour(now):
            end_timestamp = utility.epoch_to_hour(last_timestamp, next=True)
            values.append([end_timestamp, None])

    # split into lists
    timestamp_l, value_l = list(zip(*values))
    timestamp_l = pd.to_datetime(timestamp_l, unit='s', utc=True)

    # create a dataframe from the queryset
    ds = pd.Series(value_l, index=timestamp_l)
    #ds.sort(inplace=True)
    ds.fillna(-np.inf, inplace=True)

    #ds = ds.resample('%ss' % period, how='last', fill_method="ffill", limit=(3600//period - 1))
    ds = ds.resample('%ss' % period).last().ffill(limit=(3600//period - 1))
    ds.replace(-np.inf, np.nan, inplace=True)

    # trim down to original timespan
    start = utility.epoch_to_datetime(start)
    end = utility.epoch_to_datetime(end)
    if timestamp_l[0] < start or timestamp_l[-1] > end:
        ds = ds[(ds.index >= start) & (ds.index <= end)]
        #ds = ds[start_dt:end_dt] #LEVY: this method is empirically slower

    # for timestamp, value in values:
    #     #print(timestamp.strftime("%H:%M:%S"), value)
    #     if timestamp >= start_dt and timestamp <= end_dt:
    #         print(timestamp.strftime("%H:%M:%S"), value)

    return ds

def get_leftover_spans (start, end, hourstamps, datetime=True):
    # convert hourstamps to epoch
    if datetime:
        hourstamps = [utility.datetime_to_epoch(x) for x in hourstamps]

    # only consider hourstamps applicable to the range
    hourstamps = [x for x in hourstamps if utility.epoch_to_hour(start) <= x < end]

    if not hourstamps:
        return [(start, end)]

    hourstamps.sort()
    first_hourstamp = hourstamps[0]
    last_hourstamp = hourstamps[-1]

    # find the spans to check in the raw sample table
    # we know we need spans before and after the hourstamps
    spans = []
    if start < (first_hourstamp - 1):
        spans.append((start, first_hourstamp))
    if end > (last_hourstamp + 3600):
        spans.append((last_hourstamp + 3600, end))

    # see if an interior block is missing
    x = first_hourstamp
    s = e = None
    while (x < last_hourstamp and x < end):
        if x not in hourstamps:
            if not s:
                s = x
            e = x + 3600
        else:
            if s:
                spans.append((s, e))
            s = e = None
        x += 3600

    return spans

def get_series_trace (device_name, nugget_name):
    query = {
        'name' : "series_trace",
        'options' : {
            'device_name' : device_name,
            'nugget_name' : nugget_name,
            }
        }

    trace = None
    try:
        trace = json.loads(utility.poller_query(query))
        #if trace:
            # convert the timestamp
            #trace[0] = utility.epoch_to_datetime(trace[0])
    except ValueError: pass

    return trace

def get_series_buffer (device_name, nugget_name):
    query = {
        'name' : "series_buffer",
        'options' : {
            'device_name' : device_name,
            'nugget_name' : nugget_name,
            }
        }

    values = None
    try:
        # get the raw table
        values = json.loads(utility.poller_query(query))
        # remove null entries
        values = [x for x in values if x is not None]
        # convert timestamps to datetime
        #values = [[utility.epoch_to_datetime(x),y] for x,y in values]
    except: pass

    return values
