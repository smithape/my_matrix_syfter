from django.contrib.postgres.fields import JSONField, ArrayField
from django.db import models
import architect

from . import fields

class Device (models.Model):
    name = models.TextField(unique=True)
    type = models.TextField()
    ip_address = models.GenericIPAddressField(null=True)
    group_l = ArrayField(models.TextField(), default=list)

    def __unicode__(self):
        return self.name

    class Meta:
        db_table = 'mtx_device'

class Nugget (models.Model):
    name = models.TextField(unique=True)

    def __unicode__(self):
        return self.name

    class Meta:
        db_table = 'mtx_nugget'

class Config (models.Model):
    name = models.TextField(unique=True)
    text = models.TextField(null=True, default="")
    class Meta:
        db_table = 'mtx_config'

class State (models.Model):
    timestamp = models.DateTimeField()
    name = models.TextField(unique=True)
    value = models.TextField(null=True)
    data = JSONField(null=True)
    class Meta:
        db_table = 'mtx_state'

@architect.install('partition', type='range', subtype='date', constraint='week', column='timestamp')
class Log (models.Model):
    id = fields.BigAutoField(primary_key=True)
    timestamp = models.DateTimeField(db_index=True)
    type = models.SmallIntegerField()
    severity = models.SmallIntegerField()
    device = models.ForeignKey(Device, null=True, on_delete=models.CASCADE)
    nugget = models.ForeignKey(Nugget, null=True, on_delete=models.CASCADE)
    message = models.TextField(null=True)

    class Meta:
        db_table = 'mtx_log'
        #index_together = [["device", "nugget", "timestamp"]]

@architect.install('partition', type='range', subtype='date', constraint='day', column='timestamp')
class SampleHourly (models.Model):
    id = models.BigIntegerField(primary_key=True)
    timestamp = models.DateTimeField(db_index=True)
    device = models.ForeignKey(Device, db_index=False, on_delete=models.CASCADE)
    nugget = models.ForeignKey(Nugget, on_delete=models.CASCADE)
    avg = models.FloatField();
    min = fields.SmallFloatField();
    max = fields.SmallFloatField();
    data = JSONField(null=True)

    def __unicode__(self):
        return self.device, self.nugget, self.timestamp

    class Meta:
        db_table = 'mtx_samplehr'
        index_together = [["device", "nugget", "timestamp"]]

class Event (models.Model):
    name = models.TextField(null=True)
    group = models.TextField(null=True)
    start_timestamp = models.PositiveIntegerField(db_index=True)
    end_timestamp = models.PositiveIntegerField(db_index=True, null=True)
    data = models.TextField()

    class Meta:
        db_table = 'mtx_event'
