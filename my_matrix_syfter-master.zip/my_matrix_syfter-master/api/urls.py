from django.urls import path

from . import views

urlpatterns = [
    # data
    path('latest_value/<str:device_name>/<str:nugget_name>/',
        views.latest_value, name='api.latest_value'),
    path('series/<str:device_name>/<str:nugget_name>/<int:start>/<int:end>/',
        views.series_data, name='api.series'),
    path('conditions/<slug:_type>/', views.conditions, name='api.conditions_type'),
    path('conditions/', views.conditions, name='api.conditions'),
    path('metric_summary/<int:start>/<int:end>/', views.metric_summary, name='api.metric_summary'),
    path('metric_presence/', views.metric_presence, name='api.metric_presence'),
    path('metric_presence/<int:start>/<int:end>/', views.metric_presence_span, name='api.metric_presence_span'),
    path('top_devices/<str:nugget_name>/', views.top_devices, name='api.top_devices'),
    path('top_devices/<str:nugget_name>/<int:start>/<slug:end>/',
        views.top_devices_span, name='api.top_devices_span'),
    path('logs/<int:start>/<int:end>/', views.logs, name='api.logs'),
    # event
    path('event/', views.event_list, name='api.event_list'),
    path('event/<int:event_id>/', views.event, name='api.event'),
    path('event/save/', views.event_save, name='api.event_save'),
    path('event/delete/<int:event_id>/', views.event_delete, name='api.event_delete'),
    path('event/name/<int:event_id>/', views.event_name, name='api.event_name'),
    path('event_status/', views.event_status, name='api.event_status'),
    # info
    path('build_date/', views.build_date, name='api.build_date'),
    path('license_info/', views.license_info, name='api.license_info'),
    path('system_status/', views.system_status, name='api.system_status'),
    # misc
    path('send_report/<int:start>/<int:end>/', views.send_report, name='api.send_report'),
    path('config/', views.config, name='api.config'),
    path('cloudNuggetList/', views.cloudNuggetList, name='api.cloudNuggetList'), # deprecated
    path('config_text/', views.config_text, name='api.config_text'),
    path('config_file/<slug:config_name>/', views.config_file, name='api.config_file'),
    path('config_save/', views.config_save, name='api.config_save'),
    path('poller_control/<slug:action>/', views.poller_control, name='api.poller_control'),
    path('poller_status/', views.poller_status, name='api.poller_status'),
    path('poller_stats/', views.poller_stats, name='api.poller_stats'),
    path('health_check/', views.health_check, name='api.health_check'),
    path('group_list/', views.group_list, name='api.group_list'),
    path('device_list/', views.device_list, name='api.device_list'),
    path('client_list/', views.client_list, name='api.client_list'),
    path('client_count/', views.client_count, name='api.client_count'),
    path('device_status/<str:device_name>/', views.device_status, name='api.device_status'),
    path('test/<slug:test>/<str:device_name>/', views.test, name='api.test'),
    path('term/<str:device_name>/', views.terminal, name='api.term'),
    path('license_check/<slug:key>/', views.license_check, name='api.license_check'),
    # public APIs
    path('nugget_poll/<str:device_name>/<str:nugget_name>/', views.nugget_poll, name='api.nugget_poll'),
]
