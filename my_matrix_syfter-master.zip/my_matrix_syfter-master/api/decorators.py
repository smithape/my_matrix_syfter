import base64
from functools import wraps
from django.http import HttpResponse
from django.contrib.auth import authenticate, login

def check_auth (view, request, test_fn, realm = "", *args, **kwargs):
    """
    This is a helper function used by both 'logged_in_or_basicauth' and
    'has_perm_or_basicauth' that does the nitty of determining if they
    are already logged in or if they have provided proper http-authorization
    and returning the view if all goes well, otherwise responding with a 401.
    """
    # if already logged in, just return the view
    if test_fn(request.user):
        return view(request, *args, **kwargs)

    # See if they provided login credentials
    if 'HTTP_AUTHORIZATION' in request.META:
        auth_method, auth = request.META['HTTP_AUTHORIZATION'].split()
        # NOTE: We are only support basic authentication for now.
        if auth_method.lower() == 'basic':
            auth = base64.b64decode(auth.strip()).decode()
            username, password = auth.split(':')
            user = authenticate(username=username, password=password)
            if user and user.is_active:
                login(request, user)
                request.user = user
                return view(request, *args, **kwargs)

    # Auth failed, send a challenge
    response = HttpResponse()
    response.status_code = 401
    response['WWW-Authenticate'] = 'Basic realm="%s"' % realm
    return response

def login_or_basicauth_required (realm = ""):
    """
    A simple decorator that requires a user to be logged in. If they are not
    logged in the request is examined for a 'authorization' header.

    @login_or_basicauth_required(realm)
    def your_view:
        ...

    """

    #@wraps(fn)
    def _decorator(fn):
        def wrapper(request, *args, **kwargs):
            return check_auth(fn, request,
                              lambda u: u.is_authenticated,
                              realm, *args, **kwargs)
        return wrapper
    return _decorator
