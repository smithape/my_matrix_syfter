import traceback
import os, time
from collections import OrderedDict
import multiprocessing
import pickle
import json
from subprocess import getstatusoutput
import re

from django.http import HttpResponse, FileResponse
from django.contrib.auth.decorators import user_passes_test
import psutil
import numpy as np
import pandas as pd
import yaml
try:
    from yaml import CLoader as Loader, CDumper as Dumper
except ImportError:
    from yaml import Loader, Dumper

from nugget import Nugget
from common.utility import termserver_query, poller_query, db_query
from common.models import \
    Event as Event_db
from common.http import json_response
from common import \
    config as cfg, \
    utility, \
    DB, \
    Event, \
    logger as log, \
    License as lic, \
    Report, \
    Splunk, \
    ElasticSearch

from .decorators import login_or_basicauth_required

def decode (arg):
    return arg.replace("__", "/")

realm = "%s.api" % cfg.tool_name

@login_or_basicauth_required(realm)
def build_date (request):
    return json_response(utility.get_build_date() * 1000)

@login_or_basicauth_required(realm)
def license_info (request):
    return json_response(json.dumps(lic.get_license_info()))

@login_or_basicauth_required(realm)
def system_status (request):
    GB = 1073741824
    ret = {}

    cpu_count = multiprocessing.cpu_count()
    cpu_tuple = os.getloadavg()
    ret['cpu'] = {
        'count': cpu_count,
        'usage_1m': (cpu_tuple[0] / cpu_count) * 100,
        'usage_5m': (cpu_tuple[1] / cpu_count) * 100,
        'usage_15m': (cpu_tuple[2] / cpu_count) * 100
        }


    mem_tuple = psutil.virtual_memory()
    ret['memory'] = {
        'usage': mem_tuple.percent,
        'total': mem_tuple.total / GB,
        'used': (mem_tuple.total - mem_tuple.available) / GB,
        'free': mem_tuple.available / GB
        }

    disk_tuple = psutil.disk_usage(DB.db.dir)
    ret['disk'] = {
        'usage': disk_tuple.percent,
        'total': disk_tuple.total / GB,
        'used': disk_tuple.used / GB,
        'free': disk_tuple.free / GB
        }

    db_tuple = DB.db.get_disk_usage()
    ret['db'] = {
        'total': db_tuple[0] / GB,
        'table': db_tuple[1] / GB,
        'index': db_tuple[2] / GB
        }

    for a,b in ret.items():
        for x,y in b.items():
            b[x] = round(y, 2)

    return json_response(json.dumps(ret))

@login_or_basicauth_required(realm)
def event_list (request):
    event_l = Event.get_all()
    # convert timestamps to ms
    for x in event_l:
        x['start_timestamp'] = x['start_timestamp'] * 1000
        x['end_timestamp'] = x['end_timestamp'] * 1000

    response = {'event_l': event_l}
    return json_response(response)

@login_or_basicauth_required(realm)
def event (request, event_id):
    return json_response(Event.get(event_id))

@login_or_basicauth_required(realm)
def event_save (request):
    if request.method == 'POST':
        event = json.loads(request.POST['data'])
        e = Event.save_event(event)
        e['start_timestamp'] = e['start_timestamp'] * 1000
        e['end_timestamp'] = e['end_timestamp'] * 1000
        return json_response(e)

@login_or_basicauth_required(realm)
def event_name (request, event_id):
    if request.method == 'POST':
        name = request.POST['name']
        return json_response(Event.name_event(event_id, name))

@login_or_basicauth_required(realm)
def event_delete (request, event_id):
    if request.method == 'POST':
        return json_response(Event.delete(event_id))

@login_or_basicauth_required(realm)
def config (request):
    response = {}

    response['config'] = {}
    response['nugget'] = {}

    #
    # group list
    response['group_l'] = json.loads(DB.redis.get("group_l").decode())

    # device types for Nugget config
    cfg.read_config()
    cfg.set_device_type_dictionary()
    response['config']['dtype_hard_l'] = cfg.device_type_hard_l
    response['config']['dtype_l'] = cfg.device_type_l
    response['config']['dtype_d'] = cfg.device_type_d
    response['config']['dtype_path_d'] = cfg.device_type_path_d

    # get the config text
    if request.user.is_superuser:
        response['cfg_before'] = response['cfg_after'] = get_config_text()

    # get the tool config
    current_tool_cfg = cfg.tool_cfg_opts.copy()
    current_tool_cfg.update(cfg.get_config_yaml("tool"))
    response['config']['tool'] = current_tool_cfg

    # Nuggets for cloud use
    response['nugget']['cloud'] = list(Nugget.getNuggetByFlag('Cloud').keys())

    # build the datatype dictionary
    unit_d = {}
    for dtype in Nugget.nugget_config:
        for nugget_name, nugget_cfg in Nugget.nugget_config[dtype].items():
            if nugget_cfg.get('datatype') == 'time_series' and nugget_cfg.get('unit'):
                for category, unit_cfg in Nugget.unit_cfg.items():
                    try:
                        unit = unit_cfg[nugget_cfg['unit']]
                        unit_d[nugget_name] = unit
                        if 'alias' in nugget_cfg:
                            unit_d[nugget_cfg['alias']] = unit
                        break
                    except KeyError: continue

    response['nugget']['unit_d'] = unit_d
    response['nugget']['unit_cfg'] = Nugget.unit_cfg

    # build the polling interval dictionary
    # response['nugget']['polling_interval_d'] = cfg.get_polling_interval_d()

    # global nugget
    if cfg.global_throughput:
        device, nugget = cfg.global_throughput.split('/', 1)
    else:
        device = None
        nugget = "ethThroughput"

    response['nugget']['global'] = {
        'throughput' : {
            'device' : device,
            'nugget': nugget
        }
    }

    response['sev_map'] = log.sev_name
    response['user_is_admin'] = request.user.is_superuser

    # set the default span
    response['span_start'] = cfg.default_span_start
    response['span_end'] = cfg.default_span_end

    # if event is occurring, change the timespan
    try:
        event_status = json.loads(poller_query({'name' : "event_status"}))
        event_status = event_status['AP']
        if event_status['state'] in ['on', 'stopping']:
            response['span_start'] = event_status['start_time']
    except (KeyError, ValueError): pass

    return json_response(response)

def cloudNuggetList (request):
    nugget_l = list(Nugget.getNuggetByFlag('Cloud').keys())

    return json_response(nugget_l)

@user_passes_test(lambda u: u.is_staff)
def config_save (request):
    if request.method == "POST":
        config_d = json.loads(request.POST['data'])

        for config_name, config_data in config_d.items():
            try:
                cfg_before = config_data['cfg_before'].replace("\r", "")
                cfg_after = config_data['cfg_after'].replace("\r", "")

                # if nothing changed, move on
                if cfg_before == cfg_after:
                    continue

                # get the current state of the cfg file (it could have changed since we
                # opened it)
                cfg_now = cfg.get_config_text(config_name)

                # unmask passwords?
                if cfg.mask_passwords and config_name in ['site']:
                    decode_d = get_mask_decoder(cfg_now)
                    cfg_before = unmask_passwords(cfg_before, decode_d)
                    cfg_after = unmask_passwords(cfg_after, decode_d)

                # validate the config syntax
                try:
                    test = yaml.full_load(cfg_after)
                except yaml.YAMLError as e:
                    error = "Syntax Error in %s:\r\r%s" % (config_name, e)
                    return HttpResponse(error, status=500)

                if cfg_before == cfg_now:
                    # 3-way merge isn't required
                    cfg_final = cfg_after
                else:
                    # patch the current config
                    try:
                        cfg_final = utility.three_way_merge(cfg_before,
                                                            cfg_after,
                                                            cfg_now)
                    except Exception as e:
                        cfg_final = cfg_after
                        # levy: disabling the errors for now, best effort instead
                        #error = "Merge Error in %s:\r\r%s" % (config_name, e)
                        #return HttpResponse(error, status=500)

                if config_name == "tool":
                    DB.redis.publish("%s.control" % cfg.tool_name, "db restart")

                # write final config
                cfg.save_config_text(config_name, cfg_final)
            except Exception as e:
                return HttpResponse(e, status=404)

        return HttpResponse(status=201)

@user_passes_test(lambda u: u.is_staff)
def config_file (request, config_name):
    config_name = decode(config_name)

    if request.method == 'GET':
        ret = {'text': cfg.get_config_text(config_name)}
        return json_response(ret)

def remove_password_masks (text):
    return re.sub(r'(\n.*(?:password|community)\s*:\s*)(\*\*\d+\*\*)', r'\1', text)

def get_mask_decoder (text):
    return mask_passwords(text, decoder=True)

def mask_passwords (text, decoder=False):
    mask_decode_d = {}
    i = 0
    delta = 0
    for m in re.finditer(r'(\n.*(?:password|community)\s*:[ \t]*)([^\s]+)', text):
        # get the encoded text
        encoded = '**%s**' % i
        # find the start/end indexes of the password
        start = m.start(2) + delta
        end = m.end(2) + delta
        # remember the mapping
        mask_decode_d[encoded] = m.group(2)
        # update the config text
        text = text[0:start] + encoded + text[end:]
        # update delta and i for the next iteration
        delta += len(encoded) - len(m.group(2))
        i += 1

    if decoder:
        return mask_decode_d
    else:
        return text

def unmask_passwords (text, decode_d):
    for key, val in decode_d.items():
        text = text.replace(key, val)

    return text

def get_config_text ():
    ret = {}

    site_config = cfg.get_config_text('site')
    if cfg.mask_passwords:
        site_config = mask_passwords(site_config)

    ret['site'] = site_config
    ret['tool'] = cfg.get_config_text('tool')
    ret['polling'] = cfg.get_config_text('polling')
    ret['device_type'] = cfg.get_config_text('device_type')
    ret['nugget'] = {}

    for dtype in cfg.device_type_l:
        dtype = dtype.strip()
        config_name = "nugget/%s" % dtype
        ret['nugget'][dtype] = cfg.get_config_yaml(config_name)

    return ret

@user_passes_test(lambda u: u.is_staff)
def config_text (request):
    ret = get_config_text()
    return json_response(ret)

@login_or_basicauth_required(realm)
def event_status (request):
    query = {'name' : "event_status"}
    event_status = json.loads(poller_query(query))
    return json_response(event_status)

@user_passes_test(lambda u: u.is_staff)
def poller_control (request, action):
    if request.method == 'POST':
        DB.redis.publish("%s.control" % cfg.tool_name, "poller %s" % action)
        return HttpResponse(status=201)

@login_or_basicauth_required(realm)
def poller_status (request):
    query = {'name' : "status"}
    response = json.loads(poller_query(query))
    db_status = json.loads(DB.redis.get("syfter.db_status").decode())
    response['db_status'] = db_status
    return json_response(response)

@login_or_basicauth_required(realm)
def health_check (request):
    # get system health
    GB = 1073741824
    mem_tuple = psutil.virtual_memory()
    cpu_count = multiprocessing.cpu_count()
    cpu_tuple = os.getloadavg()

    health = {
        'system_health': {
            'cpu': {
                'count': cpu_count,
                'usage_1m': "%s%%" % round((cpu_tuple[0] / cpu_count) * 100, 2),
                'usage_5m': "%s%%" % round((cpu_tuple[1] / cpu_count) * 100, 2),
                'usage_15m': "%s%%" % round((cpu_tuple[2] / cpu_count) * 100, 2),
            },
            'memory': {
                'usage': "%s%%" % round(mem_tuple.percent, 2),
                'total': "%s GB" % round(mem_tuple.total / GB, 2),
                'used': "%s GB" % round((mem_tuple.total - mem_tuple.available) / GB, 2),
                'free': "%s GB" % round(mem_tuple.available / GB, 2),
            }
        },
        'service_health': {}
    }
    # get the service health
    services = ['poller', 'db']
    for x in services:
        try:
            status = DB.redis.get("%s.%s.health" % (cfg.tool_name, x)).decode()
            try:
                status = json.loads(status)
            except: pass
        except:
            status = "down"

        health['service_health'][x] = status

    db_status = json.loads(DB.redis.get("%s.db_status" % cfg.tool_name).decode())
    health['datastore_status'] = db_status
    return json_response(health)

@login_or_basicauth_required(realm)
def poller_stats (request):
    query = {'name' : "stats"}
    return json_response(poller_query(query))

@login_or_basicauth_required(realm)
def group_list (request):
    return json_response(DB.redis.get("group_l"))

@login_or_basicauth_required(realm)
def device_list (request):
    static = group = None
    if 'group' in request.GET:
        group = request.GET['group']
    if 'static' in request.GET:
        static = request.GET['static']

    device_d = json.loads(DB.redis.get("device_d").decode())
    device_by_ip_d = {y['ip_address']:y for x,y in device_d.items()}

    if static:
        cfg.set_device_dictionary()
        static_device_d = {x.name:x.get_device_d() for x in cfg.device_d.values()}
                           #if x.ip_address not in device_by_ip_d}
        device_d.update(static_device_d)

    device_l = [x for x in device_d.values()
                if group is None or group in x['groups']]

    device_l = sorted(device_l, key=lambda x: x['name'])

    # if the poller isn't running, give manaully-configured devices
    if not device_l:
        # re-initialize the config
        cfg.init_config()
        device_l = []
        for device in cfg.devices().values():
            if group is None or group in device.group_d:
                device_l.append(device.get_device_d())

    return json_response(json.dumps(device_l))

@login_or_basicauth_required(realm)
def device_status (request, device_name):
    device_name = decode(device_name)

    query = {
        'name' : "device_status",
        'options' : {
            'device_name' : device_name
            }
        }
    return json_response(poller_query(query))

@login_or_basicauth_required(realm)
def test (request, test, device_name):
    device_name = decode(device_name)

    try:
        # first try the manually-configured devices
        device = cfg.device_d[device_name]
        if test == "snmp":
            if device.snmp:
                device.reload_cfg()
                device.snmp.init_config()
                result = device.snmp.is_up(check=True, quiet=True)
            else:
                result = False
        elif test == "ping":
            result = device.is_pingable()
    except KeyError:
        # go to the polling engine
        query = {
            'name' : "test_%s" % test,
            'options' : {
                'device_name' : device_name
                }
            }
        result = json.loads(poller_query(query))

    response = {'result': result}
    return json_response(response)

@login_or_basicauth_required(realm)
def top_devices (request, nugget_name):
    nugget_name = decode(nugget_name)
    query = {
        'name' : "top_devices",
        'options' : {
            'device_type' : None,
            'nugget_name' : nugget_name,
            'filter' : None,
            'group' : None,
            'n' : 0,
            }
        }

    if 'device_type' in request.GET:
        query['options']['device_type'] = request.GET['device_type']
    if 'n' in request.GET:
        query['options']['n'] = int(request.GET['n'])
    if 'filter' in request.GET:
        query['options']['filter'] = request.GET['filter']
    if 'group' in request.GET:
        query['options']['group'] = request.GET['group']

    return json_response(poller_query(query))

@login_or_basicauth_required(realm)
def latest_value(request, device_name, nugget_name):
    device_name = decode(device_name)
    nugget_name = decode(nugget_name)

    query = {
        'name' : "latest_value",
        'options' : {
            'device_name' : device_name,
            'nugget_name' : nugget_name,
            }
        }

    return json_response(poller_query(query))

@user_passes_test(lambda u: u.is_staff)
def terminal (request, device_name):
    device_name = decode(device_name)

    query = {'device_name' : device_name}

    if 'command' in request.GET:
        query['command'] = request.GET['command']

    return json_response(termserver_query(query))

@login_or_basicauth_required(realm)
def top_devices_span (request, nugget_name, start, end):
    nugget_name = decode(nugget_name)
    start = int(start)
    if (end == "now"):
        end = int(time.time())
    else:
        end = int(end)

    # get the device type filter
    device_type_l = []
    device_type = request.GET.get("device_type")
    if device_type:
        device_d = json.loads(DB.redis.get("device_d_full").decode())
        device_type_obj = cfg.init_device_object("__type__", device_type)
        device_type_l = [device_type] + device_type_obj.descendant_l

    # initialize the resample_period
    resample_period = 0;
    if 'period' in request.GET:
        resample_period = int(request.GET['period'])
    elif 'point_count' in request.GET:
        point_count = int(request.GET['point_count'])
        # find the resample_period based on the desired point_count
        resample_period = (end - start) / point_count;
        # round to the nearest 30s
        resample_period = int(round(resample_period / 30) * 30)

    # parse the options
    n = 0
    filter_re = None
    if 'n' in request.GET:
        n = int(request.GET['n'])
    if 'filter' in request.GET:
        filter_re = request.GET['filter']

    query = {
        'name' : "top_devices",
        'options' : {
            "start": start,
            "end": end,
            "resample_period": resample_period,
            "device_type_l": device_type_l,
            "device_filter": filter_re,
            'device_group' : None,
            "nugget": nugget_name,
            "n": n
        }
    }

    if 'group' in request.GET:
        query['options']['device_group'] = request.GET['group']

    return json_response(db_query(query))

@login_or_basicauth_required(realm)
def series_data (request, device_name, nugget_name, start, end):
    device_name = decode(device_name)
    nugget_name = decode(nugget_name)

    start = int(start)
    if (end == "now"):
        end = int(time.time())
    else:
        end = int(end)

    # initialize the resample_period
    resample_period = 0;
    if 'period' in request.GET:
        resample_period = int(request.GET['period'])
    elif 'point_count' in request.GET:
        point_count = int(request.GET['point_count'])
        # find the resample_period based on the desired point_count
        resample_period = (end - start) / point_count;
        # round to the nearest 30s
        resample_period = int(round(resample_period / 30) * 30)

    query = {
        'name' : "series_data",
        'options' : {
            "start": start,
            "end": end,
            "device": device_name,
            "nugget": nugget_name,
            "resample_period": resample_period
        }
    }

    # t1 = time.time() * 1000
    # ret = db_query(query)
    # print "series: %s" % (time.time() * 1000 - t1)
    # return json_response(ret)
    return json_response(db_query(query))

@login_or_basicauth_required(realm)
def logs (request, start, end):
    start = int(start)
    if (end == "now"):
        end = int(time.time())
    else:
        end = int(end)
    device_name = None
    nugget_name = None
    group = None

    if 'group' in request.GET:
        group = request.GET['group']
    if 'device' in request.GET:
        device_name = request.GET['device']
    if 'nugget' in request.GET:
        nugget_name = request.GET['nugget']

    query_start_time = time.time() * 1000
    fields = ['timestamp', 'type', 'severity', 'device', 'nugget', 'message']
    values = DB.db.query_logs(start, end, fields, group=group,
                              device_name=device_name, nugget_name=nugget_name)

    if not values:
        #log.debug("No Log Values")
        return json_response(None)

    df_start_time = time.time() * 1000

    logs_l = []
    for timestamp, type_id, sev_id, device_id, nugget_id, message in values:
        # get the device/nugget names (if present)
        device = nugget = None
        if device_id:
            device = DB.db.get_device(id=device_id).name
        if nugget_id:
            nugget = DB.db.get_nugget(id=nugget_id).name
        type = log.log_type_name[type_id]

        row = [timestamp, type, sev_id, device, nugget, message]
        logs_l.append(row)

    # sort the list
    #logs_l = sorted(logs_l, key=lambda x: x['timestamp'])

    # create a dataframe from the queryset
    df = pd.DataFrame(logs_l, columns=fields)
    df.sort_values(['timestamp'], inplace=True)

    end_time = time.time() * 1000

    if cfg.query_debug:
        log.debug("Logs: query/df/total: %s/%s/%s" % (
            int(df_start_time - query_start_time),
            int(end_time - df_start_time),
            int(end_time - query_start_time),
        ))

    #return json_response(json.dumps(logs_l))
    return json_response(df.to_json(orient='records'))

@login_or_basicauth_required(realm)
def metric_presence (request):
    group = None
    if 'group' in request.GET:
        group = request.GET['group']

    query = {
        'name' : "metric_presence",
        'options' : {
            "group": group
        }
    }
    ret = poller_query(query)

    return json_response(ret)

@login_or_basicauth_required(realm)
def metric_presence_span (request, start, end):
    start = int(start)
    end = int(end)

    group = None
    if 'group' in request.GET:
        group = request.GET['group']

    query = {
        'name' : "metric_presence",
        'options' : {
            "start": start,
            "end": end,
            "group": group
        }
    }
    ret = db_query(query)

    return json_response(ret)

@login_or_basicauth_required(realm)
def metric_summary (request, start, end):
    start = int(start)
    end = int(end)

    group = None
    if 'group' in request.GET:
        group = request.GET['group']

    query = {
        'name' : "metric_summary",
        'options' : {
            "start": start,
            "end": end,
            "group": group
        }
    }
    ret = db_query(query)

    return json_response(ret)

@login_or_basicauth_required(realm)
def conditions (request, _type=None):
    group = None
    if 'group' in request.GET:
        group = request.GET['group']

    min_severity = 0
    if 'min_severity' in request.GET:
        try:
            min_severity = int(request.GET['min_severity'])
        except ValueError:
            min_severity_str = request.GET['min_severity']
            if min_severity_str in log.sev_id:
                min_severity = log.sev_id[min_severity_str]

    return json_response(get_conditions(_type, min_severity, group))

def get_conditions (_type, min_severity, group):

    query = {
        'name' : "conditions",
        'options' : {
            'type' : _type,
            'min_severity' : min_severity,
            'group' : group
            }
        }

    return poller_query(query)

@login_or_basicauth_required(realm)
def send_report (request, start, end):
    start = int(start)
    end = int(end)

    if request.method == 'POST':
        # init the recipient list
        mailto = None
        if 'to' in request.POST:
            mailto = request.POST['to']

        event = json.loads(request.POST['data'])

        Report.send_report("Custom Report", event,
                           'network', mailto=mailto)

    return HttpResponse(status=201)

@login_or_basicauth_required(realm)
def license_check (request, key):
    valid = False
    try:
        s = License_db.objects.get(key=key)
        valid = s.valid
    except License_db.DoesNotExist: pass

    return json_response(json.dumps(valid))

@login_or_basicauth_required(realm)
def client_list (request):
    query = {'name' : "client_list"}
    l = json.loads(poller_query(query))
    return json_response(l)

@login_or_basicauth_required(realm)
def client_count (request):
    query = {'name' : "client_count"}
    l = json.loads(poller_query(query))
    return json_response(l)

@login_or_basicauth_required(realm)
def nugget_poll (request, device_name, nugget_name):
    device = cfg.get_device(device_name)

    if nugget_name not in device.nugget_cfg:
        return json_response("Nugget not found")

    # initialize polling config
    device.init_polling_config({nugget_name: 3600})

    # get the nugget entry
    nugget = device.nugget_d[nugget_name]

    # determine if the nugget was expanded
    expanded_l = [x for x in device.nugget_d.keys()
                  if x.startswith((nugget.cfg.get("alias") or nugget_name)+":")]

    # query the nugget
    response_l = device.poll(once=True)
    child_l = [x.name for x in nugget.child_l]
    split_l = [x.name for x in nugget.split_l]

    # look through for the nugget in question
    result = []
    for name, timestamp, value in response_l:
        if ((not nugget.split and name == nugget.name) or
            (nugget.split and name in split_l) or
            name in expanded_l or
            (nugget.type == "group" and
             not nugget.aggregate and name in child_l)):
            result.append({
                'timestamp': timestamp,
                'nugget': name,
                'value': value
            })

    return json_response(result)
