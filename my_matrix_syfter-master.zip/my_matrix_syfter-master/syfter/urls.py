from django.urls import path, include
from django.contrib import admin
from django.conf import settings

if settings.SUB_URL:
    prefix = '%s/' % settings.SUB_URL
else:
    prefix = ''

urlpatterns = [
    path(prefix,
        include(
            [
                path('admin/', admin.site.urls),
                path('', include('common.urls')),
                path('api/', include('api.urls')),
                #path('diff/', include('klaus.urls', namespace='klaus'))
            ]
        )
    )
]
