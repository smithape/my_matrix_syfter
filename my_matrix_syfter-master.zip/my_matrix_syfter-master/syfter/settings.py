"""
Django settings for syfter project.

For more information on this file, see
https://docs.djangoproject.com/en/1.7/topics/settings/

For the full list of settings and their values, see
https://docs.djangoproject.com/en/1.7/ref/settings/
"""

import os
import sys
import yaml
from common import linux

if linux.distro() == "docker":
    db_host = 'db'
else:
    db_host = 'localhost'

cfg_file = "/etc/cisco/syfter.conf"

# import the tool config
try:
    with open (cfg_file) as f:
        CONFIG = yaml.full_load(f.read()) or {}
except Exception as e:
    CONFIG = {}

# Build paths inside the project like this: os.path.join(BASE_DIR, ...)
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = '7*^m4lb3u_jll=6apqxxq229b+s9l$mt8i%%#9t(%2pphpl(z$'

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = CONFIG.get('debug', False)

ALLOWED_HOSTS = ['*']


# Application definition
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    # syfter
    'common.apps.CommonConfig',
    'api.apps.ApiConfig',
    'termserver'
]

# levy: only add channels if needed. Adding channels causes
# twisted to use an asyncio reactor and that doesn't play
# well with the rest of our daemons (which rely on epoll reactor)
if sys.argv[0].endswith("daphne"):
    INSTALLED_APPS.append("channels")

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.contrib.sites.middleware.CurrentSiteMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

TEMPLATE_DEBUG = False
TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

ROOT_URLCONF = 'syfter.urls'
WSGI_APPLICATION = 'syfter.wsgi.application'
ASGI_APPLICATION = "syfter.routing.application"


# Database
# https://docs.djangoproject.com/en/1.9/ref/settings/#databases

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql_psycopg2', # Add 'postgresql_psycopg2', 'mysql', 'sqlite3' or 'oracle'.
        'NAME': 'syfter',                      # Or path to database file if using sqlite3.
        'USER': 'postgres',                      # Not used with sqlite3.
        'PASSWORD': 'Fhnu5LzeghCt5L6zW7UG',                  # Not used with sqlite3.
        'HOST': db_host,                      # Set to empty string for localhost. Not used with sqlite3.
        'PORT': '',                      # Set to empty string for default. Not used with sqlite3.
    }
}

# Password validation
# https://docs.djangoproject.com/en/1.9/ref/settings/#auth-password-validators

AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]

# Internationalization
# https://docs.djangoproject.com/en/1.9/topics/i18n/

LANGUAGE_CODE = 'en-us'

USE_TZ = True

USE_I18N = True

USE_L10N = True

# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/1.9/howto/static-files/

USE_X_FORWARDED_HOST = True
STATIC_ROOT = os.path.join(BASE_DIR, "static/")

SUB_URL = CONFIG.get('sub_url', '')
if SUB_URL:
    ROOT_URL = '/%s/' % SUB_URL
else:
    ROOT_URL = '/'

STATIC_URL = '%sstatic/' % ROOT_URL
LOGIN_URL = '%slogin' % ROOT_URL
LOGIN_REDIRECT_URl = ROOT_URL

# HTTPS
SESSION_COOKIE_SECURE = True
CSRF_COOKIE_SECURE = True

# klaus
INSTALLED_APPS += ['klaus']
KLAUS_REPO_PATHS = ['/storage/cfg']

# LEVY: Debug junk
#SESSION_COOKIE_SECURE = False
#CSRF_COOKIE_SECURE = False
