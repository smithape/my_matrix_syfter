from django.urls import path, include
from django.conf import settings
from channels.auth import AuthMiddlewareStack
from channels.routing import ProtocolTypeRouter, URLRouter
from termserver.consumers import TSConsumer
from nugget.consumers import NuggetTestConsumer, NuggetPollConsumer

if settings.SUB_URL:
    prefix = '%s/ws' % settings.SUB_URL
else:
    prefix = 'ws'

application = ProtocolTypeRouter({
    'websocket': AuthMiddlewareStack(
        URLRouter(
            [
                path('%s/term/' % prefix, TSConsumer),
                path('%s/nugget_test/' % prefix, NuggetTestConsumer),
                path('%s/nugget_poll/' % prefix, NuggetPollConsumer)
            ]
        )
    )
})
