from datetime import datetime
import logger as log
import json
import pytz

# Models
from json_results.models import JsonData, JsonDataLabel, JsonDataIndex

from AbstractHandler import AbstractHandler

class JsonResultsHandler (AbstractHandler):
    def __init__ (self, *args):
        super(JsonResultsHandler, self).__init__(*args)

        # specific
        self.json_label_d = {}  # dict to hold the json label objects to avoid DB lookups
        self.json_index_d = {}  # dict to hold the json index objects to avoid DB lookups

    def consume (self, nugget_l):
        log.debug("%s consuming data: %s" % (self, len(nugget_l)))
        for x in nugget_l:
            self.store_json(x)

    def get_json_label (self, name):
        try:
            json_label = self.json_label_d[name]
        except KeyError:
            json_label_obj, created = JsonDataLabel.objects.get_or_create(name=name)
            # cache for later
            self.json_label_d[name] = json_label = json_label_obj

        return json_label

    def get_json_index (self, name):
        if not name:
            return None

        try:
            json_index = self.json_index_d[name]
        except KeyError:
            json_index_obj, created = JsonDataIndex.objects.get_or_create(name=name)
            # cache for later
            self.json_index_d[name] = json_index = json_index_obj

        return json_index

    def store_json (self, sample):
        # get node ip
        try:
            node_name = sample['device']
            node = self.common.node_d[node_name]
        except: return

        # convert timestamp to datetime
        timestamp = datetime.fromtimestamp(sample['timestamp'], pytz.UTC)

        # try to extract name/index
        nugget_name = sample['nugget']
        index = None
        try:
            nugget_name, index = nugget_name.split(':', 1)
        except: pass

        # Write the Report
        db_obj, created = JsonData.objects.update_or_create(
            label = self.get_json_label(nugget_name),
            index = self.get_json_index(index),
            node = node,
            defaults = {
                'timestamp': timestamp,
                'data': sample['value']
            }
        )
