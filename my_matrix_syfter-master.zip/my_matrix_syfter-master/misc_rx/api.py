"""
Not used: This was my idea to use a django view to receive data.
I decided not to use this because (1) it required deeper integration into
the matrix cloud codebase and (2) with multiple gunicorn workers, state
could not be saved.
"""
from __future__ import division, print_function
import os, time
import pytz
from datetime import datetime
import json
from django.http import HttpResponse

from common.http import json_response
from common import logger as log
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth import authenticate, login

@csrf_exempt
def receive (request):
    if check_auth(request):
        if request.method == 'POST':
            data = json.loads(request.body)
            if 'device' in data:
                device_d = data['device']
                store_devices(device_d)
            if 'kpi' in data:
                data = data['kpi']
                store_kpi_data(data)
        return HttpResponse(status=200)
    else:
        # levy: for some reason I had to make this complicated or it wouldn't
        # build the response fully
        msg = "Authorization Failed"
        response = HttpResponse(msg, status=401)
        response['Content-Length'] = len(msg)
        return response


def check_auth (request):
    if 'HTTP_AUTHORIZATION' in request.META:
        auth_method, auth = request.META['HTTP_AUTHORIZATION'].split()
        if auth_method.lower() == 'basic':
            username, password = auth.strip().decode('base64').split(':')
            user = authenticate(username=username, password=password)
            if user and user.is_active:
                login(request, user)
                request.user = user
                return True

    return False


def format_data (data):
    # convert the samples to postgres records
    pg_sample_l = []

    for sample in data:
        kpi_name = sample['kpi']
        index = ""
        try:
            kpi_name, index = sample['kpi'].split(":")
        except: pass

        schema = ""
        try:
            schema, kpi_name = kpi_name.split("_")
        except: pass

        if index:
            sample['index'] = index
        if schema:
            sample['schema'] = schema

        sample['kpi'] = kpi_name

        r = create_sample(sample)
        pg_sample_l.append(r)

    return pg_sample_l

def create_sample (sample):
    # get device pointer

    # get the kpi pointer

    # get the index pointer

    # get the schema pointer

    # convert timestamp to datetime
    timestamp_dt = datetime.fromtimestamp(sample['timestamp'], pytz.UTC)

    r = KpiResult(
        node_id = node_id,
        kpi_id = kpi_id,
        schema_type_id = schema_id,
        index_id = index_id,
        time = timestamp_dt,
        value = sample['value']
    )
    return r

def store_kpi_data (data):
    record_l = format_data(data)
    KpiResult.objects.bulk_create(record_l)
    log.debug(data[0])

def store_devices (device_d):
    log.debug(json.dumps(device_d, indent=4))
