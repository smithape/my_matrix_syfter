#!/usr/bin/env python
#from __future__ import division, print_function
import sys
import time
from commands import getstatusoutput
import signal
import lockfile
import traceback
import redis
import json

from daemon import runner
import logger as log

from MatrixConsumer import MatrixConsumer

report_storage_dir = '/storage/reports/'
log_storage_dir = '/storage/logs/'

class RedisRXDaemon():
    def __init__(self):
        # daemon arguments
        self.stdin_path = '/dev/null'
        self.stdout_path = '/dev/tty'
        self.stderr_path = '/dev/tty'
        self.pidfile_path =  '/var/run/redis_streamrx.pid'
        self.pidfile_timeout = 1
        self.interrupt = False
        # other
        self.consumer = None
        self.redis = None
        self.sub = None

    def run(self):
        log.info('starting redis daemon')

        # initialize redis and subscribe to data
        self.redis = redis.StrictRedis()
        self.sub = self.redis.pubsub(ignore_subscribe_messages=True)
        self.sub.subscribe('syfter.data', 'syfter.snmptrap', 'syfter.nugget_cfg')

        # start the Matrix Import
        self.consumer = MatrixConsumer(self)
        self.consumer.start()

        # start with an OK status
        self.set_status("ok")

        try:
            while not self.interrupt:
                try:
                    msg = self.sub.get_message()
                    if msg:
                        self.consumer.process_message(msg)
                        self.set_status("ok")
                    time.sleep(1)
                except Exception as e:
                    self.set_status("error")
                    log.debug("Unexpected exception processing data: %s" % e)
        except Exception as e:
            print(traceback.format_exc())
        finally:
            try:
                self.redis.delete('syfter.status')
                self.consumer.stop()
            except Exception as e:
                log.debug("exception in RedisRX shutdown: %s" % e)
                #log(traceback.format_exc())
            finally:
                # hacky way to make sure we die
                getstatusoutput('pkill -9 -f "python\s.*%s\s*start"'
                                % sys.argv[0])

    def terminate(self, signal_number, stack_frame):
        self.interrupt = True

    def get_config (self):
        return json.loads(self.redis.get("syfter.config"))

    def set_status (self, status):
        self.redis.set('syfter.status', status)

def start_daemon ():

    # find FDs to preserve into the daemon
    files_preserve = []
    # the logging file
    files_preserve.append(log.fh.stream)

    app = RedisRXDaemon()
    daemon_runner = runner.DaemonRunner(app)
    daemon_runner.daemon_context.files_preserve=files_preserve
    daemon_runner.daemon_context.signal_map = {
        signal.SIGTTIN: None,
        signal.SIGTTOU: None,
        signal.SIGTSTP: None,
        signal.SIGTERM: app.terminate,
    }
    try:
        daemon_runner.do_action()
    except runner.DaemonRunnerStopFailureError as e:
        if "PID" not in e.message:
            print(e)
        sys.exit (-1)
    except lockfile.LockTimeout as e:
        print("redis import already running")
        sys.exit (-1)

if __name__ == '__main__':
    # initialize the logging facility
    log.init_logger()
    start_daemon()
