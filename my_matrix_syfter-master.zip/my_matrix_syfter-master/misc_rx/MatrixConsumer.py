import os
import sys
import time
import json
import yaml
import pytz
from PeriodicThread import PeriodicThread
import logger as log

# import the configuration
matrix_path = ""
route_l = []
import_l = []
try:
    with open ("/etc/cisco/syfter.matrix.conf") as f:
        cfg = yaml.full_load(f.read()) or {}
        matrix_path = cfg.get('matrix_path', matrix_path)
        import_l = cfg.get('imports', [])
        route_l = cfg.get('routes', [])
except IOError: pass

# initialize django
sys.path.append(matrix_path)
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "matrix_cloud.settings")
import django
django.setup()
from django.contrib.auth import get_user_model
from django.db import connection

# Models
from node.models import Node, NodeType
from company.models import Company

# import the required modules
for x in import_l:
    _module, _class = x.split('.')
    exec('from %s import %s' % (_module, _class))

class MatrixConsumer (object):
    def __init__ (self, interface):
        self.interface = interface
        self.cfg = {}
        self.route_cache = {}
        self.user = get_user_model().objects.get(email='matrix')
        self.company_d = {}
        self.node_d = {}  # dict to hold the Node objects to avoid DB lookups
        self.node_type_d = {} # dict to hold NodeType objects to avoid DB lookups

        # monitoring
        now = int(time.time())
        self.tstamp_d = {
            'import': 0,
        }

        self.handler_d = {x['handler']:globals().get(x['handler'])(self) for x in route_l}

    def start (self):
        log.info('starting matrix consumer')

        # reset the db connection
        connection.close()

        # Start the monitor thread
        self.monitor_t = PeriodicThread(name="monitor",
                                        interval=60,
                                        action=self.monitor,
                                        daemon=True)
        self.monitor_t.start()

    def stop (self):
        # stop the monitor thread
        if self.monitor_t:
            self.monitor_t.stop()

    def monitor (self):
        now = int(time.time())

        # send import config
        if now - self.tstamp_d['import'] >= 3600:
            self.import_config()
            self.tstamp_d['import'] = now

    def process_message (self, msg):
        if msg['type'] == 'message':
            data = json.loads(msg['data'])
            if msg['channel'] == 'syfter.data':
                self.process_nugget_data(data)
            elif msg['channel'] == 'syfter.snmptrap':
                log.debug(data)
            elif msg['channel'] == 'syfter.nugget_cfg':
                self.process_new_nugget_cfg(data)

    def get_company_id (self, x):
        try:
            company_id = self.company_d[x]
        except KeyError:
            company_obj, c = Company.objects.get_or_create(company_name=x)
            company_id = company_obj.id
            self.company_d[x] = company_id

        return company_id

    def get_node_type_id (self, x):
        try:
            node_type_id = self.node_type_d[x]
        except KeyError:
            node_type_obj, c = NodeType.objects.get_or_create(node_type=x)
            node_type_id = node_type_obj.id
            self.node_type_d[x] = node_type_id

        return node_type_id

    def process_new_nugget_cfg (self, nugget_cfg_d):
        # update the config
        self.cfg['nugget'].update(nugget_cfg_d)

        # remove route cache entries
        for nugget_name in nugget_cfg_d:
            # remove cache entry if present
            self.route_cache.pop(nugget_name, None)

        # see if handlers require updates
        for handler in self.handler_d.values():
            if hasattr(handler, 'process_new_nugget_cfg'):
                handler.process_new_nugget_cfg(nugget_cfg_d)

    def import_config (self):
        # read the config from the data interface
        self.cfg = self.interface.get_config()

        # extract generic config
        company = self.cfg['company'] or "NA"
        company_id = self.get_company_id(company)
        tz = self.cfg['timezone']
        try:
            tz = pytz.timezone(tz)
        except:
            tz = pytz.UTC


        for device_name, device_d in self.cfg['device'].items():

            node_type_id = self.get_node_type_id(device_d['type'])

            # Get the node obj
            try:
                node = self.node_d[device_name]
            except KeyError:
                try:
                    node = Node.objects.get(node_name=device_name)
                except Node.DoesNotExist:
                    # create new DB entry
                    node = Node(created_by=self.user)

                self.node_d[device_name] = node

            # update the node
            node.node_name = device_name
            node.node_ip = device_d['ip_address']
            node.company_id = company_id
            node.timezone = tz
            node.node_type_id = node_type_id
            node.save()

    def guess_type (self, value):
        if isinstance(value, (int, float)):
            _type = 'time_series'
        elif isinstance(value, str):
            _type = 'text'
        else:
            _type = "json"

        return _type

    def route_match (self, nugget_name, nugget_entry, value):
        nugget_type = nugget_entry.get('datatype') or self.guess_type(value)

        try:
            return self.route_cache[nugget_name]
        except KeyError:
            for route in route_l:

                # match by datatype
                type_match = False
                route_type = route.get('datatype')
                if (route_type is None or
                    isinstance(route_type, list) and nugget_type in route_type or
                    isinstance(route_type, str) and nugget_type == route_type):
                    type_match = True

                # match by name
                name_match = False
                route_name = route.get('name')
                if (route_name is None or
                    isinstance(route_name, list) and nugget_name in route_name or
                    isinstance(route_name, str) and nugget_name == route_name):
                    name_match = True

                if type_match and name_match:
                    ret = self.route_cache[nugget_name] = route.get('handler')
                    return ret

    def route_nugget_data (self, data):
        # initialize the routed data dict
        routed_data = {}

        for x in data:
            nugget_name = x['nugget']
            index = None
            try:
                nugget_name, index = nugget_name.split(':', 1)
            except: pass
            try:
                nugget_entry = self.cfg['nugget'][nugget_name]
            except KeyError:
                self.import_config()
                try:
                    nugget_entry = self.cfg['nugget'][nugget_name]
                except KeyError:
                    raise Exception("Nugget not found in configs: %s" % nugget_name)

            route = self.route_match(nugget_name, nugget_entry, x['value'])
            if route is None:
                log.info("No route for nugget: %s" % nugget_name)

            try:
                routed_data[route].append(x)
            except KeyError:
                routed_data[route] = [x]

        return routed_data

    def process_nugget_data (self, data):
        log.debug("data recieved: %s" % len(data))
        routed_data = self.route_nugget_data(data)

        for handler_name, nugget_l in routed_data.items():
            handler = self.handler_d.get(handler_name)
            if handler and nugget_l:
                handler.consume(nugget_l)
