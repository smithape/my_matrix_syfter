from datetime import datetime
import logger as log
import json
import pytz

# Models
from pcrf.models import PCRFRegionMap
from ultram.models import Report

from AbstractHandler import AbstractHandler

report_storage_dir = '/storage/reports/'

class UltramReportHandler (AbstractHandler):
    def __init__ (self, *args):
        super(UltramReportHandler, self).__init__(*args)

    def consume (self, nugget_l):
        for x in nugget_l:
            self.process_health_report(x)
            self.dump_report(x)

    def process_health_report (self, sample):
        # get node ip
        try:
            node_name = sample['device']
            node = self.node_d[node_name]
        except: return

        # convert timestamp to datetime
        timestamp = datetime.fromtimestamp(sample['timestamp'], pytz.UTC)
        report = sample['value']
        node_ip = node.node_ip
        try:
            tenant = node_name.split(':')[1]
        except:
            tenant = ''

        # find the pcrf_region_map
        pcrf_region_map = None
        try:
            pcrf_region_name = node_name.split('-', 1)[0] + '-ultra'
            pcrf_region_map = PCRFRegionMap.objects.get(cluster__iexact=pcrf_region_name)
        except PCRFRegionMap.DoesNotExist:
            log.debug("cluster not found: %s" % pcrf_region_name)

        # Write the Report
        nova_value_obj, created = Report.objects.update_or_create(
            name = sample['nugget'],
            node = node,
            defaults = {
                'timestamp': timestamp,
                'tenant': tenant,
                'pcrf_region_map': pcrf_region_map,
                'data': report
            }
        )

    def dump_report (self, x):
        # find the report filepath
        #filepath = "%s/%s/%s.%s" % (report_dir, x['device'], x['nugget'], x['timestamp'])
        filepath = "%s/%s/%s" % (report_storage_dir, x['device'], x['nugget'])

        # create directory (if necessary)
        filedir = os.path.dirname(filepath)
        if not os.path.exists(filedir):
            os.makedirs(filedir)

        # write the file
        with open(filepath, "wb") as f:
            if not isinstance(x['value'], str):
                text = json.dumps(x['value'], indent=4)
            else:
                text = x['value']

            f.write("%s\n" % text)

