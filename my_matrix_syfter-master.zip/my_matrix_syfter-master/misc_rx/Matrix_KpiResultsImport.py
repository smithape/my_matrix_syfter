from datetime import datetime
import logger as log

# Models
from kpi_results.kpi_libs import kpi_results_import

from Matrix_KpiResults import KpiResultsHandler

class KpiResultsImportHandler (KpiResultsHandler):
    def __init__ (self, *args):
        super(KpiResultsImportHandler, self).__init__(*args)

    def consume (self, nugget_l):
        log.debug("%s consuming data: %s" % (self, len(nugget_l)))
        record_l = self.format_data(nugget_l)

        company = self.common.cfg['company'] or "NA"
        try:
            kpi_results_import(company, "NA", allStatInfo=record_l)
        except Exception as e:
            log.error(traceback.format_exc())

    def format_data (self, data):

        for sample in data:
            kpi_name = sample['nugget']
            index = "NOINDEX"
            try:
                kpi_name, index = sample['nugget'].split(':', 1)
            except: pass

            # get the schema pointer (make sure it exists)
            schema = "DEFAULT"
            try:
                schema = self.common.cfg['nugget'][kpi_name]['schema']
            except: pass
            schema_id = self.get_schema_id(schema)

            # get the kpi pointer (make sure it exists)
            try:
                kpi_id = self.get_kpi_id(kpi_name, schema_id)
            except Exception as e:
                log.debug("Error with kpi: %s" % e)
                continue

            # kpi details
            sample['kpi_calc'] = kpi_name
            sample['index'] = index
            sample['schema'] = "DEFAULT"
            del sample['nugget']
            # node details
            sample['node_name'] = sample.pop('device')
            sample['node_type'] = self.common.cfg['device'][sample['node_name']]['type']
            # time details
            dt = datetime.utcfromtimestamp(sample.pop('timestamp'))
            sample['dataset'] = [{
                '%date%': '%4.4d%2.2d%2.2d' % (dt.year, dt.month, dt.day),
                '%time%': '%2.2d%2.2d%2.2d' % (dt.hour, dt.minute, dt.second),
                'KPI': sample.pop('value')
            }]

        return data

