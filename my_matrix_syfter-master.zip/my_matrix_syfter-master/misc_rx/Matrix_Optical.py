from datetime import datetime
import logger as log
import json
import pytz

# Models
from data_tables.models import *
from django.core.files import File

from Matrix_JsonResults import JsonResultsHandler

class OpticalHandler (JsonResultsHandler):
    def consume (self, nugget_l):
        log.debug("%s consuming data: %s" % (self, len(nugget_l)))

        for x in nugget_l:
            self.store_json(x)
            self.store(x)

    def store (self, sample):
        # get node ip
        try:
            node_name = sample['device']
            #node = self.node_d[node_name]
        except Exception as e:
	    log.debug("exception casued is %s " % e)
	    return

        # convert timestamp to datetime
        timestamp = datetime.fromtimestamp(sample['timestamp'], pytz.UTC)
	if (sample['nugget'] == 'get_all_alarms'):
		self.load_alarm_data(timestamp, sample)

	if (sample['nugget'] == 'get_sw_data'):
		self.load_ne_gen_data(sample)

	if (sample['nugget'] == 'get_sw_version'):
		self.load_sw_data(sample)

    def load_alarm_data(self, timestamp, sample):
        data = sample['value']
        for alarm in data.keys():
            for item in data[alarm]:
                    now = datetime.now()
                    year = now.year
		    month_m = now.month
                    month, day = item["DATE"].split("-")
                    hours, minutes, seconds = item["TIME"].split("-")
		    if(month_m > month):
			year = str(int(year)-1)
                    if(item["SUB_TYPE"] in ('NA', 'NR')):
                        db_obj, created =  ConditionTable.objects.update_or_create(
                                device_name = sample['device'],
                                alarm_id = item["ID"],
                                alarm_timestamp = datetime(year, int(month), int(day), int(hours), int(minutes), int(seconds)),
                                alarm_type = item["SUB_TYPE"],
                                alarm_code = item["ALARM-TYPE"],
                                defaults = {'nugget_timestamp': timestamp, 'alarm_description': item["ALARM"]}
                        )
                    else:
                        db_obj, created =  AlarmTable.objects.update_or_create(
                            device_name = sample["device"],
                            alarm_id = item["ID"],
                            alarm_timestamp = datetime(year, int(month), int(day), int(hours), int(minutes), int(seconds)),
                            alarm_type = item["SUB_TYPE"],
                            alarm_code = item["ALARM-TYPE"],
			    defaults = {'nugget_timestamp': timestamp, 'alarm_description': item["ALARM"]}
                        )
        return None

    def load_sw_data(self,sample):
	data = sample['value']
	for sw_version in data.keys():
	    for item in data[sw_version]:
	            db_obj, created =  NetworkGen.objects.update_or_create(
		        device_name = item["NAME"],
			defaults = {'software_version': item['SWVER'], 'load': item['LOAD'], 'mode': item['MODE'] }
		    )
		    db_obj, created =  DeviceTable.objects.update_or_create(
			device_name = item["NAME"],
			defaults = {'ip_address': item['IPADDR'], 'platform': item['PLATFORM']}
		    )
        return None

    def load_ne_gen_data(self, sample):
        data = sample['value']
        for device_name in data.keys():
            for cmd in data[device_name].keys():
                item = data[device_name][cmd]
                db_obj, created =  NetworkGen.objects.update_or_create(
                	device_name = device_name,
            		defaults = {'software_version': item['SWVER'], 'load': item['LOAD'], 'mode': item['MODE'] }
                )
		db_obj, created =  DeviceTable.objects.update_or_create(
                        device_name = device_name,
                        defaults = {'ip_address': item['IPADDR'], 'platform': item['PLATFORM']}
                )
        return None

    def load_cond_data(self, timestamp, sample):
	data = sample['value']
        for cond in data.keys():
                for item in data[cond]:
                    now = datetime.now()
                    year = now.year
                    month, day = item["DATE"].split("-")
                    hours, minutes, seconds = item["TIME"].split("-")
	            if(item["SUB_TYPE"] in ('NA', 'NR')):
                    	db_obj, created =  ConditionTable.objects.update_or_create(
                        	device_name = sample['device'],
                        	alarm_id = item["ID"],
                        	alarm_timestamp = datetime(year, int(month), int(day), int(hours), int(minutes), int(seconds)),
                        	alarm_type = item["SUB_TYPE"],
                                alarm_code = item["ALARM-TYPE"],
                        	defaults = {'nugget_timestamp': timestamp, 'alarm_description': item["ALARM"]}
                        )
        return None

    def load_sw_data_4k(self,sample):
        data = sample['value']
        for sw_version in data.keys():
            for item in data[sw_version]:
                    db_obj, created =  NetworkGen.objects.update_or_create(
                        device_name = item["NAME"],
                        defaults = {'software_version': item['SWVER'], 'load': item['LOAD'], 'mode': item['MODE'] }
                    )
                    db_obj, created =  DeviceTable.objects.update_or_create(
                        device_name = item["NAME"],
                        defaults = {'ip_address': item['IPADDR'], 'platform': item['PLATFORM']}
                    )
        return None
