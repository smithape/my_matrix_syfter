#!/usr/bin/python
"""
Generic Port RX daemon example.
"""

import sys
import time
import signal
from twisted.internet import reactor, protocol as p
import json
import lockfile
import traceback
from daemon import runner
from threading import Thread

def log (msg):
    with open("/tmp/port_rx.log", "a") as f:
        f.write("%s\n" % msg)

def out (msg):
    with open("/tmp/port_rx.out", "a") as f:
        f.write("%s\n" % msg)

port = 8087

class TrapDaemon ():
    def __init__(self):
        self.stdin_path = '/dev/null'
        self.stdout_path = '/dev/tty'
        self.stderr_path = '/dev/tty'
        self.pidfile_path =  '/var/run/port_rx.pid'
        self.pidfile_timeout = 1
        self.interrupt = False
        self.server_t = Thread(target=reactor.run, kwargs={'installSignalHandlers': 0})


    def run(self):
        reactor.listenTCP(port, TrapServer())
        try:
            self.server_t.start()
            while not self.interrupt:
                time.sleep(1)
        except Exception as e:
            log(traceback.format_exc())
        finally:
            try:
                reactor.callFromThread(reactor.stop)
            except:
                log("exception in DB server shutdown")
                log(traceback.format_exc())

    def terminate(self, signal_number, stack_frame):
        self.interrupt = True


class TrapServer (p.Factory):
    def buildProtocol(self, addr):
        return MessageHandler()


class MessageHandler (p.Protocol):
    delimiter = b'\n'

    def __init__(self):
        #self.ibuffer = bytearray()
        self.ibuffer = ''

    def dataReceived(self, data):
        # add new data to the buffer
        #self.ibuffer.extend(data)
        self.ibuffer += data
        # delimiter marks the end of the message
        if data[-1] == self.delimiter[-1]:
            try:
                # parse the message into json
                msg = json.loads(self.ibuffer)
                # process the message
                self.process_message(msg)
            except Exception as e:
                log("Invalid Request (cannot parse): %s" % e)
            finally:
                # clear the buffer
                #self.ibuffer = bytearray()
                self.ibuffer = ''

    def process_message (self, msg):
        out(json.dumps(msg, indent=4))

    # def respond (self, response):
    #     if not isinstance(response, str):
    #         response = json.dumps(response)

    #         response = response.encode() + self.delimiter
    #         self.transport.write(response)
    #         self.transport.loseConnection()


def start_daemon ():

    # find FDs to preserve into the daemon
    files_preserve = []

    # Twisted FDs (this was hard; don't delete!)
    for x, y in reactor._selectables.items():
        files_preserve += [y.i, y.o]
        files_preserve.append(reactor._poller.fileno())

    app = TrapDaemon()
    daemon_runner = runner.DaemonRunner(app)
    daemon_runner.daemon_context.files_preserve=files_preserve
    daemon_runner.daemon_context.signal_map = {
        signal.SIGTTIN: None,
        signal.SIGTTOU: None,
        signal.SIGTSTP: None,
        signal.SIGTERM: app.terminate,
    }
    try:
        daemon_runner.do_action()
    except runner.DaemonRunnerStopFailureError as e:
        if "PID" not in e.message:
            print(e)
            sys.exit (-1)
    except lockfile.LockTimeout as e:
        print("daemon already running")
        sys.exit (-1)

if __name__ == '__main__':
    start_daemon()
