"""
First daemon attempt using Twisted sockets
"""
from __future__ import division
import sys
import time
import traceback
import asyncore, socket
#import cPickle as pickle
import json
from commands import getstatusoutput
from threading import Thread
import urllib3

from twisted.internet import reactor, threads, protocol as p
from pkg import pexpect

from common.PeriodicThread import PeriodicThread
from common import \
    utility, \
    config as cfg, \
    logger as log, \
    DB

port = 8085

class StreamRXDaemon():
    def __init__(self):
        self.stdin_path = '/dev/null'
        self.stdout_path = '/dev/tty'
        self.stderr_path = '/dev/tty'
        self.pidfile_path =  '/var/run/%s_streamrx.pid' % cfg.tool_name
        self.pidfile_timeout = 1
        self.interrupt = False
        self.server_t = Thread(target=reactor.run, kwargs={'installSignalHandlers': 0})

    def run(self):
        reactor.listenTCP(port, StreamRXServer())
        try:
            self.server_t.start()
            while not self.interrupt:
                time.sleep(1)
        except Exception, e:
            print traceback.format_exc()
        finally:
            try:
                reactor.callFromThread(reactor.stop)
            except:
                log.debug("exception in termserver shutdown")
                log.debug(traceback.format_exc())
            finally:
                # hacky way to make sure we die
                getstatusoutput('pkill -9 -f "python\s.*%s\s*start"'
                                % sys.argv[0])

    def terminate(self, signal_number, stack_frame):
        self.interrupt = True

class StreamRXServer (p.Factory):
    def buildProtocol(self, addr):
        return RequestHandler()

class RequestHandler (p.Protocol):
    delimiter = '\n'

    def __init__(self):
        self.ibuffer = []

    def dataReceived(self, data):
        log.debug("dataReceived")
        self.ibuffer.append(data)
        if data[-1] == self.delimiter:
            request = ''.join(self.ibuffer)
            self.process_request(request)
            self.ibuffer = []

    def process_request (self, request):
        print(request)
        log.debug(request)
        # try:
        #     request = json.loads(request)
        # except: return

        respond(self.generate_headers(200))

    def respond (self, response):
        if not isinstance(response, basestring):
            response = json.dumps(response)

        self.transport.write(response + self.delimiter)
        self.transport.loseConnection()

    def query (self, device_name, command):
        d = threads.deferToThread(rx.query, device_name, command)
        d.addCallback(self.respond)

    def _generate_headers(self, response_code):
        """
        Generate HTTP response headers.
        Parameters:
        - response_code: HTTP response code to add to the header. 200 and 404 supported
        Returns:
        A formatted HTTP header for the given response_code
        """
        header = ''
        if response_code == 200:
            header += 'HTTP/1.1 200 OK\n'
        elif response_code == 404:
            header += 'HTTP/1.1 404 Not Found\n'

        time_now = time.strftime("%a, %d %b %Y %H:%M:%S", time.localtime())
        header += 'Date: {now}\n'.format(now=time_now)
        header += 'Server: Simple-Python-Server\n'
        header += 'Connection: close\n\n' # Signal that connection will be closed after completing the request
        return header
