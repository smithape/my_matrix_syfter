
class AbstractHandler (object):
    def __init__ (self, common):
        # for common operations
        self.common = common

    def __repr__(self):
        return self.__class__.__name__

    def consume (self, nugget_l):
        pass
