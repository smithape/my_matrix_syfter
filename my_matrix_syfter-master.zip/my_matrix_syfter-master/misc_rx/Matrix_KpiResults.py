from datetime import datetime
import logger as log
import json
import pytz

from django.db import IntegrityError

# Models
from kpi_calc.models import KpiCalc, SchemaType
from kpi_results.models import KpiResult, KpiIndex, KpiUsage, IndexUsage, BusyHour
from node.models import Node, NodeType

from AbstractHandler import AbstractHandler

class KpiResultsHandler (AbstractHandler):
    def __init__ (self, *args):
        super(KpiResultsHandler, self).__init__(*args)

        # specific
        self.kpi_d = {}  # dict to hold the KPI Calc objects to avoid DB lookups
        self.index_d = {}     # dict to hold the KpiIndex obj to avoid DB lookups
        self.schema_d = {}     # dict to hold schema_type
        self.usage_d = {} # remember usage objects to avoid DB lookups
        # track the kpi/index usage (timestamps)
        self.usage = {}
        self.unit_map = {
            'percentage': 'Percentage',
            'bytes': 'Bytes',
            'kbps': 'Kbps',
            'mbps': 'Mbps',
            'gbps': 'Gbps'
        }

    def consume (self, nugget_l):
        log.debug("%s consuming data: %s" % (self, len(nugget_l)))
        record_l = self.format_data(nugget_l)

        try:
            KpiResult.objects.bulk_create(record_l)
        except IntegrityError as e:
            log.debug("Duplicate KPI object: %s" % e)

        # write usage
        self.save_usage()

    def get_kpi_id (self, kpi_name, schema_id):
        try:
            kpi_id = self.kpi_d[kpi_name]
        except KeyError:
            # extract the config options
            try:
                kpi_entry = self.common.cfg['nugget'][kpi_name]
                unit = self.unit_map.get(kpi_entry.get('unit')) or "Number"
                description = kpi_entry.get("description") or kpi_name
            except KeyError:
                # revert to defaults
                unit = "Number"
                description = kpi_name

            kpi_obj, created = KpiCalc.objects.update_or_create(
                name=kpi_name,
                defaults = {
                    'schema_type_id': schema_id,
                    'units': unit,
                    'header': description,
                    'formula': kpi_name,
                    'quality_kpi': True,
                    'aggregation_time': 'avg',
                    'aggregation_node': 'sum',
                    'aggregation_network': 'sum',
                }
            )
            # cache for later
            self.kpi_d[kpi_name] = kpi_id = kpi_obj.id

        return kpi_id

    def get_schema_id (self, x):
        if not x:
            return None

        try:
            schema_id = self.schema_d[x]
        except KeyError:
            schema_obj, c = SchemaType.objects.get_or_create(schema_type=x)
            schema_id = schema_obj.id
            self.schema_d[x] = schema_id

        return schema_id

    def get_index_id (self, index, company):
        if not index:
            return None

        try:
            index_id = self.index_d[index]
        except KeyError:
            index_obj, c = KpiIndex.objects.get_or_create(index = index,
                                                          company = company)
            self.index_d[index] = index_id = index_obj.id
            self.index_d[index] = index_id

        return index_id

    def format_data (self, data):
        # convert the samples to postgres records
        pg_sample_l = []

        for sample in data:
            kpi_name = sample['nugget']
            index = "NOINDEX"
            try:
                kpi_name, index = sample['nugget'].split(':', 1)
            except: pass

            schema = "DEFAULT"
            try:
                schema = self.common.cfg['nugget'][kpi_name]['schema']
            except: pass

            sample['nugget'] = kpi_name
            sample['index'] = index
            sample['schema'] = schema

            r = self.create_sample(sample)
            if r is not None:
                pg_sample_l.append(r)

        return pg_sample_l

    def save_usage (self):
        # save node usage
        for x in self.usage.values():
            x.save()
        self.usage.clear()

    def track_usage (self, timestamp, node, schema_id, kpi_id, index_id):
        # Node Usage
        if not (node.first_kpi_used):
            node.first_kpi_used = timestamp
            node.last_kpi_used = timestamp
            node.save()
        else:
            node.last_kpi_used = timestamp
            self.usage[node.id] = node

        # KPI Usage
        key = "%s/%s" % (node.id, kpi_id)
        try:
            kpiUsage = self.usage_d[key]
        except KeyError:
            # check the database object
            try:
                kpiUsage = KpiUsage.objects.get(node=node,
                                                kpi_id=kpi_id,
                                                schema_type_id=schema_id)
            except KpiUsage.DoesNotExist:
                KpiUsage.objects.create(node=node,
                                        kpi_id=kpi_id,
                                        schema_type_id=schema_id,
                                        first_used=timestamp,
                                        last_used=timestamp)
                return

            self.usage_d[key] = kpiUsage

        kpiUsage.last_used = timestamp
        self.usage[key] = kpiUsage

        # Index Usage
        key = "%s/%s/%s" % (node.id, kpi_id, index_id)
        try:
            indexUsage = self.usage_d[key]
        except KeyError:
            # check the database object
            try:
                indexUsage = IndexUsage.objects.get(node=node,
                                                    kpi_id=kpi_id,
                                                    index_id=index_id)
            except IndexUsage.DoesNotExist:
                IndexUsage.objects.create(node=node,
                                          kpi_id=kpi_id,
                                          index_id=index_id,
                                          first_used=timestamp,
                                          last_used=timestamp)
                return

            self.usage_d[key] = indexUsage

        indexUsage.last_used = timestamp
        self.usage[key] = indexUsage

    def create_sample (self, sample):
        # get node
        try:
            node = self.common.node_d[sample['device']]
        except:
            return None

        # get the schema pointer
        schema_id = self.get_schema_id(sample['schema'])

        # get the kpi pointer
        try:
            kpi_id = self.get_kpi_id(sample['nugget'], schema_id)
        except Exception as e:
            log.debug("Error with kpi: %s" % e)
            return None

        # get the kpi index pointer
        index_id = self.get_index_id(sample['index'], node.company)

        # convert timestamp to datetime
        timestamp = datetime.fromtimestamp(sample['timestamp'], pytz.UTC)

        # track the time these kpi/index were used
        self.track_usage(timestamp, node, schema_id, kpi_id, index_id)

        # create the record
        r = KpiResult (
            node = node,
            kpi_id = kpi_id,
            schema_type_id = schema_id,
            index_id = index_id,
            time = timestamp,
            value = sample['value']
        )
        return r

    def process_new_nugget_cfg (self, nugget_cfg_d):
        for nugget_name in nugget_cfg_d:
            # remove cache entry if present
            self.kpi_d.pop(nugget_name, None)
