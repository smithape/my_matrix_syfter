import os
import logging
logger = None
fh = None
log_dir = '/var/log/cisco/'
log_file = 'syfter.redis.log'

def init_logger (debug_lvl="critical"):
    global logger, fh

    debug_lvl = eval("logging." + debug_lvl.upper())

    # create logger
    logger = logging.getLogger("redis_rx")
    logger.setLevel(logging.DEBUG)
    logger.propagate = False

    # create the directory (if required)
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)

    #
    # create file handler
    fh = logging.handlers.RotatingFileHandler(log_dir + log_file,
                                              maxBytes=100*1024,
                                              backupCount=5)
    # create formatter
    fmt = logging.Formatter(fmt = "%(asctime)s\t%(levelname)s/%(module)s\t%(message)s",
                            datefmt = "%Y-%m-%d_%H:%M:%S")

    # set log level
    fh.setLevel(logging.DEBUG)
    # add formatter to handler
    fh.setFormatter(fmt)
    # add handler to logger
    logger.addHandler(fh)

    #
    # create console handler
    ch = logging.StreamHandler()
    # set log level
    ch.setLevel(debug_lvl)
    # add handler to logger
    logger.addHandler(ch)

def debug (*args, **kwargs):
    logger.debug(*args, **kwargs)

def info (*args, **kwargs):
    logger.info(*args, **kwargs)

def warning (*args, **kwargs):
    logger.warning(*args, **kwargs)

def error (message):
    logger.error(message)

def critical (message):
    logger.critical(message)

def exception (message):
    logger.exception(message)
