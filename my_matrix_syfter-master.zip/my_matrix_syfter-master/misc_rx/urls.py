from django.conf.urls import url, include

import api

urlpatterns = [
    # data
    url(r'^receive/?$', api.receive, name="data_collector.receive"),
]

