cd common/static/js/
./build.sh $1
cd -
./deploy.sh
