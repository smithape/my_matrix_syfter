
function getJSON(url) {
    var json = null;
    $.ajax({
        'async': false,
        'global': false,
        'url': url,
        'dataType': "json",
        'success': function (data) {
            json = data;
        }
    });
    return json;
}

$(document).ready(function(){
    var metric_list = [];
    var dict = getJSON("device_data");


    for(var d in dict)
    {
        device = dict[d]

        for (var i in device.metrics)
        {
            metric = device.metrics[i]
            //console.log(metric_list.indexOf(metric));
            if (metric_list.indexOf(metric) < 0) {
                //console.log("hey");
                metric_list.push(metric);
            }
        }
    }
    metric_list.sort();
    html_text = "";
    html_text += "<div class='scrollable-table'> \
<table class='table table-striped table-header-rotated'> \
<thead>
<tr><th></th>";

    for (var i in metric_list) {
        html_text +='<th class="rotate-45"><div><span>'+metric_list[i]+'</span></div></th>';
    }
    html_text += '</tr>';
    html_text += "</thead>";

    html_text += "<tbody>";
    for(var d in dict)
    {
        device = dict[d]
        html_text += '<tr>';
        html_text += '<th class="row-header">'+device.name+'</th>';
        for (var i in metric_list)
        {
            metric = metric_list[i];
            //console.log(metric_list.indexOf(metric));
            if (device.metrics.indexOf(metric) >= 0) {
                //console.log("hey");
                html_text += '<td><input name="column1[]" type="checkbox" value="'+metric+'"></td>\n';
            } else {
                html_text += '<td></td>\n';
            }
        }
        html_text += '</tr>\n';
    }
    html_text += "</tbody>";
    html_text += "</table>";
    html_text += "</div>";

    console.log(html_text);
});
