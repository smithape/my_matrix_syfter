$(document).ready(function(){
    var sort_name_inverse = false;
    var sort_type_inverse = false;
    var sort_owner_inverse = false;

    /*
     * Sort by name
     */
    //$('#name_header').click(function(e) {
    $('#device_content').on('click', '#name_header', function(e){
        $('.group').each(function(i) {
            $(this).children('.device').sortElements(
		function(a, b){
 	            a_text = $("div.summary:first", a).find(".device_name").text();
 	            b_text = $("div.summary:first", b).find(".device_name").text();
                    return a_text > b_text ?
                        sort_name_inverse ? -1 : 1 :
		    sort_name_inverse ? 1 : -1;
		});
	});
        sort_name_inverse = !sort_name_inverse;
	sort_type_inverse = false;
	sort_owner_inverse = false;
    });

    /*
     * Sort by type
     */
    //$('#type_header').click(function(e) {
    $('#device_content').on('click', '#type_header', function(e){
        $('.group').each(function(i) {
            $(this).children('.device').sortElements(
		function(a, b){
 	            a_text = $("div.summary:first", a).find(".device_type").text();
 	            b_text = $("div.summary:first", b).find(".device_type").text();
                    return a_text > b_text ?
                        sort_type_inverse ? -1 : 1 :
		    sort_type_inverse ? 1 : -1;
		});
	});
        sort_type_inverse = !sort_type_inverse;
	sort_name_inverse = false;
	sort_owner_inverse = false;
    });

    /*
     * Sort by owner
     */
    //$('#owner_header').click(function(e) {
    $('#device_content').on('click', '#owner_header', function(e){
        $('.group').each(function(i) {
            $(this).children('.device').sortElements(
		function(a, b){
 	            a_text = $("div.summary:first", a).find(".device_owner").text();
 	            b_text = $("div.summary:first", b).find(".device_owner").text();
                    return a_text > b_text ?
                        sort_owner_inverse ? -1 : 1 :
		    sort_owner_inverse ? 1 : -1;
		});
	});
        sort_owner_inverse = !sort_owner_inverse;
	sort_name_inverse = false;
	sort_type_inverse = false;
    });

    /*
     * EXPAND
     */

    //$('.summary').click(function(e) {
    $('#device_content').on('click', '.summary', function(e) {
	elem = $(this).parent().children('.details');
	$(elem).slideToggle(0, function() {});

	if ($(elem).is(":visible")) {
	    $(elem).parents('.dev_box').css('background-color', '#f0f0f0');
	} else {
	    $(elem).parents('.dev_box').css('background-color', '#ffffff');
	}
    });

    $("#device_content").on('click', '.plus_button', function(e){
	e.stopPropagation();
	elem = $(this).parent().parent().children('.children')
	$(elem).slideToggle(0, function() {});
	if ($(elem).is(":visible")) {
            $(this).attr("src", "img/minus.png");
	} else {
            $(this).attr("src", "img/plus.png");
	}
    });


    /* This version does the full expand option
       $('#top_plus_button').toggle(
       function() {
       $('.plus_button').not(this).attr("src", "img/minus.png");
       $('.children').show();
       }, function() {
       $(this).attr("src", "img/minus.png");
       $('.summary').parent().children('.details').show();
       $('.dev_box').css('background-color', '#f0f0f0');
       }, function() {
       $('.summary').parent().children('.details').hide();
       $('.dev_box').css('background-color', '#ffffff');
       $('.plus_button').attr("src", "img/plus.png");
       $('.children').hide();
       });
    */

    $('.inside_link').click(function(e) {
	e.stopPropagation();
    });

    $('.inside_link').hover(
	function() {
	    $(this).parent().find('.hidden').show();
	},
	function() {
	    $(this).parent().find('.hidden').hide();
	}
    );

});

