$(document).ready(function(){
    var last_clicked;

    /*
     * Submit a confirmation/action form
     */
    $(document).on('submit', '.fancy_form', function(event) {
	var action = $("input[name=action]", this).val();
	event.preventDefault();

	if (last_clicked=="Yes") {
	    $.post("post", $(this).serialize(),
		   function(data, textStatus) {
                       if (data && data != "success") {
			   alert (data);
                       }
		   }
		  );
	};

	$.fancybox.close();
    });

    $(document).on('click', 'button', function() {
	last_clicked = $(this).val()
    });


    /*
     * Bring up the fancybox confirmation (etc.) form with URL content
     */
    $("#fancy").fancybox({
	fitToView   : true,
	minWidth    : 10,
	minHeight   : 10,
	openEffect  : 'none',
	closeEffect : 'none',
	closeBtn : false,
	helpers : {
	    overlay : {
		locked : false,
		css : {
		    background : 'none'
		}
	    }
	}
    });

});
