#!/bin/bash

#
# Install symlink for dokuwiki config
rm -rf /etc/dokuwiki
ln -s /opt/cisco/matrix-wifi/wiki/config /etc/dokuwiki

#
# Install symlink for dokuwiki data
rm -rf /var/lib/dokuwiki/data
ln -s /opt/cisco/matrix-wifi/wiki/data /var/lib/dokuwiki/data

#
# Install symlink for the matrix template
rm -rf /var/lib/dokuwiki/lib/tpl/matrix
ln -s /opt/cisco/matrix-wifi/wiki/template /var/lib/dokuwiki/lib/tpl/matrix

#
# Install symlinks for the plugins
rm -rf /var/lib/dokuwiki/lib/plugins/authextdjango
ln -s /opt/cisco/matrix-wifi/wiki/plugins/authextdjango /var/lib/dokuwiki/lib/plugins/
rm -rf /var/lib/dokuwiki/lib/plugins/baselink
ln -s /opt/cisco/matrix-wifi/wiki/plugins/baselink /var/lib/dokuwiki/lib/plugins/
rm -rf /var/lib/dokuwiki/lib/plugins/wrap
ln -s /opt/cisco/matrix-wifi/wiki/plugins/wrap /var/lib/dokuwiki/lib/plugins/

#
# Install symlink for "wiki" url replacement
rm -rf /usr/share/wiki
ln -s /usr/share/dokuwiki /usr/share/wiki

#
# Set the file permissions
chown -R www-data:root /opt/cisco/matrix-wifi/wiki/data
find /opt/cisco/matrix-wifi/wiki/data -type d -exec chmod 700 {} \;
chown -R www-data:root /opt/cisco/matrix-wifi/wiki/config
find /opt/cisco/matrix-wifi/wiki/config -type d -exec chmod 700 {} \;
