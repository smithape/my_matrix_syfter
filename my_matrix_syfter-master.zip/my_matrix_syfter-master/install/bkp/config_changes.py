#!/usr/bin/env python
from __future__ import division
import os, sys
import re
# initialize django
import django
sys.path.append("/opt/cisco/matrix-wifi/")
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "matrix.settings")
django.setup()

from common.models import Config as Config_db

#
# read in the polling config
try:
    cfg_obj, created = Config_db.objects.get_or_create(name="polling-config")
    poll_cfg_txt = cfg_obj.text
    # changes
    poll_cfg_txt = re.sub(r'cpuLoad', 'cpuUtilization', poll_cfg_txt)
    poll_cfg_txt = re.sub(r'channelLoad', 'channelUtilization', poll_cfg_txt)
    # write
    cfg_obj.text = poll_cfg_txt
    cfg_obj.save()
except: pass
