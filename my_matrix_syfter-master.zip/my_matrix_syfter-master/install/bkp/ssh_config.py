#!/usr/bin/env python
from __future__ import division
import re

#
# find the config file
filepath = "/etc/ssh/ssh_config"

#
# edit the config
with open (filepath, "r") as f:
    cfg = f.read()
    # remove the lines
    cfg = re.sub(r'\n#?\s*StrictHostKeyChecking[\s=]+\w+', '', cfg)
    cfg = re.sub(r'\n#?\s*UserKnownHostsFile[\s=]+[\w\/]+', '', cfg)
    # append lines to the end
    cfg += "StrictHostKeyChecking no\n"
    cfg += "UserKnownHostsFile /dev/null\n"

with open (filepath, "w") as f:
    f.write(cfg)
