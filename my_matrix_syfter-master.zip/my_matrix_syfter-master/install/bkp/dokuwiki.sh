#!/bin/bash
apt_cmd='apt-get -q -o Acquire::ForceIPv4=true -y --force-yes --fix-missing --allow-unauthenticated'

$apt_cmd update

printf "\ninstalling dokuwiki dependencies...\n"
$apt_cmd install dokuwiki php5-fpm

printf "\ndownloading dokuwiki...\n"
cd /tmp/
wget http://download.dokuwiki.org/src/dokuwiki/dokuwiki-stable.tgz
tar zxf dokuwiki-stable.tgz
cd dokuwiki-*

printf "\ninstalling dokuwiki...\n"
cp -rf * /usr/share/dokuwiki
cp -rf lib/tpl/* /var/lib/dokuwiki/lib/tpl/
cp -rf lib/plugins/* /var/lib/dokuwiki/lib/plugins/
cd ..
rm -rf dokuwiki*
pip install -e git://github.com/cato-/django-external-auth.git#egg=django-external-auth 2> /dev/null
cd src/django-external-auth
python setup.py install
rm -rf /tmp/src
