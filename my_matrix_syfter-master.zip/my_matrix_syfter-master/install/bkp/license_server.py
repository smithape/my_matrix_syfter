#!/usr/bin/env python
from __future__ import division
import re

#
# find the config file
filepath = "/etc/matrix/matrix.conf"

#
# edit the root config
with open (filepath, "r") as f:
    cfg_str = f.read()
    # remove the lines
    cfg_str = re.sub(r'128.107.34.1', 'matrix-hub.cisco.com', cfg_str)

with open (filepath, "w") as f:
    f.write(cfg_str)
