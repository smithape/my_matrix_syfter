#!/bin/bash
apt_cmd='apt-get -q -o Acquire::ForceIPv4=true -y --force-yes --fix-missing --allow-unauthenticated'

$apt_cmd update

# apt-get install
$apt_cmd install libssl-dev libffi-dev rcs htop nmon python-psycopg2 python-pip postgresql-9.4 postgresql-server-dev-9.4 nginx redis-server
$apt_cmd install curl

# pip install
pip install setuptools --upgrade
pip install pip psutil pyyaml lockfile requests simplejson subprocess32 splunk-sdk elasticsearch twisted psycopg2 gunicorn ipaddress service_identity redis --upgrade
pip install pygments dulwich --upgrade
pip install gunicorn==19.5.0
pip install ptyprocess==0.5.1
pip install Django==1.9.1
pip install architect==0.5.5
pip install numpy==1.10.4
pip install pandas==0.17.0
pip install watchdog --upgrade
