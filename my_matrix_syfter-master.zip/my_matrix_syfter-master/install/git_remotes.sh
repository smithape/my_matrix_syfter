#!/bin/bash
DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
DIR=$(dirname $DIR) # up one directory
REPO=levmason/syfter.git
GIT_CMD="git --git-dir=$DIR/.git --work-tree=$DIR/"

# set the urls
$GIT_CMD remote set-url origin git@bitbucket.org:$REPO
$GIT_CMD remote set-url --push origin https://levmason@bitbucket.org/$REPO

# test
$GIT_CMD remote show origin &> /dev/null

# if failure, try https
if [[ "$?" -ne 0 ]]; then
    $GIT_CMD remote set-url origin https://levmason-usr@bitbucket.org/$REPO
fi
