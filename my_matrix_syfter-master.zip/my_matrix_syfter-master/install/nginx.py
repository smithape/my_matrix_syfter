#!/usr/bin/env python
import os, sys, re
from subprocess import getstatusoutput, run, PIPE

# find the directory of this file
install_dir = os.path.dirname(os.path.realpath(__file__))
project_dir = os.path.dirname(install_dir)

# determine the nginx version
command = "nginx -v 2>&1 | grep -oE [0-9.]+"
(code, result) = getstatusoutput(command)
nginx_version = float(result.rsplit('.', 1)[0])
# select the config according to version
if nginx_version >= 1.13:
    nginx_conf = 'syfter.conf'
else:
    nginx_conf = 'syfter.legacy.conf'

# remove old configs
command = "rm /etc/nginx/sites-enabled/*"
run(command.split(), stderr=PIPE)
command = "rm /etc/nginx/conf.d/*"
run(command.split(), stderr=PIPE)
# symlink nginx config
command = "ln -sf %s/server/nginx/%s /etc/nginx/conf.d/" % (project_dir, nginx_conf)
run(command.split())
# restart nginx
command = "service nginx restart"
run(command.split())
