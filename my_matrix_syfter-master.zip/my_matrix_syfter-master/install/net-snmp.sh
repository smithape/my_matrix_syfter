#!/bin/bash
DIR=$( cd "$( dirname $BASH_SOURCE )" && pwd )
PRJ_DIR="$(dirname $DIR)"

version=5.8
archive_file=net-snmp-$version.tar.gz
url="https://downloads.sourceforge.net/project/net-snmp/net-snmp/$version/$archive_file"

printf "  downloading...\n"
cd /tmp/
wget -q $url
tar zxf $archive_file
cd net-snmp-$version

printf "  building...\n"
./configure --with-defaults &> /dev/null
make &> /dev/null
printf "  installing...\n"
make install &> /dev/null
cd ..
rm -rf net-snmp*

# symlink the library
ln -s /usr/local/lib/libnetsnmp.so.35 /usr/lib/ 2> /dev/null
ln -s /usr/local/lib/libnetsnmp.so.35 /usr/lib64/ 2> /dev/null

# re-build the snmp python extension
printf "  building python extension...\n"
cd $PRJ_DIR/pkg/snmp
#./build.sh &> /dev/null
./build.sh &> /dev/null
