#!/usr/bin/env python
from __future__ import division
import os, sys, re
from subprocess import getstatusoutput
sys.path.append("/opt/cisco/syfter/")
from common import linux
from common import textIO
import apt
import yum

postgres_version = 11
distro = linux.distro()
release = linux.release()[0]

command = "which psql"
(code, result) = getstatusoutput(command)

if code == 0:
    print("postgresql already installed!")
else:
    if distro in ['ubuntu', 'debian']:
        #
        # add postgres sources
        with open ('/etc/apt/sources.list.d/pgdg.list', 'wb') as f:
            distro_str = ''
            if distro == "debian":
                if release == 8:
                    distro_str = "jessie-pgdg"
                elif release == 9:
                    distro_str = "stretch-pgdg"
                elif release == 10:
                    distro_str = "buster-pgdg"
            elif distro == "ubuntu":
                if release in [16, 17]:
                    distro_str = "xenial-pgdg"
                elif release in [18, 19]:
                    distro_str = "bionic-pgdg"

            f.write(('deb http://apt.postgresql.org/pub/repos/apt/ %s main\n' % distro_str).encode())

        command = "wget --quiet -O - https://www.postgresql.org/media/keys/ACCC4CF8.asc | sudo apt-key add -"
        (code, result) = getstatusoutput(command)

        #
        # Install the packages
        apt_packages = [
            'postgresql-%s' % postgres_version,
            'postgresql-contrib-%s' % postgres_version,
            'postgresql-server-dev-%s' % postgres_version,
        ]

        apt.update()

        # loop through the apt packages
        for pkg in apt_packages:
            try:
                apt.install(pkg)
            except:
                print(textIO.warning("%s failed to install :-(" % pkg))
                sys.exit(code)

    elif distro in ['centos']:
        # add the postgres repository
        pkg = 'https://download.postgresql.org/pub/repos/yum/reporpms/EL-7-x86_64/pgdg-redhat-repo-latest.noarch.rpm'
        yum.install(pkg, quiet=True)

        #
        # Install the packages
        yum_packages = [
            'postgresql%s' % postgres_version,
            'postgresql%s-contrib' % postgres_version,
            'postgresql%s-devel' % postgres_version,
            'postgresql%s-server' % postgres_version,
        ]

        yum.update()

        # loop through the apt packages
        for pkg in yum_packages:
            try:
                yum.install(pkg)
            except:
                print(textIO.warning("%s failed to install :-(" % pkg))
                sys.exit(code)

        # run the initdb
        command = '`find / -name postgresql*-setup` initdb'
        (code, result) = getstatusoutput(command)
        # configure to run at startup
        command = 'systemctl enable postgresql-%s' % postgres_version
        (code, result) = getstatusoutput(command)
        # start the service
        command = 'service postgresql-%s restart' % postgres_version
        (code, result) = getstatusoutput(command)

# init the database
print("Creating the syfter database...")
command = "runuser -l postgres -c 'psql -c \"create database syfter\"'"
(code, result) = getstatusoutput(command)
print("Setting the database password...")
command = "runuser -l postgres -c \"psql -d syfter -c \\\"alter user postgres with password 'Fhnu5LzeghCt5L6zW7UG'\\\"\""
(code, result) = getstatusoutput(command)
if (code != 0):
    print(textIO.error(result))
