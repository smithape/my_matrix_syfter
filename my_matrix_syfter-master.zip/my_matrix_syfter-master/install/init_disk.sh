#!/bin/bash
echo -e "o\nn\np\n\n\n\nw\n" | fdisk /dev/sdb
mkfs -t ext4 /dev/sdb1
