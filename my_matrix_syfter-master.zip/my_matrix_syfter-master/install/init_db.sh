#!/bin/bash

while ! /opt/cisco/syfter/manage.py migrate; do
    echo "Database Initialization Failed!"
    sleep 5
    echo "Trying again..."
done

export DJANGO_SETTINGS_MODULE=syfter.settings
export PYTHONPATH=/opt/cisco/syfter/
architect partition -m common.models

