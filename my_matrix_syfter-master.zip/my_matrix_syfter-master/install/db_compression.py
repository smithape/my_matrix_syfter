#!/usr/bin/env python
from __future__ import division
import os, sys
from django.db import connection
from django.db.utils import ProgrammingError

sys.path.append("/opt/cisco/syfter/")
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "syfter.settings")

cursor = connection.cursor()

# Allow null sample values
cursor.execute("ALTER TABLE mtx_sample ALTER COLUMN value DROP NOT NULL;")

# get list of tables in the DB
tables = connection.introspection.table_names()

# Drop the 'count' column
for table_name in tables:
    if 'mtx_samplehr' in table_name:
        try:
            cursor.execute("ALTER TABLE %s DROP COLUMN count;" % table_name)
        except ProgrammingError: pass
