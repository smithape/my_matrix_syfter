#!/bin/bash
DIR=$( cd "$( dirname $BASH_SOURCE )" && pwd )
PRJ_DIR="$(dirname $DIR)"

apt_cmd='apt-get -q -o Acquire::ForceIPv4=true -y --fix-missing --allow-unauthenticated'

# install the packages
printf "  installing...\n"
$apt_cmd install snmpd snmp libsnmp-dev

# symlink the library
ln -s /usr/local/lib/libnetsnmp.so.30 /usr/lib/ 2> /dev/null
ln -s /usr/local/lib/libnetsnmp.so.30 /usr/lib64/ 2> /dev/null

# re-build the snmp python extension
printf "  building python extension...\n"
cd $PRJ_DIR/pkg/snmp
./build.sh &> /dev/null
