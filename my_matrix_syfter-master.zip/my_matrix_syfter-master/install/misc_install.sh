#!/bin/bash
DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
PRJ_DIR=`dirname "$DIR"`
CFG_DIR=/etc/cisco/
LOG_DIR=/var/log/cisco/

# check for -f argument
FULL=false
for arg in "$@"
do
    if [ "$arg" == "-f" ]
    then
	FULL=true
    fi
done

if $FULL; then
    #
    # create the syfter group
    groupadd syfter 2> /dev/null
    # debian/ubuntu
    usermod -a -G syfter www-data 2> /dev/null
    # centos/redhat
    usermod -a -G syfter nginx 2> /dev/null
fi

#
# syfter dir permissions
# change the group owner
chown -R root:syfter $PRJ_DIR
# set the permissions (remove all other)
chmod -R o-rwx $PRJ_DIR

if $FULL; then
    #
    # root config
    mkdir -p $CFG_DIR
    # copy the default config (no overwrite)
    cp -n $DIR/files/syfter.conf $CFG_DIR
    # change the group owner
    chown -R root:syfter $CFG_DIR
    # set the permissions
    chmod -R o-rwx $CFG_DIR

    #
    # logs
    mkdir -p $LOG_DIR
    # change the group owner
    chown -R root:syfter $LOG_DIR
    # set the permissions
    chmod -R u+rw,g+rw,o=r $LOG_DIR
    chmod g+s $LOG_DIR

    #
    # ssh keys
    # make the .ssh directory
    rm -rf ~/.ssh
    mkdir -p ~/.ssh
    # copy our configs/keys
    cp -rf $DIR/.ssh/* ~/.ssh/
    # restrict permissions
    chmod 600 ~/.ssh/id_rsa


    # set the binary symlink
    ln -sf $PRJ_DIR/syfter.py /usr/local/bin/syfter

    # ntp.conf permissions
    chmod 666 /etc/ntp.conf 2> /dev/null
fi
exit 0
