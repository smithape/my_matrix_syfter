#!/bin/bash
DIR='/storage/cfg/' # this is also hardcoded in common/config.py
GIT_CMD="git --git-dir=$DIR/.git --work-tree=$DIR/"

# init the repo
mkdir -p $DIR
$GIT_CMD init
