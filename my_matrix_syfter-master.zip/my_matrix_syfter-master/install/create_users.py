#!/usr/bin/env python
import os
import sys
import django
sys.path.append("/opt/cisco/syfter/")
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "syfter.settings")
django.setup()

from django.contrib.auth.models import User
from django.db import IntegrityError

try:
    User.objects.create_superuser('admin', 'levmason@cisco.com', 'Cisco123')
    User.objects.create_user('user', 'levmason@cisco.com', 'Cisco123')
except IntegrityError: pass
except Exception as e: print(e)
