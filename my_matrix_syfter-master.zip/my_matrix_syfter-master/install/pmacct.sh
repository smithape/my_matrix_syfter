#!/bin/bash
apt_cmd='apt-get -q -o Acquire::ForceIPv4=true -y --force-yes --fix-missing --allow-unauthenticated'

$apt_cmd update

printf "\ninstalling dependencies...\n"
$apt_cmd install libpcap-dev pkg-config libjansson-dev libtool automake

printf "\ndownloading pmacct...\n"
cd /tmp/
wget https://github.com/pmacct/pmacct/archive/master.zip
unzip master.zip
cd pmacct-master
printf "\ninstalling pmacct...\n"
./autogen.sh
./configure --enable-jansson
make; make install
cd ..
rm -rf master.zip
rm -rf pmacct-master
