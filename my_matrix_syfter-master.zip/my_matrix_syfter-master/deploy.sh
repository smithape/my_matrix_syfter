#!/bin/bash
python manage.py collectstatic --noinput
# For a nginx/gunicorn deployment
#syfter server restart
# For an apache deployment
#touch syfter/wsgi.py
