import time
from threading import Thread
from multiprocessing.pool import ThreadPool, Pool
import traceback
from functools import reduce

from common.PeriodicThread import PeriodicThread
from common import \
    utility, \
    config as cfg, \
    logger as log, \
    DB

class ReporterDaemon():
    def __init__(self):
        self.stdin_path = '/dev/null'
        self.stdout_path = '/dev/tty'
        self.stderr_path = '/dev/tty'
        self.pidfile_path =  '/var/run/%s_reporter.pid' % cfg.tool_name
        self.pidfile_timeout = 1
        self.interrupt = False

    def run(self):
        cfg.reporter = Reporter()

        try:
            cfg.reporter.start()
            while not self.interrupt:
                time.sleep(1)
        except Exception as e:
            log.debug((traceback.format_exc()))
        finally:
            try:
                cfg.reporter.stop()
            except:
                log.debug("exception in reporter shutdown")
                log.debug(traceback.format_exc())

    def terminate(self, signal_number, stack_frame):
        self.interrupt = True

class Reporter (object):

    def __init__ (self):
        self.monitor_t = None

        # init the db manager
        DB.init()

        # start the thread that stores logs to the DB
        log.start()

        now = int(time.time())
        self.tstamp_d = {
            'start': now,
            'client_monitor': 0,
            'ap_monitor': now,
            'device_scan': now,
            'maintenance': now - cfg.maintenance_hour * 3600 - time.altzone,
            'event_baseline' : 0,
            'event_detect' : 0,
            'stats_update' : now,
            'watchdog' : now,
            'idf_neighbor_scan' : now,
            'idf_monitor' : now,
            }


    def start (self):
        """ start the reporting engine """

        log.debug("starting")
        try:
            self.init_config()
        except Exception as e:
            log.debug(e)

        # find the monitor thread period
        self.monitor_period = cfg.baseline_period

        # Start the monitor thread
        self.monitor_t = PeriodicThread(name="monitor",
                                        interval=self.monitor_period,
                                        action=self.monitor,
                                        daemon=True)
        self.monitor_t.start(time.time() + self.monitor_period)


    def stop (self):
        # stop the monitor thread
        if self.monitor_t:
            self.monitor_t.stop()

    def monitor (self):
        now = int(time.time())

    def init_config (self):
        #pool = ThreadPool(processes=200)
        for device in cfg.devices().values():
            # get the initial kpi vars
            if hasattr(device, "query_kpi_vars"):
                device.query_kpi_vars()

            device.init_polling_config()
            device.update_polling_config()
            log.debug(list(device.kpi_d.keys()))
            #pool.apply_async(device.init_reporting_config)
        #pool.close()
        #pool.join()
