import math
import sys, os, time, sched, traceback, signal
from datetime import datetime, timedelta
from fractions import gcd
from threading import Thread
from multiprocessing.pool import ThreadPool, Pool
import queue
import asyncore
from subprocess import getstatusoutput
import re
import random
import json

from django.core.exceptions import ObjectDoesNotExist
from django.db.models import Q
from django.utils import timezone
from pkg import pexpect
import psutil

from device.RootDevice import RootDevice
from .PollerServer import PollerServer
from common.models import \
    State as State_db
from device.CiscoSwitch import CiscoSwitch
from common.Client import ClientManager
from common.PeriodicThread import PeriodicThread
from common.SNMPEngine import SNMPEngine, SNMPEngineTimeout
from common import \
    utility, \
    config as cfg, \
    logger as log, \
    DB, \
    Event, \
    Report
from nugget import Nugget
from functools import reduce

class PollerDaemon():
    def __init__(self):
        self.stdin_path = '/dev/null'
        self.stdout_path = '/dev/tty'
        self.stderr_path = '/dev/tty'
        self.pidfile_path =  cfg.get_pidfile('poller')
        self.pidfile_timeout = 1
        self.interrupt = False
        self.server_t = Thread(target=asyncore.loop, kwargs={'timeout':1, 'use_poll': True})


    def run(self):
        cfg.poller = Poller()
        self.server = PollerServer('localhost', cfg.poller_server_port)
        try:
            self.server_t.start()
            cfg.poller.start()
            while not self.interrupt:
                time.sleep(1)
        except Exception as e:
            log.debug((traceback.format_exc()))
        finally:
            try:
                cfg.poller.stop()
                self.server.close()
            except:
                log.debug("exception in poller shutdown")
                log.debug(traceback.format_exc())

    def terminate(self, signal_number, stack_frame):
        self.interrupt = True


class Poller (object):

    def __init__ (self):
        self.status = ""
        self.sample_q = queue.Queue()
        self.stopping = False
        self.client_mgr = ClientManager(self)
        self.snmpEngine = SNMPEngine()
        self.root_device = RootDevice()
        self.root_device_t = None
        self.monitor_t = None
        self.ap_monitor_t = None
        self.idf_monitor_t = None
        self.vdevice_t = None
        self.vdevice_rebuild = False
        self.vdevice_d = {}
        self.db_insert_t = None
        # full including the vdevices
        self.device_d = {}
        self.sample_count = 0
        self.write_rate = 0
        self.poll_rate = 0
        self.poll_timer = 0
        self.stagger_span = 0
        self.scanned_idf_count = 0

        # init the db manager
        DB.init()

        # start the thread that stores logs to the DB
        log.start()

        # init the statistics dictionary
        self.stats = {}

        # Initialize the timestamp dictionary. This dictionary is used for
        # periodic monitor/maintenance functions and stores the last runtime
        # for the various functions. An initial value of 0 means the function
        # hasn't been run yet
        now = int(time.time())
        self.tstamp_d = {
            'start': now,
            'client_monitor': 0,
            'ap_monitor': now,
            'device_scan': now,
            'maintenance': now - cfg.maintenance_hour * 3600 - time.altzone,
            'event_baseline' : 0,
            'event_detect' : 0,
            'stats_update' : now,
            'watchdog' : now,
            'idf_neighbor_scan' : now,
            'idf_monitor' : now,
            }

    def start (self):
        """ start the polling engine """

        log.info("Starting polling engine", "system")
        self.status = "scanning"

        # restore the client manager state
        self.client_mgr.restore_state()

        # get the previous shutdown state
        shutdown_success = False
        try:
            value = State_db.objects.get(name="shutdown").value
            if value == "success":
                shutdown_success = True
        except State_db.DoesNotExist: pass

        # overwrite the previous shutdown state
        db_row = {'timestamp': timezone.now(), 'value': ""}
        s, created = State_db.objects.update_or_create(name="shutdown", defaults=db_row)

        for device in cfg.devices().values():
            # check reachability
            device.is_up(check=True)


        # convert IP address to hostnames
        thread_l = []
        for device in cfg.devices().values():
            if (device.is_up() and
                device.snmp.is_up() and
                utility.is_valid_ip_address(device.name)):
                t = Thread(target=device.snmp_get_hostname)
                thread_l.append(t)
                t.start()
        # wait for threads to end
        for t in thread_l:
            t.join()

        # add the localhost device
        cfg.device_d['localhost'] = cfg.init_device_object('localhost', device_type='LocalHost')

        # scan the network
        self.scan()

        if not cfg.devices():
            self.stop()

        # start the snmp engine
        self.snmpEngine.start()
        cfg.snmpEngine = self.snmpEngine

        # add devices to the DB
        for device in cfg.devices().values():
            DB.db.add_device(device)

        self.status = "starting"

        # init the polling configs
        log.debug("Initializing polling configs...")
        pool = ThreadPool(processes=200)
        for device in cfg.devices().values():
            try:
                device.init_polling_config()
            except Exception as e:
                log.debug((traceback.format_exc()))
                #pool.apply_async(device.init_polling_config)
        pool.close()
        pool.join()

        # init virtual devices
        for group_name, group in cfg.group_d.items():
            for vdevice_name, vdevice in group.vdevice_d.items():
                # add to the DB
                DB.db.add_device(vdevice)

                # initialize the nugget_d
                if vdevice.aggregation:
                    vdevice.init_polling_config()

                # add to the dict
                self.vdevice_d[vdevice_name] = vdevice

        # initialize the full device_d (including virtual devices)
        self.device_d = dict(cfg.device_d, **self.vdevice_d)

        # initialize the nugget config
        self.init_nugget_cfg_d()

        # dump into redis
        self.redis_dump()

        # Start device terminal sessions
        self.start_terminal_sessions(cfg.devices().values())

        # trim the polling configs
        for device in cfg.devices().values():
            device.update_polling_config()

        # Start device-centric polling threads
        self.start_polling_threads()

        # Start the root_device thread
        # LEVY: remove when replacing dashboard
        self.root_device_t = PeriodicThread(name="root_device",
                                            interval=cfg.root_poll_period,
                                            action=self.poll_root_device)
        self.root_device_t.start(time.time() + cfg.root_poll_period)

        # Start the virtual_device thread
        try:
            self.vdevice_period = min(x.schedule for x in self.vdevice_d.values()
                                      if x.aggregation and x.periodic and x.schedule)

            self.vdevice_t = PeriodicThread(name="virtual_device",
                                            interval=self.vdevice_period,
                                            action=self.poll_virtual_devices)
            if cfg.poll_bulk:
                start_time = period * math.ceil(time.time() / period)
            else:
                start_time = time.time()

            self.vdevice_t.start(start_time + self.stagger_span)
        except ValueError: pass

        # Start the db_insert thread
        self.db_insert_t = Thread(name="db_insert",
                                  target=self.db_insert,
                                  args=[cfg.db_insert_period]
        )
        # self.db_insert_t = PeriodicThread(name="db_insert",
        #                                   interval=cfg.db_insert_period,
        #                                   action=self.db_insert)
        self.db_insert_t.start()

        # find the monitor thread period
        self.monitor_period = reduce(gcd,
                                     [60,
                                      cfg.poller_stats_update_period,
                                      cfg.ap_monitor_period,
                                      cfg.event_detection_period,
                                      cfg.baseline_period])

        # Start the monitor thread
        self.monitor_t = PeriodicThread(name="poller/monitor",
                                        interval=self.monitor_period,
                                        action=self.monitor,
                                        daemon=True)
        self.monitor_t.start(time.time() + self.monitor_period)

        self.status = "running"


    def stop (self):
        self.status = "stopping"

        # set the "stopping" flag
        self.stopping = True

        # stop the monitor thread
        if self.monitor_t:
            self.monitor_t.stop()

        # save the client manager state
        self.client_mgr.save_state()

        # save the event detector state
        # if cfg.event_detection and self.event_detector:
        #     self.event_detector.save()

        # stop the root device thread
        if self.root_device_t:
            self.root_device_t.stop()

        # stop the virtual device thread
        if self.vdevice_t:
            self.vdevice_t.stop()

        # stop all of the polling threads
        self.stop_polling_threads()

        # stop the snmp engine
        self.snmpEngine.stop()

        # null-terminate the series
        log.debug("Terminating series...")
        timestamp = int(time.time()) + 1
        t_start = time.time()
        sample_l = self.series_terminate(timestamp)
        self.bulk_insert(sample_l)
        log.debug("...done (%.2fs)" % (time.time() - t_start))

        # # stop the root device thread
        # if self.db_insert_t:
        #     self.db_insert_t.stop()

        # was it a successful shutdown?
        db_row = {'timestamp': timezone.now(), 'value': "success"}
        s, created = State_db.objects.update_or_create(name="shutdown", defaults=db_row)

    def init_nugget_cfg_d (self):
        # build the datatype dictionary
        nugget_cfg_d = {}
        for dtype in Nugget.nugget_config:
            for nugget_name, nugget_cfg in Nugget.nugget_config[dtype].items():
                nugget_cfg_d[nugget_name] = {
                    'datatype': nugget_cfg.get('datatype'),
                    'unit': nugget_cfg.get('unit'),
                    'description': nugget_cfg.get('description', '')
                }

        self.nugget_cfg_d = nugget_cfg_d

    def redis_dump (self):
        # dump into redis
        DB.redis.set('device_d', json.dumps({x.name:x.get_device_d() for x in cfg.device_d.values()}).encode())
        DB.redis.set('device_d_full', json.dumps({x.name:x.get_device_d(full=True) for x in cfg.device_d.values()}).encode())
        DB.redis.set('vdevice_d', json.dumps({x.name:x.get_device_d() for x in self.vdevice_d.values()}).encode())
        DB.redis.set('group_l', json.dumps([x.as_dict() for x in cfg.group_d.values() if x.name != "AP"]).encode())
        self.redis_dump_nugget_cfg(update_d = self.nugget_cfg_d)

    def redis_dump_nugget_cfg (self, update_d = None):
        DB.redis.set('nugget_cfg_d', json.dumps(self.nugget_cfg_d).encode())
        if update_d:
            utility.db_publish("nugget_cfg", update_d)


    def rescan_needed (self):
        """
        determine whether we should rescan the network (via snmp)
        """
        now = int(time.time())

        # has the scan period elapsed?
        if (now - self.tstamp_d['device_scan']) >= cfg.scan_period:
            return True

        # are APs down?
        for ap in cfg.devices(dtype="CiscoAP").values():
            if (not ap.is_up() or
                ('term_down' in ap.code_d and
                 now - ap.code_d['term_down']['timestamp'] > 300)):
                return True

    def ap_monitor (self):
        to_stop = []
        to_start = []

        #
        # Check APs that are down
        for key, ap in cfg.devices(dtype="CiscoAP").items():
            if not ap.is_up():
                if (time.time() - ap.code_d['down']['timestamp']) > cfg.ap_hold_time:
                    log.info("Removing AP", "device", device=ap)
                    # queue for stopping later
                    to_stop.append(ap)
                    # remove from the global dictionary
                    del cfg.device_d[key]

        if self.rescan_needed():
            t_start = time.time()
            # Scan the network (discover APs/switches)
            ap_d = {}

            #
            # scan each wlc
            for wlc in cfg.devices(dtype="CiscoWLC").values():
                ap_d.update(wlc.ap_scan())

            # by mac address
            ap_macaddr_d = {}
            for ap in ap_d.values():
                ap_macaddr_d[ap.mac_address] = ap

            #
            # Remove APs that weren't in the recent scan
            for ap_name, ap in cfg.devices(dtype="CiscoAP").items():
                if ap_name not in ap_d and ap.mac_address in ap_macaddr_d:
                    log.info("Removing AP (not in recent scan)", "device", device=ap)
                    # queue for stopping later
                    to_stop.append(ap)
                    # remove from the global dictionary
                    del cfg.device_d[ap_name]

            t_end = time.time()
            log.debug("rescan took (%.2fs)" % (t_end - t_start))

            #
            # Check for new/changed APs
            for key, ap in ap_d.items():
                if key not in cfg.device_d:
                    log.info("Adding AP", "device", device=ap)
                    # add to the global dictionary
                    cfg.device_d[key] = ap
                    # add entry to the database
                    DB.db.add_device(ap)
                    # start the thread
                    to_start.append(ap)

                # update devices that have changed
                elif not cfg.device_d[key].equals_other(ap):
                    ap_old = cfg.device_d[key]
                    ap_old.update_other = ap

            # LEVY: check for duplicate APs here

            self.tstamp_d['device_scan'] = time.time()

            #
            # find switches for failed-CDP APs
            self.fix_missing_cdp()

            # initialize switch stuff
            self.init_switches()

            # dump into redis
            self.redis_dump()

        # refresh groups (and associated db entries)
        for device in cfg.devices().values():
            device.set_groups()
            DB.db.add_device(device)

        pool = ThreadPool(processes=100)
        #
        # Execute thread stops
        for x in to_stop:
            pool.apply_async(x.stop_polling_thread)

        #
        # Execute thread starts
        if to_start:
            # Start device terminal sessions
            self.start_terminal_sessions(to_start)

            # Execute thread starts
            for ap in to_start:
                pool.apply_async(self.to_start_helper, args=[ap])

        pool.close()
        pool.join()

        #
        # rebuild the virtual devices to include new devices
        self.vdevice_rebuild = True

    def to_start_helper(self, ap):
        ap.init_polling_config()
        if ap.cli_session_required():
            ap.cli.set_session()
        ap.update_polling_config()
        offset = random.randrange(0, self.stagger_span)
        ap.start_polling_thread(offset)

    def monitor (self):
        now = int(time.time())
        day = utility.epoch_to_day(now)
        local_hour = datetime.now().hour
        try:
            # gather polling stats
            if now - self.tstamp_d['stats_update'] >= cfg.poller_stats_update_period:
                last = self.tstamp_d['stats_update']
                self.tstamp_d['stats_update'] = now
                self.polling_stats(now, last)

            # client_monitor
            if now - self.tstamp_d['client_monitor'] >= cfg.client_monitor_period:
                self.tstamp_d['client_monitor'] = now
                Thread(target=self.client_mgr.monitor).start()

            # ap_monitor
            if now - self.tstamp_d['ap_monitor'] >= cfg.ap_monitor_period:
                if self.ap_monitor_t and self.ap_monitor_t.isAlive():
                    log.warning("Device scan running long (iteration missed)", "system")
                else:
                    self.tstamp_d['ap_monitor'] = now
                    self.ap_monitor_t = Thread(target=self.ap_monitor)
                    self.ap_monitor_t.start()

            # first check if idf devices are configured
            if len(cfg.devices(dtype="CiscoIDF")) > 0:
                if now - self.tstamp_d['idf_neighbor_scan'] >= cfg.idf_neighbor_scan_period or (now - self.tstamp_d['idf_monitor'] >= cfg.idf_monitor_period and self.scanned_idf_count < len(cfg.devices(dtype="CiscoIDF"))):
                    if self.idf_monitor_t and self.idf_monitor_t.isAlive():
                        log.warning("IDF monitor running long (iteration missed)", "system")
                    else:
                        self.tstamp_d['idf_monitor'] = now
                        self.idf_monitor_t = Thread(target=self.idf_monitor)
                        self.idf_monitor_t.start()

            # set baseline
            if now - self.tstamp_d['event_baseline'] >= cfg.baseline_period:
                self.tstamp_d['event_baseline'] = now
                for vdevice in self.vdevice_d.values():
                    if vdevice.event_detector:
                        Thread(target=vdevice.event_detector.set_baseline).start()
                        # event detect
            if now - self.tstamp_d['event_detect'] >= cfg.event_detection_period:
                self.tstamp_d['event_detect'] = now
                for vdevice in self.vdevice_d.values():
                    if vdevice.event_detector:
                        vdevice.event_detector.detect()

            # # maintenance
            # last_day = utility.epoch_to_day(self.tstamp_d['maintenance'])
            # if (local_hour == cfg.maintenance_hour and last_day != day):
            #     self.tstamp_d['maintenance'] = now

            #     # Disk Usage Warning
            #     disk_usage = psutil.disk_usage(DB.db.dir).percent
            #     if disk_usage > cfg.disk_usage_error:
            #         utility.send_email("Disk Usage Warning",
            #                            message=("Disk usage is %s%%" % disk_usage))

            #     # Nightly Report
            #     recipients = cfg.nightly_email
            #     today = utility.datetime_to_day(datetime.now())
            #     yesterday = today - timedelta(days=1)
            #     date_str = yesterday.strftime('%m-%d-%Y')
            #     event = Event.create_event(utility.datetime_to_epoch(yesterday, local=True),
            #                                utility.datetime_to_epoch(today, local=True))
            #     Report.send_report("Nightly Report %s" % date_str,
            #                        event, 'admin', mailto=recipients)

            #     # client report
            #     start = now - 86400
            #     self.client_mgr.report(start, now)
        except Exception as e:
            log.debug(e)
        # # Resend last client report
        # end = datetime.now().replace(hour=cfg.maintenance_hour, minute=0, second=0, microsecond=0)
        # end = utility.datetime_to_epoch(end, local=True)
        # self.client_mgr.report(end - 86400, end)

    def polling_stats (self, now, last):
        health = {}
        #
        # poll/write statistics
        self.poll_rate = self.sample_count / (now - last)
        # get the write rate from the DB daemon
        try:
            self.write_rate = float(utility.db_query({"name": "write_rate"}))
        except ValueError:
            self.write_rate = 0

        # check the watchdog
        if self.write_rate >= self.poll_rate:
            self.tstamp_d['watchdog'] = now
            health['poll_rate'] = 'ok'
        elif now - self.tstamp_d['watchdog'] >= cfg.watchdog_timer:
            if self.write_rate == 0:
                utility.send_email("I'm dead!")
                health['poll_rate'] = 'critical'
            else:
                utility.send_email("I'm dying!")
                health['poll_rate'] = 'warning'
            self.tstamp_d['watchdog'] = now

        # reset the counters
        self.sample_count = 0

        #
        # poll timers
        total_timer = 0
        total_timer_count = 0
        #min_timer = 60
        #max_timer = 0
        for device in cfg.devices().values():
            if device.poll_thread and device.poll_thread.max_timer:
                total_timer_count += 1
                total_timer += device.poll_thread.max_timer
                #max_timer = max(max_timer, device.poll_thread.max_timer)
                #min_timer = min(min_timer, device.poll_thread.max_timer)
                device.poll_thread.max_timer = 0
        try:
            #print(min_timer, max_timer)
            self.poll_timer = total_timer / total_timer_count
        except ZeroDivisionError: pass

        #
        # missed polling iterations
        device_d = {}
        total_missed = 0
        total_iterations = 0
        for device in cfg.devices().values():
            if device.poll_thread:
                iterations = device.poll_thread.iterations
                missed = device.poll_thread.missed_iterations
                if missed:
                    total_missed += missed
                    total_iterations += iterations
                    device_d[device.name] = (missed, iterations)

                # reset the counters
                device.poll_thread.iterations = 0
                device.poll_thread.missed_iterations = 0

        if len(device_d) == 0:
            health['poll_success_rate'] = "ok"
        elif len(device_d) > 20:
            log.warning("%d devices are missing polling iterations! (%d/%d missed)" %
                        (len(device_d), total_missed, total_iterations), "system")
            health['poll_success_rate'] = "critical"
        else:
            health['poll_success_rate'] = "warning"
            for device_name, (missed, total) in device_d.items():
                if missed / total > 0.5:
                    device = cfg.device_d[device_name]
                    log.warning("Missing polling iterations! (%d/%d missed)" % (missed, total), "system", device=device)

        health['uptime_seconds'] = now - self.tstamp_d['start']
        DB.redis.set('%s.poller.health' % cfg.tool_name, json.dumps(health).encode(),
                     ex=(self.monitor_t.interval * 2))

    def scan (self):
        # Scan the network (discover APs/switches)
        t_start = time.time()
        dev_d = {}

        # scan each nfvi
        for dev in cfg.devices().values():
            if dev.is_up() and hasattr(dev, 'scan'):
                dev_d.update(dev.scan())

        #
        # scan each wlc
        for wlc in cfg.devices(dtype="CiscoWLC").values():
            dev_d.update(wlc.ap_scan())

        #
        # Add APs to the config
        i = 0
        for key, device in dev_d.items():
            # add the ap to the global dictionary
            cfg.device_d[key] = device
            i += 1

        log.debug("scanning switches...")
        #
        # find switches for failed-CDP APs
        self.fix_missing_cdp()

        # initialize switch stuff
        self.init_switches()

        # find neighbors for CiscoIDF device
        self.idf_monitor()


        # match devices into groups
        for device in cfg.devices().values():
            if not device.group_d:
                device.set_groups()

        t_end = time.time()
        log.debug("scan took (%.2fs)" % (t_end - t_start))

        self.tstamp_d['device_scan'] = time.time()

    def start_terminal_sessions (self, device_l):
        log.debug("Starting terminal sessions...")

        t_start = time.time()
        if True:
            # thread pool method
            pool = ThreadPool(processes=100)
            for device in device_l:
                if (device.cli.is_up() and
                    not device.cli.is_alive() and
                    device.cli_session_required()):

                    # initialize the session in the thread pool
                    pool.apply_async(device.cli.set_session, kwds={'quiet': True})
                    # take a break
                    time.sleep(0.1)

            # wait for threads to end
            pool.close()
            pool.join()
        else:
            # thread method
            thread_l = []
            for device in device_l:
                if (device.cli.is_up() and
                    not device.cli.is_alive() and
                    device.cli_session_required()):

                    # initialize the session in a thread
                    t = Thread(target=device.cli.set_session, kwargs={'quiet': True})
                    thread_l.append(t)
                    t.start()

                    # take a break
                    time.sleep(0.1)

            # wait for threads to end
            for t in thread_l:
                t.join()

        # find failed CLI sessions
        failed_count = len([x for x in device_l if 'term_fail' in x.code_d])
        if failed_count:
            log.error("%s terminal sessions failed! (see Conditions)" % failed_count,
                      "config")

        t_end = time.time()
        log.info("Terminal sessions started (%.2fs)" % (t_end - t_start), "system")

    def init_switches (self):
        #
        # Find shorter switch names
        thread_l = []
        for switch in cfg.devices(dtype="CiscoSwitch").values():
            if (switch.is_up() and
                not hasattr(switch, "hostname") and
                not switch.configured):
                t = Thread(target=switch.snmp_get_hostname)
                thread_l.append(t)
                t.start()
        # wait for threads to end
        for t in thread_l:
            t.join()

        #
        # Scan for switch interfaces
        thread_l = []
        for switch in cfg.devices(dtype="CiscoSwitch").values():
            if switch.is_up():
                t = Thread(target=switch.set_ap_ifindex)
                thread_l.append(t)
                t.start()
        # wait for threads to end
        for t in thread_l:
            t.join()

    def start_polling_threads (self):
        log.debug("Starting polling threads...")

        t_start = time.time()
        thread_l = []

        #
        # First, start non-AP devices
        for key, device in cfg.devices().items():
            if device.type != "CiscoAP":
                t = Thread(target=device.start_polling_thread)
                thread_l.append(t)
                t.start()

        #
        # Next, start APs
        ap_d = cfg.devices(dtype="CiscoAP")
        if ap_d and cfg.poll_stagger:
            # find the min AP polling interval
            self.stagger_span = cfg.poll_stagger_span or min([ap.polling_interval for ap in ap_d.values()])
            stagger_group_size = math.ceil(len(ap_d) / (self.stagger_span * cfg.poll_stagger_interval))

        i = 0
        offset = 0
        for key, device in ap_d.items():
            # do we need to take a break?
            if cfg.poll_stagger and stagger_group_size and i and i % stagger_group_size == 0:
                offset += cfg.poll_stagger_interval

            t = Thread(target=device.start_polling_thread, args=(offset,))
            thread_l.append(t)
            t.start()

            i += 1

        # wait for threads to end
        for t in thread_l:
            t.join()

        log.info("Polling threads started (%.2fs)" % (time.time() - t_start), "system")

    def idf_monitor(self):

        now = int(time.time())
        devices = cfg.devices(dtype="CiscoIDF")

        if now - self.tstamp_d['idf_neighbor_scan'] >= cfg.idf_neighbor_scan_period:
            self.tstamp_d['idf_neighbor_scan'] = now
            self.scanned_idf_count = 0
            for device in devices.values():
                self.idf_neighbor_scan(device)
        else:
            for device in devices.values():
                if not device.neighbor_scanned:
                    self.idf_neighbor_scan(device)

    def idf_neighbor_scan(self, device):
        # call neighbor scan for input device
        if device.ssh_is_up():
            cdp_neighbors = device.neighbor_scan()
            self.send_report("idf_neighbors", device, cdp_neighbors)
            self.scanned_idf_count += 1
        else:
            device.neighbor_scanned = False

    def fix_missing_cdp (self):
        #
        # find switches for failed-CDP APs
        pool = ThreadPool(processes=400)
        res_d = {}
        for ap_name, ap in cfg.devices(dtype="CiscoAP").items():
            if ap.switch_info_required() and ap.switch is None:
                res_d[ap_name] = pool.apply_async(ap.find_upstream_switch)
        # wait for threads to end
        pool.close()
        pool.join()

        # loop through the switches
        for ap_name, res in res_d.items():
            res = res.get()
            if res:
                switch_name, switch_ip, switch_if = res
                # find/create the switch
                try:
                    # see if the switch is already discovered
                    switch = cfg.device_by_ip_d[switch_ip]
                except KeyError:
                    # Initialize a new switch object
                    switch = CiscoSwitch(switch_ip) # temp name
                    switch.ip_address = switch_ip
                    # pull in the snmp configuration
                    switch.reload_cfg()
                    # Get the switch name
                    switch.name = switch_name

                    cfg.device_by_ip_d[switch_ip] = switch
                    cfg.device_d[switch.name] = switch

                cfg.device_d[ap_name].switch = switch
                cfg.device_d[ap_name].switch_ifname = switch_if

    def stop_polling_threads (self):
        """stop all of the per-device periodic polling threads"""

        log.debug("Stopping polling threads...")
        thread_l = []
        for device in cfg.devices().values():
            t = Thread(target=device.stop_polling_thread)
            thread_l.append(t)
            t.start()
        for t in thread_l:
            t.join()

        log.debug("...done")

    def db_insert_new (self):
        try:
            sample_l = []

            # read from devices
            for device_name, device in self.device_d.items():
                try:
                    while True:
                        try:
                            sample_l.append(device.sample_q.get(False))
                        except queue.Empty: break
                except IOError: break
                except:
                    log.debug("Unexpected Error: %s" % traceback.format_exc())
                    utility.send_email("Unexpected Error: %s" % traceback.format_exc())


            # bulk write the samples
            self.sample_count = len(sample_l)
            self.bulk_insert(sample_l)
        except:
            utility.send_email("Unexpected Error: %s" % traceback.format_exc())

    def db_insert (self, interval):
        # initialize
        break_time = time.time() + interval

        # loop until we shut down
        while not self.stopping:
            try:
                # read from the queue
                sample_l = []
                nugget_cfg_d = {}
                while not self.stopping:
                    try:
                        s = self.sample_q.get(timeout=1)
                        sample_l.append(s)

                        # see if we have new Nuggets to publish
                        timestamp, device_name, nugget_name, value = s
                        nugget_name_root = nugget_name.split(':', 1)[0]
                        if nugget_name_root not in self.nugget_cfg_d:
                            nugget_cfg = cfg.device_d[device_name].nugget_d[nugget_name].cfg
                            self.nugget_cfg_d[nugget_name_root] = nugget_cfg_d[nugget_name_root] = {
                                'datatype': nugget_cfg.get('datatype'),
                                'description': nugget_cfg.get('description', '')

                            }
                    except queue.Empty: break
                    except IOError: break
                    except:
                        utility.send_email("Unexpected Error: %s" % traceback.format_exc())

                    if time.time() > break_time and sample_l:
                        break

                # set the next breakpoint
                break_time += interval

                # are we shutting down?
                if self.stopping:
                    return

                # publish new Nuggets
                if nugget_cfg_d:
                    # update the redis cache
                    self.redis_dump_nugget_cfg(update_d = nugget_cfg_d)

                # publish samples
                self.sample_count = len(sample_l)
                self.bulk_insert(sample_l)
            except:
                utility.send_email("Unexpected Error: %s" % traceback.format_exc())

    def bulk_insert (self, sample_l):
        if sample_l:
            # bulk write the samples
            query = {
                'name' : "bulk_insert",
                'options' : {
                    "sample_l": sample_l
                }
            }
            utility.db_query(query)

    def series_terminate (self, timestamp, startup=False):
        sample_l = []

        # combine devices and vdevices
        #device_d = cfg.device_d.copy()
        #device_d.update(self.vdevice_d)

        # loop through real devices
        for device_name, device in self.device_d.items():
            for nugget_name, entry in device.nugget_d.items():
                if entry.store and (startup or entry.prev_value is not None):

                    # add null
                    r = (timestamp, device_name, nugget_name, None)
                    self.sample_q.put(r)
                if entry.cfg.get("incremental_process") == "timestamped_entries":
                    # store the latest timestamp in redis
                    DB.redis.set("%s/%s" % (device.name, entry.name),
                                 json.dumps(entry.latest_log_timestamp).encode())

    def send_report(self, field, device, sample_l):

        if sample_l:

            query = {
                'name' : "send_report",
                'options' : {
                    "field": field,
                    "report": sample_l,
                    "device": device.name
                }
            }
            utility.db_query(query)


    def poll_root_device (self):
        # for status polling
        # LEVY: This is probably temporary
        self.stats['top_aps_tput'] = self.root_device.top_ethThroughput();
        self.stats['top_aps_count'] = self.root_device.top_clientCount();

    def poll_virtual_devices (self):
        # rebuild the virtual devices to include new devices
        if self.vdevice_rebuild:
            try:
                for vdev in self.vdevice_d.values():
                    # initialize the nugget_d
                    if vdev.aggregation:
                        vdev.init_polling_config()
            finally:
                self.vdevice_rebuild = False

        # AP groups
        sample_l = []
        for vdev in self.vdevice_d.values():
            if vdev.aggregation:
                vdev.poll(self.vdevice_period)
