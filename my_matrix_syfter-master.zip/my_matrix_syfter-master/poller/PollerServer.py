import time
from collections import OrderedDict
import asyncore, socket
import json
import re

from common import config as cfg
from common import utility

class PollerServer(asyncore.dispatcher):
    def __init__ (self, host, port):
        asyncore.dispatcher.__init__(self)
        self.create_socket(socket.AF_INET, socket.SOCK_STREAM)
        self.set_reuse_addr()
        self.bind((host, port))
        self.listen(5)

    def handle_accept(self):
        pair = self.accept()
        if pair is not None:
            sock, addr = pair
            handler = EchoHandler(sock)

    def handle_close(self):
        self.close()
        return

class EchoHandler(asyncore.dispatcher):
    def __init__ (self, sock, chunk_size=512):
        asyncore.dispatcher.__init__(self, sock=sock)
        self.chunk_size = chunk_size
        self.data_to_write = []

    def handle_read(self):
        data = {}
        try:
            request = json.loads(self.recv(1024).decode())
        except:
            self.data_to_write.insert(0, json.dumps(data).encode())
            return

        query = request['name'].lower()

        response = ""
        if query == "status":
            # status string
            data['status'] = cfg.poller.status
            data['start_time'] = cfg.poller.tstamp_d['start'] * 1000

            # get the device count
            counters = {}
            for device in cfg.devices().values():
                if device.type not in ['LocalHost']:
                    dtype = device.type.replace("Cisco", "")
                    if dtype not in counters:
                        counters[dtype] = 0

                    # add one to the count
                    counters[dtype] += 1

            # get the error codes
            code_d = {}
            for device_name, device in cfg.devices().items():
                for code,x in device.get_codes().items():
                    if code not in code_d:
                        code_d[code] = {
                            'msg': x['msg'],
                            'sev': x['sev'],
                            'devices': []
                            }
                    code_d[code]['devices'].append(device.name)

            # build the return object
            data['counters'] = counters
            data['issues'] = code_d

            # get disk write stats
            data['stats'] = {
                'poll_timer': round(cfg.poller.poll_timer, 2),
                'poll_rate': round(cfg.poller.poll_rate, 2),
                'write_rate': round(cfg.poller.write_rate, 2),
                }

        elif query == "stats":
            data = cfg.poller.stats
        elif query == "device_status":
            device_name = request['options']['device_name']
            data = get_device_status(device_name)
        elif query == "test_snmp":
            device_name = request['options']['device_name']
            data = test_snmp(device_name)
        elif query == "test_ping":
            device_name = request['options']['device_name']
            data = test_ping(device_name)
        elif query == "conditions":
            _type = request['options']['type']
            min_severity = request['options']['min_severity']
            group = request['options']['group']
            data = conditions(_type, min_severity, group)
        elif query == "top_devices":
            device_type = request['options']['device_type']
            nugget_name = request['options']['nugget_name']
            filter_re = request['options']['filter']
            group = request['options']['filter']
            n = request['options']['n']

            data = top_devices(device_type, nugget_name, filter_re, group, n)

        elif query == "latest_value":
            device_name = request['options']['device_name']
            nugget_name = request['options']['nugget_name']

            data = get_latest_value(device_name, nugget_name)

        elif query == "series_buffer":
            device_name = request['options']['device_name']
            nugget_name = request['options']['nugget_name']

            data = get_series_buffer(device_name, nugget_name)

        elif query == "series_trace":
            device_name = request['options']['device_name']
            nugget_name = request['options']['nugget_name']

            data = get_series_trace(device_name, nugget_name)

        elif query == "event_status":
            data = get_event_status()

        elif query == "metric_presence":
            group = request['options']['group']
            data = metric_presence(group)

        elif query == "client_list":
            data = client_list()

        elif query == "client_count":
            data = client_count()

        self.data_to_write.insert(0, json.dumps(data).encode())

    def writable(self):
        return bool(self.data_to_write)

    def handle_write(self):
        """Write as much as possible of the most recent message we have received."""
        data = self.data_to_write.pop()
        sent = self.send(data[:self.chunk_size])
        if sent < len(data):
            remaining = data[sent:]
            self.data_to_write.append(remaining)
        if not self.writable():
            self.handle_close()

    def handle_close(self):
        self.close()

def get_device_status (device_name):
    try:
        # first check the device dict
        device = cfg.device_d[device_name]
    except KeyError:
        return {}

    return device.get_device_status()

def test_snmp (device_name):
    try:
        device = cfg.device_d[device_name]
    except KeyError:
        return {}

    return device.snmp_is_up(check=True, reload_cfg=True)

def test_ping (device_name):
    try:
        device = cfg.device_d[device_name]
    except KeyError:
        return {}

    return device.is_pingable()

def conditions (_type, min_severity, group):
    condition_l = []

    #
    # Add device codes
    if group:
        device_l = [x for x in cfg.devices().values() if group in x.group_d]
    else:
        device_l = cfg.devices().values()

    for device in device_l:
        for code,x in device.get_codes().items():
            if x['sev'] >= min_severity and (_type == x['type'] or not _type):
                msg = x['msg']
                if 'msg_details' in x:
                    msg += ": %s" % x['msg_details']

                condition = {
                    'device': device.name,
                    'type': x['type'],
                    'severity': x['sev'],
                    'message': msg,
                    'timestamp': x['timestamp'] * 1000
                    }
                # does it have a nugget?
                if 'nugget' in x:
                    condition['nugget'] = x['nugget']

                condition_l.append(condition)

    if _type == "nugget" or not _type:
        #
        # Add nugget-level conditions
        for device in device_l:
            for nugget_name, nugget_entry in device.nugget_d.items():
                thresh = nugget_entry.active_threshold
                #for thresh in nugget_entry.thresholds:
                if thresh and thresh.state == "on" and thresh.severity >= min_severity:
                    condition = {
                        'device': device.name,
                        'type': "nugget",
                        'nugget': nugget_name,
                        'severity': thresh.severity,
                        'message': thresh.msg,
                        'timestamp': thresh.timestamp * 1000
                        }
                    condition_l.append(condition)

    return condition_l

def top_devices (device_type, nugget_name, filter_re, group, n):
    """
    returns the devices with the top values for a particular Nugget. The rankings
    are based on the latest sample taken.

    device_type: device_type to rank
    nugget_name: name of the nugget we want to rank
    n: the number of devices to return
    """

    if filter_re:
        filter_re = re.compile(filter_re, re.IGNORECASE)

    devices_l = []
    for device in cfg.devices(dtype=device_type).values():
        # filter out devices that do not match
        if (filter_re and not filter_re.search(device.name) or
            group and group not in device.group_d):
            continue

        if nugget_name in device.nugget_d:
            val = device.nugget_d[nugget_name].prev_value
            timestamp = device.nugget_d[nugget_name].sample_timestamp
            interval = device.nugget_d[nugget_name].interval

            # it only counts if there was a values in the last sample interval
            if val != None and timestamp >= (int(time.time()) - interval):
                devices_l.append({
                        'name': device.name,
                        'val': round(val, 2)
                        })

    # sort the list by value
    devices_l = sorted(devices_l, key=lambda x: x['val'], reverse=True)

    # only return n entries
    if n:
        devices_l = devices_l[:n]

    # convert to dictionary
    devices_d = OrderedDict()
    for x in devices_l:
        devices_d[x['name']] = x['val']

    return devices_d

def get_latest_value (device_name, nugget_name):
    ret = {}
    try:
        # first check the device dict
        device = cfg.device_d[device_name]
    except KeyError:
        try:
            # next check the poller virtual devices
            device = cfg.poller.vdevice_d[device_name]
        except KeyError:
            return ret

    if nugget_name in device.nugget_d:
        value = device.nugget_d[nugget_name].prev_value
        if value is not None:
            ret['val'] = round(value, 2)
            ret['timestamp'] = device.nugget_d[nugget_name].prev_timestamp * 1000

    return ret

def get_series_buffer (device_name, nugget_name):
    ret = {}
    try:
        # first check the device dict
        device = cfg.device_d[device_name]
    except KeyError:
        try:
            # next check the poller virtual devices
            device = cfg.poller.vdevice_d[device_name]
        except KeyError:
            return ret

    if nugget_name in device.nugget_d:
        ret = device.nugget_d[nugget_name].buffer.get()

    return ret

def get_series_trace (device_name, nugget_name):
    ret = None
    try:
        # first check the device dict
        device = cfg.device_d[device_name]
    except KeyError:
        try:
            # next check the poller virtual devices
            device = cfg.poller.vdevice_d[device_name]
        except KeyError:
            return ret

    if nugget_name in device.nugget_d:
        ret = device.nugget_d[nugget_name].trace_record

    return ret

def get_event_status ():
    ret = {}
    for vdevice in cfg.poller.vdevice_d.values():
        ed = vdevice.event_detector
        if ed:
            if ed.state == "on" or ed.state == "starting":
                end_time = None
            else:
                end_time = ed.end_time * 1000

            ret[vdevice.group.name] = {
                'state': ed.state,
                'start_time': ed.start_time * 1000,
                'end_time': end_time,
                }

    return ret

def metric_presence (group=None):
    all_device_d = cfg.device_d.copy()
    all_device_d.update(cfg.poller.vdevice_d)

    if group:
        all_device_d = {x:y for x,y in all_device_d.items() if group in y.group_d}

    device_d = {}
    for device_name, device in all_device_d.items():
        for nugget_name, nugget_entry in device.nugget_d.items():
            if nugget_entry.store and isinstance(nugget_entry.prev_value, (int, float)):
                if device_name not in device_d:
                    device_d[device_name] = {
                        'type': device.type,
                        'nugget_l': [nugget_name]
                    }
                else:
                    device_d[device_name]['nugget_l'].append(nugget_name)

    return device_d

def client_list ():
    return [x.as_dict() for x in cfg.poller.client_mgr.client_d.values()]

def client_count ():
    client_d = cfg.poller.client_mgr.json_client_d()
    return {'total':len(client_d),
            'vc': len([x for x in client_d.values() if x['vc_data']]),
            'location': len([x for x in client_d.values() if x['location_data']]),
            }
